/* Qwen 聊天面板（加载于 app 页面）。 */
(function initQwenChatApp(global) {
  'use strict';

  const FAB_ID = 'qwen-chat-fab';
  const PANEL_ID = 'qwen-chat-panel';
  const STATUS_ID = 'qwen-chat-status';
  const MESSAGES_ID = 'qwen-chat-messages';
  const MESSAGES_SCROLL_ID = 'qwen-chat-messages-scroll';
  const LOGIN_HINT_ID = 'qwen-chat-login-hint';
  const INPUT_ID = 'qwen-chat-input';
  const SEND_ID = 'qwen-chat-send';
  const STOP_ID = 'qwen-chat-stop';
  const SCROLL_BOTTOM_ID = 'qwen-chat-scroll-bottom';
  const MODEL_ID = 'qwen-chat-model';
  const THINKING_ID = 'qwen-chat-thinking';

  let port = null;
  let historyNeedsInitialScroll = false;
  let activeBubble = null;
  let busy = false;
  let sessionChatId = '';
  let sessionParentId = '';
  let nextReplyFresh = false;
  let inThinking = false;
  let lastSendText = '';
  let pendingEditParentId = '';
  let pendingEdit = false;
  let chatStateLoaded = false;
  let lastKnownLoggedIn = false;
  let lastKnownEnabled = true;
  let openingStarted = false;
  let openingCompleted = false;
  let autoScrollEnabled = true;
  let lastMessagesScrollTop = 0;
  let historyLoadPromise = null;
  let historyReloadAfterLogin = false;

  function el(id) {
    return document.getElementById(id);
  }

  function escapeHtmlQwen(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[c]));
  }

  function safeUrlQwen(href, allowed) {
    try {
      const url = new URL(href, global.location?.href);
      return allowed.has(url.protocol) ? url.href : '';
    } catch {
      return '';
    }
  }

  let qwenMarkdownParser = null;
  function getQwenMarkdownParser() {
    if (qwenMarkdownParser) return qwenMarkdownParser;
    const markedApi = global.marked;
    if (!markedApi?.Marked || !markedApi?.Renderer) return null;
    const renderer = new markedApi.Renderer();
    renderer.html = ({ text }) => {
      const value = String(text || '').trim();
      if (/^<br\s*\/?\s*>$/i.test(value)) return '<br>';
      return escapeHtmlQwen(text);
    };
    renderer.link = function renderSafeLink({ href, title, tokens }) {
      const text = this.parser.parseInline(tokens || []);
      const safeHref = safeUrlQwen(href, new Set(['http:', 'https:', 'mailto:']));
      if (!safeHref) return text;
      const titleAttribute = title ? ` title="${escapeHtmlQwen(title)}"` : '';
      return `<a href="${escapeHtmlQwen(safeHref)}"${titleAttribute} target="_blank" rel="noopener noreferrer">${text}</a>`;
    };
    renderer.image = ({ href, title, text }) => {
      const safeSrc = safeUrlQwen(href, new Set(['http:', 'https:']));
      if (!safeSrc) return escapeHtmlQwen(String(text || ''));
      const titleAttribute = title ? ` title="${escapeHtmlQwen(title)}"` : '';
      return `<img src="${escapeHtmlQwen(safeSrc)}" alt="${escapeHtmlQwen(String(text || ''))}"${titleAttribute} loading="lazy">`;
    };
    renderer.codespan = ({ text }) => `<code class="qwen-md-inline-code">${escapeHtmlQwen(text)}</code>`;
    renderer.code = ({ text, lang }) => {
      const language = String(lang || '').trim().split(/\s+/)[0];
      if (language === 'res') {
        const jsonText = String(text || '').trim();
        return `<div class="qwen-chat-op qwen-inline-res"><div class="qwen-chat-op-name">操作结果</div><div class="qwen-chat-op-result">${escapeHtmlQwen(jsonText)}</div></div>`;
      }
      const languageAttribute = language ? ` data-language="${escapeHtmlQwen(language)}"` : '';
      return `<pre class="qwen-md-codeblock"${languageAttribute}><code>${escapeHtmlQwen(String(text || ''))}</code></pre>`;
    };
    renderer.blockquote = function renderBlockquote({ tokens }) {
      return `<blockquote class="qwen-md-blockquote">${this.parser.parse(tokens || [])}</blockquote>`;
    };
    qwenMarkdownParser = new markedApi.Marked({
      gfm: true,
      breaks: true,
      pedantic: false,
      renderer
    });
    return qwenMarkdownParser;
  }

  function renderQwenMarkdown(text) {
    const source = String(text || '').replace(/\r\n?/g, '\n');
    if (!source) return '';
    const parser = getQwenMarkdownParser();
    if (!parser) return escapeHtmlQwen(source);
    try {
      return parser.parse(source, { async: false });
    } catch {
      return escapeHtmlQwen(source);
    }
  }

  function mdContainer(bubble) {
    let container = bubble.querySelector(':scope > .qwen-chat-md');
    if (!(container instanceof HTMLElement)) {
      container = document.createElement('div');
      container.className = 'qwen-chat-md';
      container._mdText = '';
      bubble.appendChild(container);
    }
    return container;
  }

  function mdRawText(bubble) {
    if (!(bubble instanceof HTMLElement)) return '';
    const container = bubble.querySelector(':scope > .qwen-chat-md');
    return container?._mdText || '';
  }

  async function copyQwenText(text, button) {
    const value = String(text || '');
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = value;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }
    if (button instanceof HTMLButtonElement) {
      const previous = button.textContent;
      button.textContent = '已复制';
      setTimeout(() => { button.textContent = previous; }, 900);
    }
  }

  function createCopyButton(getText, className = 'qwen-chat-copy-btn') {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = '复制';
    button.title = '复制 Markdown 原文';
    button.addEventListener('click', () => void copyQwenText(getText?.(), button));
    return button;
  }

  function enhanceOperationCopyButtons(container) {
    if (!(container instanceof HTMLElement)) return;
    container.querySelectorAll('.qwen-chat-op').forEach((card) => {
      const name = card.querySelector(':scope > .qwen-chat-op-name');
      if (!(name instanceof HTMLElement) || name.querySelector('.qwen-chat-copy-btn')) return;
      name.appendChild(createCopyButton(() => card.querySelector(':scope > .qwen-chat-op-result')?.textContent || ''));
    });
  }

  function extractUserQuestion(content) {
    const source = String(content || '');
    const marker = '用户问题：';
    const index = source.lastIndexOf(marker);
    return index >= 0 ? source.slice(index + marker.length).trim() : source;
  }

  function extractAssistantReply(message) {
    const list = Array.isArray(message?.content_list) ? message.content_list : [];
    const parts = [];
    for (const item of list) {
      if (item?.phase === 'answer' && item?.content) parts.push(String(item.content));
    }
    if (parts.length) return parts.join('\n');
    return String(message?.content || '');
  }

  function extractResJson(text) {
    const match = /^```res\s*([\s\S]*?)```\s*$/.exec(String(text || '').trim());
    return match ? String(match[1] || '').trim() : String(text || '');
  }

  function resBlocksFromText(text) {
    const blocks = [];
    const regex = /```res\s*([\s\S]*?)```/g;
    const source = String(text || '');
    let match;
    while ((match = regex.exec(source))) blocks.push(match[0]);
    return blocks;
  }

  function appendResCard(text) {
    const messages = el(MESSAGES_ID);
    if (!(messages instanceof HTMLElement)) return;
    const card = document.createElement('div');
    card.className = 'qwen-chat-op';
    const name = document.createElement('div');
    name.className = 'qwen-chat-op-name';
    const nameText = document.createElement('span');
    nameText.textContent = '操作结果';
    const content = document.createElement('div');
    content.className = 'qwen-chat-op-result';
    content.textContent = extractResJson(text);
    name.append(nameText, createCopyButton(() => content.textContent || ''));
    card.append(name, content);
    messages.appendChild(card);
    maybeAutoScrollMessages(messages);
  }

  function renderHistory(messages) {
    const messagesEl = el(MESSAGES_ID);
    if (!(messagesEl instanceof HTMLElement)) return;
    messagesEl.replaceChildren();
    const list = Array.isArray(messages) ? messages : [];
    let lastAssistantResponseId = '';
    for (const message of list) {
      const role = String(message?.role || '');
      if (role === 'user') {
        const content = String(message?.content || '');
        if (content.includes('你是「BJTU 课程助手」的智能代理')) continue;
        const blocks = resBlocksFromText(content);
        if (blocks.length) {
          for (const block of blocks) appendResCard(block);
        } else {
          appendMessage('user', extractUserQuestion(content), String(message?.parentId || message?.parent_id || lastAssistantResponseId));
        }
      } else if (role === 'assistant') {
        const text = extractAssistantReply(message);
        appendMessage('assistant', text || '（无回复）');
        lastAssistantResponseId = String(message?.response_id || message?.id || lastAssistantResponseId);
      }
    }
    sessionParentId = lastAssistantResponseId;
    scrollMessagesToBottom(messagesEl, { force: true });
  }

  // 历史记录渲染完成后滚动到最后一条消息（Markdown 可能异步渲染，多拍几次确保到位）
  function getMessagesScrollContainer(container) {
    const scroller = el(MESSAGES_SCROLL_ID);
    if (scroller instanceof HTMLElement) return scroller;
    return container instanceof HTMLElement ? container : null;
  }

  function isMessagesAtBottom(container) {
    container = getMessagesScrollContainer(container);
    return container instanceof HTMLElement
      && container.scrollHeight - container.scrollTop - container.clientHeight <= 3;
  }

  function updateScrollBottomButton(container) {
    container = getMessagesScrollContainer(container);
    const button = el(SCROLL_BOTTOM_ID);
    if (button instanceof HTMLButtonElement) button.hidden = autoScrollEnabled || isMessagesAtBottom(container);
  }

  function scrollMessagesToBottom(container, { force = false, settle = true } = {}) {
    container = getMessagesScrollContainer(container);
    if (!(container instanceof HTMLElement)) return;
    if (!force && !autoScrollEnabled) {
      updateScrollBottomButton(container);
      return;
    }
    if (force) autoScrollEnabled = true;
    const scroll = () => {
      if (!autoScrollEnabled) return;
      container.scrollTop = container.scrollHeight;
      lastMessagesScrollTop = container.scrollTop;
      updateScrollBottomButton(container);
    };
    scroll();
    if (settle) {
      requestAnimationFrame(scroll);
      setTimeout(scroll, 60);
      setTimeout(scroll, 180);
    }
  }

  function maybeAutoScrollMessages(container) {
    scrollMessagesToBottom(container, { settle: false });
  }

  const HISTORY_LOADING_ID = 'qwen-chat-history-loading';

  async function loadHistoryOnce() {
    if (!sessionChatId) return;
    const loadingEl = el(HISTORY_LOADING_ID);
    if (loadingEl instanceof HTMLElement) loadingEl.hidden = false;
    try {
      const response = await send('QWEN_GET_CHAT_HISTORY', { chatId: sessionChatId });
      if (response?.ok && Array.isArray(response.messages)) {
        historyNeedsInitialScroll = true;
        renderHistory(response.messages);
      } else if (response?.code === 'CHAT_NOT_FOUND') {
        // 原会话已被用户删除：清空会话并重新触发开场，
        // 由 maybeSendOpening/sendOpening 自动新建会话并发送系统提示词。
        sessionChatId = '';
        sessionParentId = '';
        nextReplyFresh = false;
        pendingEditParentId = '';
        pendingEdit = false;
        openingStarted = false;
        openingCompleted = false;
        void chrome.storage.local.remove(['qwenLastChatId', 'qwenOpeningPendingChatId']).catch(() => { });
      }
    } finally {
      if (loadingEl instanceof HTMLElement) loadingEl.hidden = true;
      const messagesEl = el(MESSAGES_ID);
      scrollMessagesToBottom(messagesEl, { force: true });
      if (messagesEl instanceof HTMLElement && messagesEl.clientHeight > 0) historyNeedsInitialScroll = false;
    }
  }

  function loadHistory() {
    if (!sessionChatId) return Promise.resolve();
    if (historyLoadPromise) return historyLoadPromise;
    historyLoadPromise = loadHistoryOnce().finally(() => {
      historyLoadPromise = null;
    });
    return historyLoadPromise;
  }

  function restoreHistoryAfterLogin() {
    if (!chatStateLoaded || !historyReloadAfterLogin) return Promise.resolve();
    historyReloadAfterLogin = false;
    return (sessionChatId ? loadHistory() : Promise.resolve()).finally(() => {
      maybeSendOpening();
    });
  }

  function send(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (response) => {
        const error = chrome?.runtime?.lastError;
        resolve(error ? { ok: false, message: String(error.message || '通信失败') } : (response || {}));
      });
    });
  }

  const JS_SANDBOX_CHANNEL = 'bjtu-qwen-js-sandbox';
  let jsSandboxFramePromise = null;

  function ensureJsSandboxFrame() {
    if (jsSandboxFramePromise) return jsSandboxFramePromise;
    jsSandboxFramePromise = new Promise((resolve, reject) => {
      const frame = document.createElement('iframe');
      frame.hidden = true;
      frame.setAttribute('aria-hidden', 'true');
      frame.src = chrome.runtime.getURL('core/sandbox/js-executor.html');
      const timer = setTimeout(() => {
        frame.remove();
        jsSandboxFramePromise = null;
        reject(new Error('JavaScript 沙箱加载超时'));
      }, 10000);
      frame.addEventListener('load', () => {
        clearTimeout(timer);
        resolve(frame);
      }, { once: true });
      frame.addEventListener('error', () => {
        clearTimeout(timer);
        frame.remove();
        jsSandboxFramePromise = null;
        reject(new Error('JavaScript 沙箱加载失败'));
      }, { once: true });
      document.body.appendChild(frame);
    });
    return jsSandboxFramePromise;
  }

  function jsBridgePathParts(path) {
    const parts = String(path || '').split('.').map((part) => part.trim()).filter(Boolean);
    if (!parts.length) throw new Error('桥接路径为空');
    if (parts.some((part) => ['__proto__', 'prototype', 'constructor'].includes(part))) {
      throw new Error('桥接路径包含不允许访问的属性');
    }
    if (['window', 'globalThis', 'self'].includes(parts[0])) parts.shift();
    if (!parts.length) throw new Error('不能直接访问整个页面全局对象');
    return parts;
  }

  function resolveJsBridgePath(root, path) {
    const parts = jsBridgePathParts(path);
    let owner = root;
    for (let i = 0; i < parts.length - 1; i += 1) {
      owner = owner?.[parts[i]];
      if (owner == null) throw new Error(`桥接路径不存在：${parts.slice(0, i + 1).join('.')}`);
    }
    const key = parts.at(-1);
    return { owner, key, value: owner?.[key] };
  }

  function jsBridgeSerializable(value, seen = new WeakSet(), depth = 0) {
    if (value === undefined) return { __type: 'undefined' };
    if (typeof value === 'bigint') return `${value}n`;
    if (typeof value === 'function') return `[Function ${value.name || 'anonymous'}]`;
    if (typeof value === 'symbol') return String(value);
    if (value === null || typeof value !== 'object') return value;
    if (value instanceof Error) return { name: value.name, message: value.message, stack: value.stack || '' };
    if (value instanceof Element) {
      return {
        tagName: value.tagName.toLowerCase(),
        id: value.id || '',
        className: typeof value.className === 'string' ? value.className : '',
        textContent: String(value.textContent || '').slice(0, 10000),
        attributes: Object.fromEntries(Array.from(value.attributes || []).map((item) => [item.name, item.value]))
      };
    }
    if (depth > 8) return '[深度受限]';
    if (seen.has(value)) return '[循环引用]';
    seen.add(value);
    if (Array.isArray(value)) return value.map((item) => jsBridgeSerializable(item, seen, depth + 1));
    const output = {};
    for (const key of Object.keys(value)) {
      try { output[key] = jsBridgeSerializable(value[key], seen, depth + 1); } catch (error) {
        output[key] = `[读取失败：${String(error?.message || error)}]`;
      }
    }
    return output;
  }

  function requireJsBridgeElement(selector) {
    const element = document.querySelector(String(selector || ''));
    if (!(element instanceof Element)) throw new Error(`未找到元素：${String(selector || '')}`);
    return element;
  }

  async function handleAppJsBridge(action, payload) {
    if (action === 'dom.query') return jsBridgeSerializable(document.querySelector(String(payload?.selector || '')));
    if (action === 'dom.queryAll') {
      return jsBridgeSerializable(Array.from(document.querySelectorAll(String(payload?.selector || ''))));
    }
    if (action.startsWith('dom.')) {
      const element = requireJsBridgeElement(payload?.selector);
      if (action === 'dom.get') return jsBridgeSerializable(resolveJsBridgePath(element, payload?.property).value);
      if (action === 'dom.set') {
        const target = resolveJsBridgePath(element, payload?.property);
        target.owner[target.key] = payload?.value;
        return true;
      }
      if (action === 'dom.call') {
        const target = resolveJsBridgePath(element, payload?.method);
        if (typeof target.value !== 'function') throw new Error(`DOM 方法不存在：${String(payload?.method || '')}`);
        return jsBridgeSerializable(await target.value.apply(target.owner, Array.isArray(payload?.args) ? payload.args : []));
      }
    }
    const target = resolveJsBridgePath(global, payload?.path);
    if (action === 'get') return jsBridgeSerializable(target.value);
    if (action === 'set') {
      target.owner[target.key] = payload?.value;
      return true;
    }
    if (action === 'call') {
      if (typeof target.value !== 'function') throw new Error(`页面方法不存在：${String(payload?.path || '')}`);
      return jsBridgeSerializable(await target.value.apply(target.owner, Array.isArray(payload?.args) ? payload.args : []));
    }
    throw new Error(`未知 app 桥接操作：${String(action || '')}`);
  }

  async function handleJsBridge(mode, action, payload) {
    if (mode === 'app') return handleAppJsBridge(action, payload);
    if (mode === 'background') {
      const response = await send('QWEN_JS_BACKGROUND_BRIDGE', { action, payload });
      if (!response?.ok) throw new Error(String(response?.message || '后台桥接调用失败'));
      return response.value;
    }
    throw new Error('sandbox 模式不能调用上下文桥接');
  }

  async function executeJsInSandbox(code, mode = 'sandbox') {
    const frame = await ensureJsSandboxFrame();
    const id = `js-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        global.removeEventListener('message', onMessage);
        reject(new Error('JavaScript 执行超时'));
      }, 30000);
      const onMessage = (event) => {
        const data = event?.data;
        if (event.source !== frame.contentWindow || data?.channel !== JS_SANDBOX_CHANNEL) return;
        if (data?.type === 'bridge-call' && String(data.executionId || '') === id) {
          void handleJsBridge(mode, String(data.action || ''), data.payload).then((result) => {
            frame.contentWindow?.postMessage({
              channel: JS_SANDBOX_CHANNEL,
              type: 'bridge-result',
              requestId: String(data.requestId || ''),
              ok: true,
              result: jsBridgeSerializable(result)
            }, '*');
          }).catch((error) => {
            frame.contentWindow?.postMessage({
              channel: JS_SANDBOX_CHANNEL,
              type: 'bridge-result',
              requestId: String(data.requestId || ''),
              ok: false,
              error: String(error?.message || error)
            }, '*');
          });
          return;
        }
        if (data?.type !== 'result' || String(data.id || '') !== id) return;
        clearTimeout(timer);
        global.removeEventListener('message', onMessage);
        if (data.ok === true) resolve(data.result);
        else reject(new Error(String(data.error || 'JavaScript 执行失败')));
      };
      global.addEventListener('message', onMessage);
      frame.contentWindow?.postMessage({
        channel: JS_SANDBOX_CHANNEL,
        type: 'execute',
        id,
        code: String(code || ''),
        mode: String(mode || 'sandbox')
      }, '*');
    });
  }

  function setStatus(text, state = '') {
    const statusEl = el(STATUS_ID);
    if (statusEl instanceof HTMLElement) {
      statusEl.textContent = text;
      statusEl.className = `qwen-chat-status ${state}`;
    }
  }

  function renderOperationsPopover(groups, enabledOperations) {
    const list = document.querySelector('#qwen-chat-ops-popover [data-operation-list]');
    if (!(list instanceof HTMLElement)) return;
    if (global.BjtuQwenOperationsUi) {
      BjtuQwenOperationsUi.render(list, groups, enabledOperations, !Array.isArray(enabledOperations));
      return;
    }
    list.replaceChildren();
    const enabledSet = new Set(Array.isArray(enabledOperations) ? enabledOperations : []);
    const allSelected = !Array.isArray(enabledOperations);
    for (const group of groups || []) {
      const names = group.operations || [];
      if (!names.length) continue;
      const title = document.createElement('div');
      title.className = 'qwen-chat-ops-group-title';
      title.textContent = String(group.label || '');
      list.appendChild(title);
      for (const entry of names) {
        const name = String(entry?.name ?? entry ?? '');
        const isMeta = name.startsWith('qwen.');
        const item = document.createElement('label');
        item.className = 'qwen-chat-ops-item';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.dataset.operationName = name;
        checkbox.checked = isMeta || allSelected || enabledSet.has(name) || enabledSet.size === 0;
        checkbox.disabled = isMeta;
        const code = document.createElement('code');
        code.textContent = name;
        item.append(checkbox, code);
        list.appendChild(item);
      }
    }
    if (list.childElementCount === 0) {
      const empty = document.createElement('div');
      empty.className = 'qwen-chat-ops-empty';
      empty.textContent = '暂无可调用的操作';
      list.appendChild(empty);
    }
  }

  function initOperationsPopover() {
    const wrap = document.querySelector('.qwen-chat-ops-toggle-wrap');
    const popover = el('qwen-chat-ops-popover');
    if (!(wrap instanceof HTMLElement) || !(popover instanceof HTMLElement)) return;
    const toggle = el('qwen-chat-ops-toggle');
    if (popover.parentElement !== document.body) {
      document.body.appendChild(popover);
    }
    let loaded = false;
    let closeTimer = null;
    const clearCloseTimer = () => {
      if (closeTimer) {
        clearTimeout(closeTimer);
        closeTimer = null;
      }
    };
    const positionPopover = () => {
      if (popover.hidden) return;
      const btnRect = toggle.getBoundingClientRect();
      const vw = window.innerWidth || document.documentElement.clientWidth || 0;
      const vh = window.innerHeight || document.documentElement.clientHeight || 0;
      popover.style.visibility = 'hidden';
      popover.style.top = 'auto';
      popover.style.left = 'auto';
      popover.style.right = '0px';
      popover.style.bottom = '0px';
      const pw = popover.offsetWidth || 300;
      const ph = popover.offsetHeight || 0;
      const right = pw > vw ? 0 : Math.max(0, vw - btnRect.right);
      popover.style.right = `${right}px`;
      if (ph <= btnRect.top) {
        popover.style.bottom = `${vh - btnRect.top}px`;
        popover.style.top = 'auto';
      } else {
        popover.style.top = `${btnRect.bottom}px`;
        popover.style.bottom = 'auto';
      }
      popover.style.visibility = '';
    };
    const open = () => {
      clearCloseTimer();
      popover.hidden = false;
      positionPopover();
      if (loaded) return;
      loaded = true;
      const opsUi = global.BjtuQwenOperationsUi;
      const load = opsUi?.mounted
        ? Promise.resolve(opsUi.mounted).then(() => send('QWEN_LIST_OPERATIONS'))
        : send('QWEN_LIST_OPERATIONS');
      void load.then((response) => {
        if (response?.ok === true) {
          renderOperationsPopover(response.groups, response.enabledOperations);
        } else {
          const l = document.querySelector('#qwen-chat-ops-popover [data-operation-list]');
          if (l instanceof HTMLElement) {
            l.replaceChildren();
            const empty = document.createElement('div');
            empty.className = 'qwen-operation-loading';
            empty.textContent = String(response?.message || '操作加载失败');
            l.appendChild(empty);
          }
        }
        positionPopover();
      });
    };
    const close = () => {
      clearCloseTimer();
      popover.hidden = true;
    };
    const scheduleClose = () => {
      clearCloseTimer();
      closeTimer = setTimeout(close, 140);
    };
    wrap.addEventListener('mouseenter', open);
    wrap.addEventListener('mouseleave', scheduleClose);
    popover.addEventListener('mouseenter', clearCloseTimer);
    popover.addEventListener('mouseleave', scheduleClose);
    if (toggle instanceof HTMLButtonElement) {
      toggle.addEventListener('click', () => {
        if (popover.hidden) open();
        else close();
      });
    }
    window.addEventListener('resize', () => positionPopover());
  }

  function setBusy(value) {
    busy = value === true;
    const sendBtn = el(SEND_ID);
    const input = el(INPUT_ID);
    const stopBtn = el(STOP_ID);
    if (sendBtn instanceof HTMLButtonElement) sendBtn.hidden = busy;
    if (stopBtn instanceof HTMLButtonElement) stopBtn.hidden = !busy;
    const messages = el(MESSAGES_ID);
    if (messages instanceof HTMLElement) messages.classList.toggle('qwen-chat-generating', busy);
  }

  function appendMessage(role, text, parentId) {
    const messages = el(MESSAGES_ID);
    if (!(messages instanceof HTMLElement)) return;
    const str = String(text || '');
    let bubble;
    let anchor;
    if (role === 'user') {
      const row = document.createElement('div');
      row.className = 'qwen-chat-msg-row user';
      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.className = 'qwen-chat-edit-btn';
      editBtn.textContent = '编辑';
      editBtn.title = '编辑此消息（发送时将以此消息为基准续接）';
      editBtn.addEventListener('click', () => {
        pendingEditParentId = String(parentId || '');
        pendingEdit = true;
        const container = row.parentElement;
        if (container instanceof HTMLElement) {
          while (row.nextSibling) row.nextSibling.remove();
          row.remove();
        }
        const input = el(INPUT_ID);
        if (input instanceof HTMLTextAreaElement) {
          input.value = str;
          const panel = el(PANEL_ID);
          if (panel instanceof HTMLElement) panel.hidden = false;
          const fab = el(FAB_ID);
          if (fab instanceof HTMLElement) fab.style.display = 'none';
          input.focus();
        }
      });
      row.appendChild(editBtn);
      bubble = document.createElement('div');
      bubble.className = 'qwen-chat-msg user';
      row.appendChild(bubble);
      anchor = row;
    } else if (role === 'assistant') {
      const row = document.createElement('div');
      row.className = 'qwen-chat-msg-row assistant';
      bubble = document.createElement('div');
      bubble.className = 'qwen-chat-msg assistant';
      row.append(bubble, createCopyButton(() => mdRawText(bubble), 'qwen-chat-copy-btn qwen-chat-assistant-copy-btn'));
      anchor = row;
    } else {
      bubble = document.createElement('div');
      bubble.className = `qwen-chat-msg ${role}`;
      anchor = bubble;
    }
    if (role === 'error') {
      bubble.textContent = str;
    } else {
      const container = mdContainer(bubble);
      container._mdText = str;
      container.innerHTML = renderQwenMarkdown(str);
      enhanceOperationCopyButtons(container);
    }
    messages.appendChild(anchor);
    maybeAutoScrollMessages(messages);
    return bubble;
  }

  function removeMessageBubble(bubble) {
    if (!(bubble instanceof HTMLElement)) return;
    const row = bubble.closest('.qwen-chat-msg-row.assistant');
    if (row instanceof HTMLElement) row.remove();
    else bubble.remove();
  }

  function cursorHost(bubble) {
    if (!(bubble instanceof HTMLElement)) return bubble;
    const md = bubble.querySelector(':scope > .qwen-chat-md');
    const container = md instanceof HTMLElement ? md : bubble;
    let host = container;
    const last = container.lastElementChild;
    if (last instanceof HTMLElement) {
      if (last.matches('ul, ol, table')) {
        host = last.lastElementChild instanceof HTMLElement ? last.lastElementChild : last;
      } else {
        host = last;
      }
      const code = host.querySelector(':scope > code, :scope > .qwen-md-inline-code');
      if (code instanceof HTMLElement) host = code;
    }
    return host;
  }

  function ensureCursor(bubble) {
    if (!(bubble instanceof HTMLElement)) return;
    const host = cursorHost(bubble);
    if (!host.querySelector(':scope > .qwen-chat-cursor')) {
      const cursor = document.createElement('span');
      cursor.className = 'qwen-chat-cursor';
      let insertionPoint = null;
      let tail = host.lastChild;
      while (tail) {
        if (tail instanceof HTMLBRElement) {
          insertionPoint = tail;
          tail = tail.previousSibling;
          continue;
        }
        if (tail.nodeType === Node.TEXT_NODE) {
          const trailingNewlines = /[\r\n]+$/.exec(tail.data || '');
          if (!trailingNewlines) break;
          const splitAt = trailingNewlines.index;
          if (splitAt > 0) {
            insertionPoint = tail.splitText(splitAt);
            break;
          }
          insertionPoint = tail;
          tail = tail.previousSibling;
          continue;
        }
        break;
      }
      if (insertionPoint) host.insertBefore(cursor, insertionPoint);
      else host.appendChild(cursor);
    }
  }

  function removeCursor(bubble) {
    if (!(bubble instanceof HTMLElement)) return;
    bubble.querySelectorAll('.qwen-chat-cursor').forEach((node) => node.remove());
  }

  function collapseThinking(bubble) {
    if (!(bubble instanceof HTMLElement)) return;
    const details = bubble.querySelector(':scope > .qwen-chat-thinking');
    if (details instanceof HTMLDetailsElement) details.open = false;
  }

  function placeCursor(bubble, inThinkingFlag) {
    if (!(bubble instanceof HTMLElement)) return;
    removeCursor(bubble);
    if (inThinkingFlag) {
      const details = bubble.querySelector(':scope > .qwen-chat-thinking');
      const body = details instanceof HTMLElement ? details.querySelector('.qwen-chat-thinking-body') : null;
      if (body instanceof HTMLElement) {
        ensureCursor(body);
      } else {
        ensureCursor(bubble);
      }
    } else {
      ensureCursor(bubble);
    }
  }

  function appendOperationCard(operation) {
    const messages = el(MESSAGES_ID);
    if (!(messages instanceof HTMLElement)) return;
    const card = document.createElement('div');
    card.className = 'qwen-chat-op';
    const name = document.createElement('div');
    name.className = 'qwen-chat-op-name';
    const nameText = document.createElement('span');
    nameText.textContent = '操作结果';
    name.append(nameText, createCopyButton(() => card.querySelector(':scope > .qwen-chat-op-result')?.textContent || ''));
    card.append(name);
    messages.appendChild(card);
    maybeAutoScrollMessages(messages);
    return card;
  }

  function formatResult(value, depth = 0) {
    if (value === null || value === undefined) return 'null';
    const type = typeof value;
    if (type === 'string') {
      const text = String(value);
      if (depth === 0) return text;
      return /[\r\n]/.test(text) ? `"""${text}"""` : `"${text}"`;
    }
    if (type === 'number' || type === 'boolean') return String(value);
    const indent = '  '.repeat(depth);
    const childIndent = '  '.repeat(depth + 1);
    if (Array.isArray(value)) {
      if (!value.length) return '[]';
      const items = value.map((item) => `${childIndent}${formatResult(item, depth + 1)}`);
      return `[\n${items.join(',\n')}\n${indent}]`;
    }
    const keys = Object.keys(value).filter((key) => key !== 'ok');
    if (!keys.length) return '{}';
    const entries = keys.map((key) => {
      const keyText = /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key)
        ? key
        : formatResult(key, depth + 1);
      return `${childIndent}${keyText}: ${formatResult(value[key], depth + 1)}`;
    });
    return `{\n${entries.join(',\n')}\n${indent}}`;
  }

  function formatOutcomeText(outcome) {
    if (outcome && typeof outcome === 'object' && typeof outcome.ok === 'boolean') {
      if (outcome.ok) return formatResult(outcome.result);
      const parts = [];
      if (outcome.code) parts.push(`错误代码：${outcome.code}`);
      parts.push(String(outcome.error || '操作失败'));
      return parts.join('\n');
    }
    return formatResult(outcome);
  }

  function updateOperationResult(card, result) {
    if (!(card instanceof HTMLElement)) return;
    const existing = card.querySelector(':scope > .qwen-chat-op-result');
    if (existing instanceof HTMLElement) existing.remove();
    const content = document.createElement('div');
    content.className = 'qwen-chat-op-result';
    content.textContent = formatOutcomeText(result);
    card.appendChild(content);
    const messages = el(MESSAGES_ID);
    maybeAutoScrollMessages(messages);
  }

  function showLoginHint(show) {
    const hint = el(LOGIN_HINT_ID);
    if (hint instanceof HTMLElement) hint.hidden = !show;
  }

  async function refreshModels() {
    const select = el(MODEL_ID);
    if (!(select instanceof HTMLSelectElement)) return;
    const status = await send('QWEN_GET_STATUS', { ensureLogin: false });
    const response = await send('QWEN_LIST_MODELS');
    select.replaceChildren();
    if (response?.ok && Array.isArray(response.models) && response.models.length) {
      for (const model of response.models) {
        const option = document.createElement('option');
        option.value = model.id;
        option.textContent = model.name;
        select.appendChild(option);
      }
      const current = String(status?.modelId || '') || String(response.models[0]?.id || '');
      if (current) select.value = current;
      select.disabled = false;
    } else {
      const option = document.createElement('option');
      option.value = '';
      option.textContent = response?.ok ? '无可用模型' : '模型加载失败';
      select.appendChild(option);
      select.disabled = true;
    }
  }

  async function refreshStatus({ openLoginIfNeeded = false } = {}) {
    const status = await send('QWEN_GET_STATUS', { ensureLogin: false });
    lastKnownLoggedIn = status?.loggedIn === true;
    lastKnownEnabled = status?.enabled !== false;
    if (status?.loggedIn) {
      setStatus('已登录', 'ok');
      showLoginHint(false);
    } else {
      setStatus('未登录', 'error');
      showLoginHint(true);
      const panel = el(PANEL_ID);
      if (openLoginIfNeeded && panel instanceof HTMLElement && !panel.hidden) {
        void send('QWEN_OPEN_LOGIN', { auth: true });
      }
    }
    const thinking = el(THINKING_ID);
    if (thinking instanceof HTMLInputElement) thinking.checked = status?.thinkingEnabled === true;
    maybeSendOpening();
    return status;
  }

  function ensureAssistantBubble() {
    const messages = el(MESSAGES_ID);
    if (!activeBubble && messages instanceof HTMLElement) {
      activeBubble = appendMessage('assistant', '');
    }
    return activeBubble;
  }

  function appendAssistantText(bubble, text) {
    if (!text) return;
    const container = mdContainer(bubble);
    container._mdText = String(container._mdText || '') + String(text);
    container.innerHTML = renderQwenMarkdown(container._mdText);
    enhanceOperationCopyButtons(container);
  }

  function ensureThinkingBlock(bubble) {
    let details = bubble.querySelector(':scope > .qwen-chat-thinking');
    if (!(details instanceof HTMLElement)) {
      details = document.createElement('details');
      details.className = 'qwen-chat-thinking';
      const summary = document.createElement('summary');
      summary.textContent = '思考过程';
      const body = document.createElement('div');
      body.className = 'qwen-chat-thinking-body';
      details.append(summary, body);
    }
    if (bubble.firstElementChild !== details) bubble.prepend(details);
    return details.querySelector('.qwen-chat-thinking-body');
  }

  let pendingAskId = null;
  let pendingAskMode = '';

  function updateAskContinueLabel() {
    const count = el('qwen-chat-ask-count');
    const button = el('qwen-chat-ask-continue');
    if (button instanceof HTMLButtonElement) {
      if (pendingAskMode === 'operation-permission') {
        button.textContent = '允许一次';
        return;
      }
      const value = count instanceof HTMLInputElement ? parseInt(count.value, 10) : 0;
      button.textContent = `继续 ${value > 0 ? value : 1} 次`;
    }
  }

  function showAsk(message) {
    pendingAskId = String(message?.id || '');
    pendingAskMode = String(message?.mode || '');
    const container = el('qwen-chat-ask');
    const text = el('qwen-chat-ask-text');
    const count = el('qwen-chat-ask-count');
    const always = el('qwen-chat-ask-always');
    const stop = el('qwen-chat-ask-stop');
    if (container instanceof HTMLElement) {
      if (text instanceof HTMLElement) text.textContent = message?.message || '操作调用次数过多，是否继续？';
      const value = Number(message?.count) > 0 ? Number(message.count) : 3;
      if (count instanceof HTMLInputElement) {
        count.value = String(value);
        count.hidden = pendingAskMode === 'operation-permission';
      }
      if (always instanceof HTMLButtonElement) always.textContent = '始终允许';
      if (stop instanceof HTMLButtonElement) stop.textContent = pendingAskMode === 'operation-permission' ? '拒绝' : '结束本次';
      updateAskContinueLabel();
      container.hidden = false;
    }
  }

  function hideAsk() {
    const container = el('qwen-chat-ask');
    if (container instanceof HTMLElement) container.hidden = true;
    pendingAskId = null;
    pendingAskMode = '';
  }

  function resolveAsk(action) {
    const container = el('qwen-chat-ask');
    if (container instanceof HTMLElement) container.hidden = true;
    if (!pendingAskId) return;
    const id = pendingAskId;
    pendingAskId = null;
    pendingAskMode = '';
    const countEl = el('qwen-chat-ask-count');
    const count = countEl instanceof HTMLInputElement ? parseInt(countEl.value, 10) : 0;
    try {
      port?.postMessage({ type: 'askResponse', id, action, count: count > 0 ? count : 1 });
    } catch {
      // 端口可能已断开
    }
  }

  function startStream({ text, editParent = '', isEditSend = false, showUserBubble = true }) {
    lastSendText = text;
    if (showUserBubble) {
      appendMessage('user', text, editParent || sessionParentId);
      const input = el(INPUT_ID);
      if (input instanceof HTMLTextAreaElement) input.value = '';
    }
    hideAsk();
    setBusy(true);
    setStatus('思考中…');
    inThinking = false;
    activeBubble = ensureAssistantBubble();
    placeCursor(activeBubble, false);
    scrollMessagesToBottom(el(MESSAGES_ID), { force: true });
    const lastOperationCard = { card: null };
    let retryPrompt = null;

    const connectPort = () => {
      const chatPort = chrome.runtime.connect({ name: 'bjtu-qwen-chat' });
      port = chatPort;
      chatPort.onMessage.addListener((message) => {
        if (message?.type === 'delta') {
          setStatus('回复中…');
          const bubble = ensureAssistantBubble();
          if (bubble) appendAssistantText(bubble, message.text);
          if (inThinking) {
            collapseThinking(bubble);
            inThinking = false;
          }
          placeCursor(bubble, false);
          const messages = el(MESSAGES_ID);
          maybeAutoScrollMessages(messages);
        } else if (message?.type === 'thinking') {
          setStatus('思考中…');
          const bubble = ensureAssistantBubble();
          if (bubble) {
            const existingDetails = bubble.querySelector(':scope > .qwen-chat-thinking');
            const body = ensureThinkingBlock(bubble);
            if (body) appendAssistantText(body, message.text);
            const details = bubble.querySelector(':scope > .qwen-chat-thinking');
            if (!(existingDetails instanceof HTMLDetailsElement) && details instanceof HTMLDetailsElement) details.open = true;
            inThinking = true;
            placeCursor(bubble, true);
            if (body instanceof HTMLElement) body.scrollTop = body.scrollHeight;
            const messages = el(MESSAGES_ID);
            maybeAutoScrollMessages(messages);
          }
        } else if (message?.type === 'operation') {
          setStatus('操作中…');
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          removeCursor(activeBubble);
          lastOperationCard.card = appendOperationCard(message.operation);
          const messages = el(MESSAGES_ID);
          maybeAutoScrollMessages(messages);
        } else if (message?.type === 'operationResult') {
          setStatus('思考中…');
          updateOperationResult(lastOperationCard.card, message.result);
          nextReplyFresh = false;
          if (activeBubble instanceof HTMLElement) removeCursor(activeBubble);
          activeBubble = null;
          const fresh = ensureAssistantBubble();
          placeCursor(fresh, false);
          const messages = el(MESSAGES_ID);
          maybeAutoScrollMessages(messages);
        } else if (message?.type === 'firstMessage') {
          setStatus('思考中…');
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          if (activeBubble instanceof HTMLElement) removeCursor(activeBubble);
          activeBubble = null;
          const messages = el(MESSAGES_ID);
          maybeAutoScrollMessages(messages);
        } else if (message?.type === 'done') {
          sessionChatId = String(message.chatId || sessionChatId);
          sessionParentId = String(message.responseId || sessionParentId);
          if (sessionChatId) void chrome.storage.local.set({ qwenLastChatId: sessionChatId });
          if (openingStarted) {
            openingStarted = false;
            openingCompleted = true;
            void chrome.storage.local.remove('qwenOpeningPendingChatId');
          }
          hideAsk();
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          if (message.stoppedByLimit === true) {
            const bubble = ensureAssistantBubble();
            if (bubble instanceof HTMLElement) {
              if (mdRawText(bubble)) appendAssistantText(bubble, '\n\n_（操作调用次数过多，已结束本次。）_');
              else appendAssistantText(bubble, '_（操作调用次数过多，已结束本次。）_');
            }
          } else if (activeBubble instanceof HTMLElement && !mdRawText(activeBubble)) {
            appendAssistantText(activeBubble, '（无回复）');
          }
          removeCursor(activeBubble);
          activeBubble = null;
          setBusy(false);
          setStatus('已登录', 'ok');
          chatPort.disconnect();
          if (port === chatPort) port = null;
        } else if (message?.type === 'stopped') {
          hideAsk();
          const stoppedChatId = String(message?.chatId || '');
          if (stoppedChatId) {
            sessionChatId = stoppedChatId;
            const patch = { qwenLastChatId: stoppedChatId };
            if (openingStarted) patch.qwenOpeningPendingChatId = stoppedChatId;
            void chrome.storage.local.set(patch);
          }
          if (openingStarted) openingStarted = false;
          if (message?.parentId) sessionParentId = String(message.parentId);
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          if (activeBubble instanceof HTMLElement) {
            const raw = mdRawText(activeBubble);
            appendAssistantText(activeBubble, raw ? '\n（已停止）' : '（已停止）');
          }
          removeCursor(activeBubble);
          activeBubble = null;
          setBusy(false);
          setStatus('已登录', 'ok');
          chatPort.disconnect();
          if (port === chatPort) port = null;
        } else if (message?.type === 'ask') {
          showAsk(message);
        } else if (message?.type === 'askResolved') {
          if (!message?.id || String(message.id) === pendingAskId) hideAsk();
        } else if (message?.type === 'retryRequest') {
          const retryChatId = String(message?.chatId || sessionChatId || '');
          const retryId = String(message?.retryId || '');
          if (retryChatId) {
            sessionChatId = retryChatId;
            const patch = { qwenLastChatId: retryChatId };
            if (openingStarted) patch.qwenOpeningPendingChatId = retryChatId;
            void chrome.storage.local.set(patch);
          }
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          if (message?.afterOperationResult === true) {
            if (!(lastOperationCard.card instanceof HTMLElement) || !lastOperationCard.card.isConnected) {
              lastOperationCard.card = appendOperationCard();
            }
            updateOperationResult(lastOperationCard.card, message.operationResult);
          }
          removeCursor(activeBubble);
          removeMessageBubble(activeBubble);
          activeBubble = null;
          const bubble = appendMessage('error', message.message || '请求失败');
          if (message.code === 'WAF_PUNISH' || message.code === 'WAF_BUSY' || message.code === 'WAF_CHALLENGE') {
            setStatus('风控校验', 'error');
            void send('QWEN_OPEN_LOGIN');
          }
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'qwen-chat-retry-btn';
          btn.textContent = '重试';
          btn.title = '重新发送刚才的请求';
          btn.addEventListener('click', () => {
            btn.disabled = true;
            btn.textContent = '正在重试…';
            try {
              chatPort.postMessage({
                type: 'retryDecision',
                action: 'retry',
                retryId,
                chatId: retryChatId || sessionChatId
              });
            } catch {
              btn.disabled = false;
              btn.textContent = '重试';
              btn.title = '重试连接已失效，请重新发送消息';
            }
          });
          bubble.appendChild(btn);
          retryPrompt = { id: retryId, bubble, button: btn };
          const messages = el(MESSAGES_ID);
          maybeAutoScrollMessages(messages);
        } else if (message?.type === 'retryAccepted') {
          if (!retryPrompt || (message?.retryId && String(message.retryId) !== retryPrompt.id)) return;
          retryPrompt.bubble.remove();
          retryPrompt = null;
          activeBubble = null;
          const fresh = ensureAssistantBubble();
          placeCursor(fresh, false);
          setBusy(true);
          setStatus('思考中…');
          maybeAutoScrollMessages(el(MESSAGES_ID));
        } else if (message?.type === 'retryRejected') {
          if (!retryPrompt || (message?.retryId && String(message.retryId) !== retryPrompt.id)) return;
          retryPrompt.button.disabled = false;
          retryPrompt.button.textContent = '重试';
          retryPrompt.button.title = '重试连接已失效，请重新发送消息';
        } else if (message?.type === 'error') {
          hideAsk();
          if (message?.parentId) sessionParentId = String(message.parentId);
          if (inThinking) {
            collapseThinking(activeBubble);
            inThinking = false;
          }
          const errorChatId = String(message.chatId || '');
          if (errorChatId) {
            sessionChatId = errorChatId;
            const patch = { qwenLastChatId: errorChatId };
            if (openingStarted) patch.qwenOpeningPendingChatId = errorChatId;
            void chrome.storage.local.set(patch);
          }
          if (openingStarted) openingStarted = false;
          if (message.code === 'NOT_LOGGED_IN') {
            setStatus('未登录', 'error');
            showLoginHint(true);
            removeMessageBubble(activeBubble);
            activeBubble = null;
          } else if (message.code === 'WAF_PUNISH' || message.code === 'WAF_BUSY' || message.code === 'WAF_CHALLENGE') {
            if (activeBubble instanceof HTMLElement) {
              removeCursor(activeBubble);
              removeMessageBubble(activeBubble);
            }
            activeBubble = null;
            appendMessage('error', message.message || '请求失败');
            setStatus('风控校验', 'error');
            void send('QWEN_OPEN_LOGIN');
          } else {
            removeCursor(activeBubble);
            if (activeBubble instanceof HTMLElement && !mdRawText(activeBubble)) removeMessageBubble(activeBubble);
            activeBubble = null;
            appendMessage('error', message.message || '请求失败');
          }
          setBusy(false);
          chatPort.disconnect();
          if (port === chatPort) port = null;
        }
      });
      chatPort.onDisconnect.addListener(() => {
        hideAsk();
        if (activeBubble) {
          activeBubble = null;
          setBusy(false);
        }
        if (openingStarted) openingStarted = false;
        if (port === chatPort) port = null;
      });
      chatPort.postMessage({ type: 'send', text, thinking: (el(THINKING_ID) instanceof HTMLInputElement) && el(THINKING_ID).checked, chatId: sessionChatId, parentId: editParent || sessionParentId, editParentGiven: isEditSend });
    };

    try {
      connectPort();
    } catch (error) {
      appendMessage('error', `无法连接：${String(error?.message || error)}`);
      setBusy(false);
    }
  }

  function sendMessage(text) {
    if (busy) return;
    if (!chatStateLoaded || !openingCompleted) {
      maybeSendOpening();
      return;
    }
    const editParent = pendingEditParentId;
    pendingEditParentId = '';
    const isEditSend = pendingEdit;
    pendingEdit = false;
    startStream({ text, editParent, isEditSend, showUserBubble: true });
  }

  function maybeSendOpening() {
    if (!chatStateLoaded || !lastKnownEnabled || !lastKnownLoggedIn
      || openingCompleted || openingStarted || historyLoadPromise) return;
    sendOpening();
  }

  function sendOpening() {
    if (!lastKnownEnabled || !lastKnownLoggedIn || openingStarted || openingCompleted) return;
    openingStarted = true;
    setBusy(true);
    setStatus('思考中…');
    void send('QWEN_BUILD_SYSTEM_PROMPT').then((response) => {
      const text = String(response?.text || '').trim();
      if (!text) throw new Error('系统提示词为空');
      startStream({ text, showUserBubble: false });
    }).catch((error) => {
      openingStarted = false;
      appendMessage('error', `系统提示词发送准备失败：${String(error?.message || error)}`);
      setTimeout(() => sendOpening(), 1000);
    });
  }

  function init() {
    if (new URLSearchParams(global.location?.search || '').get('popup') === '1') {
      const fab = el(FAB_ID);
      if (fab instanceof HTMLElement) fab.style.display = 'none';
      const panel = el(PANEL_ID);
      if (panel instanceof HTMLElement) panel.hidden = true;
      return;
    }

    void chrome.storage.local.get(['qwenEnabled']).then((data) => {
      if (data?.qwenEnabled === false) {
        const fab = el(FAB_ID);
        if (fab instanceof HTMLElement) fab.style.display = 'none';
        const panel = el(PANEL_ID);
        if (panel instanceof HTMLElement) panel.hidden = true;
      }
    });

    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === 'QWEN_TOKEN_CAPTURED_BROADCAST') {
        lastKnownLoggedIn = true;
        showLoginHint(false);
        historyReloadAfterLogin = true;
        void restoreHistoryAfterLogin();
        void refreshStatus();
        return false;
      }
      if (message?.type !== 'PAGE_API' || message?.payload?.module !== 'qwen') return false;
      if (String(message?.payload?.fn || '') !== 'executeJs') {
        sendResponse({ ok: false, error: `未知页面操作：${String(message?.payload?.fn || '')}` });
        return false;
      }
      void executeJsInSandbox(message?.payload?.args?.code, message?.payload?.args?.mode).then((value) => {
        sendResponse({ ok: true, value });
      }).catch((error) => {
        sendResponse({ ok: false, error: String(error?.message || error) });
      });
      return true;
    });

    const fab = el(FAB_ID);
    const panel = el(PANEL_ID);
    const closeBtn = el('qwen-chat-close');
    const stopBtn = el(STOP_ID);
    const form = el('qwen-chat-input-form');
    const input = el(INPUT_ID);
    const loginBtn = el('qwen-chat-login-btn');
    const messages = el(MESSAGES_ID);
    const messagesScroller = getMessagesScrollContainer(messages);
    const scrollBottomBtn = el(SCROLL_BOTTOM_ID);

    if (messagesScroller instanceof HTMLElement) {
      lastMessagesScrollTop = messagesScroller.scrollTop;
      messagesScroller.addEventListener('wheel', (event) => {
        if (event.deltaY < 0) {
          autoScrollEnabled = false;
          updateScrollBottomButton(messagesScroller);
        }
      }, { passive: true });
      messagesScroller.addEventListener('scroll', () => {
        const current = messagesScroller.scrollTop;
        if (isMessagesAtBottom(messagesScroller)) autoScrollEnabled = true;
        else if (current < lastMessagesScrollTop - 1) autoScrollEnabled = false;
        lastMessagesScrollTop = current;
        updateScrollBottomButton(messagesScroller);
      }, { passive: true });
    }
    if (scrollBottomBtn instanceof HTMLButtonElement) {
      scrollBottomBtn.addEventListener('click', () => {
        scrollMessagesToBottom(messages, { force: true });
      });
    }

    if (panel instanceof HTMLElement) {
      const panelEdgeGap = 20;
      const syncPanelViewportHeight = () => {
        const availableHeight = Math.max(1, window.innerHeight - panelEdgeGap * 2);
        panel.style.maxHeight = `${availableHeight}px`;
        panel.style.minHeight = `${Math.min(320, availableHeight)}px`;
        const currentHeight = panel.getBoundingClientRect().height;
        if (currentHeight > availableHeight) panel.style.height = `${availableHeight}px`;
      };
      syncPanelViewportHeight();
      panel.addEventListener('pointerdown', (event) => {
        if (event.button !== 0) return;
        const rect = panel.getBoundingClientRect();
        const resizeHandleSize = 20;
        const onNativeResizeHandle = event.clientX >= rect.right - resizeHandleSize
          && event.clientY >= rect.bottom - resizeHandleSize;
        if (!onNativeResizeHandle) return;
        // fixed + bottom 会使原生右下角缩放以底部为锚点；缩放前改为 top 锚定。
        panel.style.left = `${rect.left}px`;
        panel.style.top = `${rect.top}px`;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
        panel.style.width = `${rect.width}px`;
        panel.style.height = `${rect.height}px`;
      }, { capture: true });
      const header = panel.querySelector('.qwen-chat-header');
      if (header instanceof HTMLElement) {
        header.addEventListener('pointerdown', (event) => {
          if (event.button !== 0) return;
          if (event.target.closest('button, select, input, a')) return;
          const rect = panel.getBoundingClientRect();
          const edgeGap = panelEdgeGap;
          const availableHeight = Math.max(1, window.innerHeight - edgeGap * 2);
          const fixedHeight = Math.min(rect.height, availableHeight);
          panel.style.height = `${fixedHeight}px`;
          panel.style.maxHeight = `${availableHeight}px`;
          const fixedRect = panel.getBoundingClientRect();
          const offsetX = event.clientX - fixedRect.left;
          const offsetY = event.clientY - fixedRect.top;
          const onMove = (moveEvent) => {
            panel.style.right = 'auto';
            panel.style.bottom = 'auto';
            const size = panel.getBoundingClientRect();
            const maxLeft = Math.max(edgeGap, window.innerWidth - size.width - edgeGap);
            const maxTop = Math.max(edgeGap, window.innerHeight - size.height - edgeGap);
            const left = Math.min(Math.max(edgeGap, moveEvent.clientX - offsetX), maxLeft);
            const top = Math.min(Math.max(edgeGap, moveEvent.clientY - offsetY), maxTop);
            panel.style.left = `${left}px`;
            panel.style.top = `${top}px`;
            panel.style.maxWidth = `${Math.max(280, window.innerWidth - left - edgeGap)}px`;
          };
          const onUp = () => {
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerup', onUp);
          };
          window.addEventListener('pointermove', onMove);
          window.addEventListener('pointerup', onUp, { once: true });
          event.preventDefault();
        });
      }
      const clampPanel = () => {
        syncPanelViewportHeight();
        if (panel.hidden) return;
        const rect = panel.getBoundingClientRect();
        const edgeGap = panelEdgeGap;
        const inBounds =
          rect.left >= edgeGap && rect.top >= edgeGap &&
          rect.right <= window.innerWidth - edgeGap && rect.bottom <= window.innerHeight - edgeGap;
        if (inBounds) return;
        const size = rect;
        const maxHeight = Math.max(1, window.innerHeight - edgeGap * 2);
        panel.style.height = `${Math.min(size.height, maxHeight)}px`;
        panel.style.maxHeight = `${maxHeight}px`;
        const resized = panel.getBoundingClientRect();
        const maxLeft = Math.max(edgeGap, window.innerWidth - resized.width - edgeGap);
        const maxTop = Math.max(edgeGap, window.innerHeight - resized.height - edgeGap);
        const left = Math.min(Math.max(edgeGap, resized.left), maxLeft);
        const top = Math.min(Math.max(edgeGap, resized.top), maxTop);
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
        panel.style.maxWidth = `${Math.max(280, window.innerWidth - left - edgeGap)}px`;
      };
      window.addEventListener('resize', clampPanel);
    }

    void chrome.storage.local.get(['qwenLastChatId', 'qwenOpeningPendingChatId']).then((data) => {
      sessionChatId = String(data?.qwenLastChatId || '');
      const pendingOpeningChatId = String(data?.qwenOpeningPendingChatId || '');
      openingCompleted = !!sessionChatId && pendingOpeningChatId !== sessionChatId;
      chatStateLoaded = true;
      if (sessionChatId) {
        if (!port && !openingStarted) setBusy(false);
        if (historyReloadAfterLogin) {
          void restoreHistoryAfterLogin();
        } else {
          void loadHistory().finally(() => maybeSendOpening());
        }
      }
      else if (historyReloadAfterLogin) void restoreHistoryAfterLogin();
      else maybeSendOpening();
    });

    if (fab instanceof HTMLButtonElement) {
      fab.addEventListener('click', () => {
        if (panel instanceof HTMLElement) {
          panel.hidden = !panel.hidden;
          if (!panel.hidden) {
            fab.style.display = 'none';
            void refreshStatus({ openLoginIfNeeded: true });
            void refreshModels();
            if (historyNeedsInitialScroll) {
              scrollMessagesToBottom(el(MESSAGES_ID), { force: true });
              historyNeedsInitialScroll = false;
            }
            if (input instanceof HTMLTextAreaElement) input.focus();
          } else {
            fab.style.display = '';
          }
        }
      });
    }
    const modelSelect = el(MODEL_ID);
    if (modelSelect instanceof HTMLSelectElement) {
      modelSelect.addEventListener('change', () => {
        void send('QWEN_SETTINGS_SET', { modelId: modelSelect.value });
      });
    }
    const thinkingToggle = el(THINKING_ID);
    if (thinkingToggle instanceof HTMLInputElement) {
      thinkingToggle.addEventListener('change', () => {
        void send('QWEN_SETTINGS_SET', { thinkingEnabled: thinkingToggle.checked === true });
      });
    }
    if (closeBtn instanceof HTMLButtonElement) {
      closeBtn.addEventListener('click', () => {
        if (panel instanceof HTMLElement) panel.hidden = true;
        if (fab instanceof HTMLButtonElement) fab.style.display = '';
      });
    }
    const newChatBtn = el('qwen-chat-new');
    if (newChatBtn instanceof HTMLButtonElement) {
      newChatBtn.addEventListener('click', () => {
        const currentId = sessionChatId;
        const doNew = () => {
          sessionChatId = '';
          sessionParentId = '';
          nextReplyFresh = false;
          pendingEditParentId = '';
          pendingEdit = false;
          openingStarted = false;
          openingCompleted = false;
          hideAsk();
          const messages = el(MESSAGES_ID);
          if (messages instanceof HTMLElement) messages.replaceChildren();
          void chrome.storage.local.remove(['qwenLastChatId', 'qwenOpeningPendingChatId']);
          sendOpening();
        };
        if (!currentId) {
          doNew();
          return;
        }
        if (global.confirm('是否删除当前会话？')) {
          void send('QWEN_DELETE_CHAT', { chatId: currentId }).then(() => doNew()).catch(() => doNew());
        } else {
          doNew();
        }
      });
    }
    if (stopBtn instanceof HTMLButtonElement) {
      stopBtn.addEventListener('click', () => {
        if (port && busy) {
          try {
            port.postMessage({ type: 'stop' });
          } catch {
            // 端口可能已断开
          }
        }
      });
    }
    const askCount = el('qwen-chat-ask-count');
    if (askCount instanceof HTMLInputElement) {
      askCount.addEventListener('input', updateAskContinueLabel);
    }
    const askContinue = el('qwen-chat-ask-continue');
    if (askContinue instanceof HTMLButtonElement) {
      askContinue.addEventListener('click', () => resolveAsk('continue'));
    }
    const askAlways = el('qwen-chat-ask-always');
    if (askAlways instanceof HTMLButtonElement) {
      askAlways.addEventListener('click', () => resolveAsk('always'));
    }
    const askStop = el('qwen-chat-ask-stop');
    if (askStop instanceof HTMLButtonElement) {
      askStop.addEventListener('click', () => resolveAsk('stop'));
    }
    if (form instanceof HTMLFormElement) {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const text = String(input instanceof HTMLTextAreaElement ? input.value : '').trim();
        if (text) sendMessage(text);
      });
    }
    if (input instanceof HTMLTextAreaElement) {
      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
          event.preventDefault();
          form?.requestSubmit?.();
        }
      });
    }
    if (loginBtn instanceof HTMLButtonElement) {
      loginBtn.addEventListener('click', () => {
        void send('QWEN_OPEN_LOGIN', { auth: true });
        setTimeout(() => void refreshStatus(), 4000);
        setTimeout(() => void refreshModels(), 4000);
      });
    }

    void refreshStatus();
    void refreshModels();
    initOperationsPopover();
  }

  // 调试辅助：控制台可直接调用 ve.courseList() 等命名空间方法；callOp 继续兼容旧用法。
  async function callOp(name, args) {
    const response = await send('QWEN_RUN_OPERATION', { name, arguments: args || {} });
    if (response?.ok === true) return response.result;
    const error = new Error(response?.error || response?.message || `操作失败：${name}`);
    error.code = String(response?.code || '');
    throw error;
  }
  global.BjtuQwenDebug = Object.freeze({ callOp });
  global.callOp = callOp;

  async function installConsoleOperationNamespaces() {
    const response = await send('QWEN_LIST_OPERATIONS');
    if (!response?.ok || !Array.isArray(response.groups)) return false;
    for (const group of response.groups) {
      for (const entry of Array.isArray(group?.operations) ? group.operations : []) {
        const operationName = String(entry?.name || entry || '').trim();
        const parts = operationName.split('.');
        if (parts.length !== 2 || !parts[0] || !parts[1]) continue;
        const [moduleName, methodName] = parts;
        let namespace = global[moduleName];
        if (!namespace || (typeof namespace !== 'object' && typeof namespace !== 'function')) {
          namespace = {};
          Object.defineProperty(global, moduleName, {
            value: namespace,
            configurable: true,
            enumerable: true,
            writable: false
          });
        }
        if (Object.prototype.hasOwnProperty.call(namespace, methodName)) continue;
        Object.defineProperty(namespace, methodName, {
          value: (args = {}) => {
            const promise = callOp(operationName, args);
            promise.then(
              (result) => console.log(`[${operationName}]`, result),
              (error) => console.error(`[${operationName}]`, error)
            );
            return promise;
          },
          configurable: true,
          enumerable: true,
          writable: false
        });
      }
    }
    return true;
  }
  void (async () => {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      if (await installConsoleOperationNamespaces()) return;
      await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1)));
    }
  })();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init(), { once: true });
  } else {
    init();
  }
})(globalThis);
