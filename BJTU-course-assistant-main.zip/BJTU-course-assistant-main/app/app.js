const FILE_BASE = 'http://123.121.147.7:8081';

const PLATFORM_LOGIN_ASSIST_POLL_INTERVAL_MS = 1000;
const PLATFORM_LOGIN_ASSIST_POPUP_SIZE = Object.freeze({ width: 420, height: 600 });
const DEFAULT_PLATFORM_SESSION_ID = 'D571D57D255EA0BECF299C45D4C0468A';

// Platform header `sessionId` is maintained at runtime (NOT saved in settings).
let runtimePlatformSessionId = DEFAULT_PLATFORM_SESSION_ID;

// DOM
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const fileList = document.getElementById('file-list');
const usernameInput = document.getElementById('username-input');
const accountHistorySelect = document.getElementById('account-history-select');
const xqSelect = document.getElementById('xq-select');
const jsessionidInput = document.getElementById('jsessionid-input');
const totalServerBar = document.getElementById('total-server-bar');
const totalSizeInfoDiv = document.getElementById('total-size-info');
const totalPercentDiv = document.getElementById('total-percent');
const totalEtaDiv = document.getElementById('total-eta');
const copyAllBtn = document.getElementById('copy-all-btn');

function cleanRpUrl(url, { keepG = false } = {}) {
  try {
    const u = new URL(url);
    const params = new URLSearchParams(u.search);
    const id = params.get('id');
    const p = params.get('p');
    const g = keepG ? params.get('g') : null;
    const clean = new URL(u.origin + u.pathname);
    if (id) clean.searchParams.set('id', id);
    if (p) clean.searchParams.set('p', p);
    if (g) clean.searchParams.set('g', g);
    return clean.toString();
  } catch {
    return url;
  }
}

const resourceSpaceSection = document.getElementById('resource-space-section');
const resourceSpaceStatus = document.getElementById('resource-space-status');
const resourceSpaceList = document.getElementById('resource-space-list');
const resourceSearchInput = document.getElementById('resource-search-input');
const resourceSelectAllBtn = document.getElementById('resource-select-all-btn');
const resourceCopySelectedBtn = document.getElementById('resource-copy-selected-btn');
const resourceDownloadSelectedBtn = document.getElementById('resource-download-selected-btn');
const resourceSpaceCount = document.getElementById('resource-space-count');
const resourceTotalBar = document.getElementById('resource-download-total-bar');
const resourceTotalSizeInfo = document.getElementById('resource-download-total-size');
const resourceTotalPercent = document.getElementById('resource-download-total-percent');
const resourceTotalSpeed = document.getElementById('resource-download-total-speed');
const resourceTotalEta = document.getElementById('resource-download-total-eta');
const courseListDiv = document.getElementById('course-list');
const courseLoadingStatus = document.getElementById('course-loading-status');
const layoutContainer = document.querySelector('.layout-container');
const leftColumn = document.querySelector('.left-column');
const rightColumn = document.getElementById('right-column');
const columnResizer = document.getElementById('column-resizer');
const columnCollapseToggle = document.getElementById('column-collapse-toggle');
const courseHelperEvenWidthsButton = document.getElementById('course-helper-even-widths');
const veStatusBtn = document.getElementById('ve-status-btn');
const yktStatusBtn = document.getElementById('ykt-status-btn');
const mrjzyStatusBtn = document.getElementById('mrjzy-status-btn');
const jlgjStatusBtn = document.getElementById('jlgj-status-btn');
const moocStatusBtn = document.getElementById('mooc-status-btn');
const xuetangxStatusBtn = document.getElementById('xuetangx-status-btn');
const popupOpenFullscreenBtn = document.getElementById('popup-open-fullscreen');

// Login modal
const loginModal = document.getElementById('login-modal');
const loginBtn = document.getElementById('login-btn');
const cancelBtn = document.getElementById('cancel-btn');

function renderDirectOpenNotice() {
  document.body.innerHTML = `
    <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box;background:linear-gradient(135deg,#f8fafc 0%,#eef2ff 55%,#e0f2fe 100%);font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
      <div style="max-width:720px;width:100%;background:#fff;border:1px solid #dbeafe;border-radius:20px;box-shadow:0 18px 45px rgba(15,23,42,0.12);padding:32px 28px;color:#0f172a;">
        <div style="font-size:14px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2563eb;margin-bottom:12px;">BJTU 课程助手</div>
        <h1 style="margin:0 0 14px;font-size:28px;line-height:1.25;">请到 about:extensions 页面加载已解压的扩展，而非直接打开 app.html</h1>
        <p style="margin:0 0 18px;font-size:16px;line-height:1.8;color:#334155;">这个页面是扩展的工作台，只能在浏览器扩展环境中使用。请复制并在地址栏打开 <span style="font-weight:700;color:#0f172a;">about:extensions</span>，开启「开发人员模式」，再点击「加载已解压的扩展程序」载入本目录。</p>
        <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
          <button id="copy-extensions-page-url" type="button" style="display:inline-flex;align-items:center;justify-content:center;padding:10px 16px;border:0;border-radius:10px;background:#2563eb;color:#fff;font:inherit;font-weight:700;cursor:pointer;">复制 about:extensions</button>
          <span id="copy-extensions-page-status" style="color:#64748b;font-size:13px;">复制后粘贴到浏览器地址栏打开。</span>
        </div>
      </div>
    </div>`;

  const copyButton = document.getElementById('copy-extensions-page-url');
  const copyStatus = document.getElementById('copy-extensions-page-status');
  copyButton?.addEventListener('click', async () => {
    const value = 'about:extensions';
    let copied = false;
    try {
      await navigator.clipboard.writeText(value);
      copied = true;
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = value;
      textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
      document.body.appendChild(textarea);
      textarea.select();
      try { copied = document.execCommand('copy'); } catch { copied = false; }
      textarea.remove();
    }
    if (copyStatus) {
      copyStatus.textContent = copied
        ? '已复制，请粘贴到浏览器地址栏打开。'
        : '复制失败，请手动在地址栏输入 about:extensions';
    }
  });
}

const extensionRuntimeId = typeof chrome !== 'undefined' && chrome?.runtime ? String(chrome.runtime.id || '').trim() : '';
if ((!extensionRuntimeId && !globalThis.BJTU_ANDROID_WEBVIEW) ||
    (location.protocol !== 'chrome-extension:' && !globalThis.BJTU_ANDROID_WEBVIEW)) {
  renderDirectOpenNotice();
  throw new Error('Direct app.html open is not supported outside the extension runtime.');
}

const appSearchParams = new URLSearchParams(String(location.search || ''));
const popupMode = appSearchParams.get('popup') === '1';
const forceAccountListInitialization = appSearchParams.get('accountInit') === '1';
const forceAccountPasswordMigration = appSearchParams.get('accountInit') === '2';
if (popupMode) {
  document.body.classList.add('popup-mode');
}

const fullscreenWindowLayers = globalThis.BjtuFullscreenWindowLayers || (() => {
  const windows = [];
  const sync = () => {
    const active = windows.filter((item) => item instanceof HTMLElement && item.isConnected);
    windows.splice(0, windows.length, ...active);
    active.forEach((item, index) => { item.style.zIndex = String(10004 + index); });
  };
  return {
    bringToFront(item) {
      if (!(item instanceof HTMLElement)) return;
      const index = windows.indexOf(item);
      if (index >= 0) windows.splice(index, 1);
      windows.push(item);
      sync();
    },
    remove(item) {
      const index = windows.indexOf(item);
      if (index >= 0) windows.splice(index, 1);
      sync();
    }
  };
})();
globalThis.BjtuFullscreenWindowLayers = fullscreenWindowLayers;

const floatingWindowAnimations = globalThis.BjtuFloatingWindowAnimations || Object.freeze({
  measureVisibleButtonRect(button) {
    if (!(button instanceof HTMLButtonElement)) return null;
    const container = button.closest('.fullscreen-module-buttons');
    const containerWasHidden = container instanceof HTMLElement && container.hidden;
    const buttonWasHidden = button.hidden;
    if (container instanceof HTMLElement) container.hidden = false;
    button.hidden = false;
    button.classList.add('is-measuring-visible');
    const rect = button.getBoundingClientRect();
    button.classList.remove('is-measuring-visible');
    button.hidden = buttonWasHidden;
    if (container instanceof HTMLElement) container.hidden = containerWasHidden;
    return rect;
  },
  animateButton(button, showing) {
    if (!(button instanceof HTMLButtonElement)) return Promise.resolve();
    const container = button.closest('.fullscreen-module-buttons');
    if (showing && container instanceof HTMLElement) container.hidden = false;
    if (globalThis.BjtuMotion?.isEnabled?.() === false) {
      button.classList.remove('is-appearing', 'is-disappearing');
      button.hidden = !showing;
      globalThis.BjtuSyncFloatingLauncherContainer?.();
      return Promise.resolve();
    }
    const animationToken = String((Number(button.dataset.floatingAnimationToken || 0) + 1) % 1000000);
    button.dataset.floatingAnimationToken = animationToken;
    button.classList.remove('is-appearing', 'is-disappearing');
    if (showing) button.hidden = false;
    void button.offsetWidth;
    button.classList.add(showing ? 'is-appearing' : 'is-disappearing');
    return new Promise((resolve) => {
      let settled = false;
      let timer = 0;
      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        button.removeEventListener('animationend', finish);
        if (button.dataset.floatingAnimationToken !== animationToken) {
          resolve();
          return;
        }
        delete button.dataset.floatingAnimationToken;
        button.classList.remove('is-appearing', 'is-disappearing');
        if (!showing) button.hidden = true;
        globalThis.BjtuSyncFloatingLauncherContainer?.();
        resolve();
      };
      button.addEventListener('animationend', finish, { once: true });
      timer = setTimeout(finish, globalThis.BjtuMotion?.duration?.(240) ?? 240);
    });
  },
  async animateWindowFromButton(view, buttonRect, opening) {
    if (!(view instanceof HTMLElement) || !buttonRect || typeof view.animate !== 'function'
      || globalThis.BjtuMotion?.isEnabled?.() === false) return;
    const rect = view.getBoundingClientRect();
    const scale = 0.06;
    const collapsed = {
      opacity: 0,
      transformOrigin: '0 0',
      transform: `translate(${buttonRect.left + buttonRect.width / 2 - rect.left - rect.width * scale / 2}px, ${buttonRect.top + buttonRect.height / 2 - rect.top - rect.height * scale / 2}px) scale(${scale})`
    };
    const expanded = { opacity: 1, transformOrigin: '0 0', transform: 'translate(0, 0) scale(1)' };
    const animation = view.animate(opening ? [collapsed, expanded] : [expanded, collapsed], {
      duration: opening ? 220 : 180,
      easing: opening ? 'cubic-bezier(.2,.8,.2,1)' : 'cubic-bezier(.4,0,1,1)',
      fill: 'both'
    });
    try { animation.updatePlaybackRate(globalThis.BjtuMotion?.getSpeed?.() || 1); } catch {}
    await animation.finished.catch(() => {});
    animation.cancel();
  }
});
globalThis.BjtuFloatingWindowAnimations = floatingWindowAnimations;

const syncFloatingLauncherContainer = () => {
  const container = document.getElementById('fullscreen-module-buttons');
  if (!(container instanceof HTMLElement)) return;
  const buttons = [...container.querySelectorAll(':scope > .floating-launcher-button')];
  container.hidden = !buttons.some((button) => (
    !button.hidden || button.classList.contains('is-appearing') || button.classList.contains('is-disappearing')
  ));
};
globalThis.BjtuSyncFloatingLauncherContainer = syncFloatingLauncherContainer;

const FULLSCREEN_MODULE_BUTTONS = Object.freeze({
  mail: {
    id: 'mail-fullscreen-button',
    key: 'mailFullscreenButtonEnabled',
    iconKey: 'mailFullscreenButtonIcon',
    label: 'BJTU 邮件系统'
  },
  academic: {
    id: 'academic-fullscreen-button',
    key: 'academicFullscreenButtonEnabled',
    iconKey: 'academicFullscreenButtonIcon',
    label: '教务系统'
  }
});

async function initFullscreenModuleButtons() {
  const container = document.getElementById('fullscreen-module-buttons');
  if (!(container instanceof HTMLElement)) return;
  const fullscreen = !popupMode && appSearchParams.get('view') !== 'sidepanel';
  if (!fullscreen) {
    container.hidden = true;
    return;
  }
  const available = await globalThis.BjtuModuleRegistry.ready;
  const keys = ['qwenEnabled', ...Object.values(FULLSCREEN_MODULE_BUTTONS)
    .flatMap((item) => [item.key, item.iconKey].filter(Boolean))];
  const stored = await chrome.storage.local.get(keys);
  const moduleViewPromises = new Map();
  const moduleWindows = new Map();

  const showPanelMessage = (text, ok = true, options = {}) => {
    const type = options?.type === 'info' ? 'info' : (ok ? 'success' : 'error');
    showToast(String(text || ''), type, options?.persistent ? 0 : 3000);
  };

  const refreshButtonContainer = () => {
    syncFloatingLauncherContainer();
  };

  const bringToFront = (view) => {
    fullscreenWindowLayers.bringToFront(view);
  };

  const animateButton = (button, showing) => {
    return floatingWindowAnimations.animateButton(button, showing)
      .finally(refreshButtonContainer);
  };

  const animateWindowFromButton = (view, buttonRect, opening) => (
    floatingWindowAnimations.animateWindowFromButton(view, buttonRect, opening)
  );

  const clampWindow = (view, edgeGap = 12) => {
    if (!(view instanceof HTMLElement) || view.hidden) return;
    const availableWidth = Math.max(240, window.innerWidth - edgeGap * 2);
    const availableHeight = Math.max(200, window.innerHeight - edgeGap * 2);
    const rect = view.getBoundingClientRect();
    if (rect.width > availableWidth) view.style.width = `${availableWidth}px`;
    if (rect.height > availableHeight) view.style.height = `${availableHeight}px`;
    const resized = view.getBoundingClientRect();
    const left = Math.min(Math.max(edgeGap, resized.left), Math.max(edgeGap, window.innerWidth - resized.width - edgeGap));
    const top = Math.min(Math.max(edgeGap, resized.top), Math.max(edgeGap, window.innerHeight - resized.height - edgeGap));
    view.style.left = `${left}px`;
    view.style.top = `${top}px`;
    view.style.right = 'auto';
    view.style.bottom = 'auto';
  };

  const closeModuleWindow = async (moduleId) => {
    const view = moduleWindows.get(moduleId);
    if (!(view instanceof HTMLElement) || view.dataset.closing === '1') return;
    view.dataset.closing = '1';
    const config = FULLSCREEN_MODULE_BUTTONS[moduleId];
    const button = config && document.getElementById(config.id);
    const shouldShowButton = button instanceof HTMLButtonElement
      && available[moduleId] === true
      && stored[config.key] !== false;
    const targetRect = shouldShowButton
      ? floatingWindowAnimations.measureVisibleButtonRect(button)
      : null;
    await Promise.all([
      animateWindowFromButton(view, targetRect, false),
      shouldShowButton ? animateButton(button, true) : Promise.resolve()
    ]);
    view.hidden = true;
    delete view.dataset.closing;
    fullscreenWindowLayers.remove(view);
    moduleWindows.delete(moduleId);
    if (!shouldShowButton && button instanceof HTMLButtonElement) button.hidden = true;
    refreshButtonContainer();
  };

  window.addEventListener('bjtu-close-floating-windows', (event) => {
    const keep = event instanceof CustomEvent ? event.detail?.keep : null;
    for (const [moduleId, view] of moduleWindows) {
      if (view !== keep) void closeModuleWindow(moduleId);
    }
  });

  const prepareWindowInteractions = (view, moduleId) => {
    const header = view.querySelector(':scope > .section-title');
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'fullscreen-module-window-close';
    close.textContent = '×';
    close.title = '关闭';
    close.setAttribute('aria-label', '关闭');
    header?.appendChild(close);
    close.addEventListener('click', () => { void closeModuleWindow(moduleId); });

    let drag = null;
    let resizing = false;
    let preservedScroll = null;
    view.addEventListener('pointerdown', () => bringToFront(view), true);
    header?.addEventListener('pointerdown', (event) => {
      if (event.button !== 0 || event.target.closest('button, input, select, textarea, a')) return;
      const rect = view.getBoundingClientRect();
      drag = { x: event.clientX, y: event.clientY, left: rect.left, top: rect.top };
      view.style.left = `${rect.left}px`;
      view.style.top = `${rect.top}px`;
      view.style.right = 'auto';
      view.style.bottom = 'auto';
      event.preventDefault();
    });
    window.addEventListener('pointermove', (event) => {
      if (!drag) return;
      const rect = view.getBoundingClientRect();
      view.style.left = `${Math.min(Math.max(12, drag.left + event.clientX - drag.x), Math.max(12, window.innerWidth - rect.width - 12))}px`;
      view.style.top = `${Math.min(Math.max(12, drag.top + event.clientY - drag.y), Math.max(12, window.innerHeight - rect.height - 12))}px`;
    });
    window.addEventListener('pointerup', () => { drag = null; });
    view.addEventListener('pointerdown', (event) => {
      const rect = view.getBoundingClientRect();
      resizing = event.clientX >= rect.right - 20 && event.clientY >= rect.bottom - 20;
      if (!resizing) return;
      view.style.left = `${rect.left}px`;
      view.style.top = `${rect.top}px`;
      view.style.right = 'auto';
      view.style.bottom = 'auto';
      view.style.width = `${rect.width}px`;
      view.style.height = `${rect.height}px`;
      preservedScroll = { left: view.scrollLeft, top: view.scrollTop, windowX: window.scrollX, windowY: window.scrollY };
    }, true);
    const restoreScroll = () => {
      if (!preservedScroll) return;
      view.scrollLeft = preservedScroll.left;
      view.scrollTop = preservedScroll.top;
      window.scrollTo(preservedScroll.windowX, preservedScroll.windowY);
    };
    const resizeObserver = new ResizeObserver(() => {
      if (resizing) {
        clampWindow(view);
        requestAnimationFrame(restoreScroll);
      }
    });
    resizeObserver.observe(view);
    window.addEventListener('pointerup', () => {
      if (!resizing) return;
      clampWindow(view);
      restoreScroll();
      requestAnimationFrame(() => {
        restoreScroll();
        resizing = false;
        preservedScroll = null;
      });
    });
  };

  const loadModuleView = (moduleId) => {
    if (moduleViewPromises.has(moduleId)) return moduleViewPromises.get(moduleId);
    const promise = (async () => {
      const definition = globalThis.BjtuModuleRegistry.definitions[moduleId];
      const options = definition?.options;
      if (!options?.fragment || !options?.script) throw new Error(`模块 ${moduleId} 没有可加载的选项片段`);
      const stylePaths = [options.style, ...(options.styles || [])].filter(Boolean);
      for (const style of stylePaths) {
        await globalThis.BjtuModuleRegistry.loadStyle(`modules/${moduleId}/${style}`);
      }
      const response = await fetch(chrome.runtime.getURL(`modules/${moduleId}/${options.fragment}`), { cache: 'no-store' });
      if (!response.ok) throw new Error(`模块界面加载失败：HTTP ${response.status}`);
      const parsed = new DOMParser().parseFromString(await response.text(), 'text/html');
      const fragment = parsed.querySelector('[data-options-fragment]');
      if (!(fragment instanceof HTMLElement)) throw new Error('模块界面中缺少选项片段');
      const view = document.importNode(fragment, true);
      view.classList.add('fullscreen-module-window', 'floating-launcher-window');
      view.dataset.module = moduleId;
      view.hidden = true;
      view.querySelectorAll('.module-options-page-link').forEach((link) => {
        const title = document.createElement('span');
        title.textContent = link.textContent;
        link.replaceWith(title);
      });
      document.body.appendChild(view);
      prepareWindowInteractions(view, moduleId);
      for (const script of [...(options.scripts || []), options.script]) {
        await globalThis.BjtuModuleRegistry.loadScript(`modules/${moduleId}/${script}`);
      }
      const controller = moduleId === 'mail' ? globalThis.BjtuMailOptions : globalThis.BjtuAcademicOptions;
      if (!controller?.init) throw new Error('模块选项控制器未加载');
      await controller.init({ setMessage: showPanelMessage });
      globalThis.BjtuOptionTips?.setup?.();
      return view;
    })().catch((error) => {
      moduleViewPromises.delete(moduleId);
      throw error;
    });
    moduleViewPromises.set(moduleId, promise);
    return promise;
  };

  const openModulePanel = async (moduleId, config) => {
    const button = document.getElementById(config.id);
    if (moduleWindows.has(moduleId)) {
      const current = moduleWindows.get(moduleId);
      if (current instanceof HTMLElement) bringToFront(current);
      return;
    }
    if (button instanceof HTMLButtonElement) {
      button.disabled = true;
      button.classList.add('is-loading');
    }
    try {
      const view = await loadModuleView(moduleId);
      const sourceRect = button instanceof HTMLButtonElement ? button.getBoundingClientRect() : null;
      moduleWindows.set(moduleId, view);
      if (!view.dataset.positioned) {
        view.dataset.positioned = '1';
        view.style.width = `${Math.round(window.innerWidth * 0.75)}px`;
        view.style.height = `${Math.round(window.innerHeight * 0.75)}px`;
        view.style.left = `${Math.round(window.innerWidth * 0.125)}px`;
        view.style.top = `${Math.round(window.innerHeight * 0.125)}px`;
      }
      view.hidden = false;
      clampWindow(view);
      bringToFront(view);
      const buttonAnimation = button instanceof HTMLButtonElement ? animateButton(button, false) : Promise.resolve();
      await Promise.all([animateWindowFromButton(view, sourceRect, true), buttonAnimation]);
      refreshButtonContainer();
    } catch (error) {
      showPanelMessage(`模块加载失败：${String(error?.message || error)}`, false);
    } finally {
      if (button instanceof HTMLButtonElement) {
        button.disabled = false;
        button.classList.remove('is-loading');
      }
    }
  };

  const apply = (values) => {
    const mailButton = document.getElementById(FULLSCREEN_MODULE_BUTTONS.mail.id);
    if (mailButton instanceof HTMLButtonElement) {
      const useSystemIcon = values.mailFullscreenButtonIcon === 'system';
      const envelopeIcon = mailButton.querySelector('.mail-fullscreen-button-icon-envelope');
      const systemIcon = mailButton.querySelector('.mail-fullscreen-button-icon-system');
      if (envelopeIcon instanceof Element) envelopeIcon.toggleAttribute('hidden', useSystemIcon);
      if (systemIcon instanceof Element) systemIcon.toggleAttribute('hidden', !useSystemIcon);
    }
    const academicButton = document.getElementById(FULLSCREEN_MODULE_BUTTONS.academic.id);
    if (academicButton instanceof HTMLButtonElement) {
      const useSystemIcon = values.academicFullscreenButtonIcon === 'system';
      const graduationIcon = academicButton.querySelector('.academic-fullscreen-button-icon-graduation');
      const systemIcon = academicButton.querySelector('.academic-fullscreen-button-icon-system');
      academicButton.classList.toggle('use-system-icon', useSystemIcon);
      if (graduationIcon instanceof Element) graduationIcon.toggleAttribute('hidden', useSystemIcon);
      if (systemIcon instanceof Element) systemIcon.toggleAttribute('hidden', !useSystemIcon);
    }
    for (const [moduleId, config] of Object.entries(FULLSCREEN_MODULE_BUTTONS)) {
      const button = document.getElementById(config.id);
      if (!(button instanceof HTMLButtonElement)) continue;
      const shouldShow = available[moduleId] === true && values[config.key] !== false && !moduleWindows.has(moduleId);
      if (shouldShow && button.hidden) void animateButton(button, true);
      else if (!shouldShow && !button.hidden && !moduleWindows.has(moduleId)) void animateButton(button, false);
      if (values[config.key] === false && moduleWindows.has(moduleId)) void closeModuleWindow(moduleId);
      if (button.dataset.bound !== '1') {
        button.dataset.bound = '1';
        button.addEventListener('click', () => {
          void openModulePanel(moduleId, config);
        });
      }
    }
    refreshButtonContainer();
  };
  window.addEventListener('resize', () => moduleWindows.forEach((view) => clampWindow(view)));
  apply(stored);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !keys.some((key) => changes[key])) return;
    for (const key of keys) {
      if (changes[key]) stored[key] = changes[key].newValue;
    }
    apply(stored);
  });
}

void initFullscreenModuleButtons();

if (!popupMode) {
  const isBlankDoubleClickTarget = (target, floatingWindow) => {
    if (!(target instanceof Element)) return false;
    if (floatingWindow instanceof HTMLElement) {
      if (target === floatingWindow || target.classList.contains('section-title')) return true;
      if (floatingWindow.id !== 'qwen-chat-panel') return false;
      return target.matches([
        '.qwen-chat-header',
        '.qwen-chat-messages-wrap',
        '.qwen-chat-messages-scroll',
        '.qwen-chat-messages',
        '.qwen-chat-input-row'
      ].join(','));
    }
    return target === document.body
      || target === document.documentElement
      || target.matches([
        '.layout-container',
        '.left-column',
        '.right-column',
        '#course-list',
        '.platform-course-columns',
        '.platform-course-column-body'
      ].join(','));
  };

  document.addEventListener('dblclick', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const floatingWindow = target.closest('.floating-launcher-window:not([hidden])');
    if (!isBlankDoubleClickTarget(target, floatingWindow)) return;
    window.dispatchEvent(new CustomEvent('bjtu-close-floating-windows', {
      detail: { keep: floatingWindow instanceof HTMLElement ? floatingWindow : null }
    }));
  });
}

if (usernameInput) {
  let mjActivationRequested = false;
  usernameInput.addEventListener('input', () => {
    const value = String(usernameInput.value || '').trim();
    const activateMj = value.toLowerCase() === 'mj';
    if (activateMj && !mjActivationRequested) {
      mjActivationRequested = true;
      chrome.runtime.sendMessage({ type: 'ACTIVATE_MJ_MODULE' }).then((result) => {
        if (!result?.ok) {
          mjActivationRequested = false;
          if (result?.code === 'MODULE_NOT_INSTALLED') return;
          showToast?.(`无法激活 MJ：${result?.message || '未知错误'}`, 'error');
        }
      }).catch((error) => {
        mjActivationRequested = false;
        showToast?.(`无法激活 MJ：${String(error?.message || error)}`, 'error');
      });
    } else if (!activateMj) {
      mjActivationRequested = false;
    }
    const current = String(lastValidUsername || '').trim();
    if (value && value !== current) {
      beginAccountSwitchInterruption();
    } else if (!value || value === current) {
      resetAccountSwitchInterruption();
    }
    updateJsessionidState();
  });
  usernameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (typeof doLoginFlow === 'function' && !isLoginInProgress) {
        doLoginFlow();
      }
    }
  });
}

// Upload state
const uploadQueue = [];
let activeUploads = 0;
let maxParallelUploads = 3;
const PARALLEL_LIMIT_KEY = 'parallelLimit';
let pendingLoginCallbacks = [];
let isLoginSessionValid = true;
window.filesData = {}; // {fileId: {size, uploaded}}
window.courseHomeworkData = {};
window.veHomeworkPendingTypesByCourse = {}; // {courseId: string[]}
window.yktMatchedHomeworkByCourseId = {}; // {courseId: YktHomework[]}
window.yktMatchedCourseLinkByCourseId = {}; // {courseId: yktCourseUrl}
window.yktStandaloneCourses = []; // YktCourse[]
window.yktCourseGroupsSnapshot = []; // [{token,name,teacher_name,classroom_id,course_name,homeworks}]
window.yktHomeworkLoadingByCourse = {}; // {courseId: boolean}
window.yktHomeworkPendingTypesByCourse = {}; // {courseId: string[]}
window.mrjzyMatchedHomeworkByCourseId = {}; // {courseId: MrjzyHomework[]}
window.mrjzyStandaloneCourses = []; // MrjzyCourse[]
window.mrjzyCourseGroupsSnapshot = []; // [{token,divClass,classNum,teacherName,homeworks}]
window.jlgjMatchedHomeworkByCourseId = {}; // {courseId: JlgjHomework[]}
window.jlgjStandaloneCourses = []; // JlgjCourse[]
window.jlgjCourseGroupsSnapshot = []; // [{token,name,groupId,homeworks}]
window.courseCardStateById = {}; // {courseId: {allHomeworkCount,pendingHomeworkCount,hasReplay}}
window.videoReplayCacheByCourseId = {}; // {courseId: {html: string, loaded: boolean}}
window.veReplayScheduleByCourseId = {}; // {courseId: {list,promise,loaded,error}}
window.coursewareCacheByCourseId = {}; // {courseId: {html: string, loaded: boolean}}
const PLATFORM_IDS = Object.freeze(['ve', 'ykt', 'mrjzy', 'jlgj', 'mooc', 'xuetangx']);
window.platformOrder = [...PLATFORM_IDS];
window.platformNeedLogin = Object.fromEntries(PLATFORM_IDS.map((id) => [id, false]));
window.platformLoginState = Object.fromEntries(PLATFORM_IDS.map((id) => [id, 'checking'])); // checking|offline|online
window.platformLoginChecked = Object.fromEntries(PLATFORM_IDS.map((id) => [id, false]));
window.platformInteractiveLoginPending = { ve: false, ykt: false, mrjzy: false, jlgj: false, mooc: false, xuetangx: false };
const DEFAULT_PLATFORM_ENABLED = { jlgj: false, mooc: false, mrjzy: false, ve: true, ykt: false, xuetangx: false };
const DEFAULT_PLATFORM_VISIBLE = { jlgj: true, mooc: true, mrjzy: true, ve: true, ykt: true, xuetangx: true };
const PLATFORM_AUTO_LOGIN_STORAGE_KEYS = Object.freeze({
  ve: 'veAutoLoginOnExpiry',
  ykt: 'yktAutoLoginOnExpiry',
  mrjzy: 'mrjzyAutoLoginEnabled',
  jlgj: 'jlgjAutoLoginOnExpiry',
  mooc: 'moocAutoLoginOnExpiry',
  xuetangx: 'xuetangxAutoLoginOnExpiry'
});
const DEFAULT_PLATFORM_AUTO_LOGIN_ON_EXPIRY = Object.freeze({
  ve: true,
  ykt: true,
  mrjzy: true,
  jlgj: true,
  mooc: true,
  xuetangx: true
});
window.platformEnabled = { ...DEFAULT_PLATFORM_ENABLED };
window.platformVisible = { ...DEFAULT_PLATFORM_VISIBLE };
window.platformAutoLoginOnExpiry = { ...DEFAULT_PLATFORM_AUTO_LOGIN_ON_EXPIRY };
window.platformLoadedOnce = Object.fromEntries(PLATFORM_IDS.map((id) => [id, false]));
window.platformLoadVersion = Object.fromEntries(PLATFORM_IDS.map((id) => [id, 0]));
window.platformContentLoadProgress = {};
window.currentVeCourseList = [];
window.veDisabledCourseListCache = [];
window.homeworkScoreCacheByKey = {}; // {"upId|snId": string}
window.homeworkScorePendingByCourse = {}; // {courseId: boolean}
window.homeworkScoreForcePublishStateByCourse = {}; // {courseId:{running,progress,ids:[]}}
window.homeworkNoteAttachmentCacheByKey = {}; // {"noteId|courseId|teacherId": {loading,loaded,picList}}
window.homeworkAttachmentPendingByCourse = {}; // {courseId: boolean}
window.uploadedFileMetaById = {}; // {fileId: {fileNameNoExt,fileExtName,fileSize,visitName,pid,ftype}}
window.savedUploadedFiles = []; // [{id,fileName,fileSize,visitName,url,savedAt}]
window.saveUploadedFilesEnabled = true;
window.downloadInExtensionEnabled = true;
window.autoLoadCourseResourcesEnabled = false;
window.yktActivityTypes = [14, 15, 5, 9];
window.homeworkDetailCollapsedLines = 3;
window.collapseHomeworkDetailsDownward = true;
window.scrollExpandHomeworkLists = false;
window.scrollCollapseHomeworkLists = true;
window.replayDetailCollapsedLines = 3;
window.jlgjDarkModeEnabled = true;
window.homeworkDetailExpandedByCourse = {}; // {courseId: {expandKey: boolean}}
window.courseShowOverdueById = {};
window.courseShowDoneById = {};
window.yktDetailCacheByKey = {}; // {detailKey: {state,title,exam_problems,problem_results,promise}}
window.externalPlatformLoadVersion = 0;
window.courseHelperPlatformSplitMode = false;
window.courseHelperPlatformColumnWeights = {};
window.showCourseListDuringLayoutTransition = false;
window.courseListLoadVersion = 0;
window.veTeacherMetaByCourseId = {}; // {courseId:{teacherId,loading,loaded,teachers:[]}}
window.veCourseTeachersMetaByCourseId = {}; // {courseId:{rows,loading,loaded,error,promise}}
window.veCourseTeachersCacheByPrefix = {}; // {courseNumberWithoutSequence:{rows}}
window.veStudentsMetaByCourseId = {}; // {courseId:{students,total,loading,loaded,error,promise}}
window.resourceSpaceItems = []; // [{id,name,url,inputTime}]
window.resourceSpaceSelected = new Set();
window.coursewareItemsById = {}; // {resourceId: {id,name,url,extName,courseId}}
window.coursewareItemsByCourseId = {}; // {courseId: CoursewareItem[]}
window.archiveItemsById = {}; // {resourceId: {id,name,url,extName,courseId}}
window.archiveItemsByCourseId = {}; // {courseId: ArchiveItem[]}
window.archiveCacheByCourseId = {}; // {courseId:{loaded,loading,items,html}}
window.homeworkAttachmentItemsById = {}; // {resourceId: {id,name,url,extName,courseId,sizeMbRaw,sizeMb}}
window.homeworkAttachmentItemsByCourseId = {}; // {courseId: HomeworkAttachmentItem[]}
window.resourceSpaceLoadVersion = 0;
window.currentAccountLoginName = '';
window.isTeacherAccount = false; // teacher role detected
window.resourceDownloadTasks = {}; // {resourceId: {active,loaded,total,speed,samples,lastUiTs,abortController,xhr,cancelled,chromeDownloadId}}
window.resourceDownloadBatch = {
  active: false,
  totalFiles: 0,
  totalBytes: 0,
  knownTotal: true,
  completedFiles: 0,
  completedBytes: 0
};
window.resourceDownloadQueue = []; // [{id,item,resolve,reject,cancelled,started,promise}]
window.resourceDownloadQueueById = {}; // {resourceId: queueEntry}
window.resourceDownloadQueueRunning = 0;
window.resourceDownloadQueueStatus = { totalFiles: 0, savedFiles: 0 };
window.resourceDownloadCompletedContribution = { loadedBytes: 0, totalBytes: 0 };
window.resourceDownloadQueueClearTimer = null;
let resourceSpaceSearchKeyword = '';

function normalizePlatformId(platform) {
  const p = String(platform || '').trim();
  return PLATFORM_IDS.includes(p) ? p : 've';
}

function isPlatformEnabled(platform) {
  const p = normalizePlatformId(platform);
  return window.platformEnabled?.[p] === true;
}

function shouldAutoLoginAfterExpiry(platform) {
  const p = normalizePlatformId(platform);
  return window.platformAutoLoginOnExpiry?.[p] === true;
}
globalThis.shouldAutoLoginAfterExpiry = shouldAutoLoginAfterExpiry;

function sanitizePlatformEnabled(raw, fallback = DEFAULT_PLATFORM_ENABLED) {
  const src = (raw && typeof raw === 'object') ? raw : null;
  const result = {
    jlgj: typeof src?.jlgj === 'boolean' ? src.jlgj : !!fallback.jlgj,
    mooc: typeof src?.mooc === 'boolean' ? src.mooc : !!fallback.mooc,
    mrjzy: typeof src?.mrjzy === 'boolean' ? src.mrjzy : !!fallback.mrjzy,
    ve: typeof src?.ve === 'boolean' ? src.ve : !!fallback.ve,
    ykt: typeof src?.ykt === 'boolean' ? src.ykt : !!fallback.ykt,
    xuetangx: typeof src?.xuetangx === 'boolean' ? src.xuetangx : !!fallback.xuetangx
  };
  PLATFORM_IDS.forEach((id) => {
    if (globalThis.BjtuModuleRegistry && !globalThis.BjtuModuleRegistry.has(id)) result[id] = false;
  });
  return result;
}

function sanitizePlatformVisible(raw, fallback = DEFAULT_PLATFORM_VISIBLE) {
  const src = (raw && typeof raw === 'object') ? raw : null;
  return Object.fromEntries(Object.keys(DEFAULT_PLATFORM_VISIBLE).map((key) => [
    key,
    typeof src?.[key] === 'boolean' ? src[key] : !!fallback[key]
  ]));
}

function normalizePlatformOrderForApp(raw) {
  return globalThis.BjtuUiOrder?.normalizePlatforms(raw) || [...PLATFORM_IDS];
}

function applyPlatformOrderInApp() {
  const container = document.querySelector('.platform-status-actions');
  if (!container) return;
  window.platformOrder.forEach((id) => {
    const button = document.getElementById(`${id}-status-btn`);
    if (button) container.appendChild(button);
  });
}

async function loadPlatformOrderFromStorage() {
  try {
    const data = await chrome.storage.local.get(['platformOrder']);
    window.platformOrder = normalizePlatformOrderForApp(data?.platformOrder);
  } catch {
    window.platformOrder = [...PLATFORM_IDS];
  }
  applyPlatformOrderInApp();
}

function applyPlatformVisibility() {
  const buttons = { ve: veStatusBtn, ykt: yktStatusBtn, mrjzy: mrjzyStatusBtn, jlgj: jlgjStatusBtn, mooc: moocStatusBtn, xuetangx: xuetangxStatusBtn };
  Object.entries(buttons).forEach(([key, button]) => {
    if (!button) return;
    const moduleMissing = globalThis.BjtuModuleRegistry && !globalThis.BjtuModuleRegistry.has(key);
    button.hidden = moduleMissing;
    button.style.display = moduleMissing || window.platformVisible?.[key] === false ? 'none' : '';
  });
}

async function loadPlatformEnabledFromStorage() {
  try {
    const localData = await chrome.storage.local.get(['platformEnabled']);
    const saved = localData?.platformEnabled ?? null;
    window.platformEnabled = sanitizePlatformEnabled(saved, DEFAULT_PLATFORM_ENABLED);
    chrome.storage.sync.remove(['platformEnabled']).catch(() => { });
  } catch {
    window.platformEnabled = { ...DEFAULT_PLATFORM_ENABLED };
  }
}

async function savePlatformEnabledToStorage() {
  const normalized = sanitizePlatformEnabled(window.platformEnabled);
  await chrome.storage.local.set({ platformEnabled: normalized });
  await chrome.storage.sync.remove(['platformEnabled']).catch(() => { });
  scheduleFullscreenCourseCacheSave(200);
}

function disablePlatformAfterLoginFailure(platform) {
  const p = normalizePlatformId(platform);
  if (!PLATFORM_IDS.includes(p)) return;
  if (!window.platformEnabled?.[p]) return;

  window.platformEnabled[p] = false;
  window.platformLoadedOnce[p] = false;
  window.platformNeedLogin[p] = false;
  bumpPlatformLoadVersion(p);

  savePlatformEnabledToStorage().catch(() => { });
}

const AUTO_LOAD_COURSE_RESOURCES_KEY = 'autoLoadCourseResourcesEnabled';
const YKT_ACTIVITY_TYPES_KEY = 'yktActivityTypes';
const HOMEWORK_DETAIL_COLLAPSED_LINES_KEY = 'homeworkDetailCollapsedLines';
const COLLAPSE_HOMEWORK_DETAILS_DOWNWARD_KEY = 'collapseHomeworkDetailsDownward';
const SCROLL_EXPAND_HOMEWORK_LISTS_KEY = 'scrollExpandHomeworkLists';
const SCROLL_COLLAPSE_HOMEWORK_LISTS_KEY = 'scrollCollapseHomeworkLists';
const REPLAY_DETAIL_COLLAPSED_LINES_KEY = 'replayDetailCollapsedLines';
const JLGJ_DARK_MODE_KEY = 'jlgjDarkModeEnabled';
const AUTO_LOAD_COURSE_RESOURCES_DEFAULT_OFF_STATE_KEY = 'autoLoadCourseResourcesDefaultOffState';

async function migrateAutoLoadCourseResourcesDefaultOff() {
  try {
    const data = await chrome.storage.local.get([
      AUTO_LOAD_COURSE_RESOURCES_KEY,
      AUTO_LOAD_COURSE_RESOURCES_DEFAULT_OFF_STATE_KEY
    ]);
    const storedState = String(data[AUTO_LOAD_COURSE_RESOURCES_DEFAULT_OFF_STATE_KEY] || '').trim();
    if (storedState === 'pending' || storedState === 'done') {
      return storedState === 'pending';
    }

    const shouldNotify = data[AUTO_LOAD_COURSE_RESOURCES_KEY] === true;
    const nextState = shouldNotify ? 'pending' : 'done';
    await chrome.storage.local.set({
      [AUTO_LOAD_COURSE_RESOURCES_KEY]: false,
      [AUTO_LOAD_COURSE_RESOURCES_DEFAULT_OFF_STATE_KEY]: nextState
    });
    return shouldNotify;
  } catch {
    return false;
  }
}

function showAutoLoadCourseResourcesDisabledNotice() {
  if (document.getElementById('auto-load-resources-disabled-notice')) return;
  const modal = document.createElement('div');
  modal.id = 'auto-load-resources-disabled-notice';
  modal.className = 'version-modal-mask';
  modal.style.zIndex = '10020';
  modal.innerHTML = `
    <div class="version-modal-card" role="alertdialog" aria-modal="true" aria-labelledby="auto-load-resources-disabled-title">
      <div id="auto-load-resources-disabled-title" class="version-download-title">选项已调整</div>
      <div class="version-download-body" style="margin-top:10px;line-height:1.65;">
        已为您关闭「自动获取课件/回放列表」选项以减少请求数，您可以在<a href="#" data-action="open-extension-options" style="color:#0369a1;font-weight:700;text-decoration:underline;">扩展选项</a>中重新开启
      </div>
      <button type="button" class="btn version-notice-download-btn" data-action="acknowledge" style="margin-top:12px;" disabled>我知道了（2 秒）</button>
    </div>`;
  document.body.appendChild(modal);
  modal.style.display = 'flex';
  const optionsLink = modal.querySelector('[data-action="open-extension-options"]');
  optionsLink?.addEventListener('click', (event) => {
    event.preventDefault();
    if (typeof popupMode !== 'undefined' && popupMode) {
      window.location.href = '../options/options.html?popup=1';
      return;
    }
    chrome.runtime.openOptionsPage?.();
  });
  const acknowledge = modal.querySelector('[data-action="acknowledge"]');
  acknowledge?.addEventListener('click', async () => {
    await chrome.storage.local.set({ [AUTO_LOAD_COURSE_RESOURCES_DEFAULT_OFF_STATE_KEY]: 'done' }).catch(() => { });
    modal.remove();
  });
  const unlockAt = Date.now() + 2000;
  const countdownTimer = setInterval(() => {
    if (!(acknowledge instanceof HTMLButtonElement) || !acknowledge.isConnected) {
      clearInterval(countdownTimer);
      return;
    }
    const seconds = Math.ceil((unlockAt - Date.now()) / 1000);
    if (seconds > 0) {
      acknowledge.textContent = `我知道了（${seconds} 秒）`;
      return;
    }
    clearInterval(countdownTimer);
    acknowledge.textContent = '我知道了';
    acknowledge.disabled = false;
  }, 100);
}

async function loadAutoLoadCourseResourcesSetting() {
  try {
    const data = await chrome.storage.local.get([AUTO_LOAD_COURSE_RESOURCES_KEY]);
    window.autoLoadCourseResourcesEnabled = data[AUTO_LOAD_COURSE_RESOURCES_KEY] === undefined
      ? false
      : !!data[AUTO_LOAD_COURSE_RESOURCES_KEY];
  } catch {
    window.autoLoadCourseResourcesEnabled = false;
  }
}

function isAutoLoadCourseResourcesEnabled() {
  return window.autoLoadCourseResourcesEnabled === true;
}

function bumpPlatformLoadVersion(platform) {
  const p = normalizePlatformId(platform);
  const next = Number(window.platformLoadVersion?.[p] || 0) + 1;
  window.platformLoadVersion[p] = next;
  return next;
}

// 更新检查由可选 updater 模块提供；模块未安装时版本按钮自动隐藏。

function clearPlatformData(platform) {
  delete window.platformContentLoadProgress?.[normalizePlatformId(platform)];
  if (platform === 've') {
    window.veHomeworkPendingTypesByCourse = {};
  }
  if (platform === 'ykt') {
    window.yktMatchedHomeworkByCourseId = {};
    window.yktStandaloneCourses = [];
    window.yktMatchedCourseLinkByCourseId = {};
    window.yktCourseGroupsSnapshot = [];
    window.yktHomeworkLoadingByCourse = {};
    window.yktHomeworkPendingTypesByCourse = {};
    window.yktDetailCacheByKey = {};
    clearYktStandaloneCards();
  } else if (platform === 'mrjzy') {
    window.mrjzyMatchedHomeworkByCourseId = {};
    window.mrjzyStandaloneCourses = [];
    window.mrjzyCourseGroupsSnapshot = [];
    clearMrjzyStandaloneCards();
  } else if (platform === 'jlgj') {
    window.jlgjMatchedHomeworkByCourseId = {};
    window.jlgjStandaloneCourses = [];
    window.jlgjCourseGroupsSnapshot = [];
    clearJlgjStandaloneCards();
  } else if (platform === 'mooc') {
    window.BjtuMoocPlatform?.clear();
  } else if (platform === 'xuetangx') {
    window.BjtuXuetangxPlatform?.clear();
  }
}

// Open options button in top inline controls
const openOptionsBtn = document.getElementById('open-options-btn');
const sidePanelView = new URLSearchParams(window.location.search).get('view') === 'sidepanel';
let sidePanelQwenAvailable = false;
if (openOptionsBtn) {
  if (sidePanelView) {
    void fetch(chrome.runtime.getURL('modules/qwen/module.json'), { cache: 'no-store' }).then((response) => {
      if (!response.ok) return;
      sidePanelQwenAvailable = true;
      openOptionsBtn.textContent = '🔄';
      openOptionsBtn.title = '切换到千问助手';
    }).catch(() => {});
  }
  openOptionsBtn.addEventListener('click', () => {
    if (typeof popupMode !== 'undefined' && popupMode) {
      if (sidePanelView && sidePanelQwenAvailable) {
        try { window.parent?.postMessage({ type: 'BJTU_SIDE_PANEL_TOGGLE' }, '*'); } catch { }
        return;
      }
      // Navigate inside popup iframe instead of opening a new tab.
      try { window.location.href = '../options/options.html?popup=1'; return; } catch { }
    }
    if (chrome.runtime && chrome.runtime.openOptionsPage) {
      try { chrome.runtime.openOptionsPage(); return; } catch { }
    }
    // fallback
    try { chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html') }).then((tab) => groupBjtuOpenedTab(tab?.id)); } catch { }
  });
}

if (popupOpenFullscreenBtn) {
  popupOpenFullscreenBtn.addEventListener('click', () => {
    try {
      chrome.runtime.sendMessage({ type: 'OPEN_APP' }, () => {
        if (chrome.runtime.lastError) {
          try { chrome.tabs.create({ url: chrome.runtime.getURL('app/app.html') }).then((tab) => groupBjtuOpenedTab(tab?.id)); } catch { }
        }
      });
    } catch {
      try { chrome.tabs.create({ url: chrome.runtime.getURL('app/app.html') }).then((tab) => groupBjtuOpenedTab(tab?.id)); } catch { }
    }
  });
}

function triggerExternalPlatformLoad(platform, forceReload = false) {
  platform = normalizePlatformId(platform);
  if (!['ykt', 'mrjzy', 'jlgj', 'mooc', 'xuetangx'].includes(platform)) return Promise.resolve();
  if (!isPlatformEnabled(platform)) return Promise.resolve();
  if (!forceReload && window.platformLoadedOnce?.[platform]) return window.platformLoadPromises?.[platform] || Promise.resolve();

  if (platform === 'jlgj') {
    clearPlatformData('jlgj');
    rerenderAllHomeworkAreas();
  }

  const version = bumpPlatformLoadVersion(platform);
  // Optional platforms always acquire and normalize their own data first. Matching
  // against VE courses is a core concern handled after the module finishes.
  const independentCourseInput = [];
  const finishIndependentLoad = () => {
    if (!isPlatformEnabled(platform) || version !== Number(window.platformLoadVersion?.[platform] || 0)) return;
    rematchExternalByVeCourses(platform);
    rerenderAllHomeworkAreas();
    if (platform === 'ykt') renderYktStandaloneCourses();
    if (platform === 'mrjzy') renderMrjzyStandaloneCourses();
    if (platform === 'jlgj') renderJlgjStandaloneCourses();
  };

  let loadPromise;
  if (platform === 'ykt') {
    setPlatformLoginState('ykt', 'checking');
    loadPromise = scheduleYktLoad(independentCourseInput, version).then(finishIndependentLoad).catch(() => {
      if (isPlatformEnabled('ykt') && version === Number(window.platformLoadVersion?.ykt || 0)) renderYktNeedLoginMessage();
    });
  } else if (platform === 'mrjzy') {
    setPlatformLoginState('mrjzy', 'checking');
    loadPromise = scheduleMrjzyLoad(independentCourseInput, version).then(finishIndependentLoad).catch(() => {
      if (isPlatformEnabled('mrjzy') && version === Number(window.platformLoadVersion?.mrjzy || 0)) {
        renderMrjzyNeedLoginMessage();
      }
    });
  } else if (platform === 'jlgj') {
    setPlatformLoginState('jlgj', 'checking');
    loadPromise = scheduleJlgjLoad(independentCourseInput, version).then(finishIndependentLoad).catch((error) => {
      if (!isPlatformEnabled('jlgj') || version !== Number(window.platformLoadVersion?.jlgj || 0)) return;
      console.error('[bjtu] 接龙管家加载失败', error);
      window.platformLoadedOnce.jlgj = true;
      if ((window.jlgjCourseGroupsSnapshot || []).length) setPlatformLoginState('jlgj', 'online');
      showToast(`接龙管家加载失败：${String(error?.message || error || '未知错误')}`, 'error', 3200);
      rematchExternalByVeCourses('jlgj');
      rerenderAllHomeworkAreas();
      renderJlgjStandaloneCourses();
    });
  } else if (platform === 'mooc') {
    setPlatformLoginState('mooc', 'checking');
    loadPromise = window.BjtuMoocPlatform?.load().catch(() => { });
  } else {
    setPlatformLoginState('xuetangx', 'checking');
    loadPromise = window.BjtuXuetangxPlatform?.load().catch(() => { });
  }
  window.platformLoadPromises ||= {};
  window.platformLoadPending ||= {};
  const trackedPromise = Promise.resolve(loadPromise);
  window.platformLoadPromises[platform] = trackedPromise;
  window.platformLoadPending[platform] = true;
  void trackedPromise.finally(() => {
    if (window.platformLoadPromises?.[platform] === trackedPromise) {
      window.platformLoadPending[platform] = false;
    }
  });
  return trackedPromise;
}

async function triggerInitialPlatformLoads() {
  // Keep startup priority consistent across all enabled platforms.
  if (isPlatformEnabled('ykt')) triggerExternalPlatformLoad('ykt', false);
  if (isPlatformEnabled('mrjzy')) triggerExternalPlatformLoad('mrjzy', false);
  if (isPlatformEnabled('jlgj')) triggerExternalPlatformLoad('jlgj', false);
  if (isPlatformEnabled('xuetangx')) triggerExternalPlatformLoad('xuetangx', false);
  let veStartupResult = null;
  if (isPlatformEnabled('ve')) {
    veStartupResult = await reloadVePlatformFromSession({ reloadCourses: true, reloadResourceSpace: true });
  } else {
    window.currentVeCourseList = [];
    renderCourseList([]);
  }
  if (isPlatformEnabled('mooc')) triggerExternalPlatformLoad('mooc', false);
  return veStartupResult;
}

async function loadPlatformDetailSettings() {
  try {
    const data = await chrome.storage.local.get([
      PARALLEL_LIMIT_KEY,
      YKT_ACTIVITY_TYPES_KEY,
      HOMEWORK_DETAIL_COLLAPSED_LINES_KEY,
      COLLAPSE_HOMEWORK_DETAILS_DOWNWARD_KEY,
      SCROLL_EXPAND_HOMEWORK_LISTS_KEY,
      SCROLL_COLLAPSE_HOMEWORK_LISTS_KEY,
      REPLAY_DETAIL_COLLAPSED_LINES_KEY,
      JLGJ_DARK_MODE_KEY
    ]);
    maxParallelUploads = normalizeParallelLimit(data[PARALLEL_LIMIT_KEY], 3);
    window.yktActivityTypes = Array.isArray(data[YKT_ACTIVITY_TYPES_KEY])
      ? data[YKT_ACTIVITY_TYPES_KEY].map(Number).filter((type) => [14, 15, 5, 9].includes(type))
      : [14, 15, 5, 9];
    window.homeworkDetailCollapsedLines = normalizeDetailCollapsedLines(data[HOMEWORK_DETAIL_COLLAPSED_LINES_KEY], 3);
    window.collapseHomeworkDetailsDownward = data[COLLAPSE_HOMEWORK_DETAILS_DOWNWARD_KEY] !== false;
    window.scrollExpandHomeworkLists = data[SCROLL_EXPAND_HOMEWORK_LISTS_KEY] === true;
    window.scrollCollapseHomeworkLists = data[SCROLL_COLLAPSE_HOMEWORK_LISTS_KEY] !== false;
    window.replayDetailCollapsedLines = normalizeDetailCollapsedLines(data[REPLAY_DETAIL_COLLAPSED_LINES_KEY], 3);
    window.jlgjDarkModeEnabled = data[JLGJ_DARK_MODE_KEY] !== false;
  } catch {
    maxParallelUploads = 3;
    window.yktActivityTypes = [14, 15, 5, 9];
    window.homeworkDetailCollapsedLines = 3;
    window.collapseHomeworkDetailsDownward = true;
    window.scrollExpandHomeworkLists = false;
    window.scrollCollapseHomeworkLists = true;
    window.replayDetailCollapsedLines = 3;
    window.jlgjDarkModeEnabled = true;
  }
  applyDetailCollapsedLineSettings();
}

function normalizeParallelLimit(value, fallback = 3) {
  const limit = Math.trunc(Number(value));
  return Number.isFinite(limit) && limit > 0 ? limit : fallback;
}

function normalizeDetailCollapsedLines(value, fallback = 3) {
  if (value === '' || value === null || value === undefined) return fallback;
  const lines = Number(value);
  return Number.isFinite(lines) && lines >= 0 ? Math.trunc(lines) : fallback;
}

function applyDetailCollapsedLineSettings() {
  document.documentElement.style.setProperty(
    '--homework-detail-max-height',
    detailCollapsedMaxHeight(window.homeworkDetailCollapsedLines)
  );
  document.documentElement.style.setProperty(
    '--replay-detail-max-height',
    detailCollapsedMaxHeight(window.replayDetailCollapsedLines)
  );
}

function detailCollapsedMaxHeight(lines) {
  return `calc(${normalizeDetailCollapsedLines(lines, 3) * 1.5}em + 2px)`;
}

async function loadPlatformAutoLoginSettings() {
  try {
    const stored = await chrome.storage.local.get(Object.values(PLATFORM_AUTO_LOGIN_STORAGE_KEYS));
    window.platformAutoLoginOnExpiry = Object.fromEntries(PLATFORM_IDS.map((platform) => {
      const key = PLATFORM_AUTO_LOGIN_STORAGE_KEYS[platform];
      return [platform, stored[key] === undefined
        ? DEFAULT_PLATFORM_AUTO_LOGIN_ON_EXPIRY[platform]
        : stored[key] === true];
    }));
  } catch {
    window.platformAutoLoginOnExpiry = { ...DEFAULT_PLATFORM_AUTO_LOGIN_ON_EXPIRY };
  }
}

function detailVisibleMaxHeight(lines) {
  return `calc(${normalizeDetailCollapsedLines(lines, 3) * 1.5}em + 2px)`;
}

function rematchExternalByVeCourses(platform = '') {
  const veCourses = Array.isArray(window.currentVeCourseList) ? window.currentVeCourseList : [];
  const shouldRematch = (id) => !platform || platform === id;
  const keepPlatformsSeparate = shouldUseCoursePlatformColumns();

  if (shouldRematch('ykt') && isPlatformEnabled('ykt') && Array.isArray(window.yktCourseGroupsSnapshot) && window.yktCourseGroupsSnapshot.length) {
    const yktStrictMap = collectVeFzIdTail10Map(veCourses);
    window.yktMatchedHomeworkByCourseId = {};
    window.yktMatchedCourseLinkByCourseId = {};
    window.yktStandaloneCourses = [];
    window.yktCourseGroupsSnapshot.forEach((group) => {
      const strictToken = String(group?.strictToken || group?.token || '').trim();
      const matched = !keepPlatformsSeparate && strictToken ? yktStrictMap.get(strictToken) : null;
      if (matched?.courseId) {
        const cid = String(matched.courseId);
        if (!window.yktMatchedHomeworkByCourseId[cid]) window.yktMatchedHomeworkByCourseId[cid] = [];
        window.yktMatchedHomeworkByCourseId[cid].push(...(group?.homeworks || []));
        window.yktMatchedCourseLinkByCourseId[cid] = yktCourseLink(group?.classroom_id);
      } else {
        window.yktStandaloneCourses.push({
          name: group?.name || '',
          teacher_name: group?.teacher_name || '',
          classroom_id: group?.classroom_id,
          course_name: group?.course_name || group?.name || '雨课堂课程',
          homeworks: Array.isArray(group?.homeworks) ? group.homeworks : []
        });
      }
    });
  }

  if (shouldRematch('mrjzy') && isPlatformEnabled('mrjzy') && Array.isArray(window.mrjzyCourseGroupsSnapshot) && window.mrjzyCourseGroupsSnapshot.length) {
    const mrjzyMatchMap = collectCourseNameMatchMap(veCourses);
    window.mrjzyMatchedHomeworkByCourseId = {};
    window.mrjzyStandaloneCourses = [];
    window.mrjzyCourseGroupsSnapshot.forEach((group) => {
      const matched = keepPlatformsSeparate ? null : mrjzyMatchMap.get(String(group?.token || ''));
      if (matched?.courseId) {
        const cid = String(matched.courseId);
        if (!window.mrjzyMatchedHomeworkByCourseId[cid]) window.mrjzyMatchedHomeworkByCourseId[cid] = [];
        window.mrjzyMatchedHomeworkByCourseId[cid].push(...(group?.homeworks || []));
      } else {
        window.mrjzyStandaloneCourses.push({
          divClass: group?.divClass || '每日交作业课程',
          classNum: group?.classNum,
          teacherName: group?.teacherName || '',
          homeworks: Array.isArray(group?.homeworks) ? group.homeworks : []
        });
      }
    });
  }

  if (shouldRematch('jlgj') && isPlatformEnabled('jlgj') && Array.isArray(window.jlgjCourseGroupsSnapshot) && window.jlgjCourseGroupsSnapshot.length) {
    const jlgjMatchMap = collectCourseNameMatchMap(veCourses);
    window.jlgjMatchedHomeworkByCourseId = {};
    window.jlgjStandaloneCourses = [];
    window.jlgjCourseGroupsSnapshot.forEach((group) => {
      const matched = keepPlatformsSeparate ? null : jlgjMatchMap.get(String(group?.token || ''));
      if (matched?.courseId) {
        const cid = String(matched.courseId);
        if (!window.jlgjMatchedHomeworkByCourseId[cid]) window.jlgjMatchedHomeworkByCourseId[cid] = [];
        window.jlgjMatchedHomeworkByCourseId[cid].push(...(group?.homeworks || []));
      } else {
        window.jlgjStandaloneCourses.push({
          name: group?.name || '接龙管家课程',
          groupId: group?.groupId,
          teacherName: group?.teacherName || '',
          homeworks: Array.isArray(group?.homeworks) ? group.homeworks : []
        });
      }
    });
  }
}

function rerenderAllHomeworkAreas() {
  Object.keys(window.courseHomeworkData || {}).forEach((cid) => {
    renderHomeworkList(cid);
  });
  syncCourseActionLoadingSpinnerPhase();
}

function renderEnabledExternalStandaloneCourses() {
  if (isPlatformEnabled('ykt') && typeof renderYktStandaloneCourses === 'function') renderYktStandaloneCourses();
  if (isPlatformEnabled('mrjzy') && typeof renderMrjzyStandaloneCourses === 'function') renderMrjzyStandaloneCourses();
  if (isPlatformEnabled('jlgj') && typeof renderJlgjStandaloneCourses === 'function') renderJlgjStandaloneCourses();
  if (isPlatformEnabled('mooc') && window.platformLoadedOnce?.mooc) window.BjtuMoocPlatform?.render();
  if (isPlatformEnabled('xuetangx') && window.platformLoadedOnce?.xuetangx) window.BjtuXuetangxPlatform?.render();
}
globalThis.renderEnabledExternalStandaloneCourses = renderEnabledExternalStandaloneCourses;

function hasMatchedExternalHomework(courseId) {
  const id = String(courseId || '');
  return ((window.yktMatchedHomeworkByCourseId?.[id] || []).length > 0)
    || ((window.mrjzyMatchedHomeworkByCourseId?.[id] || []).length > 0)
    || ((window.jlgjMatchedHomeworkByCourseId?.[id] || []).length > 0);
}

function isPlatformChecking(platform) {
  const p = normalizePlatformId(platform);
  return isPlatformEnabled(p) && window.platformLoginState?.[p] === 'checking';
}

function togglePlatformSelection(platform, options = {}) {
  platform = normalizePlatformId(platform);
  if (!platform || !PLATFORM_IDS.includes(platform)) return;
  const interactive = options?.interactive !== false;
  const persist = options?.persist !== false;
  if (isPlatformChecking(platform)) {
    if (platform === 've') {
      window.platformInteractiveLoginPending.ve = false;
      if (loginModal?.style.display !== 'none') dismissLoginModal();
    }
    if (platform === 'ykt') {
      window.platformInteractiveLoginPending.ykt = false;
      closeYktLoginAssistPopup(true);
    }
    if (platform === 'mrjzy') {
      window.platformInteractiveLoginPending.mrjzy = false;
      closeMrjzyLoginAssistPopup(true);
      cancelMrjzyActiveLoad().catch(() => {});
    }
    if (platform === 'jlgj') {
      window.platformInteractiveLoginPending.jlgj = false;
      closeJlgjLoginAssistPopup(true);
    }
    if (platform === 'mooc') {
      window.platformInteractiveLoginPending.mooc = false;
      closeMoocLoginAssistPopup(true);
    }
    window.platformEnabled[platform] = false;
    window.platformLoadedOnce[platform] = false;
    bumpPlatformLoadVersion(platform);
    setPlatformLoginState(platform, 'offline');
    if (persist) savePlatformEnabledToStorage().catch(() => { });
    refreshPlatformLoginTip();

    if (platform === 've') {
      abortAllCoursewareReplayFetches();
      if (Array.isArray(window.currentVeCourseList) && window.currentVeCourseList.length) {
        window.veDisabledCourseListCache = window.currentVeCourseList.slice();
      }
      window.currentVeCourseList = [];
      window.courseListLoadVersion = Number(window.courseListLoadVersion || 0) + 1;
      renderCourseList([]);
      rematchExternalByVeCourses();
      rerenderAllHomeworkAreas();
      if (isPlatformEnabled('ykt')) renderYktStandaloneCourses();
      if (isPlatformEnabled('mrjzy')) renderMrjzyStandaloneCourses();
      if (isPlatformEnabled('jlgj')) renderJlgjStandaloneCourses();
    } else {
      clearPlatformData(platform);
      rerenderAllHomeworkAreas();
    }
    return;
  }

  const enabled = !isPlatformEnabled(platform);
  window.platformEnabled[platform] = enabled;
  if (persist) savePlatformEnabledToStorage().catch(() => { });
  refreshPlatformLoginTip();

  if (!enabled) {
    bumpPlatformLoadVersion(platform);
    if (platform === 'ykt') {
      window.platformInteractiveLoginPending.ykt = false;
      closeYktLoginAssistPopup(true);
    }
    if (platform === 'mrjzy') {
      window.platformInteractiveLoginPending.mrjzy = false;
      closeMrjzyLoginAssistPopup(true);
      cancelMrjzyActiveLoad().catch(() => {});
    }
    if (platform === 'jlgj') {
      window.platformInteractiveLoginPending.jlgj = false;
      closeJlgjLoginAssistPopup(true);
    }
    if (platform === 'mooc') {
      window.platformInteractiveLoginPending.mooc = false;
      closeMoocLoginAssistPopup(true);
    }
    window.platformLoadedOnce[platform] = false;
    if (platform === 've') {
      window.courseListLoadVersion = window.platformLoadVersion.ve;
      abortAllCoursewareReplayFetches();
      if (Array.isArray(window.currentVeCourseList) && window.currentVeCourseList.length) {
        window.veDisabledCourseListCache = window.currentVeCourseList.slice();
      }
      window.currentVeCourseList = [];
      renderCourseList([]);
      rematchExternalByVeCourses();
      rerenderAllHomeworkAreas();
      if (isPlatformEnabled('ykt')) renderYktStandaloneCourses();
      if (isPlatformEnabled('mrjzy')) renderMrjzyStandaloneCourses();
      if (isPlatformEnabled('jlgj')) renderJlgjStandaloneCourses();
    } else {
      clearPlatformData(platform);
      rerenderAllHomeworkAreas();
    }
    return;
  }

  if (platform === 've') {
    window.platformInteractiveLoginPending.ve = !!interactive;
    window.platformLoadedOnce.ve = false;
    setPlatformLoginState('ve', 'checking');
    const cachedCourses = Array.isArray(window.veDisabledCourseListCache)
      ? window.veDisabledCourseListCache
      : [];
    if (cachedCourses.length) {
      window.currentVeCourseList = cachedCourses.slice();
      renderCourseList(window.currentVeCourseList, { cachedOnly: true });
      rematchExternalByVeCourses();
      rerenderAllHomeworkAreas();
    }
    if (isPlatformEnabled('ve')) {
      void (async () => {
        await loadAutoLoadCourseResourcesSetting();
        await reloadVePlatformFromSession({ reloadCourses: true, reloadResourceSpace: true });
      })();
    }
    return;
  }

  if (platform === 'ykt' || platform === 'mrjzy' || platform === 'jlgj' || platform === 'mooc' || platform === 'xuetangx') {
    window.platformInteractiveLoginPending[platform] = !!interactive;
  }

  clearPlatformData(platform);
  rerenderAllHomeworkAreas();
  triggerExternalPlatformLoad(platform, true);
}

function applyPlatformEnabledSettingFromStorage(raw) {
  const next = sanitizePlatformEnabled(raw, window.platformEnabled || DEFAULT_PLATFORM_ENABLED);
  PLATFORM_IDS.forEach((platform) => {
    if (isPlatformEnabled(platform) !== !!next[platform]) {
      togglePlatformSelection(platform, { interactive: false, persist: false });
    }
  });
}

let optionsStorageLiveSyncReady = false;
function setupOptionsStorageLiveSync() {
  if (optionsStorageLiveSyncReady || !chrome?.storage?.onChanged) return;
  optionsStorageLiveSyncReady = true;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;

    if (changes.platformEnabled) {
      applyPlatformEnabledSettingFromStorage(changes.platformEnabled.newValue);
    }
    if (changes.platformVisible) {
      window.platformVisible = sanitizePlatformVisible(changes.platformVisible.newValue, window.platformVisible);
      applyPlatformVisibility();
    }
    Object.entries(PLATFORM_AUTO_LOGIN_STORAGE_KEYS).forEach(([platform, key]) => {
      if (changes[key]) window.platformAutoLoginOnExpiry[platform] = changes[key].newValue === true;
    });
    if (changes.platformOrder) {
      window.platformOrder = normalizePlatformOrderForApp(changes.platformOrder.newValue);
      applyPlatformOrderInApp();
      scheduleCourseCardsByPlatform();
    }
    if ((changes.xuetangxCourseStatuses || changes.xuetangxActivityTypes) && isPlatformEnabled('xuetangx')) {
      clearPlatformData('xuetangx');
      window.platformLoadedOnce.xuetangx = false;
      triggerExternalPlatformLoad('xuetangx', true);
    }
    if (changes.mrjzyAutoLoginClass
      && changes.mrjzyAutoLoginClass.oldValue !== changes.mrjzyAutoLoginClass.newValue
      && isPlatformEnabled('mrjzy')) {
      const selectedClass = String(changes.mrjzyAutoLoginClass.newValue || '');
      void Promise.resolve(globalThis.BjtuMrjzySwitchConfiguredClass?.(selectedClass)).then((result) => {
        if (result?.stale) return;
        if (!result?.ok) {
          showToast('每日交作业班级切换失败，请重新登录', 'error', 3000);
          return;
        }
        clearPlatformData('mrjzy');
        window.platformLoadedOnce.mrjzy = false;
        triggerExternalPlatformLoad('mrjzy', true);
      }).catch((error) => {
        showToast(`每日交作业班级切换失败：${String(error?.message || error)}`, 'error', 3200);
      });
    }
    if (!popupMode && changes[COURSE_HELPER_EXPANDED_DEFAULT_KEY]) {
      setCourseHelperFocusMode(changes[COURSE_HELPER_EXPANDED_DEFAULT_KEY].newValue === true);
    }
    if (!popupMode && (changes[FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY] || changes[STICKY_COURSE_HEADER_KEY])) {
      applyFullscreenHeaderLayout(
        changes[FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY]
          ? changes[FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY].newValue === true
          : !document.body.classList.contains('page-top-config-in-left-column'),
        changes[STICKY_COURSE_HEADER_KEY]
          ? changes[STICKY_COURSE_HEADER_KEY].newValue !== false
          : document.body.classList.contains('course-header-sticky')
      );
    }
    if (!popupMode && changes[SHOW_COURSE_LIST_DURING_LAYOUT_TRANSITION_KEY]) {
      window.showCourseListDuringLayoutTransition = changes[SHOW_COURSE_LIST_DURING_LAYOUT_TRANSITION_KEY].newValue === true;
      syncCourseHelperLayoutProcessingPlaceholder();
    }
    if (changes.saveUploadedFilesEnabled) {
      window.saveUploadedFilesEnabled = changes.saveUploadedFilesEnabled.newValue === undefined
        ? true
        : !!changes.saveUploadedFilesEnabled.newValue;
      const cb = document.getElementById('save-uploads-enabled');
      if (cb instanceof HTMLInputElement) cb.checked = !!window.saveUploadedFilesEnabled;
    }

    if (changes.popupUseFullscreenCacheEnabled) {
      window.popupUseFullscreenCacheEnabled = changes.popupUseFullscreenCacheEnabled.newValue === undefined
        ? true
        : !!changes.popupUseFullscreenCacheEnabled.newValue;
      if (window.popupUseFullscreenCacheEnabled || window.sidePanelUseFullscreenCacheEnabled) {
        scheduleFullscreenCourseCacheSave(200);
      }
    }
    if (changes.sidePanelUseFullscreenCacheEnabled) {
      window.sidePanelUseFullscreenCacheEnabled = changes.sidePanelUseFullscreenCacheEnabled.newValue === undefined
        ? true
        : !!changes.sidePanelUseFullscreenCacheEnabled.newValue;
      if (window.popupUseFullscreenCacheEnabled || window.sidePanelUseFullscreenCacheEnabled) {
        scheduleFullscreenCourseCacheSave(200);
      }
    }

    if (changes[AUTO_LOAD_COURSE_RESOURCES_KEY]) {
      window.autoLoadCourseResourcesEnabled = changes[AUTO_LOAD_COURSE_RESOURCES_KEY].newValue === undefined
        ? false
        : !!changes[AUTO_LOAD_COURSE_RESOURCES_KEY].newValue;
      if (window.autoLoadCourseResourcesEnabled) {
        autoLoadCourseResourcesForRenderedCourses();
      }
    }
    if (changes[COLLAPSE_HOMEWORK_DETAILS_DOWNWARD_KEY]) {
      window.collapseHomeworkDetailsDownward = changes[COLLAPSE_HOMEWORK_DETAILS_DOWNWARD_KEY].newValue !== false;
    }
    if (changes.downloadInExtensionEnabled) {
      window.downloadInExtensionEnabled = changes.downloadInExtensionEnabled.newValue !== false;
      const cb = document.getElementById('download-in-extension-enabled');
      if (cb instanceof HTMLInputElement) cb.checked = window.downloadInExtensionEnabled;
    }
    if (changes[SCROLL_EXPAND_HOMEWORK_LISTS_KEY]) {
      window.scrollExpandHomeworkLists = changes[SCROLL_EXPAND_HOMEWORK_LISTS_KEY].newValue === true;
    }
    if (changes[SCROLL_COLLAPSE_HOMEWORK_LISTS_KEY]) {
      window.scrollCollapseHomeworkLists = changes[SCROLL_COLLAPSE_HOMEWORK_LISTS_KEY].newValue !== false;
    }
    if (changes[HOMEWORK_DETAIL_COLLAPSED_LINES_KEY] || changes[REPLAY_DETAIL_COLLAPSED_LINES_KEY]) {
      if (changes[HOMEWORK_DETAIL_COLLAPSED_LINES_KEY]) {
        window.homeworkDetailCollapsedLines = normalizeDetailCollapsedLines(
          changes[HOMEWORK_DETAIL_COLLAPSED_LINES_KEY].newValue,
          3
        );
      }
      if (changes[REPLAY_DETAIL_COLLAPSED_LINES_KEY]) {
        window.replayDetailCollapsedLines = normalizeDetailCollapsedLines(
          changes[REPLAY_DETAIL_COLLAPSED_LINES_KEY].newValue,
          3
        );
      }
      applyDetailCollapsedLineSettings();
      requestAnimationFrame(() => applyExpandableAutoToggle(document));
    }
    if (changes[PARALLEL_LIMIT_KEY]) {
      maxParallelUploads = normalizeParallelLimit(changes[PARALLEL_LIMIT_KEY].newValue, 3);
      if (typeof processQueue === 'function') processQueue();
      if (typeof processResourceDownloadQueue === 'function') processResourceDownloadQueue();
    }
    if (changes[YKT_ACTIVITY_TYPES_KEY]) {
      window.yktActivityTypes = Array.isArray(changes[YKT_ACTIVITY_TYPES_KEY].newValue)
        ? changes[YKT_ACTIVITY_TYPES_KEY].newValue.map(Number).filter((type) => [14, 15, 5, 9].includes(type))
        : [14, 15, 5, 9];
      if (isPlatformEnabled('ykt')) {
        scheduleYktLoad([]).then(() => {
          rematchExternalByVeCourses('ykt');
          rerenderAllHomeworkAreas();
          renderYktStandaloneCourses();
        }).catch(() => { });
      }
    }
    if (changes[JLGJ_DARK_MODE_KEY]) {
      window.jlgjDarkModeEnabled = changes[JLGJ_DARK_MODE_KEY].newValue !== false;
    }
  });
}

let portalUsernameBindMessageListenerReady = false;
function setupPortalUsernameBindMessageListener() {
  if (portalUsernameBindMessageListenerReady || !chrome?.runtime?.onMessage) return;
  portalUsernameBindMessageListenerReady = true;
  chrome.runtime.onMessage.addListener((message) => {
    void (async () => {
      if (message?.type !== 'PORTAL_USERNAME_BIND_STATUS') return;
      const st = message.payload || {};
      if (st.status !== 'done') return;
      showToast(`已绑定极速登录 username：${st.userId || st.quickUsername || ''}`, 'success', 1800);
      if (isPlatformEnabled('ve')) {
        await loadAutoLoadCourseResourcesSetting().catch(() => { });
        window.platformLoadedOnce.ve = false;
        setPlatformLoginState('ve', 'checking');
        await loadLoginAccountHistory().catch(() => { });
        await reloadVePlatformFromSession({ reloadCourses: true, reloadResourceSpace: true });
      }
    })();
  });
}

function refreshUploadSelectVisibility() {
  const wraps = document.querySelectorAll('.upload-select-wrap');
  wraps.forEach((wrap) => {
    wrap.style.display = 'inline-flex';
  });
}

const COURSE_PLATFORM_COLUMNS = Object.freeze([
  { id: 've', label: '智慧课程平台' },
  { id: 'ykt', label: '雨课堂' },
  { id: 'mrjzy', label: '每日交作业' },
  { id: 'jlgj', label: '接龙管家' },
  { id: 'mooc', label: '中国大学MOOC' },
  { id: 'xuetangx', label: '学堂在线' }
]);
function getOrderedCoursePlatformColumns() {
  const byId = new Map(COURSE_PLATFORM_COLUMNS.map((item) => [item.id, item]));
  return normalizePlatformOrderForApp(window.platformOrder)
    .map((id) => byId.get(id))
    .filter(Boolean);
}
const COURSE_HELPER_EXPANDED_DEFAULT_KEY = 'courseHelperExpandedByDefault';
const FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY = 'fullscreenTopBarFullWidth';
const STICKY_COURSE_HEADER_KEY = 'stickyCourseHeader';
const SHOW_COURSE_LIST_DURING_LAYOUT_TRANSITION_KEY = 'showCourseListDuringLayoutTransition';
const COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY = 'courseHelperPlatformColumnWeights';
const COURSE_HELPER_PLATFORM_COLUMN_MIN_WIDTH = 240;
const COURSE_HELPER_LAYOUT_TRANSITION_MS = 240;
let coursePlatformOrganizeFrame = 0;
let coursePlatformOrganizing = false;
let coursePlatformColumnDragCleanup = null;
let courseHelperLayoutTransitionTimer = 0;
let courseHelperLayoutTransitioning = false;
let courseHelperLayoutWorkPending = false;

function applyFullscreenHeaderLayout(fullWidth, sticky) {
  if (popupMode || appSearchParams.get('view') === 'sidepanel') return;
  const topConfig = document.querySelector('.page-top-config');
  if (!(topConfig instanceof HTMLElement) || !leftColumn || !layoutContainer) return;
  const courseListStage = rightColumn?.querySelector('.course-list-stage');
  const wasSticky = document.body.classList.contains('course-header-sticky');
  const previousScrollTop = wasSticky ? courseListStage?.scrollTop || 0 : rightColumn?.scrollTop || 0;
  const courseHeader = rightColumn?.querySelector('.course-header');
  const headerHeight = courseHeader
    ? courseHeader.offsetHeight + (parseFloat(getComputedStyle(courseHeader).marginBottom) || 0)
    : 0;
  if (fullWidth) document.body.insertBefore(topConfig, layoutContainer);
  else leftColumn.prepend(topConfig);
  document.body.classList.toggle('page-top-config-in-left-column', !fullWidth);
  document.body.classList.toggle('course-header-sticky', sticky);
  if (wasSticky !== sticky) {
    rightColumn.scrollTop = 0;
    if (courseListStage instanceof HTMLElement) courseListStage.scrollTop = 0;
    if (sticky && courseListStage instanceof HTMLElement) {
      courseListStage.scrollTop = Math.max(0, previousScrollTop - headerHeight);
    } else if (!sticky) {
      rightColumn.scrollTop = previousScrollTop + (previousScrollTop > 0 ? headerHeight : 0);
    }
  }
  window.syncRightColumnResizer?.();
}

function shouldSuspendCourseHelperLayoutWork() {
  return !popupMode
    && courseHelperLayoutTransitioning
    && window.showCourseListDuringLayoutTransition !== true;
}

function suspendPendingCourseHelperLayoutWork() {
  if (!coursePlatformOrganizeFrame) return;
  cancelAnimationFrame(coursePlatformOrganizeFrame);
  coursePlatformOrganizeFrame = 0;
  courseHelperLayoutWorkPending = true;
}

function revealCourseHelperAfterSettledLayout() {
  requestAnimationFrame(() => requestAnimationFrame(() => {
    syncCourseHelperLayoutProcessingPlaceholder();
    window.syncRightColumnResizer?.();
  }));
}

function syncCourseHelperLayoutProcessingPlaceholder() {
  document.body.classList.toggle(
    'course-helper-layout-processing',
    !popupMode && courseHelperLayoutTransitioning && window.showCourseListDuringLayoutTransition !== true
  );
}

function isCourseHelperAdaptiveLayout() {
  return window.matchMedia('(max-width: 900px), (orientation: portrait)').matches;
}

function shouldUseCoursePlatformColumns() {
  if (popupMode) return false;
  return isCourseHelperAdaptiveLayout()
    ? window.courseHelperPlatformSplitMode !== true
    : window.courseHelperPlatformSplitMode === true;
}

function syncCourseHelperCollapseTogglePresentation() {
  if (!(columnCollapseToggle instanceof HTMLButtonElement)) return;
  const focused = window.courseHelperPlatformSplitMode === true;
  const adaptive = isCourseHelperAdaptiveLayout();
  const action = focused ? (adaptive ? '展开上方' : '折叠右栏') : (adaptive ? '折叠上方' : '展开右栏');
  columnCollapseToggle.textContent = focused ? (adaptive ? '▼' : '▶') : (adaptive ? '▲' : '◀');
  columnCollapseToggle.title = action;
  columnCollapseToggle.setAttribute('aria-label', action);
  columnCollapseToggle.setAttribute('aria-expanded', focused ? 'false' : 'true');
  if (columnResizer instanceof HTMLElement) {
    columnResizer.title = adaptive ? '拖动调整上下栏高度' : '拖动调整课程助手宽度';
  }
}

function getCourseCardPlatform(card) {
  if (!(card instanceof HTMLElement)) return '';
  const explicit = String(card.dataset.platform || '').trim().toLowerCase();
  if (COURSE_PLATFORM_COLUMNS.some((item) => item.id === explicit)) return explicit;
  const courseId = String(card.dataset.courseId || card.id || '').replace(/^course-/, '').toLowerCase();
  if (courseId.startsWith('ykt-') || card.classList.contains('ykt-standalone-card')) return 'ykt';
  if (courseId.startsWith('mrjzy-') || card.classList.contains('mrjzy-standalone-card')) return 'mrjzy';
  if (courseId.startsWith('jlgj-') || card.classList.contains('jlgj-standalone-card')) return 'jlgj';
  if (courseId.startsWith('mooc-') || card.classList.contains('mooc-standalone-card')) return 'mooc';
  if (courseId.startsWith('xuetangx-') || card.classList.contains('xuetangx-standalone-card')) return 'xuetangx';
  return 've';
}

function unwrapCoursePlatformColumns() {
  if (!courseListDiv) return;
  coursePlatformColumnDragCleanup?.();
  const columns = [...courseListDiv.querySelectorAll(':scope > .platform-course-column')];
  columns.forEach((column) => {
    column.querySelectorAll(':scope > .platform-course-column-body > .file-item[data-course-rankable="1"]').forEach((card) => {
      courseListDiv.appendChild(card);
    });
    column.remove();
  });
  courseListDiv.querySelectorAll(':scope > .platform-column-resizer').forEach((resizer) => resizer.remove());
  courseListDiv.classList.remove('platform-split-grid');
  courseListDiv.style.removeProperty('grid-template-columns');
  syncCourseHelperEvenWidthsButton();
}

function normalizeCourseHelperPlatformColumnWeights(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  return Object.fromEntries(COURSE_PLATFORM_COLUMNS.map(({ id }) => {
    const value = Number(source[id]);
    return [id, Number.isFinite(value) && value > 0 ? value : 1];
  }));
}

function readCourseHelperPlatformColumnWeightsFromLocalStorage() {
  try {
    const raw = localStorage.getItem(COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY);
    if (raw === null) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function saveCourseHelperPlatformColumnWeightsToLocalStorage(weights) {
  try {
    localStorage.setItem(
      COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY,
      JSON.stringify(normalizeCourseHelperPlatformColumnWeights(weights))
    );
  } catch {
    // Keep the in-memory layout when local storage is unavailable.
  }
}

function getActiveCourseHelperPlatformIds() {
  if (!courseListDiv) return [];
  return [...courseListDiv.querySelectorAll(':scope > .platform-course-column')]
    .map((column) => String(column.dataset.platform || ''))
    .filter(Boolean);
}

function syncCourseHelperEvenWidthsButton() {
  if (!(courseHelperEvenWidthsButton instanceof HTMLButtonElement)) return;
  const activeIds = getActiveCourseHelperPlatformIds();
  const weights = normalizeCourseHelperPlatformColumnWeights(window.courseHelperPlatformColumnWeights);
  const activeWeights = activeIds.map((id) => Number(weights[id] || 1));
  const uneven = activeWeights.length > 1
    && Math.max(...activeWeights) - Math.min(...activeWeights) > 0.01;
  courseHelperEvenWidthsButton.hidden = popupMode
    || !shouldUseCoursePlatformColumns()
    || !uneven;
}

function applyCourseHelperPlatformColumnWeights() {
  if (!courseListDiv) return;
  const weights = normalizeCourseHelperPlatformColumnWeights(window.courseHelperPlatformColumnWeights);
  courseListDiv.querySelectorAll(':scope > .platform-course-column').forEach((column) => {
    const platform = String(column.dataset.platform || '');
    column.style.flex = `${weights[platform] || 1} 1 0px`;
  });
  syncCourseHelperEvenWidthsButton();
}

async function persistCourseHelperPlatformColumnWeights() {
  if (!courseListDiv || popupMode) return;
  const columns = [...courseListDiv.querySelectorAll(':scope > .platform-course-column')];
  const next = { ...normalizeCourseHelperPlatformColumnWeights(window.courseHelperPlatformColumnWeights) };
  const activeWidths = columns.map((column) => column.getBoundingClientRect().width).filter((value) => Number.isFinite(value) && value > 0);
  const averageWidth = activeWidths.length
    ? activeWidths.reduce((sum, value) => sum + value, 0) / activeWidths.length
    : 1;
  columns.forEach((column) => {
    const platform = String(column.dataset.platform || '');
    const weight = column.getBoundingClientRect().width;
    if (platform && Number.isFinite(weight) && weight > 0) next[platform] = weight / averageWidth;
  });
  window.courseHelperPlatformColumnWeights = next;
  applyCourseHelperPlatformColumnWeights();
  saveCourseHelperPlatformColumnWeightsToLocalStorage(next);
}

function bindPlatformColumnResizer(resizer) {
  if (!(resizer instanceof HTMLElement) || resizer.dataset.bound === '1') return;
  resizer.dataset.bound = '1';
  resizer.addEventListener('mousedown', (event) => {
    if (event.button !== 0 || popupMode || !shouldUseCoursePlatformColumns()) return;
    const leftPlatform = String(resizer.dataset.leftPlatform || '');
    const rightPlatform = String(resizer.dataset.rightPlatform || '');
    const leftColumn = courseListDiv.querySelector(`:scope > .platform-course-column[data-platform="${leftPlatform}"]`);
    const rightColumn = courseListDiv.querySelector(`:scope > .platform-course-column[data-platform="${rightPlatform}"]`);
    if (!(leftColumn instanceof HTMLElement) || !(rightColumn instanceof HTMLElement)) return;

    event.preventDefault();
    coursePlatformColumnDragCleanup?.();
    const allColumns = [...courseListDiv.querySelectorAll(':scope > .platform-course-column')];
    const columnWidths = new Map(allColumns.map((column) => [column, column.getBoundingClientRect().width]));
    allColumns.forEach((column) => {
      const width = Math.max(1, Number(columnWidths.get(column) || 0));
      column.style.flex = `0 0 ${width}px`;
    });
    const leftRect = leftColumn.getBoundingClientRect();
    const leftStart = Number(columnWidths.get(leftColumn) || leftRect.width);
    const rightStart = Number(columnWidths.get(rightColumn) || rightColumn.getBoundingClientRect().width);
    const pairWidth = leftStart + rightStart;
    const pairLeft = leftRect.left;
    const resizerCenterOffset = resizer.getBoundingClientRect().width / 2;
    const minWidth = Math.min(COURSE_HELPER_PLATFORM_COLUMN_MIN_WIDTH, Math.max(80, pairWidth / 2));
    resizer.classList.add('dragging');
    document.body.classList.add('platform-column-resizing');

    const onMove = (moveEvent) => {
      const pointerWidth = moveEvent.clientX - pairLeft - resizerCenterOffset;
      const nextLeft = Math.max(minWidth, Math.min(pairWidth - minWidth, pointerWidth));
      leftColumn.style.flex = `0 0 ${nextLeft}px`;
      rightColumn.style.flex = `0 0 ${pairWidth - nextLeft}px`;
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      resizer.classList.remove('dragging');
      document.body.classList.remove('platform-column-resizing');
      coursePlatformColumnDragCleanup = null;
      void persistCourseHelperPlatformColumnWeights();
    };
    coursePlatformColumnDragCleanup = onUp;
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });
}

function organizeCourseCardsByPlatform() {
  if (!courseListDiv || coursePlatformOrganizing || coursePlatformColumnDragCleanup) return;
  if (shouldSuspendCourseHelperLayoutWork()) {
    courseHelperLayoutWorkPending = true;
    return;
  }
  coursePlatformOrganizing = true;
  try {
    const cards = [...courseListDiv.querySelectorAll('.file-item[data-course-rankable="1"]')];
    const cardPlatforms = new Set(cards.map(getCourseCardPlatform).filter(Boolean));
    const desired = getOrderedCoursePlatformColumns().filter(({ id }) => isPlatformEnabled(id) || cardPlatforms.has(id));
    if (!shouldUseCoursePlatformColumns()) {
      unwrapCoursePlatformColumns();
      return;
    }

    const desiredIds = new Set(desired.map(({ id }) => id));
    let structureChanged = false;

    courseListDiv.querySelectorAll(':scope > .platform-course-column').forEach((column) => {
      if (!desiredIds.has(String(column.dataset.platform || ''))) {
        column.remove();
        structureChanged = true;
      }
    });
    const desiredPairs = new Set(desired.slice(1).map(({ id }, index) => `${desired[index].id}|${id}`));
    const retainedPairs = new Set();
    courseListDiv.querySelectorAll(':scope > .platform-column-resizer').forEach((resizer) => {
      const pair = `${String(resizer.dataset.leftPlatform || '')}|${String(resizer.dataset.rightPlatform || '')}`;
      if (!desiredPairs.has(pair) || retainedPairs.has(pair)) {
        resizer.remove();
        structureChanged = true;
      } else {
        retainedPairs.add(pair);
      }
    });

    const columns = new Map();
    desired.forEach(({ id }) => {
      let column = courseListDiv.querySelector(`:scope > .platform-course-column[data-platform="${id}"]`);
      if (!(column instanceof HTMLElement)) {
        column = document.createElement('section');
        column.className = 'platform-course-column';
        column.dataset.platform = id;
        column.innerHTML = '<div class="platform-course-column-body"></div><div class="platform-course-column-empty"></div>';
        courseListDiv.appendChild(column);
        structureChanged = true;
      }
      columns.set(id, column);
    });

    const orderedLayoutNodes = [];
    desired.forEach(({ id }, index) => {
      if (index > 0) {
        const leftPlatform = desired[index - 1].id;
        let resizer = courseListDiv.querySelector(`:scope > .platform-column-resizer[data-left-platform="${leftPlatform}"][data-right-platform="${id}"]`);
        if (!(resizer instanceof HTMLElement)) {
          resizer = document.createElement('div');
          resizer.className = 'platform-column-resizer';
          resizer.dataset.leftPlatform = leftPlatform;
          resizer.dataset.rightPlatform = id;
          resizer.title = '拖动调整平台列宽';
          bindPlatformColumnResizer(resizer);
          structureChanged = true;
        }
        orderedLayoutNodes.push(resizer);
      }
      orderedLayoutNodes.push(columns.get(id));
    });
    const currentLayoutNodes = [...courseListDiv.children].filter((node) => (
      node.classList.contains('platform-course-column') || node.classList.contains('platform-column-resizer')
    ));
    const layoutOrderMatches = currentLayoutNodes.length === orderedLayoutNodes.length
      && currentLayoutNodes.every((node, index) => node === orderedLayoutNodes[index]);
    if (!layoutOrderMatches) {
      orderedLayoutNodes.forEach((node) => courseListDiv.appendChild(node));
      structureChanged = true;
    }

    cards.forEach((card) => {
      const platform = getCourseCardPlatform(card);
      card.dataset.platform = platform;
      const body = columns.get(platform)?.querySelector('.platform-course-column-body');
      if (body instanceof HTMLElement && card.parentElement !== body) {
        body.appendChild(card);
        structureChanged = true;
      }
    });

    desired.forEach(({ id }) => {
      const column = columns.get(id);
      const body = column?.querySelector('.platform-course-column-body');
      const empty = column?.querySelector('.platform-course-column-empty');
      if (!(body instanceof HTMLElement) || !(empty instanceof HTMLElement)) return;
      const hasCards = !!body.querySelector('.file-item[data-course-rankable="1"]');
      const state = String(window.platformLoginState?.[id] || 'checking');
      const label = COURSE_PLATFORM_COLUMNS.find((item) => item.id === id)?.label || '';
      const emptyText = state === 'checking'
        ? `${label}正在加载课程…`
        : (state === 'offline' ? `${label}未登录` : `${label}暂无课程`);
      const emptyViewKey = `${state}:${emptyText}`;
      if (empty.dataset.viewKey !== emptyViewKey) {
        empty.dataset.viewKey = emptyViewKey;
        empty.replaceChildren(document.createTextNode(emptyText));
        if (state === 'checking') {
          const spinner = document.createElement('span');
          spinner.className = 'spinner';
          spinner.setAttribute('aria-hidden', 'true');
          spinner.style.animationDelay = `-${Date.now() % 1000}ms`;
          empty.appendChild(spinner);
        }
      }
      const emptyDisplay = hasCards ? 'none' : '';
      if (empty.style.display !== emptyDisplay) empty.style.display = emptyDisplay;
    });

    courseListDiv.classList.add('platform-split-grid');
    applyCourseHelperPlatformColumnWeights();
    if (structureChanged) sortCourseCards();
  } finally {
    coursePlatformOrganizing = false;
  }
}

function scheduleCourseCardsByPlatform() {
  if (shouldSuspendCourseHelperLayoutWork()) {
    courseHelperLayoutWorkPending = true;
    return;
  }
  if (coursePlatformOrganizeFrame) return;
  coursePlatformOrganizeFrame = requestAnimationFrame(() => {
    coursePlatformOrganizeFrame = 0;
    organizeCourseCardsByPlatform();
  });
}

function refreshCourseHelperLayoutMode() {
  if (shouldSuspendCourseHelperLayoutWork()) {
    courseHelperLayoutWorkPending = true;
    return;
  }
  rematchExternalByVeCourses();
  rerenderAllHomeworkAreas();
  renderEnabledExternalStandaloneCourses();
  scheduleCourseCardsByPlatform();
  setTimeout(() => {
    sortCourseCardsWithGuard();
    scheduleCourseCardsByPlatform();
  }, 0);
}

function setCourseHelperFocusMode(enabled, { immediate = false } = {}) {
  const next = !popupMode && enabled === true;
  if (window.courseHelperPlatformSplitMode === next) return;
  if (immediate) {
    window.courseHelperPlatformSplitMode = next;
    document.body.classList.toggle('course-helper-focus', next);
    syncCourseHelperCollapseTogglePresentation();
    syncCourseHelperEvenWidthsButton();
    window.applyRightColumnResponsiveWidth?.();
    window.syncRightColumnResizer?.();
    return;
  }
  if (courseHelperLayoutTransitionTimer) clearTimeout(courseHelperLayoutTransitionTimer);
  courseHelperLayoutTransitioning = true;
  courseHelperLayoutWorkPending = false;
  suspendPendingCourseHelperLayoutWork();
  syncCourseHelperLayoutProcessingPlaceholder();
  window.courseHelperPlatformSplitMode = next;
  syncCourseHelperCollapseTogglePresentation();
  syncCourseHelperEvenWidthsButton();

  if (!next) {
    const deferMergedCourseList = window.showCourseListDuringLayoutTransition !== true;
    // When the list remains visible, merge before the width animation to avoid a
    // late visible reflow. When it is masked, defer all merging work until the
    // left-column animation has completed.
    if (!deferMergedCourseList) {
      if (!shouldUseCoursePlatformColumns()) unwrapCoursePlatformColumns();
      refreshCourseHelperLayoutMode();
    }
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (window.courseHelperPlatformSplitMode) return;
      window.applyRightColumnResponsiveWidth?.();
      document.body.classList.remove('course-helper-focus');
      window.trackRightColumnResizer?.();
      courseHelperLayoutTransitionTimer = setTimeout(() => {
        courseHelperLayoutTransitionTimer = 0;
        if (window.courseHelperPlatformSplitMode) return;
        if (deferMergedCourseList) {
          courseHelperLayoutTransitioning = false;
          if (!shouldUseCoursePlatformColumns()) unwrapCoursePlatformColumns();
          refreshCourseHelperLayoutMode();
          sortCourseCardsWithGuard();
        } else {
          courseHelperLayoutTransitioning = false;
        }
        courseHelperLayoutWorkPending = false;
        revealCourseHelperAfterSettledLayout();
      }, COURSE_HELPER_LAYOUT_TRANSITION_MS);
    }));
    return;
  }

  document.body.classList.add('course-helper-focus');
  window.trackRightColumnResizer?.();
  courseHelperLayoutTransitionTimer = setTimeout(() => {
    courseHelperLayoutTransitionTimer = 0;
    if (window.courseHelperPlatformSplitMode !== next) return;
    courseHelperLayoutTransitioning = false;
    refreshCourseHelperLayoutMode();
    if (courseHelperLayoutWorkPending) {
      courseHelperLayoutWorkPending = false;
      sortCourseCardsWithGuard();
      scheduleCourseCardsByPlatform();
    }
    revealCourseHelperAfterSettledLayout();
  }, COURSE_HELPER_LAYOUT_TRANSITION_MS);
}

async function loadCourseHelperLayoutSettings() {
  if (popupMode) return;
  const stored = await chrome.storage.local.get([
    COURSE_HELPER_EXPANDED_DEFAULT_KEY,
    FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY,
    STICKY_COURSE_HEADER_KEY,
    COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY,
    SHOW_COURSE_LIST_DURING_LAYOUT_TRANSITION_KEY
  ]).catch(() => ({}));
  const locallyStoredWeights = readCourseHelperPlatformColumnWeightsFromLocalStorage();
  const legacyWeights = stored[COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY];
  window.courseHelperPlatformColumnWeights = normalizeCourseHelperPlatformColumnWeights(
    locallyStoredWeights || legacyWeights
  );
  if (!locallyStoredWeights && legacyWeights && typeof legacyWeights === 'object') {
    saveCourseHelperPlatformColumnWeightsToLocalStorage(window.courseHelperPlatformColumnWeights);
  }
  if (legacyWeights !== undefined) {
    await chrome.storage.local.remove(COURSE_HELPER_PLATFORM_COLUMN_WEIGHTS_KEY).catch(() => {});
  }
  window.showCourseListDuringLayoutTransition = stored[SHOW_COURSE_LIST_DURING_LAYOUT_TRANSITION_KEY] === true;
  applyFullscreenHeaderLayout(
    stored[FULLSCREEN_TOP_BAR_FULL_WIDTH_KEY] === true,
    stored[STICKY_COURSE_HEADER_KEY] !== false
  );
  setCourseHelperFocusMode(stored[COURSE_HELPER_EXPANDED_DEFAULT_KEY] === true, { immediate: true });
}

function setupRightColumnResizer() {
  if (!layoutContainer || !leftColumn || !rightColumn || !columnResizer) return;
  const WIDTH_STORAGE_KEY = 'courseHelperWidthPx';
  const PORTRAIT_RATIO_STORAGE_KEY = 'courseHelperPortraitSplitRatio';
  const BASE_MIN_W = 480;
  const DEFAULT_W = 576;
  const DEFAULT_PORTRAIT_RATIO = 0.45;
  const MIN_PORTRAIT_RATIO = 0.1;
  const MAX_PORTRAIT_RATIO = 0.9;

  const isAdaptiveLayout = isCourseHelperAdaptiveLayout;

  const getBounds = () => {
    const vw = Math.max(0, Number(window.innerWidth || 0));
    const minW = BASE_MIN_W;
    const maxW = Math.max(minW + 20, vw - 48);
    return { minW, maxW };
  };

  const getSavedPortraitRatio = () => {
    try {
      const value = Number(localStorage.getItem(PORTRAIT_RATIO_STORAGE_KEY));
      if (Number.isFinite(value) && value > 0 && value < 1) {
        return Math.max(MIN_PORTRAIT_RATIO, Math.min(MAX_PORTRAIT_RATIO, value));
      }
    } catch {
      // ignore
    }
    return DEFAULT_PORTRAIT_RATIO;
  };

  const applyPortraitRatio = (ratio) => {
    const normalized = Math.max(
      MIN_PORTRAIT_RATIO,
      Math.min(MAX_PORTRAIT_RATIO, Number(ratio) || DEFAULT_PORTRAIT_RATIO)
    );
    const gap = Number.parseFloat(getComputedStyle(layoutContainer).rowGap || getComputedStyle(layoutContainer).gap) || 0;
    layoutContainer.style.setProperty(
      '--course-helper-portrait-split-basis',
      `calc(${normalized * 100}% - ${gap * normalized}px)`
    );
  };

  const getPortraitDragMetrics = () => {
    const rect = layoutContainer.getBoundingClientRect();
    const gap = Number.parseFloat(getComputedStyle(layoutContainer).rowGap || getComputedStyle(layoutContainer).gap) || 0;
    const available = Math.max(0, rect.height - gap);
    const resizerLineCenter = 6;
    return { rect, available, gap, resizerLineCenter };
  };

  const applyResponsiveWidth = () => {
    if (isAdaptiveLayout()) {
      rightColumn.style.width = '';
      rightColumn.style.minWidth = '0';
      applyPortraitRatio(getSavedPortraitRatio());
      return;
    }
    layoutContainer.style.removeProperty('--course-helper-portrait-split-basis');
    if (window.courseHelperPlatformSplitMode) {
      return;
    }
    rightColumn.style.minWidth = '';
    const { minW, maxW } = getBounds();
    let target = DEFAULT_W;
    try {
      const savedValue = localStorage.getItem(WIDTH_STORAGE_KEY);
      const saved = Number(savedValue);
      if (savedValue !== null && Number.isFinite(saved) && saved > 0) {
        target = saved;
      }
    } catch {
      // ignore
    }
    const clamped = Math.max(minW, Math.min(maxW, Math.round(target)));
    rightColumn.style.width = `${clamped}px`;
  };

  const syncResizerGeometry = () => {
    if (isAdaptiveLayout()) {
      columnResizer.style.display = 'block';
      columnResizer.style.removeProperty('left');
      columnResizer.style.removeProperty('top');
      columnResizer.style.removeProperty('width');
      columnResizer.style.removeProperty('height');
      return;
    }
    columnResizer.style.display = 'block';
    const rect = rightColumn.getBoundingClientRect();
    columnResizer.style.left = `${Math.round(rect.left)}px`;
    columnResizer.style.top = `${Math.round(rect.top)}px`;
    columnResizer.style.height = `${Math.max(0, Math.round(rect.height))}px`;
  };

  let resizerSyncFrame = 0;
  let resizerSyncEndTimer = 0;
  let resizerTrackingFrame = 0;
  const scheduleResizerSync = () => {
    if (!resizerSyncFrame) {
      resizerSyncFrame = requestAnimationFrame(() => {
        resizerSyncFrame = 0;
        syncResizerGeometry();
      });
    }
    if (resizerSyncEndTimer) clearTimeout(resizerSyncEndTimer);
    resizerSyncEndTimer = setTimeout(() => {
      resizerSyncEndTimer = 0;
      syncResizerGeometry();
    }, COURSE_HELPER_LAYOUT_TRANSITION_MS + 30);
  };
  window.syncRightColumnResizer = scheduleResizerSync;
  window.trackRightColumnResizer = () => {
    if (resizerTrackingFrame) cancelAnimationFrame(resizerTrackingFrame);
    const until = performance.now() + COURSE_HELPER_LAYOUT_TRANSITION_MS + 50;
    const track = (now) => {
      syncResizerGeometry();
      resizerTrackingFrame = now < until ? requestAnimationFrame(track) : 0;
    };
    resizerTrackingFrame = requestAnimationFrame(track);
  };
  window.applyRightColumnResponsiveWidth = applyResponsiveWidth;

  applyResponsiveWidth();
  syncCourseHelperCollapseTogglePresentation();
  scheduleResizerSync();

  let dragging = false;
  let dragAxis = '';
  let activePortraitRatio = getSavedPortraitRatio();

  const onMove = (e) => {
    if (!dragging || !rightColumn) return;
    if (dragAxis === 'row') {
      const { rect, available, gap, resizerLineCenter } = getPortraitDragMetrics();
      if (available <= 0) return;
      const pointerTop = Number(e.clientY || 0) - rect.top - gap - resizerLineCenter;
      const topPane = Math.max(
        available * MIN_PORTRAIT_RATIO,
        Math.min(available * MAX_PORTRAIT_RATIO, pointerTop)
      );
      activePortraitRatio = topPane / available;
      applyPortraitRatio(activePortraitRatio);
      return;
    }
    const { minW, maxW } = getBounds();
    const vw = Math.max(0, window.innerWidth || 0);
    const w = vw - Number(e.clientX || 0) - 24;
    const clamped = Math.max(minW, Math.min(maxW, Math.round(w)));
    rightColumn.style.width = `${clamped}px`;
    scheduleResizerSync();
  };

  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    const completedAxis = dragAxis;
    dragAxis = '';
    rightColumn.classList.remove('dragging');
    document.body.classList.remove('column-resizing');
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    try {
      if (completedAxis === 'row') {
        if (Number.isFinite(activePortraitRatio) && activePortraitRatio > 0 && activePortraitRatio < 1) {
          localStorage.setItem(PORTRAIT_RATIO_STORAGE_KEY, String(activePortraitRatio));
        }
      } else {
        const { minW, maxW } = getBounds();
        const current = parseInt(String(rightColumn.style.width || '0').replace('px', ''), 10);
        if (Number.isFinite(current) && current >= minW && current <= maxW) {
          localStorage.setItem(WIDTH_STORAGE_KEY, String(current));
        }
      }
    } catch {
      // ignore
    }
  };

  columnResizer.addEventListener('mousedown', (e) => {
    if (popupMode || window.courseHelperPlatformSplitMode || e.target === columnCollapseToggle) return;
    e.preventDefault();
    dragging = true;
    dragAxis = isAdaptiveLayout() ? 'row' : 'column';
    activePortraitRatio = getSavedPortraitRatio();
    rightColumn.classList.add('dragging');
    document.body.classList.add('column-resizing');
    document.body.style.cursor = dragAxis === 'row' ? 'row-resize' : 'col-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });

  if (columnCollapseToggle instanceof HTMLButtonElement) {
    columnCollapseToggle.addEventListener('mousedown', (event) => {
      event.preventDefault();
      event.stopPropagation();
    });
    columnCollapseToggle.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      setCourseHelperFocusMode(!window.courseHelperPlatformSplitMode);
    });
  }

  if (courseHelperEvenWidthsButton instanceof HTMLButtonElement) {
    courseHelperEvenWidthsButton.addEventListener('click', () => {
      window.courseHelperPlatformColumnWeights = Object.fromEntries(
        COURSE_PLATFORM_COLUMNS.map(({ id }) => [id, 1])
      );
      applyCourseHelperPlatformColumnWeights();
      saveCourseHelperPlatformColumnWeightsToLocalStorage(window.courseHelperPlatformColumnWeights);
    });
  }

  let previousAdaptiveLayout = isAdaptiveLayout();
  window.addEventListener('resize', () => {
    if (dragging && isAdaptiveLayout()) {
      onUp();
    }
    syncCourseHelperCollapseTogglePresentation();
    applyResponsiveWidth();
    scheduleResizerSync();
    const adaptiveLayout = isAdaptiveLayout();
    if (adaptiveLayout !== previousAdaptiveLayout) {
      previousAdaptiveLayout = adaptiveLayout;
      refreshCourseHelperLayoutMode();
    } else {
      scheduleCourseCardsByPlatform();
    }
  });

  window.addEventListener('scroll', scheduleResizerSync, true);
  if (typeof ResizeObserver !== 'undefined') {
    const ro = new ResizeObserver(() => scheduleResizerSync());
    ro.observe(rightColumn);
    if (courseListDiv) ro.observe(courseListDiv);
  }
  if (typeof MutationObserver !== 'undefined') {
    const mo = new MutationObserver((mutations) => {
      const courseListChanged = mutations.some((mutation) => (
        mutation.target === courseListDiv || courseListDiv?.contains(mutation.target)
      ));
      if (courseListChanged && shouldSuspendCourseHelperLayoutWork()) {
        courseHelperLayoutWorkPending = true;
        return;
      }
      scheduleResizerSync();
      if (courseListChanged && shouldUseCoursePlatformColumns()) scheduleCourseCardsByPlatform();
    });
    if (courseListDiv) {
      mo.observe(courseListDiv, { childList: true, subtree: true });
    }
    if (loginModal) {
      mo.observe(loginModal, { attributes: true, attributeFilter: ['style', 'class'] });
    }
    mo.observe(document.body, { attributes: true, attributeFilter: ['style', 'class'] });
  }
}

// speed aggregation
window.activeSpeeds = {}; // {speedId: bytesPerSecond}
const RECENT_SPEED_WINDOW_MS = 5000;
const totalProgressSamples = []; // [{t, loaded}]
let totalRecentSpeedBps = 0;

let lastValidUsername = '';
let pendingUsernameChange = null; // { from: string, to: string } | null
let isLoginInProgress = false;
let activeLoginFlowPromise = null;
let loginCancelRequested = false;
let loginAbortController = null;
let suppressedUsernameChangeValue = '';
const LOGIN_ACCOUNT_HISTORY_KEY = 'loginAccountHistory';
const CURRENT_XQ_CODE_KEY = 'selectedXqCode';
let currentXqOptions = []; // [{xqId,xqCode,xqName,currentFlag,beginDate,endDate}]
let currentXqCode = '';
let currentXqLoadPromise = null;
let loginAccountHistory = []; // [{userId,userName,roleName,lastLoginAt}]
let isSyncingAccountHistorySelect = false;
let highPrioritySwitchTarget = '';
let accountSwitchInterruptionArmed = false;
let usernameChangeVersion = 0;
let usernameChangeAbortController = null;

function prioritizeAccountSwitch() {
  window.courseListLoadVersion = Number(window.courseListLoadVersion || 0) + 1;
  window.resourceSpaceLoadVersion = Number(window.resourceSpaceLoadVersion || 0) + 1;
  bumpPlatformLoadVersion('ve');
  // 中止所有进行中的课件和回放获取请求
  abortAllCoursewareReplayFetches();
}

// 课件/回放请求的 AbortController 集合，用于账号/学期切换时立即中止
window.activeCoursewareAbortControllers = {}; // {courseId: AbortController}
window.activeReplayAbortControllers = {}; // {courseId: AbortController}
window.globalVeAbortController = new AbortController();

function abortAllCoursewareReplayFetches() {
  // 中止全局 AbortController，所有 VE 请求共享此信号
  if (window.globalVeAbortController) {
    try { window.globalVeAbortController.abort(); } catch { /* ignore */ }
  }
  window.globalVeAbortController = new AbortController();

  const cwControllers = window.activeCoursewareAbortControllers || {};
  Object.values(cwControllers).forEach((ctrl) => {
    try { ctrl.abort(); } catch { /* ignore */ }
  });
  window.activeCoursewareAbortControllers = {};

  const rpControllers = window.activeReplayAbortControllers || {};
  Object.values(rpControllers).forEach((ctrl) => {
    try { ctrl.abort(); } catch { /* ignore */ }
  });
  window.activeReplayAbortControllers = {};

  // 重置所有缓存中正在获取的标记
  Object.values(window.videoReplayCacheByCourseId || {}).forEach((cache) => {
    if (cache) {
      cache.linksFetching = false;
      cache.linksFetched = false;
    }
  });
  Object.values(window.coursewareCacheByCourseId || {}).forEach((cache) => {
    if (cache) {
      cache.rpLinksFetching = false;
      cache.rpLinksFetched = false;
      if (!cache.loaded) cache.loaded = false;
    }
  });

  // 清理课程级别的 loading 标记
  Object.keys(window.yktHomeworkLoadingByCourse || {}).forEach((k) => {
    window.yktHomeworkLoadingByCourse[k] = false;
  });
  window.veHomeworkPendingTypesByCourse = {};
  window.yktHomeworkPendingTypesByCourse = {};
}

function beginAccountSwitchInterruption() {
  if (accountSwitchInterruptionArmed) return false;
  accountSwitchInterruptionArmed = true;
  prioritizeAccountSwitch();
  return true;
}

function resetAccountSwitchInterruption() {
  accountSwitchInterruptionArmed = false;
}

function updateTotalSpeed() {
  let total = 0;
  Object.values(window.activeSpeeds).forEach(v => { total += v || 0; });
  if (Object.keys(window.activeSpeeds).length === 0) {
    total = 0;
  } else if (totalRecentSpeedBps > 0) {
    total = totalRecentSpeedBps;
  }
  const el = document.getElementById('total-speed');
  setSpeedDisplay(el, total, Object.keys(window.activeSpeeds).length ? null : '');
}

function formatEta(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return '0秒';
  const s = Math.max(1, Math.ceil(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}小时${m}分`;
  if (m > 0) return `${m}分${sec}秒`;
  return `${sec}秒`;
}

function pushAndCalcRecentSpeed(samples, loaded, now = Date.now(), windowMs = RECENT_SPEED_WINDOW_MS) {
  samples.push({ t: now, loaded: Number(loaded) || 0 });
  const minT = now - windowMs;
  while (samples.length > 2 && samples[0].t < minT) samples.shift();
  if (samples.length < 2) return 0;
  const first = samples[0];
  const last = samples[samples.length - 1];
  const dt = (last.t - first.t) / 1000;
  const db = Math.max(0, (last.loaded || 0) - (first.loaded || 0));
  if (dt <= 0 || db <= 0) return 0;
  return db / dt;
}

// -------------------- Storage helpers --------------------

function promptLoginIfPossible(message) {
  const defaultNeedLoginMsg = globalThis.BjtuPlatformLoginUi.loginRequiredHtml('ve');
  // If username is empty, do not pop modal; direct user to platform login entry.
  if (!usernameInput.value.trim()) {
    showToast(message || defaultNeedLoginMsg, 'warning', 3500, true);
    return;
  }
  doLoginFlow();
}

// -------------------- UI helpers --------------------
function dismissToastAfterCopy(toast) {
  if (!(toast instanceof HTMLElement) || !toast.isConnected || toast.dataset.dismissing === '1') return;
  toast.dataset.dismissing = '1';
  const content = String(toast.textContent || '').trim();
  if (content) navigator.clipboard.writeText(content).catch(() => { });
  toast.style.animation = 'fadeOutUp 0.25s ease-in forwards';
  toast.addEventListener('animationend', () => toast.remove(), { once: true });
  setTimeout(() => toast.remove(), 300);
}

function showToast(message, type = 'success', duration = 3000, allowHtml = false, options = {}) {
  const container = document.getElementById('toast-container');
  const preserveInfoToasts = !!options?.preserveInfoToasts;
  if (!preserveInfoToasts) {
    // clear existing info toasts
    container.querySelectorAll('.toast.info:not([data-sticky="1"])').forEach(el => el.remove());
  }

  const text = String(message || '');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.title = '点击复制通知内容并关闭';
  toast.style.whiteSpace = 'pre-line';
  if (allowHtml) {
    toast.innerHTML = text;
  } else {
    toast.textContent = text;
  }
  if (type === 'info' && text.includes('…')) {
    const spinner = document.createElement('span');
    spinner.className = 'toast-spinner';
    toast.appendChild(spinner);
  }
  container.appendChild(toast);

  if (duration > 0) {
    setTimeout(() => {
      toast.style.animation = 'fadeOutUp 0.25s ease-in forwards';
      toast.addEventListener('animationend', () => toast.remove());
    }, duration);
  }

  // Click to copy the visible message and dismiss.
  toast.addEventListener('click', () => {
    dismissToastAfterCopy(toast);
  });
}

function showBackgroundPortalLoginPendingToast() {
  const container = document.getElementById('toast-container');
  if (!(container instanceof HTMLElement)) return;

  const existed = container.querySelector('.toast[data-sticky-toast="bg-login"]');
  if (existed instanceof HTMLElement) return;

  const toast = document.createElement('div');
  toast.className = 'toast info';
  toast.dataset.sticky = '1';
  toast.dataset.stickyToast = 'bg-login';
  toast.title = '点击复制通知内容并关闭';
  toast.style.whiteSpace = 'pre-line';
  toast.textContent = '正在后台登录中…';
  const spinner = document.createElement('span');
  spinner.className = 'toast-spinner';
  toast.appendChild(spinner);
  container.appendChild(toast);

  // Click to copy and dismiss sticky toast too.
  toast.addEventListener('click', () => {
    dismissToastAfterCopy(toast);
  });
}

function hideBackgroundPortalLoginPendingToast() {
  const container = document.getElementById('toast-container');
  if (!(container instanceof HTMLElement)) return;
  container.querySelectorAll('.toast[data-sticky-toast="bg-login"]').forEach((el) => {
    if (el instanceof HTMLElement) el.remove();
  });
}

function formatSize(bytes) {
  return globalThis.BjtuFileSizeEmphasis.formatBytes(bytes);
}

function buildFileSizeEmphasisStyle(bytes) {
  return globalThis.BjtuFileSizeEmphasis.buildBytesStyle(bytes);
}

function setSpeedDisplay(element, bytesPerSecond, text = null) {
  if (!(element instanceof HTMLElement)) return;
  const speed = Math.max(0, Number(bytesPerSecond) || 0);
  const label = text === null ? formatSpeed(speed) : String(text);
  element.textContent = label;
  if (!label) {
    delete element.dataset.speedBytes;
    element.style.removeProperty('font-size');
    element.style.removeProperty('font-weight');
    element.style.removeProperty('color');
    element.style.removeProperty('text-shadow');
    return;
  }
  element.dataset.speedBytes = String(speed);
  const emphasis = buildFileSizeEmphasisStyle(speed);
  const fontSize = emphasis.match(/font-size:([^;]+)/)?.[1]?.trim();
  const fontWeight = emphasis.match(/font-weight:([^;]+)/)?.[1]?.trim();
  const emphasisColor = emphasis.match(/color:([^;]+)/)?.[1]?.trim();
  const emphasisShadow = emphasis.match(/text-shadow:([^;]+)/)?.[1]?.trim();
  if (fontSize) element.style.fontSize = fontSize;
  if (fontWeight) element.style.fontWeight = fontWeight;
  if (emphasisColor) element.style.color = emphasisColor;
  element.style.textShadow = emphasisShadow || 'none';
}

window.addEventListener('bjtu-theme-change', () => {
  document.querySelectorAll('[data-speed-bytes]').forEach((element) => {
    if (element instanceof HTMLElement) {
      setSpeedDisplay(element, Number(element.dataset.speedBytes || 0), element.textContent || '');
    }
  });
});

function applyEmphasisStyle(element, styleText) {
  globalThis.BjtuFileSizeEmphasis.applyStyle(element, styleText);
}

function renderFileSizeText(bytes, text = '') {
  const n = Math.max(0, Number(bytes) || 0);
  const label = text || formatSize(n);
  return `<span class="file-size-emphasis" data-file-size-bytes="${n}" style="${escapeHtml(buildFileSizeEmphasisStyle(n))}">${escapeHtml(label)}</span>`;
}

function renderFileSizePair(loaded, total) {
  const loadedSafe = Math.max(0, Number(loaded) || 0);
  const totalSafe = Math.max(0, Number(total) || 0);
  return `${renderFileSizeText(loadedSafe)} <span class="file-size-separator">/</span> ${renderFileSizeText(totalSafe)}`;
}

function buildHomeworkAttachmentKey(noteId, courseId, teacherId) {
  return `${String(noteId || '').trim()}|${String(courseId || '').trim()}|${String(teacherId || '').trim()}`;
}

function stripFileExtension(name) {
  const raw = String(name || '').trim();
  if (!raw) return '';
  const dot = raw.lastIndexOf('.');
  if (dot <= 0) return raw;
  return raw.slice(0, dot);
}

function buildHomeworkAttachmentSizeStyle(bytes) {
  return globalThis.BjtuFileSizeEmphasis.buildBytesStyle(bytes, 'light');
}

function normalizeHomeworkAttachmentUrl(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) return text;
  const normalized = text.startsWith('/') ? text : `/${text}`;
  if (normalized.startsWith('/rp/')) return `${FILE_BASE}${normalized}`;
  return `${BASE}${normalized}`;
}

function triggerHomeworkAttachmentDownload(url, fileName) {
  const safeUrl = String(url || '').trim();
  if (!safeUrl) return;
  const safeName = sanitizeDownloadFileName(fileName || '作业附件');
  if (chrome?.downloads?.download) {
    chrome.downloads.download(
      { url: safeUrl, filename: safeName, conflictAction: 'uniquify', saveAs: false },
      () => {
        if (chrome.runtime?.lastError) {
          chrome.tabs.create({ url: safeUrl, active: true })
            .then((tab) => groupBjtuOpenedTab(tab?.id))
            .catch(() => {});
        }
      }
    );
    return;
  }
  chrome.tabs.create({ url: safeUrl, active: true })
    .then((tab) => groupBjtuOpenedTab(tab?.id))
    .catch(() => {});
}

function syncHomeworkAttachmentItemsIndex(courseId, items) {
  const cid = String(courseId || '').trim();
  const prevList = Array.isArray(window.homeworkAttachmentItemsByCourseId?.[cid])
    ? window.homeworkAttachmentItemsByCourseId[cid]
    : [];
  prevList.forEach((it) => {
    const id = String(it?.id || '').trim();
    if (!id) return;
    delete window.homeworkAttachmentItemsById[id];
    window.resourceSpaceSelected.delete(id);
  });

  const nextList = Array.isArray(items) ? items : [];
  window.homeworkAttachmentItemsByCourseId[cid] = nextList;
  nextList.forEach((it) => {
    const id = String(it?.id || '').trim();
    if (!id) return;
    window.homeworkAttachmentItemsById[id] = it;
  });
}

function registerHomeworkAttachmentItem(courseId, item) {
  const cid = String(courseId || '').trim();
  if (!cid || !item) return;
  const id = String(item.id || '').trim();
  if (!id) return;
  if (!Array.isArray(window.homeworkAttachmentItemsByCourseId[cid])) {
    window.homeworkAttachmentItemsByCourseId[cid] = [];
  }
  window.homeworkAttachmentItemsByCourseId[cid].push(item);
  window.homeworkAttachmentItemsById[id] = item;
}

function formatSpeed(bytesPerSecond) {
  if (!bytesPerSecond) return '0 KB/s';
  if (bytesPerSecond < 1024 * 1024) return (bytesPerSecond / 1024).toFixed(1) + ' KB/s';
  return (bytesPerSecond / (1024 * 1024)).toFixed(1) + ' MB/s';
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function normalizeHomeworkContent(raw) {
  if (raw === null || raw === undefined) return '';
  let s = String(raw).replace(/\r\n/g, '\n');
  s = s.trim();
  if (!s) return '';

  const looksHtml = /<\/?[a-z][\s\S]*>/i.test(s);
  if (looksHtml) {
    // Compact common block tags to avoid overly large paragraph gaps from source HTML defaults.
    s = s.replace(/<p\b([^>]*)>/gi, (m, attrs = '') => {
      if (/\bstyle\s*=\s*(["']).*?\1/i.test(attrs)) {
        return `<p${attrs.replace(/\bstyle\s*=\s*(["'])([\s\S]*?)\1/i, (all, q, st) => ` style=${q}${st};margin:0.2em 0;${q}`)}>`;
      }
      return `<p${attrs} style="margin:0.2em 0;">`;
    });
    s = s.replace(/<(ul|ol)\b([^>]*)>/gi, (m, tag, attrs = '') => {
      if (/\bstyle\s*=\s*(["']).*?\1/i.test(attrs)) {
        return `<${tag}${attrs.replace(/\bstyle\s*=\s*(["'])([\s\S]*?)\1/i, (all, q, st) => ` style=${q}${st};margin:0.2em 0;padding-left:1.15em;${q}`)}>`;
      }
      return `<${tag}${attrs} style="margin:0.2em 0;padding-left:1.15em;">`;
    });
    s = s.replace(/<li\b([^>]*)>/gi, (m, attrs = '') => {
      if (/\bstyle\s*=\s*(["']).*?\1/i.test(attrs)) {
        return `<li${attrs.replace(/\bstyle\s*=\s*(["'])([\s\S]*?)\1/i, (all, q, st) => ` style=${q}${st};margin:0.08em 0;${q}`)}>`;
      }
      return `<li${attrs} style="margin:0.08em 0;">`;
    });
    return s;
  }

  s = s.replace(/(\n\s*){3,}/g, '\n\n');
  return escapeHtml(s).replace(/\n/g, '<br>');
}

function renderExpandableHtml(contentHtml, {
  emptyHtml = '<span style="color:#999;">无内容</span>',
  expandText = globalThis.BjtuHomeworkUi?.text?.detailExpand || '点击查看作业详情',
  collapseText = globalThis.BjtuHomeworkUi?.text?.detailCollapse || '点击收起作业详情',
  hideWhenEmpty = false,
  baseBg = 'rgba(255,255,255,0.3)',
  flatDisplay = false,
  courseId = '',
  expandKey = '',
  expanded = false,
  detailKind = 'homework'
} = {}) {
  const raw = String(contentHtml || '').trim();
  if (!raw) {
    if (hideWhenEmpty) return '';
    return `<div class="expandable-box" style="--expand-base:${baseBg};"><div class="expandable-body">${emptyHtml}</div></div>`;
  }
  const cid = escapeHtml(String(courseId || ''));
  const key = escapeHtml(String(expandKey || ''));
  const expandedNow = !!expanded;
  const modeClass = flatDisplay ? ' borderless' : '';
  const detailClass = detailKind === 'replay' ? ' expandable-box--replay' : ' expandable-box--homework';
  return `
    <div class="expandable-box${detailClass}${modeClass}${expandedNow ? ' expanded' : ''}" data-expanded="${expandedNow ? '1' : '0'}" data-course-id="${cid}" data-expand-key="${key}" style="--expand-base:${baseBg};">
      <div class="expandable-body">${raw}</div>
      <div class="expandable-fade"></div>
      <div class="expandable-toggle" data-action="toggle-expand" data-open-text="${escapeHtml(expandText)}" data-close-text="${escapeHtml(collapseText)}">${escapeHtml(expandedNow ? collapseText : expandText)}</div>
    </div>
  `;
}

function getHomeworkExpandStateMap(courseId) {
  const cid = String(courseId || '').trim();
  if (!cid) return null;
  if (!window.homeworkDetailExpandedByCourse[cid]) {
    window.homeworkDetailExpandedByCourse[cid] = {};
  }
  return window.homeworkDetailExpandedByCourse[cid];
}

function isHomeworkDetailExpanded(courseId, expandKey) {
  const map = getHomeworkExpandStateMap(courseId);
  const key = String(expandKey || '').trim();
  if (!map || !key) return false;
  return !!map[key];
}

function setHomeworkDetailExpanded(courseId, expandKey, expanded) {
  const map = getHomeworkExpandStateMap(courseId);
  const key = String(expandKey || '').trim();
  if (!map || !key) return;
  map[key] = !!expanded;
}

function buildHomeworkScoreKey(upId, snId) {
  return `${String(upId || '').trim()}|${String(snId || '').trim()}`;
}

function splitFileName(name) {
  const raw = String(name || '').trim();
  if (!raw) return { fileNameNoExt: '', fileExtName: '' };
  const idx = raw.lastIndexOf('.');
  if (idx <= 0 || idx === raw.length - 1) return { fileNameNoExt: raw, fileExtName: '' };
  return {
    fileNameNoExt: raw.slice(0, idx),
    fileExtName: raw.slice(idx + 1)
  };
}

function getSelectedUploadedFileList() {
  const checked = Array.from(document.querySelectorAll('.submit-file-check:checked'));
  const files = [];
  checked.forEach((cb) => {
    const fileId = String(cb?.dataset?.fileId || '').trim();
    const meta = window.uploadedFileMetaById[fileId];
    if (!meta || !meta.visitName) return;
    files.push({
      fileNameNoExt: encodeURIComponent(String(meta.fileNameNoExt || '')),
      fileExtName: meta.fileExtName,
      fileSize: String(meta.fileSize || ''),
      visitName: meta.visitName,
      pid: '',
      ftype: 'insert'
    });
  });
  return files;
}

async function submitNativeHomework(courseId, hw, content, fileList) {
  const upId = hw?.id ?? hw?.upId ?? hw?.upid ?? hw?.UPID ?? hw?.up_id ?? '';
  if (!upId) return { ok: false, message: '作业ID缺失，无法提交' };

  const body = new URLSearchParams({
    method: 'sendStuHomeWorks',
    content: encodeURIComponent(String(content || '')),
    groupName: '',
    groupId: '',
    courseId: String(courseId || ''),
    contentType: '0',
    fz: String(hw?.is_fz ?? '0'),
    jxrl_id: '',
    fileList: JSON.stringify(fileList || []),
    upId: String(upId),
    return_num: '0',
    isTeacher: '0'
  });

  const { text, res } = await fetchText(`${BASE_VE}back/course/courseWorkInfo.shtml`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      Accept: 'application/json, text/javascript, */*; q=0.01',
      'X-Requested-With': 'XMLHttpRequest'
    },
    body: body.toString()
  });

  if (isLikelyLoginPageHtml(text, res?.url) || (res && res.redirected && String(res.url || '').includes('/ve/s.shtml'))) {
    return { ok: false, loginRequired: true, message: '登录状态失效' };
  }

  const result = globalThis.BjtuVeHomeworkCore.parseHomeworkSubmissionResponse(text);
  return result.ok
    ? { ok: true, data: result.data }
    : { ok: false, message: result.message };
}

function updateTotalProgress() {
  let totalSize = 0;
  let totalUploaded = 0;
  const totalProgressWrap = totalServerBar?.closest?.('.progress-bar-container');

  Object.values(window.filesData).forEach(d => {
    const size = Math.max(0, Number(d?.size || 0));
    const uploaded = Math.max(0, Number(d?.uploaded || 0));
    totalSize += size;
    totalUploaded += Math.min(uploaded, size);
  });

  totalRecentSpeedBps = pushAndCalcRecentSpeed(totalProgressSamples, totalUploaded);

  totalSizeInfoDiv.innerHTML = renderFileSizePair(totalUploaded, totalSize);
  totalSizeInfoDiv.style.cssText = '';
  if (!totalSize) {
    if (totalProgressWrap instanceof HTMLElement) totalProgressWrap.style.display = 'none';
    totalServerBar.style.width = '0%';
    totalServerBar.textContent = '';
    if (totalPercentDiv) totalPercentDiv.textContent = '0%';
    if (totalPercentDiv) totalPercentDiv.style.display = 'none';
    if (totalEtaDiv) totalEtaDiv.textContent = '';
    totalRecentSpeedBps = 0;
    totalProgressSamples.length = 0;
    updateTotalSpeed();
    return;
  }

  if (totalProgressWrap instanceof HTMLElement) totalProgressWrap.style.display = '';
  if (totalPercentDiv) totalPercentDiv.style.display = '';
  const exactPercent = Math.min(100, Math.max(0, (totalUploaded / totalSize) * 100));
  const percent = Math.round(exactPercent);
  totalServerBar.style.width = exactPercent + '%';
  totalServerBar.textContent = '';
  if (totalPercentDiv) totalPercentDiv.textContent = `${percent}%`;

  const remaining = Math.max(0, totalSize - totalUploaded);
  if (totalEtaDiv) {
    if (remaining <= 0) {
      totalEtaDiv.textContent = '';
      totalRecentSpeedBps = 0;
      totalProgressSamples.length = 0;
    } else if (totalRecentSpeedBps > 0) {
      totalEtaDiv.textContent = `总剩余: ${formatEta(remaining / totalRecentSpeedBps)}`;
    } else {
      totalEtaDiv.textContent = '总剩余: --';
    }
  }
  updateTotalSpeed();
}

let currentVeUserInfoPromise = null;

async function getLocalAccountInfo(userId = '') {
  const uid = String(userId || '').trim();
  if (!uid) return null;
  const catalog = await globalThis.BjtuAccountLogin?.getAccount?.(uid) || null;
  const history = findLoginAccountRecord(uid);
  const source = catalog || history;
  if (!source) return null;
  return {
    loginName: String(source.loginName || source.userId || uid).trim(),
    userId: uid,
    userName: String(source.userName || '').trim(),
    roleName: String(source.roleName || '').trim(),
    password: String(source.password || ''),
    passwordMd5: String(source.passwordMd5 || '').trim(),
    quickUsername: String(source.quickUsername || history?.quickUsername || '').trim()
  };
}

function setWelcomeMessage(info) {
  const loginMsgEl = document.getElementById('login-welcome-msg');
  const loginName = String(info?.loginName || '').trim();
  const displayName = loginName ? `${info?.roleName || ''}${info?.userName || ''}（${loginName}）` : `${info?.roleName || ''}${info?.userName || ''}`;
  const msg = info ? displayName : '';
  if (loginMsgEl) loginMsgEl.textContent = msg;
}

function normalizeLoginAccountHistoryList(rawList) {
  const list = Array.isArray(rawList) ? rawList : [];
  return list
    .map((it) => {
      const loginName = String(it?.loginName || it?.userId || '').trim();
      if (!loginName) return null;
      const userName = String(it?.userName || '').trim();
      const roleName = String(it?.roleName || '').trim();
      const passwordMd5 = String(it?.passwordMd5 || '').trim();
      const quickUsername = String(it?.quickUsername || it?.username || '').trim();
      const lastLoginAt = Number(it?.lastLoginAt || 0);
      return {
        userId: loginName,
        userName,
        roleName,
        loginName,
        passwordMd5,
        quickUsername,
        lastLoginAt: Number.isFinite(lastLoginAt) ? lastLoginAt : 0
      };
    })
    .filter(Boolean)
    .sort((a, b) => Number(b.lastLoginAt || 0) - Number(a.lastLoginAt || 0))
    .filter((item, index, rows) => rows.findIndex((candidate) => (
      candidate.loginName.toLowerCase() === item.loginName.toLowerCase()
    )) === index);
}

function serializeLoginAccountHistoryList(rawList) {
  return normalizeLoginAccountHistoryList(rawList)
    .map((it) => ({
      loginName: String(it?.loginName || it?.userId || '').trim(),
      lastLoginAt: Number(it?.lastLoginAt || 0) || 0
    }))
    .filter((it) => it.loginName);
}

async function readAccountInfoFromIndexedDb(loginName) {
  try {
    return await globalThis.BjtuAccountLogin?.getAccount?.(loginName) || null;
  } catch {
    return null;
  }
}

async function enrichLoginAccountHistoryList(list) {
  const normalized = normalizeLoginAccountHistoryList(list);
  return Promise.all(normalized.map(async (record) => {
    const account = await readAccountInfoFromIndexedDb(record.loginName);
    return {
      ...record,
      userName: String(account?.userName || record.userName || '').trim(),
      roleName: String(account?.roleName || record.roleName || '').trim(),
      password: String(account?.password || ''),
      passwordMd5: String(account?.passwordMd5 || record.passwordMd5 || '').trim(),
      quickUsername: String(account?.quickUsername || record.quickUsername || '').trim()
    };
  }));
}

function renderLoginAccountHistorySelect(currentUserId = '') {
  if (!(accountHistorySelect instanceof HTMLSelectElement)) return;
  const current = String(currentUserId || usernameInput?.value || '').trim();
  isSyncingAccountHistorySelect = true;
  accountHistorySelect.innerHTML = '';

  const list = normalizeLoginAccountHistoryList(loginAccountHistory);
  if (!list.length) {
    const emptyOpt = document.createElement('option');
    emptyOpt.value = '';
    emptyOpt.textContent = '';
    accountHistorySelect.appendChild(emptyOpt);
    accountHistorySelect.value = '';
    isSyncingAccountHistorySelect = false;
    return;
  }

  let selectedUserId = current;
  if (!list.some((it) => it.userId === selectedUserId)) {
    selectedUserId = String(list[0]?.userId || '').trim();
  }

  const selectedRecord = list.find((it) => it.userId === selectedUserId) || list[0];
  if (selectedRecord) {
    const opt = document.createElement('option');
    opt.value = selectedRecord.userId;
    opt.hidden = true;
    const selectedName = String(selectedRecord.userName || selectedRecord.userId || '未知用户').trim();
    const selectedRole = String(selectedRecord.roleName || '').trim();
    // 选中项只显示 userName
    opt.textContent = `${selectedRole}${selectedName}`;
    accountHistorySelect.appendChild(opt);
  }

  list
    .filter((it) => it.userId !== selectedUserId)
    .forEach((it) => {
      const opt = document.createElement('option');
      opt.value = it.userId;
      const userName = String(it.userName || it.userId || '未知用户').trim();
      const roleName = String(it.roleName || '').trim();
      const loginName = String(it.loginName || '').trim();
      const loginSuffix = loginName ? `${loginName}` : '';
      const quickSuffix = it.quickUsername ? '极速' : '账密';
      // 展开列表显示 userName(loginName)
      opt.textContent = `${roleName} ${userName} (${loginSuffix}) [${quickSuffix}]`;
      accountHistorySelect.appendChild(opt);
    });

  accountHistorySelect.value = selectedUserId;
  adjustAccountHistorySelectWidth();
  isSyncingAccountHistorySelect = false;
}

const ACCOUNT_HISTORY_SELECT_EXTRA_PX = 20;

function adjustAccountHistorySelectWidth() {
  if (!(accountHistorySelect instanceof HTMLSelectElement)) return;
  const selectedText = String(accountHistorySelect.selectedOptions?.[0]?.text || accountHistorySelect.value || '').trim();
  if (!selectedText) {
    accountHistorySelect.style.width = '';
    return;
  }
  const cs = getComputedStyle(accountHistorySelect);
  const canvas = adjustAccountHistorySelectWidth._canvas || (adjustAccountHistorySelectWidth._canvas = document.createElement('canvas'));
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.font = `${cs.fontStyle || 'normal'} ${cs.fontVariant || 'normal'} ${cs.fontWeight || '400'} ${cs.fontSize || '14px'} / ${cs.lineHeight || 'normal'} ${cs.fontFamily || 'sans-serif'}`;
  const textWidth = Math.ceil(ctx.measureText(selectedText).width);
  const borderPadding = ['paddingLeft', 'paddingRight', 'borderLeftWidth', 'borderRightWidth']
    .reduce((sum, key) => sum + (parseFloat(cs[key]) || 0), 0);
  accountHistorySelect.style.width = `${Math.ceil(textWidth + borderPadding + ACCOUNT_HISTORY_SELECT_EXTRA_PX)}px`;
}

function normalizeCurrentXqOptions(rawList) {
  const list = Array.isArray(rawList) ? rawList : [];
  return list
    .map((item) => {
      const xqCode = String(item?.xqCode || item?.xq_code || item?.XQ_CODE || item?.XQCODE || '').trim();
      if (!xqCode) return null;
      const xqName = String(item?.xqName || item?.CNAME || item?.xq_name || item?.name || xqCode).trim() || xqCode;
      const beginDate = String(item?.beginDate || item?.begin_date || '').trim();
      const endDate = String(item?.endDate || item?.end_date || '').trim();
      const currentFlag = Number(item?.currentFlag || item?.current_flag || 0);
      return {
        xqId: String(item?.xqId || item?.xq_id || '').trim(),
        xqCode,
        xqName,
        currentFlag: Number.isFinite(currentFlag) ? currentFlag : 0,
        beginDate,
        endDate
      };
    })
    .filter(Boolean);
}

function chooseCurrentXqCode(list, preferredCode = '') {
  const normalizedList = Array.isArray(list) ? list : [];
  const preferred = String(preferredCode || '').trim();
  if (preferred && normalizedList.some((item) => String(item?.xqCode || '').trim() === preferred)) {
    return preferred;
  }
  const current = normalizedList.find((item) => Number(item?.currentFlag || 0) === 2);
  if (current) return String(current.xqCode || '').trim();
  return String(normalizedList[0]?.xqCode || '').trim();
}

function adjustXqSelectWidth() {
  if (!(xqSelect instanceof HTMLSelectElement)) return;
  const selectedText = String(xqSelect.selectedOptions?.[0]?.text || xqSelect.value || '').trim();
  const scaledChars = Math.max(10, Math.ceil(selectedText.length * 1.25));
  xqSelect.style.width = `calc(${scaledChars}ch + 36px)`;
}

function renderCurrentXqSelect(list = currentXqOptions, preferredCode = currentXqCode) {
  if (!(xqSelect instanceof HTMLSelectElement)) return;
  const normalizedList = Array.isArray(list) ? list : [];
  xqSelect.innerHTML = '';

  if (!normalizedList.length) {
    const empty = document.createElement('option');
    empty.value = String(preferredCode || '').trim();
    empty.textContent = empty.value ? `已保存学期（${empty.value}）` : '暂无学期';
    empty.disabled = !empty.value;
    empty.selected = true;
    xqSelect.appendChild(empty);
    xqSelect.disabled = !empty.value;
    xqSelect.title = empty.value ? `已保存学期：${empty.value}` : '未获取到学期列表';
    adjustXqSelectWidth();
    return;
  }

  normalizedList.forEach((item) => {
    const opt = document.createElement('option');
    opt.value = String(item.xqCode || '').trim();
    opt.textContent = String(item.xqName || item.xqCode || '').trim();
    opt.title = [item.xqName, item.xqCode, item.beginDate && `开始 ${item.beginDate}`, item.endDate && `结束 ${item.endDate}`].filter(Boolean).join(' · ');
    xqSelect.appendChild(opt);
  });

  const selected = chooseCurrentXqCode(normalizedList, preferredCode);
  xqSelect.disabled = false;
  xqSelect.value = selected;
  currentXqCode = selected;
  xqSelect.title = normalizedList.find((item) => String(item.xqCode || '').trim() === selected)?.title || normalizedList.find((item) => String(item.xqCode || '').trim() === selected)?.xqName || '学期选择';
  adjustXqSelectWidth();
}

function getCurrentXqCode() {
  const selectValue = xqSelect instanceof HTMLSelectElement ? String(xqSelect.value || '').trim() : '';
  return String(currentXqCode || selectValue || '').trim();
}

async function loadCurrentXqOptions(forceReload = false) {
  if (currentXqLoadPromise && !forceReload) return currentXqLoadPromise;
  const task = (async () => {
    let savedCode = '';
    try {
      savedCode = String(await getLocal(CURRENT_XQ_CODE_KEY, '') || '').trim();
    } catch {
      savedCode = '';
    }

    try {
      currentXqOptions = normalizeCurrentXqOptions(await globalThis.BjtuVeHomeworkCore.fetchTerms());
      currentXqCode = chooseCurrentXqCode(currentXqOptions, savedCode || currentXqCode);
      renderCurrentXqSelect(currentXqOptions, currentXqCode);
      if (currentXqCode) {
        await setLocal(CURRENT_XQ_CODE_KEY, currentXqCode);
      }
      return currentXqOptions;
    } catch {
      if (currentXqOptions.length) {
        currentXqCode = chooseCurrentXqCode(currentXqOptions, savedCode || currentXqCode);
        renderCurrentXqSelect(currentXqOptions, currentXqCode);
        return currentXqOptions;
      }

      currentXqCode = String(savedCode || '').trim();
      renderCurrentXqSelect([], currentXqCode);
      return currentXqOptions;
    } finally {
      currentXqLoadPromise = null;
    }
  })();
  currentXqLoadPromise = task;
  return task;
}

async function ensureCurrentXqCode() {
  const existing = getCurrentXqCode();
  if (existing) return existing;
  await loadCurrentXqOptions();
  return getCurrentXqCode();
}

if (xqSelect instanceof HTMLSelectElement) {
  xqSelect.addEventListener('change', async () => {
    const picked = String(xqSelect.value || '').trim();
    if (picked && picked !== currentXqCode) {
      prioritizeAccountSwitch();
    }
    currentXqCode = picked;
    try {
      await setLocal(CURRENT_XQ_CODE_KEY, picked);
    } catch {
      // ignore
    }
    adjustXqSelectWidth();
    if (isPlatformEnabled('ve')) {
      try {
        await loadCourses();
      } catch {
        // ignore
      }
    }
  });
}

function getAccountDisplayName(userId) {
  const uid = String(userId || '').trim();
  if (!uid) return '';
  const hit = loginAccountHistory.find((it) => String(it?.userId || '').trim() === uid);
  if (!hit) return '';
  const userName = String(hit.userName || uid).trim();
  const roleName = String(hit.roleName || '').trim();
  return `${roleName}${userName}`;
}

function findLoginAccountRecord(userId) {
  const uid = String(userId || '').trim();
  if (!uid) return null;
  return normalizeLoginAccountHistoryList(loginAccountHistory)
    .find((it) => it.userId === uid || it.loginName === uid) || null;
}

async function loadLoginAccountHistory() {
  try {
    const raw = await getLocal(LOGIN_ACCOUNT_HISTORY_KEY, []);
    loginAccountHistory = await enrichLoginAccountHistoryList(raw);
  } catch {
    loginAccountHistory = [];
  }
}

async function saveLoginAccountHistory() {
  loginAccountHistory = normalizeLoginAccountHistoryList(loginAccountHistory);
  await setLocal(LOGIN_ACCOUNT_HISTORY_KEY, serializeLoginAccountHistoryList(loginAccountHistory));
}

async function rememberLoggedInAccount(userId, info = null) {
  const uid = String(userId || '').trim();
  if (!uid) return;
  const nextInfo = info && typeof info === 'object' ? info : {};
  const idx = loginAccountHistory.findIndex((it) => String(it?.loginName || it?.userId || '').trim() === uid);
  const prev = idx >= 0 ? loginAccountHistory[idx] : null;
  // loginName: 优先 API 返回的 loginName，其次用已有记录的 loginName，最后用 userId 初始化
  const loginName = String(nextInfo.loginName || prev?.loginName || uid).trim();
  const record = {
    userId: uid,
    loginName,
    userName: String(nextInfo.userName || prev?.userName || '').trim(),
    roleName: String(nextInfo.roleName || prev?.roleName || '').trim(),
    passwordMd5: String(nextInfo.passwordMd5 || prev?.passwordMd5 || '').trim(),
    quickUsername: String(nextInfo.quickUsername || nextInfo.username || prev?.quickUsername || '').trim(),
    lastLoginAt: Date.now()
  };
  if (idx >= 0) loginAccountHistory.splice(idx, 1);
  loginAccountHistory.unshift(record);
  await saveLoginAccountHistory();
  renderLoginAccountHistorySelect(uid);
}

// -------------------- Network helpers --------------------
async function fetchText(url, options = {}) {
  const {
    signal: externalSignal,
    omitSessionId = false,
    skipVeAuthRecovery = false,
    _veAuthRetried = false,
    ...restOptions
  } = options || {};
  const controller = new AbortController();
  const externalAbortHandler = () => {
    try { controller.abort(); } catch { /* ignore */ }
  };
  if (externalSignal instanceof AbortSignal) {
    if (externalSignal.aborted) {
      try { controller.abort(); } catch { /* ignore */ }
    } else {
      externalSignal.addEventListener('abort', externalAbortHandler, { once: true });
    }
  }

  const sid = omitSessionId ? '' : await getPlatformSessionId();
  const headers = {
    'Upgrade-Insecure-Requests': '1',
    ...(options.headers || {})
  };
  if (!omitSessionId) {
    headers.sessionId = sid;
  }

  let res;
  try {
    res = await fetch(url, {
      credentials: 'include',
      cache: 'no-store',
      ...restOptions,
      headers,
      signal: controller.signal
    });
  } finally {
    if (externalSignal instanceof AbortSignal) {
      try { externalSignal.removeEventListener('abort', externalAbortHandler); } catch { /* ignore */ }
    }
  }

  // auto-refresh runtime sessionId if server provides it
  maybeUpdatePlatformSessionIdFromResponse(res);

  const buf = await res.arrayBuffer();
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  let text = '';
  try {
    if (contentType.includes('gbk') || contentType.includes('gb2312')) {
      text = new TextDecoder('gbk').decode(buf);
    } else {
      text = new TextDecoder('utf-8').decode(buf);
      if (text.includes('�')) {
        const gbkText = new TextDecoder('gbk').decode(buf);
        if (gbkText && !gbkText.includes('�')) text = gbkText;
      }
    }
  } catch {
    text = new TextDecoder('utf-8').decode(buf);
  }

  if (!skipVeAuthRecovery
    && !_veAuthRetried
    && isVeRequestUrl(url)
    && isVeSessionInvalidResponse(text, res?.url)) {
    const recovered = await reauthenticateVeSessionOnly();
    if (recovered) return fetchText(url, { ...options, _veAuthRetried: true });
  }

  return { res, text };
}

function parseAlertMsg(html) {
  const arr = [...String(html || '').matchAll(/alert\((['"])(.*?)\1\)/g)];
  if (!arr.length) return '';
  return arr[arr.length - 1][2];
}

function isSessionEndedHtml(html) {
  const t = String(html || '');
  return /<title>会话结束<\/title>/i.test(t) && t.includes('会话结束,请退出系统') && t.includes('重新登录');
}

function isLikelyLoginPageHtml(html, resUrl = '') {
  const t = String(html || '');
  const u = String(resUrl || '');
  if (u.includes('/ve/s.shtml') || u.includes('/ve/Login_2.jsp') || u.includes('/ve/Timeout.jsp') || isSessionEndedHtml(t)) return true;
  return false;
}

function isVeRequestUrl(url) {
  try {
    const parsed = new URL(String(url || ''), location.href);
    return parsed.hostname === '123.121.147.7' && parsed.port === '88' && parsed.pathname.startsWith('/ve/');
  } catch {
    return false;
  }
}

function isVeSessionInvalidResponse(text, resUrl = '') {
  if (isLikelyLoginPageHtml(text, resUrl)) return true;
  const source = String(text || '');
  if (/["'](?:ERRMSG|message)["']\s*:\s*["'][^"']*(?:登录失效|登录超时|重新登录|会话失效|会话超时|不合法)[^"']*["']/i.test(source)) return true;
  if (/alert\s*\([^)]*(?:登录|会话|不合法)[^)]*\)/i.test(source)) return true;
  return /\/ve\/back\/resourceSpace\.shtml/i.test(String(resUrl || ''))
    && /["']flag["']\s*:\s*false/i.test(source);
}

let veRequestReauthenticationPromise = null;
let veLastRequestReauthenticationAt = 0;
let veLastRequestReauthenticationResult = false;
async function reauthenticateVeSessionOnly() {
  if (globalThis.shouldAutoLoginAfterExpiry?.('ve') !== true) return false;
  if (veRequestReauthenticationPromise) return veRequestReauthenticationPromise;
  if (Date.now() - veLastRequestReauthenticationAt < 1500) return veLastRequestReauthenticationResult;
  veRequestReauthenticationPromise = (async () => {
    const account = String(window.currentAccountLoginName || usernameInput?.value || lastValidUsername || '').trim();
    if (!account || typeof doLoginFlow !== 'function') {
      veLastRequestReauthenticationResult = false;
      return false;
    }
    if (usernameInput instanceof HTMLInputElement) usernameInput.value = account;
    const result = await doLoginFlow({ reloadPlatform: false });
    const ok = result?.ok === true;
    veLastRequestReauthenticationResult = ok;
    return ok;
  })().finally(() => {
    veLastRequestReauthenticationAt = Date.now();
    veRequestReauthenticationPromise = null;
  });
  return veRequestReauthenticationPromise;
}

async function fetchVeWithAuthRetry(url, options = {}, retried = false) {
  const response = await fetch(url, options);
  if (retried || !isVeRequestUrl(url)) return response;
  let invalid = isLikelyLoginPageHtml('', response.url);
  if (!invalid && /(?:text\/html|application\/xhtml\+xml)/i.test(String(response.headers.get('content-type') || ''))) {
    const text = await response.clone().text().catch(() => '');
    invalid = isVeSessionInvalidResponse(text, response.url);
  }
  if (!invalid || !await reauthenticateVeSessionOnly()) return response;
  return fetchVeWithAuthRetry(url, options, true);
}

globalThis.isVeSessionInvalidResponse = isVeSessionInvalidResponse;
globalThis.reauthenticateVeSessionOnly = reauthenticateVeSessionOnly;
globalThis.fetchVeWithAuthRetry = fetchVeWithAuthRetry;

async function loadSaveUploadsEnabledSetting() {
  try {
    const data = await chrome.storage.local.get(['saveUploadedFilesEnabled', 'downloadInExtensionEnabled']);
    window.saveUploadedFilesEnabled = data.saveUploadedFilesEnabled === undefined
      ? true
      : !!data.saveUploadedFilesEnabled;
    window.downloadInExtensionEnabled = data.downloadInExtensionEnabled !== false;
  } catch {
    window.saveUploadedFilesEnabled = true;
    window.downloadInExtensionEnabled = true;
  }
  const input = document.getElementById('save-uploads-enabled');
  if (input instanceof HTMLInputElement) input.checked = !!window.saveUploadedFilesEnabled;
  const downloadInput = document.getElementById('download-in-extension-enabled');
  if (downloadInput instanceof HTMLInputElement) {
    downloadInput.checked = window.downloadInExtensionEnabled;
    downloadInput.addEventListener('change', () => {
      window.downloadInExtensionEnabled = downloadInput.checked;
      chrome.storage.local.set({ downloadInExtensionEnabled: downloadInput.checked });
    });
  }
}

const trackedExpandableMedia = new WeakSet();
const pendingExpandableMediaMeasurements = new WeakSet();
function applyExpandableAutoToggle(root = document) {
  const boxes = root instanceof Element && root.matches('.expandable-box')
    ? [root]
    : root.querySelectorAll('.expandable-box');
  boxes.forEach((box) => {
    if (!(box instanceof HTMLElement)) return;
    // Hidden overdue/done groups cannot be measured reliably; they are measured after the group is expanded and rerendered.
    if (!box.getClientRects().length) return;
    const body = box.querySelector('.expandable-body');
    if (!(body instanceof HTMLElement)) return;
    body.querySelectorAll('img').forEach((image) => {
      if (!(image instanceof HTMLImageElement) || trackedExpandableMedia.has(image)) return;
      trackedExpandableMedia.add(image);
      image.addEventListener('load', () => scheduleExpandableMediaMeasurement(image), { once: true });
      image.addEventListener('error', () => scheduleExpandableMediaMeasurement(image), { once: true });
      if (image.complete) scheduleExpandableMediaMeasurement(image);
    });
    const collapsedLines = box.classList.contains('expandable-box--replay')
      ? window.replayDetailCollapsedLines
      : window.homeworkDetailCollapsedLines;
    const visibleLimit = detailVisibleMaxHeight(collapsedLines);
    const prev = body.style.maxHeight;
    const prevOverflow = body.style.overflow;
    body.style.maxHeight = visibleLimit;
    body.style.overflow = 'auto';
    const canFitInCollapsed = body.scrollHeight <= body.clientHeight + 2;
    box.classList.toggle('no-toggle', canFitInCollapsed);
    if (canFitInCollapsed) {
      box.classList.remove('expanded');
      box.dataset.expanded = '0';
    }
    body.style.maxHeight = prev;
    body.style.overflow = prevOverflow;
  });
}

function scheduleExpandableMediaMeasurement(media) {
  if (!(media instanceof HTMLElement)) return;
  const box = media.closest('.expandable-box');
  if (!(box instanceof HTMLElement) || pendingExpandableMediaMeasurements.has(box)) return;
  pendingExpandableMediaMeasurements.add(box);
  requestAnimationFrame(() => {
    pendingExpandableMediaMeasurements.delete(box);
    if (!box.isConnected) return;
    applyExpandableAutoToggle(box);
  });
}

if (courseListDiv) {
  const onExpandableMediaSettled = (event) => {
    const target = event.target;
    if (target instanceof HTMLImageElement && target.closest('.expandable-body')) {
      scheduleExpandableMediaMeasurement(target);
    }
  };
  courseListDiv.addEventListener('load', onExpandableMediaSettled, true);
  courseListDiv.addEventListener('error', onExpandableMediaSettled, true);
}

async function loadPlatformVisibleFromStorage() {
  try {
    const data = await chrome.storage.local.get(['platformVisible']);
    window.platformVisible = sanitizePlatformVisible(data?.platformVisible, DEFAULT_PLATFORM_VISIBLE);
  } catch {
    window.platformVisible = { ...DEFAULT_PLATFORM_VISIBLE };
  }
  applyPlatformVisibility();
}

// -------------------- Login --------------------
function getLoginFallbackUsername(targetUsername = '') {
  const target = String(targetUsername || '').trim();
  const pendingFrom = String(pendingUsernameChange?.from || '').trim();
  if (pendingFrom && pendingFrom !== target) return pendingFrom;
  const last = String(lastValidUsername || '').trim();
  if (last && last !== target) return last;
  const newest = normalizeLoginAccountHistoryList(loginAccountHistory)[0] || null;
  const remembered = String(newest?.userId || newest?.loginName || '').trim();
  if (remembered && remembered !== target) return remembered;
  return '';
}

async function restoreLoginFallbackUsername(targetUsername = '') {
  const fallback = getLoginFallbackUsername(targetUsername);
  if (!fallback) return '';
  usernameInput.value = fallback;
  await setLocal('username', fallback);
  lastValidUsername = fallback;
  pendingUsernameChange = null;
  resetAccountSwitchInterruption();
  const localInfo = findLoginAccountRecord(fallback);
  setWelcomeMessage(localInfo || null);
  renderLoginAccountHistorySelect(fallback);
  updateJsessionidState();
  return fallback;
}

async function validateUsernameBeforeLoginStart(userId, { signal } = {}) {
  const uid = String(userId || '').trim();
  if (!uid) return { ok: false, status: 'empty', message: '请输入账号' };
  if (signal?.aborted) return { ok: false, status: 'cancelled', message: '已取消' };
  try {
    await globalThis.BjtuAccountLogin?.ensureInitialized?.({ showProgress: true });
  } catch {
    return { ok: false, status: 'unknown', message: '账号列表初始化失败' };
  }
  if (signal?.aborted) return { ok: false, status: 'cancelled', message: '已取消' };
  const info = await getLocalAccountInfo(uid);
  return { ok: true, status: 'needs-post-login', info, accountMissing: !info };
}

function hideLoginModal() {
  loginModal.style.display = 'none';
}

function showLoginCredentialEvents(result) {
  const types = new Set((Array.isArray(result?.credentialEvents) ? result.credentialEvents : [])
    .map((event) => String(event?.type || '')));
  if (types.has('quickUsername-cleared') && types.has('password-cleared')) {
    showToast('极速登录凭据和保存的密码均已失效，已从本地账号中清除', 'warning', 4200);
  } else if (types.has('quickUsername-cleared')) {
    showToast('极速登录凭据已失效，已清除该账号的 quickUsername', 'warning', 4200);
  } else if (types.has('password-cleared')) {
    showToast('保存的密码已失效，已清除该账号的 password', 'warning', 4200);
  }
}

function dismissLoginModal({ abort = true } = {}) {
  hideLoginModal();
  if (abort) {
    try { loginAbortController?.abort(); } catch { /* ignore */ }
    loginAbortController = null;
    if (isLoginInProgress) loginCancelRequested = true;
  }
  if (pendingUsernameChange) {
    const backTo = String(pendingUsernameChange.from || '').trim();
    if (backTo) {
      syncAccountInfoAndReloadVeCourses({
        userId: backTo,
        reloadCourses: false,
        reloadResourceSpace: true
      }).catch(() => { });
    }
  }
}

if (loginModal) {
  loginModal.addEventListener('mousedown', (e) => {
    loginModal.dataset.mdownMask = e.target === loginModal ? '1' : '0';
  });
  loginModal.addEventListener('mouseup', (e) => {
    if (e.target === loginModal && loginModal.dataset.mdownMask === '1') {
      dismissLoginModal();
    }
    delete loginModal.dataset.mdownMask;
  });
}

const loginModalClose = document.getElementById('login-modal-close');
if (loginModalClose instanceof HTMLButtonElement) {
  loginModalClose.addEventListener('click', () => dismissLoginModal());
}

async function handleLoginSuccess(username, { reloadPlatform = true } = {}) {
  if (reloadPlatform && !isPlatformEnabled('ve')) {
    window.platformEnabled.ve = true;
    savePlatformEnabledToStorage().catch(() => { });
  }
  if (reloadPlatform) {
    window.platformLoadedOnce.ve = false;
    setPlatformLoginState('ve', 'checking');
  }
  isLoginSessionValid = true;
  loginCancelRequested = false;
  hideLoginModal();
  void forceSyncJsessionidAfterLogin().catch(() => { });

  let finalUser = String(username || '').trim();
  usernameInput.value = finalUser;
  window.currentAccountLoginName = finalUser;
  suppressedUsernameChangeValue = finalUser;
  updateJsessionidState();

  if (reloadPlatform) runPendingLoginCallbacks();
  showToast('登录成功', 'success');

  if (reloadPlatform) {
    await loadAutoLoadCourseResourcesSetting().catch(() => { });
    await reloadVePlatformFromSession({
      reloadCourses: true,
      reloadResourceSpace: true
    }).catch(() => { });
  } else {
    if (isPlatformEnabled('ve')) setPlatformLoginState('ve', 'online');
    await syncJsessionidToUi().catch(() => { });
  }
}

async function captchaModuleManifestExists() {
  try {
    const response = await fetch(chrome.runtime.getURL('modules/captcha/module.json'), { cache: 'no-store' });
    return response.ok;
  } catch {
    return false;
  }
}

async function openCaptchaOptionsFromApp() {
  if (!(await captchaModuleManifestExists())) return false;
  const assets = globalThis.BjtuCaptchaAssets;
  const opener = typeof assets?.openOptionsPopup === 'function'
    ? assets.openOptionsPopup
    : null;
  const result = opener
    ? await opener.call(assets, { from: 'app' })
    : null;
  if (!result?.opened) {
    location.href = chrome.runtime.getURL('modules/captcha/options.html?from=app');
  }
  return true;
}

function doLoginFlow(options = {}) {
  if (activeLoginFlowPromise) return activeLoginFlowPromise;
  activeLoginFlowPromise = runLoginFlow(options).finally(() => {
    activeLoginFlowPromise = null;
  });
  return activeLoginFlowPromise;
}

async function runLoginFlow({ reloadPlatform = true } = {}) {
  if (isLoginInProgress) return { ok: false, reason: 'busy', message: '已有登录流程正在进行' };
  const username = String(usernameInput.value || '').trim();
  if (!username) {
    showToast('请输入账号，或改为填写 JSESSIONID', 'warning');
    return { ok: false, reason: 'empty', message: '请输入账号' };
  }

  loginFlowUsernameSet = true;
  usernameChangeVersion += 1;
  try { usernameChangeAbortController?.abort(); } catch { }
  if (reloadPlatform) prioritizeAccountSwitch();
  const wasSwitchingAccount = !!pendingUsernameChange;
  let restoredAfterFailure = false;
  const restoreAfterFailure = async () => {
    if (restoredAfterFailure) return;
    restoredAfterFailure = true;
    await restoreLoginFallbackUsername(username);
  };

  if (loginBtn) {
    loginBtn.disabled = true;
    loginBtn.style.opacity = '0.7';
    loginBtn.innerHTML = '登录中… <span class="spinner"></span>';
  }
  isLoginInProgress = true;
  loginCancelRequested = false;
  loginAbortController = new AbortController();
  const signal = loginAbortController.signal;

  try {
    showToast('正在读取账号列表…', 'info', 0);
    const initialInitializationResult = await globalThis.BjtuAccountLogin.ensureInitialized({ showProgress: true });
    if (signal.aborted || loginCancelRequested) return { ok: false, reason: 'cancelled', message: '登录已取消' };

    let account = await getLocalAccountInfo(username);
    let manualPassword = '';
    let manualPasswordPlain = '';
    let manualPasscode = '';
    let allowStoredCredentials = initialInitializationResult?.skipped !== true;
    let recoveryMessage = account
      ? '账号或密码错误，请重新初始化账号列表或手动输入密码。'
      : '账号不在本地账号列表中，请重新初始化账号列表或手动输入密码。';

    while (true) {
      if (signal.aborted || loginCancelRequested) return { ok: false, reason: 'cancelled', message: '登录已取消' };

      const submittedPassword = manualPassword;
      const submittedPasswordPlain = manualPasswordPlain;
      const submittedPasscode = manualPasscode;
      manualPassword = '';
      manualPasswordPlain = '';
      manualPasscode = '';
      showToast('正在登录…', 'info', 0);
      await enforceJsessionidBeforeLoginRequest();
      const result = await globalThis.BjtuAccountLogin.login(username, {
        signal,
        password: submittedPassword,
        passwordPlain: submittedPasswordPlain,
        passcode: submittedPasscode,
        skipCurrentCheck: true,
        allowStoredCredentials
      });
      if (signal.aborted || loginCancelRequested) return { ok: false, reason: 'cancelled', message: '登录已取消' };
      showLoginCredentialEvents(result);
      if (Array.isArray(result?.credentialEvents) && result.credentialEvents.length) {
        account = await getLocalAccountInfo(username);
      }

      if (result?.ok) {
        const resultLoginName = String(result?.userInfo?.loginName || '').trim();
        if (resultLoginName && resultLoginName !== username) {
          await restoreAfterFailure();
          const mismatchResult = {
            ...result,
            ok: false,
            reason: 'account-mismatch',
            account: username,
            actualAccount: resultLoginName,
            message: `登录响应账号为 ${resultLoginName}，目标账号 ${username} 未登录成功`
          };
          showToast(mismatchResult.message, 'error', 3500);
          return mismatchResult;
        }
        await handleLoginSuccess(username, { reloadPlatform });
        return { ...result, account: username };
      }
      if (result?.reason === 'captcha') {
        showToast('验证码错误，正在重新识别…', 'warning', 1800);
        manualPassword = submittedPassword;
        manualPasswordPlain = submittedPasswordPlain;
        continue;
      }
      if (result?.reason === 'captcha-module-missing'
          || result?.reason === 'captcha-resources-missing'
          || /本地验证码识别模块未安装/i.test(String(result?.message || ''))) {
        if (await openCaptchaOptionsFromApp()) {
          await restoreAfterFailure();
          return { ...result, account: username };
        }
        recoveryMessage = '本地验证码识别模块未安装，请手动输入验证码后继续登录。';
      }
      if (result?.reason === 'locked' || result?.reason === 'password-reset') {
        if (result.reason === 'password-reset') {
          const resetUrl = BASE_VE + 'CheckEmail.shtml?method=resetPassword&username=' + encodeURIComponent(username);
          chrome.tabs.create({ url: resetUrl, active: true })
            .then((tab) => groupBjtuOpenedTab(tab?.id))
            .catch(() => { });
        }
        await restoreAfterFailure();
        showToast(result.message || '登录失败', 'error', 4000);
        return { ...result, account: username };
      }
      if (!['credential', 'account-not-found', 'needs-password', 'captcha-required',
        'captcha-module-missing', 'captcha-resources-missing'].includes(result?.reason)) {
        await restoreAfterFailure();
        showToast(result?.message || '登录失败', 'error', 3000);
        return { ...result, account: username };
      }

      recoveryMessage = result?.message || recoveryMessage;
      const startManualWithCaptcha = ['captcha-required', 'captcha-module-missing',
        'captcha-resources-missing'].includes(result?.reason);
      let captchaImageUrl = '';
      if (startManualWithCaptcha) {
        try {
          captchaImageUrl = await globalThis.BjtuAccountLogin.getCaptchaImageDataUrl();
        } catch (error) {
          await restoreAfterFailure();
          showToast('验证码图片获取失败：' + String(error?.message || error), 'error', 3000);
          return { ok: false, reason: 'captcha-image', account: username, message: String(error?.message || error) };
        }
      }
      const fallbackPassword = submittedPassword
        || (account?.password && typeof strEnc === 'function' ? strEnc(account.password) : '');
      const recoveryTitle = document.getElementById('account-recovery-title');
      if (recoveryTitle instanceof HTMLElement) {
        recoveryTitle.textContent = result?.captchaRejected === true ? '验证码错误' : '账号或密码错误';
      }
      const recovery = await globalThis.BjtuAccountLogin.requestRecovery(username, recoveryMessage, {
        requireCaptcha: true,
        startManual: startManualWithCaptcha,
        captchaImageUrl,
        fallbackPassword
      });
      if (signal.aborted || loginCancelRequested) return { ok: false, reason: 'cancelled', account: username, message: '登录已取消' };
      if (recovery?.action === 'cancel') {
        await restoreAfterFailure();
        showToast('登录失败，已恢复原账号', 'warning', 2200);
        return { ok: false, reason: 'cancelled', account: username, message: '用户已取消登录' };
      }
      if (recovery?.action === 'reinitialize') {
        try {
          const initializationResult = await globalThis.BjtuAccountLogin.initialize({ force: true, showProgress: true });
          if (initializationResult?.skipped === true) {
            allowStoredCredentials = false;
            continue;
          }
          account = await getLocalAccountInfo(username);
          recoveryMessage = account
            ? '账号或密码错误，请重新初始化账号列表或手动输入密码。'
            : '账号不在本地账号列表中，请重新初始化账号列表或手动输入密码。';
          allowStoredCredentials = true;
          if (account) {
            showToast('账号列表已更新，正在重新登录…', 'info', 0);
          }
        } catch (error) {
          recoveryMessage = '账号列表初始化失败：' + String(error?.message || error);
        }
        continue;
      }
      if (recovery?.action === 'password' && recovery.password) {
        manualPassword = String(recovery.password).trim();
        manualPasswordPlain = String(recovery.passwordPlain || '');
        manualPasscode = String(recovery.passcode || '').trim();
        allowStoredCredentials = true;
      }
    }
  } catch (error) {
    if (signal.aborted || loginCancelRequested) return { ok: false, reason: 'cancelled', account: username, message: '登录已取消' };
    console.error('Login error:', error);
    await restoreAfterFailure();
    showToast('登录过程中出现异常：' + String(error?.message || error), 'error', 3500);
    return { ok: false, reason: 'error', account: username, message: String(error?.message || error) };
  } finally {
    const switchModalClosed = !loginModal || loginModal.style.display === 'none';
    if (wasSwitchingAccount && pendingUsernameChange && switchModalClosed) {
      if (isPlatformEnabled('ve')) {
        try { await loadCourses(); } catch { }
      }
      try { await loadResourceSpaceForCurrentAccount(); } catch { }
      window.syncRightColumnResizer?.();
    }
    isLoginInProgress = false;
    loginFlowUsernameSet = false;
    loginAbortController = null;
    if (loginBtn) {
      loginBtn.disabled = false;
      loginBtn.style.opacity = '1';
      loginBtn.innerHTML = '登录';
    }
  }
}

// -------------------- Courses / Homework / Videos --------------------
function normalizeCourseNumToken(v) {
  return String(v || '').trim().toUpperCase();
}

function normalizeTail10Token(v) {
  const t = normalizeCourseNumToken(v).replace(/[^A-Z0-9]/g, '');
  return t.length > 10 ? t.slice(-10) : t;
}

function getVeCourseSeq10(course) {
  const fzId = course?.fz_id || course?.fzId || course?.xkhId || course?.xkh_id || '';
  const fromFzId = normalizeTail10Token(fzId);
  if (fromFzId) return fromFzId;
  const fallback = course?.course_num || course?.courseNum || course?.courseNo
    || course?.course_id || course?.courseId || course?.id || course?.cId || '';
  return normalizeTail10Token(fallback);
}

function collectVeFzIdTail10Map(courses) {
  const result = new Map();
  (courses || []).forEach((course) => {
    const courseId = course.id || course.cId || course.courseId || course.course_id;
    const fzId = course?.fz_id || course?.fzId || course?.xkhId || course?.xkh_id || '';
    const seq10 = normalizeTail10Token(fzId);
    if (courseId && seq10) result.set(seq10, { courseId, fzId });
  });
  return result;
}

function normalizeCourseNameToken(v) {
  return String(v || '')
    .replace(/\s+/g, '')
    .replace(/[()（）\[\]【】{}<>《》:：·、,，.。!！?？'"`~_^\\/|-]/g, '')
    .trim()
    .toUpperCase();
}

function findCourseMatch(tokenMap, nameMap, token, nameToken) {
  const t = String(token || '').trim();
  const nt = String(nameToken || '').trim();
  if (t) {
    const direct = tokenMap.get(t);
    if (direct) return direct;
  }
  if (nt) {
    const directName = nameMap.get(nt);
    if (directName) return directName;
    for (const [k, v] of nameMap.entries()) {
      if (!k || k.length < 4 || nt.length < 4) continue;
      if (k.includes(nt) || nt.includes(k)) return v;
    }
  }
  return null;
}

function todayEndDateTimeString() {
  const now = new Date();
  return formatMrjzyDateTime(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59));
}

function parseDeadlineToTs(v) {
  if (v === null || v === undefined) return 0;
  if (typeof v === 'number') {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return 0;
    return n < 1e12 ? n * 1000 : n;
  }
  const s = String(v || '').trim();
  if (!s) return 0;
  if (/^\d+$/.test(s)) {
    const n = Number(s);
    if (!Number.isFinite(n) || n <= 0) return 0;
    return n < 1e12 ? n * 1000 : n;
  }
  const normalized = s.replace(/\//g, '-').replace(/\./g, '-').replace('T', ' ');
  const ts = Date.parse(normalized);
  return Number.isFinite(ts) ? ts : 0;
}

function isDeadlinePassed(v) {
  const ts = parseDeadlineToTs(v);
  return !!(ts && ts < Date.now());
}

function sortHomeworkItemsByDeadline(items, pickDeadline) {
  const list = Array.isArray(items) ? items.slice() : [];
  return list
    .map((it, idx) => {
      const raw = pickDeadline ? pickDeadline(it) : '';
      const ts = parseDeadlineToTs(raw);
      return {
        it,
        idx,
        ts: ts > 0 ? ts : Number.MAX_SAFE_INTEGER
      };
    })
    .sort((a, b) => {
      if (a.ts !== b.ts) return a.ts - b.ts;
      return a.idx - b.idx;
    })
    .map((x) => x.it);
}

function isNativeHomeworkDone(hw) {
  const subStatus = String(hw?.subStatus ?? hw?.sub_status ?? '').trim();
  const subTime = String(hw?.subTime ?? hw?.sub_time ?? '').trim();
  return (subStatus && subStatus !== '未提交') || !!subTime;
}

function isNativeHomeworkPending(hw) {
  const deadline = hw?.end_time ?? hw?.endTime ?? '';
  return !isNativeHomeworkDone(hw) && !isDeadlinePassed(deadline);
}

function isNativeHomeworkOverdue(hw) {
  const deadline = hw?.end_time ?? hw?.endTime ?? '';
  return !isNativeHomeworkDone(hw) && isDeadlinePassed(deadline);
}

function ensureCourseCardState(courseId) {
  if (!window.courseCardStateById[courseId]) {
    window.courseCardStateById[courseId] = {
      allHomeworkCount: 0,
      pendingHomeworkCount: 0,
      pendingEarliestTs: 0,
      overdueHomeworkCount: 0,
      overdueEarliestTs: 0,
      hasReplay: false,
      replayListLoading: false,
      hasCourseware: false,
      coursewareListLoading: false
    };
  }
  return window.courseCardStateById[courseId];
}

function calcCourseRank(state) {
  if ((state?.pendingHomeworkCount || 0) > 0) return 0;
  if ((state?.overdueHomeworkCount || 0) > 0) return 1;
  if ((state?.allHomeworkCount || 0) > 0) return 2;
  const hasReplay = !!state?.hasReplay && !state?.replayListLoading;
  const hasCourseware = !!state?.hasCourseware && !state?.coursewareListLoading;
  if (hasReplay && hasCourseware) return 3;
  if (hasReplay) return 4;
  if (hasCourseware) return 5;
  return 9;
}

function compareCourseCards(a, b) {
  const ra = Number(a.dataset.rank || 7);
  const rb = Number(b.dataset.rank || 7);
  if (ra !== rb) return ra - rb;

  if (ra === 0 && rb === 0) {
    const ida = String(a.id || '').startsWith('course-') ? String(a.id).slice(7) : '';
    const idb = String(b.id || '').startsWith('course-') ? String(b.id).slice(7) : '';
    const tsa = Number(window.courseCardStateById?.[ida]?.pendingEarliestTs || 0);
    const tsb = Number(window.courseCardStateById?.[idb]?.pendingEarliestTs || 0);
    const va = tsa > 0 ? tsa : Number.MAX_SAFE_INTEGER;
    const vb = tsb > 0 ? tsb : Number.MAX_SAFE_INTEGER;
    if (va !== vb) return va - vb;
  }

  if (ra === 1 && rb === 1) {
    const ida = String(a.id || '').startsWith('course-') ? String(a.id).slice(7) : '';
    const idb = String(b.id || '').startsWith('course-') ? String(b.id).slice(7) : '';
    const tsa = Number(window.courseCardStateById?.[ida]?.overdueEarliestTs || 0);
    const tsb = Number(window.courseCardStateById?.[idb]?.overdueEarliestTs || 0);
    const va = tsa > 0 ? tsa : Number.MAX_SAFE_INTEGER;
    const vb = tsb > 0 ? tsb : Number.MAX_SAFE_INTEGER;
    if (va !== vb) return va - vb;
  }

  const oa = Number(a.dataset.order || 0);
  const ob = Number(b.dataset.order || 0);
  return oa - ob;
}

function sortCourseCardsInContainer(container, cards) {
  const sortedCards = cards.slice().sort(compareCourseCards);
  const unchanged = cards.length === sortedCards.length && cards.every((c, idx) => c === sortedCards[idx]);
  if (unchanged) return false;
  sortedCards.forEach((card) => container.appendChild(card));
  return true;
}

function sortCourseCards() {
  if (!courseListDiv) return;
  if (shouldSuspendCourseHelperLayoutWork()) {
    courseHelperLayoutWorkPending = true;
    return;
  }
  let changed = false;
  if (shouldUseCoursePlatformColumns()) {
    courseListDiv.querySelectorAll('.platform-course-column-body').forEach((body) => {
      const cards = Array.from(body.querySelectorAll(':scope > .file-item[data-course-rankable="1"]'));
      changed = sortCourseCardsInContainer(body, cards) || changed;
    });
  } else {
    const cards = Array.from(courseListDiv.querySelectorAll('.file-item[data-course-rankable="1"]'));
    changed = sortCourseCardsInContainer(courseListDiv, cards);
  }
  if (changed) syncCourseActionLoadingSpinnerPhase();
}

function hasCourseActionButtonAnimationActive() {
  return !!courseListDiv.querySelector('button[data-action="videos"].replay-list-loading, button[data-action="videos"].replay-link-progress, button[data-action="courseware"].courseware-list-loading, button[data-action="courseware"].courseware-link-progress');
}

function sortCourseCardsWithGuard({ deferWhileActionAnimating = false } = {}) {
  if (deferWhileActionAnimating && hasCourseActionButtonAnimationActive()) {
    window.courseCardSortPending = true;
    return;
  }
  window.courseCardSortPending = false;
  sortCourseCards();
}

function flushPendingCourseCardSortIfIdle() {
  if (!window.courseCardSortPending) return;
  if (hasCourseActionButtonAnimationActive()) return;
  window.courseCardSortPending = false;
  sortCourseCards();
}

function updateCourseCardRank(courseId, { deferWhileActionAnimating = false } = {}) {
  const card = document.getElementById(`course-${courseId}`);
  if (!card) return;
  const state = ensureCourseCardState(courseId);
  card.dataset.rank = String(calcCourseRank(state));
  sortCourseCardsWithGuard({ deferWhileActionAnimating });
}

function isAnyExternalPlatformChecking() {
  return !!(
    isPlatformEnabled('ykt') && window.platformLoginState?.ykt === 'checking'
    || isPlatformEnabled('mrjzy') && window.platformLoginState?.mrjzy === 'checking'
    || isPlatformEnabled('jlgj') && window.platformLoginState?.jlgj === 'checking'
    || isPlatformEnabled('mooc') && window.platformLoginState?.mooc === 'checking'
    || isPlatformEnabled('xuetangx') && window.platformLoginState?.xuetangx === 'checking'
  );
}

function suffixAfterDash(v) {
  const s = String(v || '').trim();
  const idx = s.indexOf('-');
  return (idx >= 0 ? s.slice(idx + 1) : s).trim();
}

function completeExternalLoginAssist(platform, forceReload = true) {
  const p = normalizePlatformId(platform);
  if (!['ykt', 'mrjzy', 'jlgj', 'mooc'].includes(p)) return;
  if (!window.platformEnabled?.[p]) {
    window.platformEnabled[p] = true;
    savePlatformEnabledToStorage().catch(() => { });
  }
  window.platformInteractiveLoginPending[p] = false;
  setPlatformLoginState(p, 'checking');
  triggerExternalPlatformLoad(p, forceReload);
}

function showPlatformNeedLoginToast(platform) {
  const p = String(platform || '').trim();
  if (!PLATFORM_IDS.includes(p)) return;
  if (!window.__platformOfflineToastById) window.__platformOfflineToastById = {};
  const now = Date.now();
  const lastAt = Number(window.__platformOfflineToastById[p] || 0);
  if (now - lastAt < 6000) return;
  window.__platformOfflineToastById[p] = now;

  showToast(globalThis.BjtuPlatformLoginUi.loginRequiredHtml(p), 'warning', 3200, true);
}

function setPlatformLoginState(platform, state) {
  const p = normalizePlatformId(platform);
  const prev = String(window.platformLoginState?.[p] || '').trim();
  const s = (state === 'online' || state === 'offline') ? state : 'checking';
  window.platformLoginState[p] = s;
  if (p === 've' && s === 'online') window.platformInteractiveLoginPending.ve = false;
  window.dispatchEvent(new CustomEvent('bjtu-platform-login-state-change', {
    detail: { platform: p, state: s, previousState: prev }
  }));
  if (s !== 'online') delete window.platformContentLoadProgress[p];
  if (p === 'ykt' && s === 'online') {
    window.platformInteractiveLoginPending.ykt = false;
    closeYktLoginAssistPopup(false);
  }
  if (p === 'mrjzy' && s === 'online') {
    window.platformInteractiveLoginPending.mrjzy = false;
    closeMrjzyLoginAssistPopup(false);
  }
  if (p === 'jlgj' && s === 'online') {
    window.platformInteractiveLoginPending.jlgj = false;
    closeJlgjLoginAssistPopup(false);
  }
  if (p === 'mooc' && s === 'online') {
    window.platformInteractiveLoginPending.mooc = false;
    closeMoocLoginAssistPopup(false);
  }
  if (p === 'xuetangx' && s === 'online') {
    window.platformInteractiveLoginPending.xuetangx = false;
  }
  if (s === 'online' || s === 'offline') {
    window.platformLoginChecked[p] = true;
  }
  window.platformNeedLogin[p] = isPlatformEnabled(p) && s === 'offline';
  if (window.platformNeedLogin[p] && s === 'offline' && prev !== 'offline') {
    showPlatformNeedLoginToast(p);
  }
  if (s === 'offline') {
    disablePlatformAfterLoginFailure(p);
  }
  refreshPlatformLoginTip();
  updateCourseListEmptyPlaceholder();
  if (s === 'online' || s === 'offline') {
    scheduleFullscreenCourseCacheSave(300);
  }
  if (!isAnyExternalPlatformChecking()) {
    flushPendingCourseCardSortIfIdle();
  }
}

async function waitForPlatformDataReady(platform, timeoutMs = 120000) {
  const p = normalizePlatformId(platform);
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs) || 120000);
  while (Date.now() < deadline) {
    const state = String(window.platformLoginState?.[p] || 'checking');
    if (state === 'offline') return false;
    const pending = window.platformLoadPromises?.[p];
    if (pending && typeof pending.then === 'function') {
      const remaining = Math.max(1, deadline - Date.now());
      await Promise.race([
        Promise.resolve(pending).catch(() => {}),
        new Promise((resolve) => setTimeout(resolve, Math.min(remaining, 1000)))
      ]);
    }
    const progress = window.platformContentLoadProgress?.[p];
    const progressFinished = !(Number(progress?.total) > 0 && Number(progress?.completed) < Number(progress?.total));
    if (String(window.platformLoginState?.[p] || '') === 'online'
      && window.platformLoadedOnce?.[p] === true
      && progressFinished
      && window.platformLoadPending?.[p] !== true
      && window.platformLoadPromises?.[p] === pending) {
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  return false;
}
window.waitForPlatformDataReady = waitForPlatformDataReady;

// login 操作只负责启用尚未启用的平台。已经启用时返回当前页面快照，
// 避免再次触发平台加载、登录弹窗或账号切换。
function getEnabledPlatformLoginResult(platform) {
  const p = normalizePlatformId(platform);
  const loginState = String(window.platformLoginState?.[p] || 'checking');
  const progress = window.platformContentLoadProgress?.[p];
  const progressFinished = !(Number(progress?.total) > 0 && Number(progress?.completed) < Number(progress?.total));
  const ready = loginState === 'online'
    && window.platformLoadedOnce?.[p] === true
    && progressFinished
    && window.platformLoadPending?.[p] !== true;
  return {
    ok: true,
    enabled: true,
    alreadyEnabled: true,
    loggedIn: loginState === 'online',
    ready,
    loginState,
    message: ready ? '平台已启用，数据已加载完毕' : '平台已启用，不重复触发登录'
  };
}
window.getEnabledPlatformLoginResult = getEnabledPlatformLoginResult;

// 等待某个平台登录流程结束，登录成功后还要等课程和作业数据完全加载。
// 供各平台页面桥的 login 操作调用。
async function waitForPlatformLoginResult(platform, timeoutMs = 120000) {
  const p = normalizePlatformId(platform);
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs) || 120000);
  const waitForStateChange = (waitMs) => new Promise((resolve) => {
    let timer = 0;
    const cleanup = () => {
      if (timer) clearTimeout(timer);
      window.removeEventListener('bjtu-platform-login-state-change', onStateChange);
    };
    const onStateChange = (event) => {
      if (String(event?.detail?.platform || '') !== p) return;
      cleanup();
      resolve();
    };
    window.addEventListener('bjtu-platform-login-state-change', onStateChange);
    timer = setTimeout(() => {
      cleanup();
      resolve();
    }, Math.max(1, Number(waitMs) || 1));
  });
  while (Date.now() < deadline) {
    const state = String(window.platformLoginState?.[p] || 'checking');
    if (state === 'online') {
      const ready = await waitForPlatformDataReady(p, deadline - Date.now());
      const finalState = String(window.platformLoginState?.[p] || 'checking');
      if (ready && finalState === 'online') {
        return { ok: true, loggedIn: true, ready: true, loginState: finalState, message: '登录成功，平台数据已加载完毕' };
      }
      if (finalState === 'offline') return { ok: false, message: '登录失败' };
      return { ok: false, loggedIn: true, ready: false, loginState: finalState, message: '已登录，但等待平台数据加载超时' };
    }
    if (state === 'offline' && !window.platformInteractiveLoginPending?.[p]) {
      return { ok: false, message: '登录失败' };
    }
    await waitForStateChange(Math.min(1500, deadline - Date.now()));
  }
  const finalState = String(window.platformLoginState?.[p] || 'checking');
  return {
    ok: false,
    loggedIn: finalState === 'online',
    ready: false,
    loginState: finalState,
    message: finalState === 'online' ? '已登录，但等待平台数据加载超时' : '等待登录超时，请在助手页面完成登录后重试'
  };
}

// 把扩展在后台打开的登录/请求页面归入「BJTU 课程助手」标签分组（复用已存在的分组）。
async function groupBjtuOpenedTab(tabId) {
  if (typeof chrome !== 'object' || !chrome?.runtime?.sendMessage || tabId == null) return;
  try {
    await chrome.runtime.sendMessage({ type: 'GROUP_BJTU_OPENED_TAB', tabId });
  } catch {
    // 分组失败不影响主流程
  }
}

function setPlatformContentLoadProgress(platform, completed, total) {
  const p = normalizePlatformId(platform);
  const count = Math.max(0, Number(completed) || 0);
  const size = Math.max(0, Number(total) || 0);
  if (!size || count >= size || !isPlatformEnabled(p)) {
    delete window.platformContentLoadProgress[p];
  } else {
    window.platformContentLoadProgress[p] = { completed: Math.min(count, size), total: size };
  }
  refreshPlatformLoginTip({ scheduleLayout: false });
}
window.setPlatformContentLoadProgress = setPlatformContentLoadProgress;

function refreshPlatformLoginTip({ scheduleLayout = true } = {}) {
  removeMrjzyLoginTip();

  const apply = (btn, state, label) => {
    if (!btn) return;
    btn.classList.remove('checking', 'offline', 'online', 'content-loading', 'unselected-checked-online', 'unselected-checked-offline', 'unselected-checked-checking');
    const id = String(btn.id || '');
    const platform = String(btn.dataset.platform || btn.dataset.module || '') || (id.includes('ve-status-btn')
      ? 've'
      : (id.includes('mrjzy-status-btn') ? 'mrjzy' : (id.includes('jlgj-status-btn') ? 'jlgj' : (id.includes('mooc-status-btn') ? 'mooc' : 'ykt'))));
    const enabled = isPlatformEnabled(platform);
    const treatAsUnselected = !enabled || state === 'offline';
    if (!treatAsUnselected) {
      btn.classList.add(state);
    } else if (window.platformLoginChecked?.[platform]) {
      const key = state === 'online' ? 'online' : (state === 'offline' ? 'offline' : 'checking');
      btn.classList.add(`unselected-checked-${key}`);
    }
    btn.classList.toggle('unselected', treatAsUnselected);
    const progress = !treatAsUnselected && state === 'online'
      ? window.platformContentLoadProgress?.[platform]
      : null;
    const progressPercent = progress?.total > 0
      ? Math.max(0, Math.min(100, progress.completed / progress.total * 100))
      : 0;
    if (progress?.total > 0 && progress.completed < progress.total) {
      btn.classList.add('content-loading');
      btn.style.setProperty('--platform-load-progress', `${progressPercent}%`);
    } else {
      btn.style.removeProperty('--platform-load-progress');
    }
    const stateText = treatAsUnselected
      ? '未启用'
      : (progress?.total > 0 && progress.completed < progress.total
        ? `已登录，正在加载作业 ${Math.floor(progressPercent)}%`
        : (state === 'online' ? '已登录' : (state === 'offline' ? '未登录' : '登录检查中')));
    btn.title = `${label}${stateText}`;
  };

  apply(veStatusBtn, window.platformLoginState?.ve || 'checking', '智慧课程平台');
  apply(yktStatusBtn, window.platformLoginState?.ykt || 'checking', '雨课堂');
  apply(mrjzyStatusBtn, window.platformLoginState?.mrjzy || 'checking', '每日交作业');
  apply(jlgjStatusBtn, window.platformLoginState?.jlgj || 'checking', '接龙管家');
  apply(moocStatusBtn, window.platformLoginState?.mooc || 'checking', '中国大学MOOC');
  apply(xuetangxStatusBtn, window.platformLoginState?.xuetangx || 'checking', '学堂在线');
  applyPlatformVisibility();
  if (scheduleLayout && shouldUseCoursePlatformColumns()) scheduleCourseCardsByPlatform();

  // Login warnings are shown on offline-transition only (one platform at a time).
}

function shouldShowNoCoursePlaceholder() {
  if (!courseListDiv) return false;
  if (courseListDiv.querySelector('.file-item')) return false;

  const selected = PLATFORM_IDS.filter((p) => isPlatformEnabled(p));
  if (!selected.length) return true;

  const allOffline = selected.every((p) => (window.platformLoginState?.[p] || 'checking') === 'offline');
  if (allOffline) return true;

  const allSettled = selected.every((p) => {
    const state = window.platformLoginState?.[p] || 'checking';
    if (state === 'checking') return false;
    if (state === 'offline') return true;
    return !!window.platformLoadedOnce?.[p];
  });
  return allSettled;
}

function updateCourseListEmptyPlaceholder() {
  if (!courseListDiv) return;
  const existing = courseListDiv.querySelector('#course-list-empty-placeholder');
  const shouldShow = shouldShowNoCoursePlaceholder();
  if (shouldShow) {
    if (existing) return;
    const empty = document.createElement('div');
    empty.id = 'course-list-empty-placeholder';
    empty.style.color = '#666';
    empty.style.padding = '6px 0';
    empty.textContent = '暂无课程';
    courseListDiv.appendChild(empty);
    return;
  }
  if (existing) existing.remove();
}

function setCourseReplayState(courseId, hasReplay) {
  const state = ensureCourseCardState(courseId);
  state.hasReplay = !!hasReplay;
  state.replayListLoading = false;
  updateCourseCardRank(courseId);
  flushPendingCourseCardSortIfIdle();
}

function syncCoursewareButtonAvailability(btn, courseId) {
  if (!(btn instanceof HTMLElement)) return;
  const cache = window.coursewareCacheByCourseId?.[courseId];
  if (!cache?.loaded) return;
  btn.style.display = Array.isArray(cache.items) && cache.items.length ? '' : 'none';
}

function setCourseReplayLoading(courseId, isLoading) {
  const state = ensureCourseCardState(courseId);
  state.replayListLoading = !!isLoading;
  updateCourseCardRank(courseId);
  if (!state.replayListLoading) flushPendingCourseCardSortIfIdle();
}

function setCourseCoursewareState(courseId, hasCourseware) {
  const state = ensureCourseCardState(courseId);
  state.hasCourseware = !!hasCourseware;
  state.coursewareListLoading = false;
  updateCourseCardRank(courseId);
}

function setCourseCoursewareLoading(courseId, isLoading) {
  const state = ensureCourseCardState(courseId);
  state.coursewareListLoading = !!isLoading;
  updateCourseCardRank(courseId);
}

function spinnerPhaseDelayStyle(periodMs = 1000) {
  const period = Math.max(1, Number(periodMs || 1000));
  return ` animation-delay:-${Date.now() % period}ms;`;
}

function syncCourseActionLoadingSpinnerPhase(scope = courseListDiv) {
  if (!(scope instanceof HTMLElement)) return;
  const delay = `-${Date.now() % 1000}ms`;
  scope.querySelectorAll('button[data-action="videos"].replay-list-loading .spinner, button[data-action="courseware"].courseware-list-loading .spinner, button[data-action="videos"].replay-link-progress .spinner, button[data-action="courseware"].courseware-link-progress .spinner').forEach((el) => {
    if (el instanceof HTMLElement) {
      el.style.animationDelay = delay;
    }
  });
}

function getCombinedAbortSignal(...signals) {
  const validSignals = signals.filter((signal) => signal instanceof AbortSignal);
  if (!validSignals.length) return undefined;
  if (validSignals.length === 1) return validSignals[0];
  if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.any === 'function') {
    return AbortSignal.any(validSignals);
  }
  const controller = new AbortController();
  const abort = () => {
    try { controller.abort(); } catch { /* ignore */ }
  };
  validSignals.forEach((signal) => {
    if (signal.aborted) abort();
    else signal.addEventListener('abort', abort, { once: true });
  });
  return controller.signal;
}

function setCoursewareButtonLoading(btn, isLoading) {
  if (!btn) return;
  if (isLoading) {
    btn.dataset.coursewareLoading = '1';
    if (btn.classList.contains('courseware-list-loading')) {
      btn.disabled = true;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'none';
      return;
    }
    btn.disabled = true;
    btn.style.opacity = '1';
    btn.style.pointerEvents = 'none';
    btn.classList.add('courseware-list-loading', 'courseware-link-progress');
    btn.style.setProperty('--courseware-progress', '0%');
    btn.innerHTML = `资源下载 <span class="spinner" style="display:inline-block; width:10px; height:10px; margin-left:4px; border-width:2px; border-color:#1e3a8a; border-top-color:transparent;${spinnerPhaseDelayStyle()}"></span>`;
    return;
  }

  delete btn.dataset.coursewareLoading;
  delete btn.dataset.coursewareLoadingCount;
  btn.disabled = false;
  btn.style.pointerEvents = 'auto';
  btn.classList.remove('courseware-list-loading');
  if (btn.dataset.coursewareLinkFetching !== '1') {
    btn.classList.remove('courseware-link-progress');
    btn.style.removeProperty('--courseware-progress');
  }
  flushPendingCourseCardSortIfIdle();
}

function isResultAreaOpen(resultArea) {
  if (!(resultArea instanceof HTMLElement)) return false;
  if (resultArea.dataset.animOpen === '1') return true;
  if (resultArea.style.display === 'none') return false;
  return !!resultArea.offsetHeight;
}

const HEIGHT_MOTION_ACCELERATION = 48000;

function animateHeightWithMotion(element, from, to, onFrame) {
  element.__heightMotion?.cancel();
  const distance = Math.abs(to - from);
  if (distance < 1 || globalThis.BjtuMotion?.isEnabled?.() === false) {
    onFrame(to, 1);
    return Promise.resolve(true);
  }
  return new Promise((resolve) => {
    const direction = Math.sign(to - from);
    let position = from;
    let velocity = 0;
    let lastTime = 0;
    let frameId = 0;
    const motion = {
      cancel() {
        cancelAnimationFrame(frameId);
        if (element.__heightMotion === motion) delete element.__heightMotion;
        resolve(false);
      }
    };
    element.__heightMotion = motion;
    onFrame(from, 0);
    const step = (now) => {
      if (element.__heightMotion !== motion) return;
      if (globalThis.BjtuMotion?.isEnabled?.() === false) {
        position = to;
      } else {
        const dt = Math.min(0.05, (now - (lastTime || now - 16.7)) / 1000);
        lastTime = now;
        const remaining = Math.abs(to - position);
        const rate = Math.max(0.05, Number(globalThis.BjtuMotion?.getSpeed?.()) || 1);
        const acceleration = HEIGHT_MOTION_ACCELERATION * rate * rate;
        velocity = Math.min(velocity + acceleration * dt, Math.sqrt(2 * acceleration * remaining));
        position += direction * Math.min(remaining, velocity * dt);
      }
      const progress = Math.min(1, Math.abs(position - from) / distance);
      onFrame(position, progress);
      if (Math.abs(to - position) <= 0.75) {
        onFrame(to, 1);
        delete element.__heightMotion;
        resolve(true);
      } else {
        frameId = requestAnimationFrame(step);
      }
    };
    frameId = requestAnimationFrame(step);
  });
}

function createTopDownListFade(items) {
  const elements = Array.from(items).filter((item) => item instanceof HTMLElement);
  const states = elements.map((item) => {
    const opacity = Number(getComputedStyle(item).opacity);
    return {
      item,
      original: item.style.opacity,
      target: Number.isFinite(opacity) ? opacity : 1
    };
  });
  let currentFraction = 0;
  return {
    update(fraction) {
      const revealed = Math.max(0, Math.min(1, fraction));
      currentFraction = revealed;
      states.forEach(({ item, target }, index) => {
        const finishAt = listFadeFinishAt(index, states.length);
        item.style.opacity = String(target * Math.min(1, revealed / finishAt));
      });
    },
    reset() {
      states.forEach(({ item, original }) => { item.style.opacity = original; });
    },
    getFraction() {
      return currentFraction;
    },
    snapshotHtml(container) {
      this.reset();
      const html = container.innerHTML;
      this.update(currentFraction);
      return html;
    }
  };
}

function listFadeFinishAt(index, count) {
  return 0.35 + 0.65 * index / Math.max(1, count - 1);
}

function getResultAreaHtmlForCache(resultArea) {
  return resultArea.__scrollListMotion?.snapshotHtml(resultArea)
    ?? resultArea.__topDownListFade?.snapshotHtml(resultArea)
    ?? resultArea.innerHTML;
}

function toggleResultAreaAnimated(resultArea, shouldOpen, { immediate = false } = {}) {
  if (!(resultArea instanceof HTMLElement)) return;
  const interrupted = !!resultArea.__heightMotion && !!resultArea.__listTransition
    && resultArea.__listTransition.open !== shouldOpen;
  const scrollMotionEnabled = interrupted
    ? resultArea.__listTransition.scroll
    : shouldOpen ? window.scrollExpandHomeworkLists === true : window.scrollCollapseHomeworkLists !== false;
  const transition = { open: shouldOpen, scroll: scrollMotionEnabled };
  resultArea.__listTransition = transition;
  const previousScrollMotion = resultArea.__scrollListMotion;
  const previousFraction = resultArea.__topDownListFade?.getFraction();
  resultArea.__heightMotion?.cancel();
  resultArea.__topDownListFade?.reset();
  delete resultArea.__topDownListFade;
  if (!scrollMotionEnabled && previousScrollMotion) {
    previousScrollMotion.reset();
    delete resultArea.__scrollListMotion;
  }
  if (shouldOpen) delete resultArea.dataset.closingView;
  const reset = () => {
    resultArea.style.transition = '';
    resultArea.style.maxHeight = '';
    resultArea.style.height = '';
    resultArea.style.boxSizing = '';
    resultArea.style.opacity = '';
    resultArea.style.overflow = '';
    resultArea.style.willChange = '';
  };
  if (immediate) {
    delete resultArea.__listTransition;
    previousScrollMotion?.reset();
    delete resultArea.__scrollListMotion;
    reset();
    resultArea.style.display = shouldOpen ? 'block' : 'none';
    resultArea.dataset.animOpen = shouldOpen ? '1' : '0';
    if (!shouldOpen) delete resultArea.dataset.closingView;
    return;
  }
  if (!shouldOpen && resultArea.style.display === 'none') {
    delete resultArea.__listTransition;
    resultArea.dataset.animOpen = '0';
    delete resultArea.dataset.closingView;
    return;
  }
  const from = shouldOpen && resultArea.style.display === 'none'
    ? 0
    : resultArea.getBoundingClientRect().height;
  resultArea.style.transition = 'none';
  resultArea.style.boxSizing = 'border-box';
  resultArea.style.display = 'block';
  resultArea.style.maxHeight = 'none';
  resultArea.style.height = `${from}px`;
  resultArea.style.overflow = 'hidden';
  resultArea.style.willChange = 'height';
  resultArea.dataset.animOpen = shouldOpen ? '1' : '0';
  if (scrollMotionEnabled) {
    const fullHeight = Math.max(resultArea.scrollHeight + resultArea.offsetHeight - resultArea.clientHeight, from, previousScrollMotion?.fullHeight || 0, 1);
    const motion = previousScrollMotion || createListScrollMotion(resultArea, fullHeight);
    resultArea.__scrollListMotion = motion;
    resultArea.style.opacity = '1';
    void animateHeightWithMotion(resultArea, from, shouldOpen ? fullHeight : 0, (height) => {
      resultArea.style.height = `${height}px`;
      motion.update(height);
    }).then((completed) => {
      if (resultArea.__scrollListMotion !== motion || !completed) return;
      if (resultArea.__listTransition === transition) delete resultArea.__listTransition;
      if (!shouldOpen) {
        resultArea.style.display = 'none';
        delete resultArea.dataset.closingView;
      }
      motion.reset();
      delete resultArea.__scrollListMotion;
      reset();
    });
    return;
  }
  if (shouldOpen) {
    const to = Math.max(resultArea.scrollHeight + resultArea.offsetHeight - resultArea.clientHeight, 1);
    const fade = createTopDownListFade(resultArea.children);
    const startFraction = previousFraction ?? Math.min(1, from / to);
    resultArea.__topDownListFade = fade;
    resultArea.style.opacity = '1';
    void animateHeightWithMotion(resultArea, from, to, (height, progress) => {
      resultArea.style.height = `${height}px`;
      fade.update(startFraction + (1 - startFraction) * progress);
    }).then((completed) => {
      if (resultArea.__topDownListFade === fade) {
        fade.reset();
        delete resultArea.__topDownListFade;
      }
      if (completed) {
        if (resultArea.__listTransition === transition) delete resultArea.__listTransition;
        reset();
      }
    });
    return;
  }
  const fullHeight = Math.max(resultArea.scrollHeight + resultArea.offsetHeight - resultArea.clientHeight, from, 1);
  const fade = createTopDownListFade(resultArea.children);
  const startFraction = previousFraction ?? Math.min(1, from / fullHeight);
  resultArea.__topDownListFade = fade;
  resultArea.style.opacity = '1';
  void animateHeightWithMotion(resultArea, from, 0, (height, progress) => {
    resultArea.style.height = `${height}px`;
    fade.update(startFraction * (1 - progress));
  }).then((completed) => {
    if (resultArea.__topDownListFade === fade) {
      fade.reset();
      delete resultArea.__topDownListFade;
    }
    if (!completed) return;
    if (resultArea.__listTransition === transition) delete resultArea.__listTransition;
    resultArea.style.display = 'none';
    delete resultArea.dataset.closingView;
    reset();
  });
}

function resumeResultAreaCollapse(resultArea, view) {
  if (!(resultArea instanceof HTMLElement) || resultArea.dataset.closingView !== view
    || resultArea.style.display === 'none' || !resultArea.__heightMotion) return false;
  toggleResultAreaAnimated(resultArea, true);
  return true;
}

function replaceResultAreaHtmlAnimated(resultArea, html) {
  if (!(resultArea instanceof HTMLElement)) return;
  if (resultArea.dataset.animOpen !== '1' || resultArea.style.display === 'none') {
    if (resultArea.__heightMotion) toggleResultAreaAnimated(resultArea, false, { immediate: true });
    resultArea.__scrollListMotion?.reset();
    delete resultArea.__scrollListMotion;
    resultArea.innerHTML = html;
    return;
  }
  const from = resultArea.getBoundingClientRect().height;
  resultArea.__heightMotion?.cancel();
  resultArea.__scrollListMotion?.reset();
  delete resultArea.__scrollListMotion;
  resultArea.style.boxSizing = 'border-box';
  resultArea.style.height = `${from}px`;
  resultArea.innerHTML = html;
  toggleResultAreaAnimated(resultArea, true);
}

function prepareResultAreaViewSwitch(resultArea) {
  if (!(resultArea instanceof HTMLElement)) return;
  delete resultArea.dataset.closingView;
  const parent = resultArea.parentElement;
  parent?.querySelectorAll(':scope > .result-area-outgoing').forEach((outgoing) => {
    outgoing.__heightMotion?.cancel();
    outgoing.remove();
  });
  if (resultArea.style.display === 'none' || resultArea.getBoundingClientRect().height <= 0) {
    resultArea.__topDownListFade?.reset();
    delete resultArea.__topDownListFade;
    resultArea.__scrollListMotion?.reset();
    delete resultArea.__scrollListMotion;
    return;
  }
  resultArea.__heightMotion?.cancel();
  resultArea.__scrollListMotion?.reset();
  delete resultArea.__scrollListMotion;
  const from = resultArea.getBoundingClientRect().height;
  if (from > 0 && resultArea.firstChild) {
    const outgoing = resultArea.cloneNode(true);
    outgoing.classList.add('result-area-outgoing');
    outgoing.removeAttribute('id');
    outgoing.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
    outgoing.setAttribute('aria-hidden', 'true');
    outgoing.inert = true;
    outgoing.style.pointerEvents = 'none';
    outgoing.style.transition = 'none';
    outgoing.style.display = 'block';
    outgoing.style.boxSizing = 'border-box';
    outgoing.style.maxHeight = 'none';
    outgoing.style.height = `${from}px`;
    outgoing.style.overflow = 'hidden';
    resultArea.after(outgoing);
    const scrollOutgoing = window.scrollCollapseHomeworkLists !== false;
    const outgoingMotion = scrollOutgoing
      ? createListScrollMotion(outgoing, Math.max(outgoing.scrollHeight, from, 1))
      : createTopDownListFade(outgoing.children);
    outgoing.style.opacity = '1';
    void animateHeightWithMotion(outgoing, from, 0, (height, progress) => {
      outgoing.style.height = `${height}px`;
      outgoingMotion.update(scrollOutgoing ? height : 1 - progress);
    }).then(() => outgoing.remove());
  }
  resultArea.__topDownListFade?.reset();
  delete resultArea.__topDownListFade;
  resultArea.style.transition = '';
  resultArea.style.maxHeight = '';
  resultArea.style.height = '';
  resultArea.style.boxSizing = '';
  resultArea.style.opacity = '';
  resultArea.style.overflow = '';
  resultArea.style.willChange = '';
  resultArea.style.display = 'none';
  resultArea.dataset.animOpen = '0';
}

function syncCourseActionButtonText(card, activeView = '') {
  if (!card) return;
  const replayBtn = card.querySelector('button[data-action="videos"]');
  const coursewareBtn = card.querySelector('button[data-action="courseware"]');
  const archiveBtn = card.querySelector('button[data-action="archive"]');

  const setLabel = (button, label, progressClass) => {
    if (!(button instanceof HTMLButtonElement)) return;
    if (!button.classList.contains(progressClass)) {
      button.textContent = label;
      return;
    }
    const textNode = Array.from(button.childNodes).find((node) => node.nodeType === Node.TEXT_NODE);
    if (textNode) textNode.nodeValue = `${label} `;
    else button.insertBefore(document.createTextNode(`${label} `), button.firstChild);
  };

  if (replayBtn && !replayBtn.classList.contains('replay-list-loading')) {
    setLabel(replayBtn, activeView === 'replay' ? '收起' : '回放下载', 'replay-link-progress');
  }
  if (coursewareBtn && !coursewareBtn.classList.contains('courseware-list-loading')) {
    setLabel(coursewareBtn, activeView === 'courseware' ? '收起' : '资源下载', 'courseware-link-progress');
  }
  if (archiveBtn && !archiveBtn.classList.contains('archive-list-loading')) {
    setLabel(archiveBtn, activeView === 'archive' ? '收起' : '归档下载', 'archive-link-progress');
  }
}

function syncArchiveItemsIndex(courseId, items) {
  const cid = String(courseId || '').trim();
  const previous = Array.isArray(window.archiveItemsByCourseId?.[cid]) ? window.archiveItemsByCourseId[cid] : [];
  previous.forEach((item) => {
    const id = String(item?.id || '').trim();
    if (!id) return;
    delete window.archiveItemsById[id];
    window.resourceSpaceSelected.delete(id);
  });
  const next = Array.isArray(items) ? items : [];
  window.archiveItemsByCourseId[cid] = next;
  next.forEach((item) => {
    const id = String(item?.id || '').trim();
    if (id) window.archiveItemsById[id] = item;
  });
}

function syncCoursewareItemsIndex(courseId, items) {
  const cid = String(courseId || '').trim();
  const prevList = Array.isArray(window.coursewareItemsByCourseId?.[cid]) ? window.coursewareItemsByCourseId[cid] : [];
  prevList.forEach((it) => {
    const id = String(it?.id || '').trim();
    if (!id) return;
    delete window.coursewareItemsById[id];
    window.resourceSpaceSelected.delete(id);
  });

  const nextList = Array.isArray(items) ? items : [];
  window.coursewareItemsByCourseId[cid] = nextList;
  nextList.forEach((it) => {
    const id = String(it?.id || '').trim();
    if (!id) return;
    window.coursewareItemsById[id] = it;
  });
}

function syncCoursewareSelectAllButton(card) {
  if (!(card instanceof HTMLElement)) return;
  const btn = card.querySelector('button[data-action="courseware-select-all"]');
  if (!(btn instanceof HTMLButtonElement)) return;
  const scope = btn.closest('.result-area') || card;
  const ids = Array.from(scope.querySelectorAll('input[data-action="resource-check"][data-resource-id]'))
    .map((el) => (el instanceof HTMLInputElement ? String(el.dataset.resourceId || '').trim() : ''))
    .filter((id) => id && !isResourceDownloadActive(id));
  if (!ids.length) {
    btn.textContent = '反选';
    btn.disabled = true;
    return;
  }
  btn.textContent = '反选';
  btn.disabled = false;
}

function toggleCoursewareSelectionForCard(card) {
  if (!(card instanceof HTMLElement)) return;
  const btn = card.querySelector('button[data-action="courseware-select-all"]');
  const scope = (btn instanceof HTMLButtonElement ? (btn.closest('.result-area') || card) : card);
  const ids = Array.from(scope.querySelectorAll('input[data-action="resource-check"][data-resource-id]'))
    .map((el) => (el instanceof HTMLInputElement ? String(el.dataset.resourceId || '').trim() : ''))
    .filter((id) => id && !isResourceDownloadActive(id));
  if (!ids.length) return;

  ids.forEach((id) => {
    if (window.resourceSpaceSelected.has(id)) window.resourceSpaceSelected.delete(id);
    else window.resourceSpaceSelected.add(id);
  });

  const cbs = scope.querySelectorAll('input[data-action="resource-check"][data-resource-id]');
  cbs.forEach((el) => {
    if (!(el instanceof HTMLInputElement)) return;
    const id = String(el.dataset.resourceId || '').trim();
    if (!id || !ids.includes(id) || isResourceDownloadActive(id)) return;
    el.checked = window.resourceSpaceSelected.has(id);
  });

  syncCoursewareSelectAllButton(card);
  refreshResourceSelectAllButton();
}

function buildCoursewareListHtml(courseId, items, toolbarEndHtml = '') {
  const list = Array.isArray(items) ? items : [];
  if (!list.length) {
    return '<div style="font-size:12px; color:#999;">暂无课程资源</div>';
  }

  const currentCourseId = String(courseId || '').trim();
  const selectAllToolbar = currentCourseId
    ? `<div class="courseware-toolbar"><button class="btn courseware-select-all-btn" data-action="courseware-select-all" data-course-id="${escapeHtml(currentCourseId)}" style="background:#000; color:#fff; padding:3px 8px; font-size:11px; line-height:1.2;">反选</button>${toolbarEndHtml}</div>`
    : '';

  const rowsHtml = list.map((item, index) => {
    const name = String(item?.name || `资源-${index + 1}`).trim();
    const fileName = ensureResourceDownloadFileName(item, item?.url || '');
    const resourceCategory = String(item?.resourceCategory || '').trim();
    const resourceCategoryHtml = resourceCategory
      ? `<span class="homework-type-badge">${escapeHtml(resourceCategory)}</span>`
      : '';
    const url = String(item?.url || '').trim();
    const id = String(item?.id || '').trim();
    const rpId = String(item?.rpId || '').trim();
    const checked = window.resourceSpaceSelected.has(id) ? 'checked' : '';
    const sizeMb = String(item?.sizeMb || '').trim();
    const sizeStyle = buildResourceSizeEmphasisStyle(item?.sizeMbRaw ?? item?.rpSize);
    const displayUrl = cleanRpUrl(url);
    const hasUrl = !!url;
    const needsRpFetch = !hasUrl && !!rpId;
    const rpLinkContainerId = `courseware-rp-link-${id}`;
    return `
      <div class="file-item course-resource-file-item" data-resource-id="${escapeHtml(id)}" data-rp-id="${escapeHtml(rpId)}" style="margin-bottom:10px; padding:5px; border-left:3px solid #1e3a8a; background:#e8efff; border-radius:4px;">
        <div class="resource-row-title" style="margin-bottom:4px;">
          <input type="checkbox" data-action="resource-check" data-resource-id="${escapeHtml(id)}" ${checked} style="margin:0 4px 0 0;">
          <span class="resource-name">${resourceCategoryHtml}${escapeHtml(fileName || name)}</span>
          ${sizeMb ? `<span class="resource-time-inline file-size-emphasis" data-file-size-mb="${escapeHtml(String(Number(item?.sizeMbRaw ?? item?.rpSize) || 0))}" style="${sizeStyle}">${escapeHtml(sizeMb)}</span>` : ''}
        </div>
        <div class="resource-link-row">
          ${hasUrl
        ? `<a class="resource-url" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(displayUrl)}</a>`
        : needsRpFetch
          ? `<span id="${escapeHtml(rpLinkContainerId)}" class="courseware-rp-link" style="color:#999;font-size:12px;"><span class="spinner" style="width: 10px; height: 10px; border-width: 1px; border-color: #1e3a8a; border-top-color: transparent;"></span> 获取链接中…</span>`
          : `<span class="resource-url" style="color:#999;">无下载链接</span>`
      }
          ${hasUrl ? `<button class="btn resource-copy-btn" data-action="resource-copy" data-resource-id="${escapeHtml(id)}">复制</button>` : ''}
          <button class="btn resource-download-btn" data-action="resource-download" data-resource-id="${escapeHtml(id)}">下载</button>
        </div>
        <div class="resource-download-progress" style="display:none;">
          <div class="progress-bar-container"><div class="progress-bar"></div></div>
          <div class="resource-download-meta">
            <span class="resource-dl-status"></span>
            <span class="resource-dl-size"></span>
            <span class="resource-dl-speed"></span>
            <span class="resource-dl-eta"></span>
          </div>
        </div>
      </div>
    `;
  }).join('');

  return `${selectAllToolbar}${rowsHtml}`;
}

function getCourseListLoadVersionSnapshot() {
  return Number(window.courseListLoadVersion || 0);
}

function isCourseListLoadStale(snapshotVersion) {
  return Number(snapshotVersion || 0) !== Number(window.courseListLoadVersion || 0);
}

function recomputeCourseHomeworkState(courseId) {
  const nativeList = (window.courseHomeworkData[courseId]?.list || []);
  const yktList = isPlatformEnabled('ykt') ? (window.yktMatchedHomeworkByCourseId[courseId] || []) : [];
  const mrjzyList = isPlatformEnabled('mrjzy') ? (window.mrjzyMatchedHomeworkByCourseId[courseId] || []) : [];
  const jlgjList = isPlatformEnabled('jlgj') ? (window.jlgjMatchedHomeworkByCourseId[courseId] || []) : [];
  const allHomeworkCount = nativeList.length + yktList.length + mrjzyList.length + jlgjList.length;
  const nativePendingList = nativeList.filter(isNativeHomeworkPending);
  const yktPendingList = yktList.filter(isYktHomeworkPending);
  const mrjzyPendingList = mrjzyList.filter(isMrjzyHomeworkPending);
  const jlgjPendingList = jlgjList.filter(isJlgjHomeworkPending);
  const nativeOverdueList = nativeList.filter(isNativeHomeworkOverdue);
  const yktOverdueList = yktList.filter(isYktHomeworkOverdue);
  const mrjzyOverdueList = mrjzyList.filter(isMrjzyHomeworkOverdue);
  const jlgjOverdueList = jlgjList.filter(isJlgjHomeworkOverdue);
  const nativePending = nativePendingList.length;
  const yktPending = yktPendingList.length;
  const mrjzyPending = mrjzyPendingList.length;
  const jlgjPending = jlgjPendingList.length;
  const pendingTs = [];
  nativePendingList.forEach((hw) => pendingTs.push(parseDeadlineToTs(hw?.end_time ?? hw?.endTime ?? '')));
  yktPendingList.forEach((hw) => pendingTs.push(parseDeadlineToTs(hw?.end)));
  mrjzyPendingList.forEach((hw) => pendingTs.push(parseDeadlineToTs(hw?.end)));
  jlgjPendingList.forEach((hw) => pendingTs.push(parseDeadlineToTs(hw?.end)));
  const validPendingTs = pendingTs.filter((n) => Number.isFinite(n) && n > 0);
  const overdueTs = [];
  nativeOverdueList.forEach((hw) => overdueTs.push(parseDeadlineToTs(hw?.end_time ?? hw?.endTime ?? '')));
  yktOverdueList.forEach((hw) => overdueTs.push(parseDeadlineToTs(hw?.end)));
  mrjzyOverdueList.forEach((hw) => overdueTs.push(parseDeadlineToTs(hw?.end)));
  jlgjOverdueList.forEach((hw) => overdueTs.push(parseDeadlineToTs(hw?.end)));
  const validOverdueTs = overdueTs.filter((n) => Number.isFinite(n) && n > 0);
  const state = ensureCourseCardState(courseId);
  state.allHomeworkCount = allHomeworkCount;
  state.pendingHomeworkCount = nativePending + yktPending + mrjzyPending + jlgjPending;
  state.pendingEarliestTs = validPendingTs.length ? Math.min(...validPendingTs) : 0;
  state.overdueHomeworkCount = nativeOverdueList.length + yktOverdueList.length + mrjzyOverdueList.length + jlgjOverdueList.length;
  state.overdueEarliestTs = validOverdueTs.length ? Math.min(...validOverdueTs) : 0;
  const hasAnyHomework = state.allHomeworkCount > 0 || state.pendingHomeworkCount > 0 || state.overdueHomeworkCount > 0;
  updateCourseCardRank(courseId, { deferWhileActionAnimating: !hasAnyHomework });
}

function updateHomeworkToggleButton(courseId) {
  // Kept for compatibility with existing call sites.
  void courseId;
}

function setHomeworkVisibility(courseId, key, value) {
  const cid = String(courseId || '').trim();
  if (!cid) return;
  const store = key === 'showOverdue' ? window.courseShowOverdueById : window.courseShowDoneById;
  const nextValue = typeof value === 'boolean' ? value : !store[cid];
  store[cid] = nextValue;

  const data = window.courseHomeworkData[cid];
  if (data) {
    data[key] = nextValue;
  }

  if (!toggleHomeworkGroupDom(cid, key, nextValue)) {
    renderHomeworkList(cid);
  }
}

function toggleHomeworkGroupDom(courseId, key, expanded) {
  const kind = key === 'showOverdue' ? 'overdue' : 'done';
  const area = document.getElementById(`homework-area-${courseId}`);
  if (!(area instanceof HTMLElement)) return false;
  const btn = area.querySelector(`.homework-toggle-btn[data-homework-toggle-kind="${kind}"]`);
  if (!(btn instanceof HTMLElement)) return false;

  const group = area.querySelector(`.homework-group[data-homework-group="${kind}"]`);
  if (!(group instanceof HTMLElement)) return false;

  const count = String(btn.dataset.count || '').trim();
  const collapsedText = String(btn.dataset.collapsedText || '').trim();
  const expandedText = String(btn.dataset.expandedText || '').trim();
  const label = btn.querySelector('.homework-toggle-label');
  if (label) label.textContent = `${expanded ? expandedText : collapsedText}${count ? ` (${count})` : ''}`;

  btn.classList.toggle('is-expanded', expanded);
  btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  btn.classList.remove('homework-toggle-btn--up', 'homework-toggle-btn--down');
  btn.classList.add(expanded ? 'homework-toggle-btn--up' : 'homework-toggle-btn--down');

  group.dataset.expanded = expanded ? '1' : '0';
  group.setAttribute('aria-hidden', expanded ? 'false' : 'true');
  animateHomeworkGroupVisibility(group, expanded);
  return true;
}

function createListScrollMotion(container, fullHeight, itemSelector = '') {
  const children = Array.from(container.children).filter((item) => item instanceof HTMLElement).map((item) => ({
    item,
    transform: item.style.transform
  }));
  const fadeItems = itemSelector ? container.querySelectorAll(itemSelector) : container.children;
  const items = Array.from(fadeItems).filter((item) => item instanceof HTMLElement).map((item) => ({
    item,
    opacity: item.style.opacity,
    targetOpacity: Number(getComputedStyle(item).opacity)
  }));
  let currentHeight = fullHeight;
  return {
    fullHeight,
    update(height) {
      currentHeight = height;
      const scroll = Math.max(0, fullHeight - height);
      children.forEach(({ item, transform }) => {
        item.style.transform = scroll > 0 ? `translateY(-${scroll}px) ${transform}`.trim() : transform;
      });
      const collapsedFraction = Math.min(1, scroll / fullHeight);
      items.forEach(({ item, targetOpacity }, index) => {
        const finishAt = listFadeFinishAt(index, items.length);
        const visibleFraction = 1 - Math.min(1, collapsedFraction / finishAt);
        item.style.opacity = String(targetOpacity * visibleFraction);
      });
    },
    reset() {
      children.forEach(({ item, transform }) => { item.style.transform = transform; });
      items.forEach(({ item, opacity }) => { item.style.opacity = opacity; });
    },
    snapshotHtml(element) {
      this.reset();
      const html = element.innerHTML;
      this.update(currentHeight);
      return html;
    }
  };
}

function animateHomeworkGroupVisibility(group, expanded) {
  if (!(group instanceof HTMLElement)) return Promise.resolve(false);
  const interrupted = !!group.__heightMotion && !!group.__listTransition
    && group.__listTransition.open !== expanded;
  const scrollMotionEnabled = interrupted
    ? group.__listTransition.scroll
    : expanded ? window.scrollExpandHomeworkLists === true : window.scrollCollapseHomeworkLists !== false;
  const transition = { open: expanded, scroll: scrollMotionEnabled };
  group.__listTransition = transition;
  const previousScrollMotion = group.__scrollListMotion;
  const previousFraction = group.__topDownListFade?.getFraction();
  group.__heightMotion?.cancel();
  group.__topDownListFade?.reset();
  delete group.__topDownListFade;
  if (!scrollMotionEnabled && previousScrollMotion) {
    previousScrollMotion.reset();
    delete group.__scrollListMotion;
  }
  const from = group.getBoundingClientRect().height;
  if (globalThis.BjtuMotion?.isEnabled?.() === false) {
    delete group.__listTransition;
    previousScrollMotion?.reset();
    delete group.__scrollListMotion;
    group.classList.toggle('is-hidden', !expanded);
    group.style.maxHeight = '';
    group.style.height = '';
    group.style.boxSizing = '';
    group.style.opacity = '';
    group.style.transform = '';
    group.style.overflow = '';
    group.style.transition = '';
    return Promise.resolve(true);
  }
  group.classList.remove('is-hidden');
  group.style.transition = 'none';
  group.style.boxSizing = 'border-box';
  group.style.maxHeight = 'none';
  group.style.height = `${from}px`;
  group.style.overflow = 'hidden';
  const to = expanded ? Math.max(1, group.scrollHeight) : 0;
  if (scrollMotionEnabled) {
    const fullHeight = Math.max(group.scrollHeight, from, previousScrollMotion?.fullHeight || 0, 1);
    const motion = previousScrollMotion || createListScrollMotion(group, fullHeight, '.hw-card-item, .force-score-publish-row');
    group.__scrollListMotion = motion;
    group.style.opacity = '1';
    return animateHeightWithMotion(group, from, expanded ? fullHeight : 0, (height) => {
      group.style.height = `${height}px`;
      motion.update(height);
    }).then((completed) => {
      if (group.__scrollListMotion !== motion) return false;
      if (!completed) return false;
      if (group.__listTransition === transition) delete group.__listTransition;
      group.classList.toggle('is-hidden', !expanded);
      motion.reset();
      delete group.__scrollListMotion;
      group.style.maxHeight = '';
      group.style.height = '';
      group.style.boxSizing = '';
      group.style.opacity = '';
      group.style.overflow = '';
      group.style.transition = '';
      return true;
    });
  }
  const fade = createTopDownListFade(
    group.querySelectorAll('.hw-card-item, .force-score-publish-row').length
      ? group.querySelectorAll('.hw-card-item, .force-score-publish-row')
      : group.children
  );
  const fullHeight = Math.max(group.scrollHeight, from, 1);
  const startFraction = previousFraction ?? Math.min(1, from / fullHeight);
  group.__topDownListFade = fade;
  group.style.opacity = '1';
  return animateHeightWithMotion(group, from, to, (height, progress) => {
    group.style.height = `${height}px`;
    fade.update(expanded
      ? startFraction + (1 - startFraction) * progress
      : startFraction * (1 - progress));
  }).then((completed) => {
    if (group.__topDownListFade === fade) {
      fade.reset();
      delete group.__topDownListFade;
    }
    if (!completed) return false;
    if (group.__listTransition === transition) delete group.__listTransition;
    group.classList.toggle('is-hidden', !expanded);
    group.style.maxHeight = '';
    group.style.height = '';
    group.style.boxSizing = '';
    group.style.opacity = '';
    group.style.transform = '';
    group.style.overflow = '';
    group.style.transition = '';
    return true;
  });
}

window.toggleOverdueView = function (courseId) {
  setHomeworkVisibility(courseId, 'showOverdue');
};

window.toggleDoneView = function (courseId) {
  setHomeworkVisibility(courseId, 'showDone');
};

window.toggleHomeworkView = function (courseId) {
  window.toggleDoneView(courseId);
};

function collectCourseMatchMap(courses) {
  const m = new Map();
  (courses || []).forEach((course) => {
    const courseId = course.id || course.cId || course.courseId || course.course_id;
    const fzId = course.fz_id || course.fzId || course.xkhId || course.xkh_id || '';
    const seq10 = getVeCourseSeq10(course);
    const meta = { courseId, fzId };
    const tokenSources = [
      seq10,
      fzId,
      course.course_num,
      course.courseNum,
      course.courseNo,
      course.course_id,
      course.courseId,
      course.id,
      course.cId
    ];
    tokenSources.forEach((src) => {
      const token = normalizeTail10Token(src);
      if (token) m.set(token, meta);
    });
  });
  return m;
}

function collectCourseNameMap(courses) {
  const m = new Map();
  (courses || []).forEach((course) => {
    const courseId = course.id || course.cId || course.courseId || course.course_id;
    const fzId = course.fz_id || course.fzId || course.xkhId || course.xkh_id || '';
    const courseName = course.name || course.NAME || course.courseName || course.title || '';
    const token = normalizeCourseNameToken(courseName);
    if (token && courseId) m.set(token, { courseId, fzId, courseName });
  });
  return m;
}

function collectCourseNameMatchMap(courses) {
  const m = new Map();
  (courses || []).forEach((course) => {
    const courseId = course.id || course.cId || course.courseId || course.course_id;
    const courseName = course.name || course.NAME || course.courseName || course.title || '';
    const token = normalizeCourseNameToken(courseName);
    if (token && courseId) m.set(token, { courseId, courseName });
  });
  return m;
}

function renderHomeworkList(courseId) {
  const area = document.getElementById(`homework-area-${courseId}`);
  if (!area) return;
  const fallbackShowOverdue = !!window.courseShowOverdueById[courseId];
  const fallbackShowDone = !!window.courseShowDoneById[courseId];
  const data = window.courseHomeworkData[courseId] || { list: [], showOverdue: fallbackShowOverdue, showDone: fallbackShowDone };
  if (window.courseHomeworkData[courseId]) {
    window.courseHomeworkData[courseId].showOverdue = fallbackShowOverdue;
    window.courseHomeworkData[courseId].showDone = fallbackShowDone;
  }
  const list = data.list || [];
  updateAssessmentButtonVisibility(courseId);
  syncHomeworkAttachmentItemsIndex(courseId, []);

  const classify = (items, isDoneFn, isOverdueFn) => {
    const pending = [], overdue = [], done = [];
    items.forEach((hw) => {
      if (isDoneFn(hw)) done.push(hw);
      else if (isOverdueFn(hw)) overdue.push(hw);
      else pending.push(hw);
    });
    return { pending, overdue, done };
  };

  const nativeCls = classify(list, isNativeHomeworkDone, isNativeHomeworkOverdue);
  const yktItems = isPlatformEnabled('ykt') ? (window.yktMatchedHomeworkByCourseId[courseId] || []) : [];
  const yktCls = classify(yktItems, isYktHomeworkDone, isYktHomeworkOverdue);
  const mrjzyItems = isPlatformEnabled('mrjzy') ? (window.mrjzyMatchedHomeworkByCourseId[courseId] || []) : [];
  const mrjzyCls = classify(mrjzyItems, isMrjzyHomeworkDone, isMrjzyHomeworkOverdue);
  const jlgjItems = isPlatformEnabled('jlgj') ? (window.jlgjMatchedHomeworkByCourseId[courseId] || []) : [];
  const jlgjCls = classify(jlgjItems, isJlgjHomeworkDone, isJlgjHomeworkOverdue);

  const sortNativeGroup = (items) => sortHomeworkItemsByDeadline(items, (hw) => hw?.end_time ?? hw?.endTime ?? '');
  const sortExternalGroup = (items) => sortHomeworkItemsByDeadline(items, (hw) => hw?.end ?? hw?.endTime ?? '');
  const nativePendingItems = sortNativeGroup(nativeCls.pending);
  const nativeOverdueItems = sortNativeGroup(nativeCls.overdue);
  const nativeDoneItems = sortNativeGroup(nativeCls.done);
  const yktPendingItems = sortExternalGroup(yktCls.pending);
  const yktOverdueItems = sortExternalGroup(yktCls.overdue);
  const yktDoneItems = sortExternalGroup(yktCls.done);
  const mrjzyPendingItems = sortExternalGroup(mrjzyCls.pending);
  const mrjzyOverdueItems = sortExternalGroup(mrjzyCls.overdue);
  const mrjzyDoneItems = sortExternalGroup(mrjzyCls.done);
  const jlgjPendingItems = sortExternalGroup(jlgjCls.pending);
  const jlgjOverdueItems = sortExternalGroup(jlgjCls.overdue);
  const jlgjDoneItems = sortExternalGroup(jlgjCls.done);

  const isYktStandalone = String(courseId).startsWith('ykt-');
  const isMrjzyStandalone = String(courseId).startsWith('mrjzy-');
  const isJlgjStandalone = String(courseId).startsWith('jlgj-');
  const isExternalStandalone = isYktStandalone || isMrjzyStandalone || isJlgjStandalone;
  const yktLoading = !!window.yktHomeworkLoadingByCourse?.[courseId];
  const yktSyncing = isPlatformEnabled('ykt') && ((window.platformLoginState?.ykt || 'checking') === 'checking') && !window.platformLoadedOnce?.ykt;
  const mrjzySyncing = isPlatformEnabled('mrjzy') && ((window.platformLoginState?.mrjzy || 'checking') === 'checking') && !window.platformLoadedOnce?.mrjzy;
  const jlgjHasEarlyLoadingGroups = Array.isArray(window.jlgjCourseGroupsSnapshot) && window.jlgjCourseGroupsSnapshot.some((group) => !!group?.loadingMeta);
  const jlgjSyncing = isPlatformEnabled('jlgj') && (((window.platformLoginState?.jlgj || 'checking') === 'checking') && !window.platformLoadedOnce?.jlgj || jlgjHasEarlyLoadingGroups);

  const yktCourseLink = window.yktMatchedCourseLinkByCourseId[courseId] || '';
  const yktHeaderHtml = isYktStandalone ? '' : `<div style="font-size:12px;color:#0369a1; margin-bottom:4px;">${yktCourseLink ? `<a href="${yktCourseLink}" target="_blank" rel="noopener noreferrer" style="color:#0369a1; text-decoration:none;">雨课堂作业</a>` : '雨课堂作业'}</div>`;
  const yktWrapperStyle = isYktStandalone ? '' : 'margin-top:6px; padding-top:6px; border-top:1px dashed #b3e5fc;';
  const renderYktSection = (items) => yktItems.length && items.length ? `<div style="${yktWrapperStyle}">${yktHeaderHtml}${renderYktHomeworkItems(courseId, items)}</div>` : '';
  const mrjzyHeaderHtml = isMrjzyStandalone ? '' : '<div style="font-size:12px;color:#3730a3; margin-bottom:4px;">每日交作业</div>';
  const renderMrjzySection = (items) => mrjzyItems.length && items.length ? `<div>${mrjzyHeaderHtml}${renderMrjzyHomeworkItems(items)}</div>` : '';
  const jlgjHeaderHtml = isJlgjStandalone ? '' : '<div style="font-size:12px;color:#0f766e; margin-bottom:4px;">接龙管家</div>';
  const renderJlgjSection = (items) => jlgjItems.length && items.length ? `<div>${jlgjHeaderHtml}${renderJlgjHomeworkItems(items)}</div>` : '';

  const applyDoneEnterAnimation = () => {
    if (data.justExpanded) {
      const doneCards = area.querySelectorAll('.hw-card-item[data-homework-done="1"]');
      doneCards.forEach((el) => {
        el.classList.remove('hw-done-enter');
        void el.offsetWidth;
        el.classList.add('hw-done-enter');
        setTimeout(() => el.classList.remove('hw-done-enter'), 220);
      });
    }
    data.justExpanded = false;
    data.justCollapsed = false;
  };
  recomputeCourseHomeworkState(courseId);

  // 教师账号：VE 作业不计入 overdue/done 分类
  const isTeacherMode = !!window.isTeacherAccount;
  const nativeOverdueCount = isTeacherMode ? 0 : nativeCls.overdue.length;
  const nativeDoneCount = isTeacherMode ? 0 : nativeCls.done.length;
  const nativePendingCount = isTeacherMode ? list.length : nativeCls.pending.length;

  const totalOverdueCount = nativeOverdueCount + yktCls.overdue.length + mrjzyCls.overdue.length + jlgjCls.overdue.length;
  const totalDoneCount = nativeDoneCount + yktCls.done.length + mrjzyCls.done.length + jlgjCls.done.length;
  const totalPendingCount = nativePendingCount + yktCls.pending.length + mrjzyCls.pending.length + jlgjCls.pending.length;
  const totalHomeworkCount = list.length + yktItems.length + mrjzyItems.length + jlgjItems.length;

  const renderHomeworkToggle = (kind, action, isExpanded, count, collapsedText, expandedText, collapsedDirection, expandedDirection) => {
    const direction = isExpanded ? expandedDirection : collapsedDirection;
    const label = `${isExpanded ? expandedText : collapsedText} (${count})`;
    return `<button class="btn homework-toggle-btn ${isExpanded ? 'is-expanded' : ''} homework-toggle-btn--${direction}" data-action="${action}" data-course-id="${escapeHtml(String(courseId))}" data-homework-toggle-kind="${kind}" data-count="${escapeHtml(String(count))}" data-collapsed-text="${escapeHtml(collapsedText)}" data-expanded-text="${escapeHtml(expandedText)}" aria-expanded="${isExpanded ? 'true' : 'false'}"><span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span><span class="homework-toggle-label">${escapeHtml(label)}</span><span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span></button>`;
  };

  // 教师账号：doneToggleRow 始终使用原文案
  const isTeacherMode2 = !!window.isTeacherAccount;
  const doneToggleRowHtml = totalDoneCount > 0 ? `<div class="homework-toggle-row homework-toggle-row--done">${renderHomeworkToggle('done', 'toggle-done', data.showDone, totalDoneCount, '查看已交作业', '收起已交作业', 'down', 'up')}</div>` : '';
  const forcePublishScoreButtonHtml = (!isTeacherMode2 && totalDoneCount > 0) ? renderForcePublishScoreButton(courseId) : '';

  const nativeCourse = (window.currentVeCourseList || []).find((course) => String(
    course?.id || course?.cId || course?.courseId || course?.course_id || ''
  ) === String(courseId));
  const homeworkCourseNum = nativeCourse?.course_num || nativeCourse?.courseNum || nativeCourse?.courseNo || nativeCourse?.course_id || courseId;
  const homeworkFzId = nativeCourse?.fz_id || nativeCourse?.fzId || nativeCourse?.xkhId || nativeCourse?.xkh_id || '';
  const homeworkXqCode = nativeCourse?.xq_code || nativeCourse?.xqCode || getCurrentXqCode();

  const renderNativeHomeworkItems = (items) => (items || []).map((hw) => {
    const originalIdx = list.indexOf(hw);
    const idx = originalIdx >= 0 ? originalIdx : 0;
    const subStatus = hw.subStatus ?? hw.sub_status ?? '';
    const subTime = hw.subTime ?? hw.sub_time ?? '';
    const isDone = isNativeHomeworkDone(hw);
    const overdue = !isDone && isNativeHomeworkOverdue(hw);

    // 教师账号：统一蓝色背景，不区分三类；过时作业用紫色
    const isTeacherMode = !!window.isTeacherAccount;
    const bgColor = isTeacherMode
      ? (overdue ? '#ede9fe' : '#dbeafe')
      : (isDone ? '#e8f5e9' : (overdue ? '#ffebee' : '#fff3e0'));
    const borderColor = isTeacherMode
      ? (overdue ? '#a78bfa' : '#93c5fd')
      : (isDone ? '#4caf50' : (overdue ? '#ef4444' : '#ff9800'));
    const titleColor = isTeacherMode
      ? (overdue ? '#6d28d9' : '#1d4ed8')
      : (isDone ? '#2e7d32' : (overdue ? '#b91c1c' : '#e65100'));
    const detailBtnColor = isTeacherMode
      ? (overdue ? '#6d28d9' : '#1d4ed8')
      : (isDone ? '#2E7D32' : (overdue ? '#b91c1c' : '#E65100'));
    const title = hw.title || hw.workTitle || hw.courseNoteTitle || '作业';
    const homeworkSubType = Number(hw.subType ?? hw.sub_type);
    const homeworkTypeLabel = ({ 0: '作业', 1: '课程报告', 2: '实验' })[homeworkSubType] || '作业';
    const homeworkCourseToPage = ({ 0: 10460, 1: 10461, 2: 10462 })[homeworkSubType] || 10460;
    const homeworkPageUrl = `${BASE_VE}back/coursePlatform/coursePlatform.shtml?method=toCoursePlatform&courseToPage=${homeworkCourseToPage}&courseId=${encodeURIComponent(homeworkCourseNum)}&cId=${encodeURIComponent(courseId)}&xknId=${encodeURIComponent(homeworkFzId)}&xkhId=${encodeURIComponent(homeworkFzId)}&xqCode=${encodeURIComponent(homeworkXqCode)}`;
    const sub = hw.subStatus || (isDone ? '已提交' : '未提交');
    const time = hw.subTime || '';
    const deadline = hw.end_time || hw.endTime || '';

    const obtainedScore = hw.lastScore ?? hw.oldScore ?? hw.old_score ?? hw.finalScore ?? hw.final_score ?? '';
    const fullScore = hw.score ?? hw.fullScore ?? hw.maxScore ?? hw.totalScore ?? '';
    const upId = hw.id ?? hw.upId ?? hw.upid ?? hw.UPID ?? hw.up_id ?? '';
    const snId = hw.snId ?? hw.snid ?? hw.SNID ?? hw.noteSnId ?? hw.note_sn_id ?? '';
    const scoreParam = String(fullScore ?? '').trim() || String(obtainedScore ?? '').trim();
    const scoreViewUrl = (upId && snId) ? `${BASE_VE}back/course/courseWorkInfo.shtml?method=piGaiDiv&upId=${encodeURIComponent(String(upId))}&id=${encodeURIComponent(String(snId))}&uLevel=1&score=${encodeURIComponent(scoreParam || '100')}` : '';
    const scoreKey = buildHomeworkScoreKey(upId, snId);
    const cachedScore = window.homeworkScoreCacheByKey[scoreKey];

    let scoreHtml = '';
    if (isTeacherMode) {
      const shownTotal = String(fullScore || '').trim();
      if (shownTotal) {
        scoreHtml = `<span style="font-weight:bold; color:#1d4ed8; margin-left:5px;">[总分 ${escapeHtml(shownTotal)}]</span>`;
      }
    } else if (cachedScore !== undefined && cachedScore !== null) {
      scoreHtml = globalThis.BjtuHomeworkUi.scoreBadgeHtml({ userScore: cachedScore, totalScore: fullScore || null, escape: escapeHtml });
    } else if (isDone) {
      const shown = String(obtainedScore || '').trim();
      if (shown) {
        scoreHtml = globalThis.BjtuHomeworkUi.scoreBadgeHtml({ userScore: shown, totalScore: fullScore || null, escape: escapeHtml });
      }
    }

    const rawContent = hw.content || hw.content_clean || hw.workContent || '';
    const contentHtml = normalizeHomeworkContent(rawContent);
    hw.__courseId = String(courseId || '').trim();
    const nativeKeySeed = String(upId || snId || hw.id || hw.upId || hw.noteId || hw.courseNoteId || '').trim();
    const expandKey = `native:${nativeKeySeed || `idx-${idx}`}`;
    const expanded = isHomeworkDetailExpanded(courseId, expandKey);
    const attachmentHtml = renderHomeworkAttachments(hw, borderColor, bgColor);
    const expandableBaseBg = isTeacherMode ? (overdue ? 'rgba(237,233,254,0.78)' : 'rgba(219,234,254,0.78)') : (isDone ? 'rgba(232,245,233,0.75)' : 'rgba(255,243,224,0.78)');
    const expandable = renderExpandableHtml(contentHtml, {
      emptyHtml: '<span style="color:#999;">无内容</span>',
      hideWhenEmpty: true,
      baseBg: expandableBaseBg,
      flatDisplay: true,
      courseId,
      expandKey,
      expanded
    });
    const viewBtnColor = isTeacherMode ? '#1d4ed8' : (isDone ? '#2E7D32' : '#0ea5e9');
    const submitCount = hw.submitCount ?? hw.submit_count ?? hw.subCount ?? '';
    const allCount = hw.allCount ?? hw.all_count ?? hw.totalCount ?? '';
    const submitCountHtml = submitCount !== '' || allCount !== ''
      ? `<span style="margin-left:10px; white-space:nowrap;">提交人数: <span style="font-weight:700; color:#111827;">${escapeHtml(String(submitCount || 0))}/${escapeHtml(String(allCount || 0))}</span></span>`
      : '';

    // 教师账号：作业ID（用于批量下载）
    const homeworkId = String(hw.snId || hw.noteId || hw.courseNoteId || hw.id || hw.upId || '').trim();
    const batchDownloadUrl = homeworkId ? `http://123.121.147.7:88/ve/back/coursePlatform/homeWork.shtml?method=batchDownloadWorks&id=${encodeURIComponent(homeworkId)}` : '';
    const viewActionText = globalThis.BjtuHomeworkUi.actionLabel('ve', 'view', { lead: '' });
    const submitActionText = globalThis.BjtuHomeworkUi.actionLabel('ve', 'submit', { lead: '' });

    // 按钮区域：教师账号显示"下载已交作业包"，否则显示"提交"
    const actionButtonsHtml = isTeacherMode
      ? `<div style="display:flex; align-items:center; gap:6px;">
          ${scoreViewUrl ? `<a class="btn" href="${scoreViewUrl}" target="_blank" rel="noopener noreferrer" style="background:${viewBtnColor}; padding: 2px 8px; font-size: 12px; text-decoration:none; color:#fff;">${viewActionText}</a>` : ''}
          ${batchDownloadUrl ? `<a class="btn" href="${batchDownloadUrl}" target="_blank" rel="noopener noreferrer" style="background:${detailBtnColor}; padding: 2px 8px; font-size: 12px; text-decoration:none; color:#fff;">下载已交作业包</a>` : '<span style="font-size:12px; color:#999;">无作业包</span>'}
        </div>`
      : `<div style="display:flex; align-items:center; gap:6px;">
          ${scoreViewUrl ? `<a class="btn" href="${scoreViewUrl}" target="_blank" rel="noopener noreferrer" style="background:${viewBtnColor}; padding: 2px 8px; font-size: 12px; text-decoration:none; color:#fff;">${viewActionText}</a>` : ''}
          <button class="btn" data-action="open-submit" data-course-id="${escapeHtml(String(courseId))}" data-hw-index="${idx}" style="background:${detailBtnColor}; padding: 2px 8px; font-size: 12px;">${submitActionText}</button>
        </div>`;

    // 提交面板（仅非教师账号显示）
    const submitPanelHtml = isTeacherMode ? '' : `
        <div class="submit-panel" data-submit-panel="1" style="display:none;">
          <textarea data-submit-content="1" placeholder="请输入作业内容（可为空）"></textarea>
          <div class="hint">可勾选左侧上传成功文件一并提交；不勾选则仅提交文本内容。</div>
          <div class="actions">
            <button class="btn confirm-submit-btn" style="background:#2563eb; padding:4px 10px; font-size:12px;" data-action="confirm-submit" data-course-id="${escapeHtml(String(courseId))}" data-hw-index="${idx}">确定</button>
            <button class="btn cancel-submit-btn" style="background:#64748b; padding:4px 10px; font-size:12px;" data-action="cancel-submit">取消</button>
          </div>
        </div>`;

    return globalThis.BjtuHomeworkUi.renderHomeworkCard({
      done: !isTeacherMode && isDone,
      background: bgColor,
      border: borderColor,
      titleHtml: globalThis.BjtuHomeworkUi.titleHtml({ typeLabel: homeworkTypeLabel, typeHref: homeworkPageUrl, title, color: titleColor, href: homeworkPageUrl, escape: escapeHtml }),
      metaHtml: globalThis.BjtuHomeworkUi.deadlineMetaHtml({
        deadline,
        formatted: deadline,
        startTime: hw.open_date ?? hw.openDate ?? '',
        startFormatted: hw.open_date ?? hw.openDate ?? '',
        done: isDone,
        overdue,
        showStatus: !isTeacherMode,
        showCountdown: !isTeacherMode,
        tailHtml: submitCountHtml,
        escape: escapeHtml
      }),
      actionsHtml: `${scoreHtml ? `<div style="font-size:12px;">${scoreHtml}</div>` : ''}${actionButtonsHtml}`,
      detailHtml: `${attachmentHtml}${expandable ? `<div style="margin-top:3px;border-top:1px dashed ${borderColor}40;padding-top:0;">${expandable}</div>` : ''}${submitPanelHtml}`
    });
  }).join('');

  const renderHomeworkGroup = (kind) => {
    // 教师账号：VE 作业不分类，直接合并在 teacher group
    if (window.isTeacherAccount) {
      // 外部分类保持不变
      if (kind === 'overdue') {
        return `${renderYktSection(yktOverdueItems)}${renderMrjzySection(mrjzyOverdueItems)}${renderJlgjSection(jlgjOverdueItems)}`;
      }
      if (kind === 'done') {
        return `${renderYktSection(yktDoneItems)}${renderMrjzySection(mrjzyDoneItems)}${renderJlgjSection(jlgjDoneItems)}`;
      }
      return `${renderYktSection(yktPendingItems)}${renderMrjzySection(mrjzyPendingItems)}${renderJlgjSection(jlgjPendingItems)}`;
    }
    if (kind === 'overdue') {
      return `${renderNativeHomeworkItems(nativeOverdueItems)}${renderYktSection(yktOverdueItems)}${renderMrjzySection(mrjzyOverdueItems)}${renderJlgjSection(jlgjOverdueItems)}`;
    }
    if (kind === 'done') {
      return `${renderNativeHomeworkItems(nativeDoneItems)}${renderYktSection(yktDoneItems)}${renderMrjzySection(mrjzyDoneItems)}${renderJlgjSection(jlgjDoneItems)}`;
    }
    return `${renderNativeHomeworkItems(nativePendingItems)}${renderYktSection(yktPendingItems)}${renderMrjzySection(mrjzyPendingItems)}${renderJlgjSection(jlgjPendingItems)}`;
  };

  // 教师账号：VE 作业按过时/非过时分为两组
  const teacherNonOverdueItems = window.isTeacherAccount ? list.filter((hw) => !isNativeHomeworkOverdue(hw)) : [];
  const teacherOverdueItems = window.isTeacherAccount ? list.filter((hw) => isNativeHomeworkOverdue(hw)) : [];
  const teacherNonOverdueHtml = window.isTeacherAccount ? renderNativeHomeworkItems(teacherNonOverdueItems) : '';
  const teacherOverdueHtmlRaw = window.isTeacherAccount ? renderNativeHomeworkItems(teacherOverdueItems) : '';

  const overdueHtml = renderHomeworkGroup('overdue');
  const pendingHtml = renderHomeworkGroup('pending');
  const doneHtml = renderHomeworkGroup('done');

  // 教师模式：将 VE 过时作业合并到 overdue 组中，使用统一折叠切换
  const mergedOverdueHtml = window.isTeacherAccount
    ? `${teacherOverdueHtmlRaw}${overdueHtml}`
    : overdueHtml;

  const overdueCollapsedText = isTeacherMode2 ? '查看过时作业' : '查看逾期作业';
  const overdueExpandedText = isTeacherMode2 ? '收起过时作业' : '收起逾期作业';
  const mergedOverdueCount = window.isTeacherAccount
    ? teacherOverdueItems.length + (totalOverdueCount - nativeOverdueCount)
    : totalOverdueCount;
  const mergedOverdueToggleRowHtml = mergedOverdueCount > 0
    ? `<div class="homework-toggle-row homework-toggle-row--overdue">${renderHomeworkToggle('overdue', 'toggle-overdue', data.showOverdue, mergedOverdueCount, overdueCollapsedText, overdueExpandedText, 'down', 'up')}</div>`
    : '';

  const pendingTypeLabels = [
    ...(window.veHomeworkPendingTypesByCourse?.[courseId] || []),
    ...(window.yktHomeworkPendingTypesByCourse?.[courseId] || [])
  ];
  const hasTypeLoadingState = Object.prototype.hasOwnProperty.call(window.veHomeworkPendingTypesByCourse || {}, courseId)
    || Object.prototype.hasOwnProperty.call(window.yktHomeworkPendingTypesByCourse || {}, courseId);
  const hasPendingTypeLoads = pendingTypeLabels.length > 0;
  const typeLoadingHtml = globalThis.BjtuHomeworkUi.typeLoadingHtml(pendingTypeLabels, { escape: escapeHtml });
  const loadingText = isMrjzyStandalone ? '正在同步每日交作业…' : '正在获取作业…';
  const standaloneSyncing = isYktStandalone ? (yktLoading || yktSyncing) : (isMrjzyStandalone ? mrjzySyncing : jlgjSyncing);
  const loadingHtml = isExternalStandalone && standaloneSyncing && !hasTypeLoadingState ? `<div class="spinner" style="border-color:#2196F3; border-top-color:transparent; display:inline-block;${spinnerPhaseDelayStyle()}"></div> ${loadingText}` : '';
  const emptyExternalTip = isExternalStandalone && totalHomeworkCount === 0 && !standaloneSyncing ? '<span style="color:#999;">没有作业数据</span>' : '';
  const noPendingTip = !hasPendingTypeLoads && !isTeacherMode2 && totalHomeworkCount > 0 && totalPendingCount === 0
    ? `<div class="homework-empty-tip" style="color:#4CAF50; margin-top:2px;">${totalOverdueCount > 0 ? '✓ 没有作业待交' : '✓ 所有作业已交'}</div>`
    : '';
  const noRelatedTip = !hasPendingTypeLoads && !isTeacherMode2 && !pendingHtml && totalHomeworkCount > 0 && !noPendingTip ? '<span class="homework-empty-tip" style="color:#999;">无未交作业</span>' : '';
  const noDataTip = !hasPendingTypeLoads && !isExternalStandalone && totalHomeworkCount === 0 ? '<span style="color:#999;">没有作业数据</span>' : '';

  // 教师账号：VE 非过时作业始终可见（蓝色）
  const teacherNonOverdueSectionHtml = (window.isTeacherAccount && teacherNonOverdueHtml)
    ? `<div class="homework-group homework-group--pending" data-homework-group="teacher-active">${teacherNonOverdueHtml}</div>`
    : '';

  area.innerHTML = `${typeLoadingHtml}${loadingHtml}${emptyExternalTip}${noDataTip}${mergedOverdueToggleRowHtml}${mergedOverdueHtml ? `<div class="homework-group homework-group--overdue ${data.showOverdue ? '' : 'is-hidden'}" data-homework-group="overdue" data-expanded="${data.showOverdue ? '1' : '0'}" aria-hidden="${data.showOverdue ? 'false' : 'true'}">${mergedOverdueHtml}</div>` : ''}${teacherNonOverdueSectionHtml}${pendingHtml ? `<div class="homework-group homework-group--pending" data-homework-group="pending">${pendingHtml}</div>` : ''}${noPendingTip || noRelatedTip}${doneToggleRowHtml}${doneHtml ? `<div class="homework-group homework-group--done ${data.showDone ? '' : 'is-hidden'}" data-homework-group="done" data-expanded="${data.showDone ? '1' : '0'}" aria-hidden="${data.showDone ? 'false' : 'true'}">${forcePublishScoreButtonHtml}${doneHtml}</div>` : ''}`;
  applyExpandableAutoToggle(area);
  applyDoneEnterAnimation();
  refreshUploadSelectVisibility();
  setTimeout(() => typeof updateAllCountdowns === 'function' && updateAllCountdowns(), 0);
}

// Videos (best-effort implementation)
async function fetchVideoLinkInternal(containerId, videoId, courseNum, fzId, teacherId, { signal = null, onLinkExpired = null } = {}) {
  const getLinksDiv = () => document.getElementById(containerId);
  const courseListVersion = getCourseListLoadVersionSnapshot();
  const isStale = () => isCourseListLoadStale(courseListVersion);
  if (!getLinksDiv()) return false;

  try {
    const postUrl = `${BASE_VE}back/resourceSpace.shtml`;
    const postBody = new URLSearchParams({ method: 'rpinfoDownloadUrl', rpId: String(videoId) });
    const referer = `${BASE_VE}back/coursePlatform/coursePlatform.shtml?method=toCoursePlatform&courseToPage=10480&courseId=${encodeURIComponent(courseNum)}&dataSource=1&cId=122618&xkhId=${encodeURIComponent(fzId)}&xqCode=${encodeURIComponent(getCurrentXqCode())}&teacherId=${encodeURIComponent(teacherId)}`;

    const { text, res } = await fetchText(postUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': referer,
        'Accept': 'application/json, text/javascript, */*; q=0.01'
      },
      body: postBody.toString(),
      signal: getCombinedAbortSignal(window.globalVeAbortController?.signal, signal)
    });

    if (isLikelyLoginPageHtml(text, res?.url)) {
      if (typeof onLinkExpired === 'function') onLinkExpired();
      const linksDiv = getLinksDiv();
      if (linksDiv) linksDiv.innerHTML = '<span class="error" style="color:#f44336;">[登录已失效，正在重启]</span>';
      await restartVePlatformForLoginExpired('回放下载链接登录已失效，正在重启智慧课程平台…');
      return 'LOGIN_REQUIRED';
    }

    if (isStale()) return false;

    const detailData = parseVeJson(text);

    if (detailData.flag === false || (String(detailData.STATUS) === '1' && String(detailData.ERRMSG || '').includes('不合法'))) {
      const linksDiv = getLinksDiv();
      if (!linksDiv) return false;
      if (isStale()) return false;

      if (typeof onLinkExpired === 'function') onLinkExpired();
      linksDiv.innerHTML = '<span class="error" style="color:#f44336;">[登录已失效，正在重启]</span>';
      await restartVePlatformForLoginExpired('回放下载链接登录已失效，正在重启智慧课程平台…');
      return 'LOGIN_REQUIRED';
    }

    // New/alt format: {flag:true, html:"<a...>"}
    const html = (detailData.html || '').trim();
    if (html && (detailData.flag === true || String(detailData.STATUS) === '0')) {
      const linksDiv = getLinksDiv();
      if (!linksDiv) return false;
      if (isStale()) return false;
      linksDiv.style.color = '#9C27B0';
      linksDiv.style.fontWeight = 'bold';
      linksDiv.innerHTML = html;

      // style anchors
      const aTags = linksDiv.querySelectorAll('a');
      aTags.forEach(a => {
        a.style.color = '#7B1FA2';
        a.style.textDecoration = 'none';
        a.style.fontWeight = 'bold';
        a.target = '_blank';
        a.style.fontSize = '14px';
        a.style.marginRight = '20px';
        a.style.float = 'none';
        a.style.display = 'inline-block';
      });
      return true;
    }

    const linksDiv = getLinksDiv();
    if (!linksDiv) return false;
    if (isStale()) return false;
    if (typeof onLinkExpired === 'function') onLinkExpired();
    linksDiv.style.color = '#9C27B0';
    linksDiv.style.fontWeight = 'bold';
    linksDiv.innerHTML = '<span class="error" style="color:#f44336;">[链接获取失败，正在重启]</span>';
    await restartVePlatformForLoginExpired('回放下载链接获取失败，正在重启智慧课程平台…');
    return 'LOGIN_REQUIRED';
  } catch (e) {
    const linksDiv = getLinksDiv();
    if (e?.name === 'AbortError') return false;
    if (String(e?.message || e) === 'LOGIN_REQUIRED') return 'LOGIN_REQUIRED';
    if (typeof onLinkExpired === 'function') onLinkExpired();
    if (linksDiv) linksDiv.innerHTML = '<span class="error" style="color:#f44336;">[链接获取失败，正在重启]</span>';
    await restartVePlatformForLoginExpired('回放下载链接获取失败，正在重启智慧课程平台…');
    return 'LOGIN_REQUIRED';
  }
}

window.__fetchVideoDetail = async function (rpId, courseId, xkhId, teacherId, btnEl) {
  const container = btnEl.closest('div');
  const span = container.querySelector('.video-link');
  const courseListVersion = getCourseListLoadVersionSnapshot();
  const isStale = () => isCourseListLoadStale(courseListVersion);
  span.textContent = '获取中…';
  try {
    const postUrl = `${BASE_VE}back/resourceSpace.shtml`;
    const postBody = new URLSearchParams({ method: 'rpinfoDownloadUrl', rpId: rpId });
    const referer = `${BASE_VE}back/coursePlatform/coursePlatform.shtml?method=toCoursePlatform&courseToPage=10480&courseId=${encodeURIComponent(courseId)}&dataSource=1&cId=122618&xkhId=${encodeURIComponent(xkhId)}&xqCode=${encodeURIComponent(getCurrentXqCode())}&teacherId=${encodeURIComponent(teacherId)}`;
    const { text, res } = await fetchText(postUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': referer,
        'Accept': 'application/json, text/javascript, */*; q=0.01'
      },
      body: postBody.toString()
    });

    if (isStale()) return;

    if (isLikelyLoginPageHtml(text, res?.url)) {
      span.innerHTML = '<span class="error" style="color:#f44336;">[登录已失效，正在重启]</span>';
      await restartVePlatformForLoginExpired('回放下载链接登录已失效，正在重启智慧课程平台…');
      return;
    }

    const data = JSON.parse(text);
    if (data?.flag === false || (data?.STATUS === '1' && String(data?.ERRMSG || '').includes('不合法'))) {
      if (isStale()) return;
      span.innerHTML = '<span class="error" style="color:#f44336;">[登录已失效，正在重启]</span>';
      await restartVePlatformForLoginExpired('回放下载链接登录已失效，正在重启智慧课程平台…');
      return;
    }
    const html = data?.html || '';
    if (!html) {
      if (isStale()) return;
      span.textContent = '未返回链接';
      return;
    }
    // Best-effort: find first http(s) link
    const m = html.match(/https?:\/\/[^\s"']+/);
    if (m?.[0]) {
      if (isStale()) return;
      span.innerHTML = `<a class="url-link" href="${m[0]}" target="_blank">${m[0]}</a>`;
    } else {
      if (isStale()) return;
      span.textContent = '已返回 HTML（未解析出直链）';
    }
  } catch (e) {
    if (isStale()) return;
    span.textContent = 'Err: ' + e.message;
  }
};

if (resourceCopySelectedBtn) {
  resourceCopySelectedBtn.addEventListener('click', () => {
    const selected = getSelectableDownloadItems().filter((it) => window.resourceSpaceSelected.has(String(it.id || '')));
    if (!selected.length) {
      showToast('请先选择文件', 'warning', 1200);
      return;
    }
    let text = '';
    if (selected.length === 1) {
      text = String(selected[0]?.url || '').trim();
    } else {
      text = selected
        .map((it) => {
          const name = String(it?.name || '未命名文件').trim();
          const link = String(it?.url || '').trim();
          if (!link) return '';
          return `${name}\n${link}`;
        })
        .filter(Boolean)
        .join('\n\n');
    }
    if (!text) {
      showToast('选中项没有可复制链接', 'warning', 1200);
      return;
    }
    navigator.clipboard.writeText(text).then(() => {
      showToast('已复制选中链接', 'success', 1200);
    });
  });
}

if (resourceSelectAllBtn) {
  resourceSelectAllBtn.addEventListener('click', () => {
    const ids = getResourceSpaceSelectableIds();
    if (!ids.length) {
      showToast('当前资源空间无可选文件', 'warning', 1200);
      return;
    }
    invertResourceSpaceSelectionByVisibleItems();
  });
}

if (resourceSearchInput instanceof HTMLInputElement) {
  const submitSearch = () => {
    const keyword = normalizeResourceSearchKeyword(resourceSearchInput.value);
    if (keyword === resourceSpaceSearchKeyword) return;
    loadResourceSpaceForCurrentAccount(keyword).catch(() => { });
  };
  resourceSearchInput.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    submitSearch();
  });
  resourceSearchInput.addEventListener('blur', () => {
    submitSearch();
  });
}

if (resourceDownloadSelectedBtn) {
  resourceDownloadSelectedBtn.addEventListener('click', () => {
    const selected = getSelectableDownloadItems().filter((it) => {
      const rid = String(it.id || '').trim();
      return window.resourceSpaceSelected.has(rid) && !isResourceDownloadActive(rid);
    });
    if (!selected.length) {
      showToast('请先选择文件', 'warning', 1200);
      return;
    }

    const hasActiveOrQueued = Object.values(window.resourceDownloadTasks || {}).some((t) => !!t?.active)
      || (window.resourceDownloadQueue || []).some((q) => q && !q.cancelled);
    if (!hasActiveOrQueued) {
      window.resourceDownloadCompletedContribution = { loadedBytes: 0, totalBytes: 0 };
      window.resourceDownloadQueueStatus = { totalFiles: 0, savedFiles: 0 };
    }

    let queuedCount = 0;
    selected.forEach((item, idx) => {
      const rid = String(item?.id || '').trim();
      if (!rid) return;
      queuedCount++;
      setResourceSpaceStatus(`下载队列 ${Math.min(selected.length, idx + 1)}/${selected.length}: ${String(item?.name || '未命名文件')}`);
      enqueueResourceDownload(item).then(() => {
        window.resourceDownloadQueueStatus.savedFiles = Math.max(0, Number(window.resourceDownloadQueueStatus?.savedFiles || 0) + 1);
        refreshResourceQueueStatusText();
      }).catch((err) => {
        const msg = String(err?.message || err || '');
        if (msg.includes('下载已取消')) {
          refreshResourceQueueStatusText();
          return;
        }
        showToast(`下载失败：${String(item?.name || '未命名文件')} (${msg})`, 'error', 2200);
        refreshResourceQueueStatusText();
      });
      window.resourceSpaceSelected.delete(rid);
    });

    refreshResourceSelectAllButton();
    if (queuedCount > 0) {
      const prevTotal = Math.max(0, Number(window.resourceDownloadQueueStatus?.totalFiles || 0));
      window.resourceDownloadQueueStatus.totalFiles = prevTotal + queuedCount;
      refreshResourceQueueStatusText();
      showToast(`已加入队列 ${queuedCount} 个文件`, 'success', 1200);
    }
  });
}

if (loginBtn) loginBtn.addEventListener('click', doLoginFlow);
if (cancelBtn) cancelBtn.addEventListener('click', () => dismissLoginModal());

// Delegated handlers (extension CSP blocks inline onclick)
courseListDiv.addEventListener('mouseover', (e) => {
  const t = e.target;
  if (!(t instanceof Element)) return;
  const wrap = t.closest('.ve-course-num-wrap');
  if ((wrap instanceof HTMLElement)) {
    const from = e.relatedTarget;
    if (from instanceof Node && wrap.contains(from)) return;
    const courseId = String(wrap.dataset.courseId || '').trim();
    const courseNum = String(wrap.dataset.courseNum || '').trim();
    const fzId = String(wrap.dataset.fzId || '').trim();
    if (!courseId || !courseNum) return;
    hydrateVeCourseTeachersMeta(courseId, courseNum, fzId).catch(() => { });
    return;
  }
  const studentWrap = t.closest('.ve-student-wrap');
  if ((studentWrap instanceof HTMLElement)) {
    const from = e.relatedTarget;
    if (from instanceof Node && studentWrap.contains(from)) return;
    const courseId = String(studentWrap.dataset.courseId || '').trim();
    if (!courseId) return;
    hydrateVeStudentsMeta(courseId).catch(() => { });
    return;
  }
  // 教师姓名悬停
  const teacherWrap = t.closest('.ve-teacher-wrap');
  if ((teacherWrap instanceof HTMLElement)) {
    const from = e.relatedTarget;
    if (from instanceof Node && teacherWrap.contains(from)) return;
    const courseId = String(teacherWrap.dataset.courseId || '').trim();
    if (!courseId) return;
    const card = teacherWrap.closest('.file-item');
    const courseNumWrap = card?.querySelector('.ve-course-num-wrap');
    const courseNum = String(courseNumWrap?.dataset?.courseNum || '').trim();
    if (!courseNum) return;
    hydrateVeTeacherMeta(courseId, courseNum, '').catch(() => { });
    return;
  }
});

function keepExpandableTogglePosition(toggle) {
  let top = toggle.getBoundingClientRect().top;
  const scrollTargets = [];
  for (let node = toggle.parentElement; node; node = node.parentElement) {
    const overflowY = getComputedStyle(node).overflowY;
    if (/(auto|scroll)/.test(overflowY) && node.scrollHeight > node.clientHeight + 1) scrollTargets.push(node);
  }
  if (document.scrollingElement && !scrollTargets.includes(document.scrollingElement)) {
    scrollTargets.push(document.scrollingElement);
  }
  const lastScrollTops = new Map(scrollTargets.map((target) => [target, target.scrollTop]));
  let stopped = false;
  let intendedScroll = 0;
  let lastInputAt = 0;
  let lastInputDirection = 0;
  let lastTouchY = null;
  const recordInput = (delta) => {
    if (!Number.isFinite(delta) || !delta) return;
    if (lastInputDirection && Math.sign(delta) !== lastInputDirection) intendedScroll = 0;
    intendedScroll += delta;
    lastInputAt = performance.now();
    lastInputDirection = Math.sign(delta);
  };
  const onWheel = (event) => {
    if (event.ctrlKey) return;
    const multiplier = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? window.innerHeight : 1;
    recordInput(event.deltaY * multiplier);
  };
  const onTouchStart = (event) => {
    lastTouchY = event.touches[0]?.clientY ?? null;
  };
  const onTouchMove = (event) => {
    const y = event.touches[0]?.clientY;
    if (y == null) return;
    if (lastTouchY != null) recordInput(lastTouchY - y);
    lastTouchY = y;
  };
  const stop = () => {
    stopped = true;
    document.removeEventListener('wheel', onWheel, true);
    document.removeEventListener('touchstart', onTouchStart, true);
    document.removeEventListener('touchmove', onTouchMove, true);
  };
  document.addEventListener('wheel', onWheel, { capture: true, passive: true });
  document.addEventListener('touchstart', onTouchStart, { capture: true, passive: true });
  document.addEventListener('touchmove', onTouchMove, { capture: true, passive: true });
  const update = () => {
    if (stopped) return;
    if (!toggle.isConnected) {
      stop();
      return;
    }
    let actualScroll = 0;
    for (const target of scrollTargets) {
      actualScroll += target.scrollTop - lastScrollTops.get(target);
    }
    const recentInput = performance.now() - lastInputAt < 350;
    if (!recentInput) intendedScroll = 0;
    if (actualScroll && Math.sign(actualScroll) === lastInputDirection && recentInput) {
      const userScroll = intendedScroll && Math.sign(intendedScroll) === Math.sign(actualScroll)
        ? Math.sign(actualScroll) * Math.min(Math.abs(actualScroll), Math.abs(intendedScroll))
        : actualScroll;
      top -= userScroll;
      intendedScroll -= userScroll;
    }
    let delta = toggle.getBoundingClientRect().top - top;
    for (const target of scrollTargets) {
      if (Math.abs(delta) <= 0.5) break;
      const before = target.scrollTop;
      target.scrollTop += delta;
      delta -= target.scrollTop - before;
    }
    for (const target of scrollTargets) lastScrollTops.set(target, target.scrollTop);
  };
  return { update, stop };
}

courseListDiv.addEventListener('click', async (e) => {
  const t = e.target;
  if (!(t instanceof Element)) return;
  const actionEl = t.closest('[data-action]');
  if (!(actionEl instanceof HTMLElement)) return;
  const action = String(actionEl.dataset.action || '').trim();

  if (action === 'courseware' || action === 'videos') {
    const card = actionEl.closest('.file-item[id^="course-"]');
    if (!(card instanceof HTMLElement)) return;
    const rawId = String(card.dataset.courseId || card.id.replace(/^course-/, '') || '').trim();
    if (!rawId) return;
    const meta = card.querySelector('.ve-course-num-wrap');
    const courseNum = String(actionEl.dataset.courseNum || meta?.dataset?.courseNum || rawId).trim();
    const fzId = String(actionEl.dataset.fzId || meta?.dataset?.fzId || '').trim();
    e.preventDefault();
    e.stopPropagation();
    if (action === 'courseware') {
      toggleCoursewareFromCache(actionEl, rawId, courseNum, fzId);
    } else {
      actionEl.dataset.courseNum = courseNum;
      actionEl.dataset.fzId = fzId;
      toggleReplayFromCache(actionEl, rawId);
    }
    return;
  }

  if (action === 'toggle-expand') {
    const box = actionEl.closest('.expandable-box');
    if (!box) return;
    const openText = actionEl.dataset.openText || '点击展开详情';
    const closeText = actionEl.dataset.closeText || '点击收起';
    const body = box.querySelector('.expandable-body');
    const isExpanded = box.classList.contains('expanded');

    if (body instanceof HTMLElement) {
      const from = body.getBoundingClientRect().height;
      const interruptedCollapse = box.__detailCollapseState;
      const interruptedExpansion = box.__detailExpandState;
      body.__heightMotion?.cancel();
      body.style.transition = 'none';
      actionEl.style.transition = 'none';
      actionEl.style.transform = '';
      if (!isExpanded) {
        const positionTracker = interruptedCollapse && window.collapseHomeworkDetailsDownward
          ? keepExpandableTogglePosition(actionEl)
          : null;
        if (interruptedCollapse) delete box.__detailCollapseState;
        const previousPaddingBottom = interruptedCollapse?.paddingBottom ?? box.style.paddingBottom;
        const basePaddingBottom = interruptedCollapse?.basePaddingBottom
          ?? (parseFloat(getComputedStyle(box).paddingBottom) || 0);
        const startSpace = Math.max(0, (parseFloat(getComputedStyle(box).paddingBottom) || 0) - basePaddingBottom);
        const previousPosition = interruptedCollapse?.position ?? actionEl.style.position;
        const previousMarginTop = interruptedCollapse?.marginTop ?? actionEl.style.marginTop;
        box.classList.add('expanded');
        const toggleSpace = actionEl.getBoundingClientRect().height
          + (parseFloat(getComputedStyle(actionEl).marginTop) || 0);
        actionEl.style.position = 'absolute';
        actionEl.style.marginTop = '0px';
        body.style.maxHeight = 'none';
        body.style.boxSizing = 'border-box';
        body.style.height = `${from}px`;
        body.style.overflow = 'hidden';
        const to = Math.max(from + 1, body.scrollHeight);
        const expandState = { paddingBottom: previousPaddingBottom, basePaddingBottom,
          position: previousPosition, marginTop: previousMarginTop };
        box.__detailExpandState = expandState;
        void animateHeightWithMotion(body, from, to, (height, progress) => {
          body.style.height = `${height}px`;
          box.style.paddingBottom = `${basePaddingBottom + startSpace + (toggleSpace - startSpace) * progress}px`;
          positionTracker?.update();
        }).then((completed) => {
          if (box.__detailExpandState === expandState) {
            box.style.paddingBottom = previousPaddingBottom;
            actionEl.style.position = previousPosition;
            actionEl.style.marginTop = previousMarginTop;
            delete box.__detailExpandState;
          }
          if (completed) {
            body.style.height = '';
            body.style.maxHeight = '';
            body.style.boxSizing = '';
            body.style.overflow = '';
            body.style.transition = '';
            actionEl.style.transition = '';
          }
          if (positionTracker) {
            if (completed) requestAnimationFrame(() => {
              positionTracker.update();
              positionTracker.stop();
            });
            else positionTracker.stop();
          }
        });
      } else {
        const positionTracker = window.collapseHomeworkDetailsDownward
          ? keepExpandableTogglePosition(actionEl)
          : null;
        if (interruptedExpansion) delete box.__detailExpandState;
        const previousBoxHeight = interruptedExpansion ? 0 : box.getBoundingClientRect().height;
        const previousPaddingBottom = interruptedExpansion?.paddingBottom ?? box.style.paddingBottom;
        const basePaddingBottom = interruptedExpansion?.basePaddingBottom
          ?? (parseFloat(getComputedStyle(box).paddingBottom) || 0);
        const existingSpace = Math.max(0, (parseFloat(getComputedStyle(box).paddingBottom) || 0) - basePaddingBottom);
        const previousPosition = interruptedExpansion?.position ?? actionEl.style.position;
        const previousMarginTop = interruptedExpansion?.marginTop ?? actionEl.style.marginTop;
        box.classList.remove('expanded');
        const collapsedLines = box.classList.contains('expandable-box--replay')
          ? window.replayDetailCollapsedLines
          : window.homeworkDetailCollapsedLines;
        body.style.height = '';
        body.style.maxHeight = detailCollapsedMaxHeight(collapsedLines);
        const to = body.getBoundingClientRect().height;
        body.style.maxHeight = 'none';
        body.style.boxSizing = 'border-box';
        body.style.height = `${from}px`;
        body.style.overflow = 'hidden';
        // Keep the toggle at the bottom inside the card while its flow space shrinks away.
        const toggleSpace = interruptedExpansion
          ? existingSpace
          : Math.max(0, previousBoxHeight - box.getBoundingClientRect().height);
        const collapseState = { paddingBottom: previousPaddingBottom, basePaddingBottom,
          position: previousPosition, marginTop: previousMarginTop };
        box.__detailCollapseState = collapseState;
        box.style.paddingBottom = `${basePaddingBottom + toggleSpace}px`;
        void animateHeightWithMotion(body, from, to, (height, progress) => {
          body.style.height = `${height}px`;
          box.style.paddingBottom = `${basePaddingBottom + toggleSpace * (1 - progress)}px`;
          positionTracker?.update();
        }).then((completed) => {
          if (box.__detailCollapseState === collapseState) {
            box.style.paddingBottom = previousPaddingBottom;
            actionEl.style.position = previousPosition;
            actionEl.style.marginTop = previousMarginTop;
            delete box.__detailCollapseState;
          }
          if (completed) {
            body.style.height = '';
            body.style.maxHeight = '';
            body.style.boxSizing = '';
            body.style.overflow = '';
            body.style.transition = '';
            actionEl.style.transition = '';
          }
          if (positionTracker) {
            if (completed) requestAnimationFrame(() => {
              positionTracker.update();
              positionTracker.stop();
            });
            else positionTracker.stop();
          }
        });
      }
    } else {
      box.classList.toggle('expanded');
    }

    const expandedNow = box.classList.contains('expanded');
    actionEl.textContent = expandedNow ? closeText : openText;
    box.dataset.expanded = expandedNow ? '1' : '0';
    const courseId = String(box.dataset.courseId || '').trim();
    const expandKey = String(box.dataset.expandKey || '').trim();
    setHomeworkDetailExpanded(courseId, expandKey, expandedNow);
    return;
  }

  if (action === 'toggle-overdue') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    if (!courseId) return;
    if (!window.courseShowOverdueById?.[courseId]) void loadDeferredYktHomeworkDetails(courseId, 'overdue');
    window.toggleOverdueView(courseId);
    return;
  }
  if (action === 'toggle-done') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    if (!courseId) return;
    if (!window.courseShowDoneById?.[courseId]) void loadDeferredYktHomeworkDetails(courseId, 'done');
    window.toggleDoneView(courseId);
    return;
  }
  if (action === 'force-publish-scores') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    if (!courseId) return;
    e.preventDefault();
    e.stopPropagation();
    await forcePublishScoresThenRestore(courseId, actionEl instanceof HTMLButtonElement ? actionEl : null);
    return;
  }
  if (action === 'toggle-homework') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    if (!courseId) return;
    window.toggleHomeworkView(courseId);
    return;
  }

  if (action === 'switch-teacher-account') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    const teacherId = String(actionEl.dataset.teacherId || window.veTeacherMetaByCourseId?.[courseId]?.teacherId || '').trim();
    await switchToTeacherAccount(teacherId);
    return;
  }

  if (action === 'open-submit') {
    courseListDiv.querySelectorAll('.submit-panel[data-submit-panel="1"]').forEach((p) => {
      if (p instanceof HTMLElement) p.style.display = 'none';
    });
    const block = actionEl.closest('.hw-card-item');
    if (!block) return;
    const panel = block.querySelector('.submit-panel[data-submit-panel="1"]');
    if (!panel) return;
    panel.style.display = 'block';
    refreshUploadSelectVisibility();
    const textarea = panel.querySelector('textarea[data-submit-content="1"]');
    if (textarea instanceof HTMLTextAreaElement) textarea.focus();
    return;
  }

  if (action === 'cancel-submit') {
    const panel = actionEl.closest('.submit-panel[data-submit-panel="1"]');
    if (!panel) return;
    panel.style.display = 'none';
    refreshUploadSelectVisibility();
    return;
  }

  if (action === 'confirm-submit') {
    const courseId = String(actionEl.dataset.courseId || '').trim();
    const idx = Number(actionEl.dataset.hwIndex || -1);
    if (!courseId || idx < 0) return;

    const data = window.courseHomeworkData[courseId] || { list: [] };
    const hw = (data.list || [])[idx];
    if (!hw) {
      showToast('未找到作业数据，请刷新后重试', 'warning', 1800);
      return;
    }

    const panel = t.closest('.submit-panel[data-submit-panel="1"]');
    if (!panel) return;
    const textarea = panel.querySelector('textarea[data-submit-content="1"]');
    const content = textarea instanceof HTMLTextAreaElement ? textarea.value : '';
    const fileList = getSelectedUploadedFileList();

    const homeworkCore = globalThis.BjtuVeHomeworkCore;
    if (homeworkCore?.requiresNonRepeatSubmissionConfirmation?.(hw)
      && !window.confirm(homeworkCore.NON_REPEAT_SUBMISSION_CONFIRM_MESSAGE)) {
      return;
    }

    const btn = actionEl;
    const oldText = btn.textContent;
    btn.textContent = '提交中…';
    btn.setAttribute('disabled', 'disabled');
    try {
      const res = await submitNativeHomework(courseId, hw, content, fileList);
      if (res.loginRequired) {
        handleLoginRequired(() => {
          btn.removeAttribute('disabled');
          btn.textContent = oldText || '确定';
        }, null, globalThis.BjtuPlatformLoginUi.loginRequiredHtml('ve'));
        return;
      }
      if (!res.ok) {
        showToast(res.message || '提交失败', 'error', 2500);
        refreshUploadSelectVisibility();
        return;
      }

      hw.subStatus = '已提交';
      hw.subTime = formatMrjzyDateTime(new Date());
      showToast('作业提交成功', 'success', 1600);
      renderHomeworkList(courseId);
      recomputeCourseHomeworkState(courseId);
      await checkHomework(courseId);
      refreshUploadSelectVisibility();
    } catch (err) {
      showToast(`提交失败：${String(err?.message || err)}`, 'error', 2500);
    } finally {
      btn.removeAttribute('disabled');
      btn.textContent = oldText || '确定';
      refreshUploadSelectVisibility();
    }
  }
});

if (resourceSpaceList) {
  resourceSpaceList.addEventListener('click', async (e) => {
    const rawTarget = e.target;
    const t = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
    if (!(t instanceof HTMLElement)) return;

    const titleRow = t.closest('.resource-row-title');
    if (titleRow instanceof HTMLElement && !t.closest('a,button,input,textarea,select,label')) {
      const rowScope = titleRow.closest('.file-item') || titleRow;
      const cb = rowScope.querySelector('input[data-action="resource-check"][data-resource-id]');
      if (cb instanceof HTMLInputElement) {
        cb.checked = !cb.checked;
        cb.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return;
    }

    const action = String(t.dataset.action || '').trim();
    const id = String(t.dataset.resourceId || '').trim();
    if (!action || !id) return;
    const item = findSelectableDownloadItemById(id);
    if (!item) return;

    if (action === 'resource-check' && t instanceof HTMLInputElement) {
      if (t.checked) window.resourceSpaceSelected.add(id);
      else window.resourceSpaceSelected.delete(id);
      return;
    }

    if (action === 'resource-copy') {
      navigator.clipboard.writeText(cleanRpUrl(String(item.url || ''), { keepG: true })).then(() => {
        showToast('链接已复制', 'success', 1200);
      });
      return;
    }

    if (action === 'resource-cancel-download') {
      const cancelled = cancelResourceDownload(id);
      if (cancelled) {
        showToast('已取消下载', 'warning', 1000);
      }
      return;
    }

    if (action === 'resource-download') {
      try {
        if (!item.url && item.rpId) {
          const result = await fetchCoursewareRpUrl(item.rpId);
          const rpUrl = String(result?.url || '').trim();
          if (rpUrl) {
            item.url = rpUrl;
          } else if (result?.loginExpired) {
            await restartVePlatformForLoginExpired('资源下载链接获取失败，正在重启智慧课程平台…');
            showToast('获取下载链接失败', 'error', 1800);
            return;
          } else {
            showToast('获取下载链接失败', 'error', 1800);
            return;
          }
        }
        await enqueueResourceDownload(item);
        showToast('下载完成', 'success', 1200);
      } catch (err) {
        const msg = String(err?.message || err || '');
        if (msg.includes('下载已取消')) {
          // 取消操作的点击分支已经即时提示，异步任务结束时不再重复显示。
        } else {
          showToast(`下载失败：${msg}`, 'error', 1800);
        }
      }
      return;
    }
  });

  resourceSpaceList.addEventListener('change', (e) => {
    const t = e.target;
    if (!(t instanceof HTMLInputElement)) return;
    if (String(t.dataset.action || '') !== 'resource-check') return;
    const id = String(t.dataset.resourceId || '').trim();
    if (!id) return;
    if (isResourceDownloadActive(id)) {
      t.checked = false;
      refreshResourceSelectAllButton();
      return;
    }
    if (t.checked) window.resourceSpaceSelected.add(id);
    else window.resourceSpaceSelected.delete(id);
    refreshResourceSelectAllButton();
  });
}

courseListDiv.addEventListener('click', async (e) => {
  const t = e.target;
  if (!(t instanceof HTMLElement)) return;

  const titleRow = t.closest('.resource-row-title');
  if (titleRow instanceof HTMLElement && !t.closest('a,button,input,textarea,select,label')) {
    const cb = titleRow.querySelector('input[data-action="resource-check"][data-resource-id]');
    if (cb instanceof HTMLInputElement) {
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return;
  }

  const action = String(t.dataset.action || '').trim();
  if (action === 'archive-batch-download') {
    e.preventDefault();
    e.stopPropagation();
    downloadCourseArchive(String(t.dataset.courseId || '').trim());
    return;
  }
  if (action === 'courseware-select-all') {
    const card = t.closest('[id^="course-"]');
    toggleCoursewareSelectionForCard(card);
    return;
  }
  if (!['resource-check', 'resource-copy', 'resource-download', 'resource-cancel-download'].includes(action)) return;
  const id = String(t.dataset.resourceId || '').trim();
  if (!id) return;
  const item = findSelectableDownloadItemById(id);
  if (!item) return;

  if (action === 'resource-check' && t instanceof HTMLInputElement) {
    if (t.checked) window.resourceSpaceSelected.add(id);
    else window.resourceSpaceSelected.delete(id);
    const card = t.closest('[id^="course-"]');
    syncCoursewareSelectAllButton(card);
    refreshResourceSelectAllButton();
    return;
  }

  if (action === 'resource-copy') {
    navigator.clipboard.writeText(String(item.url || '')).then(() => {
      showToast('链接已复制', 'success', 1200);
    });
    return;
  }

  if (action === 'resource-cancel-download') {
    const cancelled = cancelResourceDownload(id);
    if (cancelled) showToast('已取消下载', 'warning', 1000);
    return;
  }

  if (action === 'resource-download') {
    try {
      await enqueueResourceDownload(item);
      showToast('下载完成', 'success', 1200);
    } catch (err) {
      const msg = String(err?.message || err || '');
      if (msg.includes('下载已取消')) {
        // 取消操作的点击分支已经即时提示，异步任务结束时不再重复显示。
      }
      else showToast(`下载失败：${msg}`, 'error', 1800);
    }
  }
});

courseListDiv.addEventListener('change', (e) => {
  const t = e.target;
  if (!(t instanceof HTMLInputElement)) return;
  if (String(t.dataset.action || '') !== 'resource-check') return;
  const id = String(t.dataset.resourceId || '').trim();
  if (!id) return;
  if (isResourceDownloadActive(id)) {
    t.checked = false;
    const card = t.closest('[id^="course-"]');
    syncCoursewareSelectAllButton(card);
    refreshResourceSelectAllButton();
    return;
  }
  if (t.checked) window.resourceSpaceSelected.add(id);
  else window.resourceSpaceSelected.delete(id);
  const card = t.closest('[id^="course-"]');
  syncCoursewareSelectAllButton(card);
  refreshResourceSelectAllButton();
});

courseListDiv.addEventListener('wheel', (e) => {
  const target = e.target;
  if (!(target instanceof Element)) return;
  const body = target.closest('.expandable-body');
  if (!(body instanceof HTMLElement)) return;
  const box = body.closest('.expandable-box');
  if (!(box instanceof HTMLElement)) return;
  if (box.classList.contains('expanded')) return;

  // Keep horizontal wheel/trackpad gestures untouched.
  if (e.shiftKey) return;
  const deltaX = Number(e.deltaX || 0);
  const deltaY = Number(e.deltaY || 0);
  if (!deltaY || Math.abs(deltaX) > Math.abs(deltaY)) return;

  const maxScroll = body.scrollHeight - body.clientHeight;
  if (maxScroll <= 0) return;

  const atTop = body.scrollTop <= 0;
  const atBottom = body.scrollTop + body.clientHeight >= body.scrollHeight - 1;
  if ((deltaY < 0 && atTop) || (deltaY > 0 && atBottom)) {
    // Let page scroll continue naturally when inner area reaches the edge.
    return;
  }

  e.preventDefault();
  const step = Math.max(8, Math.min(18, Math.abs(deltaY) * 0.18));
  body.scrollTop += deltaY > 0 ? step : -step;
}, { passive: false });

document.addEventListener('click', (e) => {
  const t = e.target;
  if (!(t instanceof HTMLElement)) return;
  if (t.dataset.action !== 'toggle-platform') return;
  e.preventDefault();
  e.stopPropagation();
  const platform = String(t.dataset.platform || '').trim();
  togglePlatformSelection(platform);
});

let initialUsernameSet = true;
let loginFlowUsernameSet = false;
usernameInput.addEventListener('change', async () => {
  const username = String(usernameInput.value || '').trim();
  if (suppressedUsernameChangeValue) {
    const suppress = suppressedUsernameChangeValue === username;
    suppressedUsernameChangeValue = '';
    if (suppress) return;
  }
  if (initialUsernameSet) { initialUsernameSet = false; return; }
  if (loginFlowUsernameSet || isLoginInProgress) return;

  usernameChangeVersion += 1;
  try { usernameChangeAbortController?.abort(); } catch { }
  usernameChangeAbortController = new AbortController();

  if (!username) {
    await setLocal('username', '');
    setWelcomeMessage(null);
    renderLoginAccountHistorySelect('');
    lastValidUsername = '';
    pendingUsernameChange = null;
    resetAccountSwitchInterruption();
    isLoginSessionValid = false;
    updateJsessionidState();
    showToast('账号已清空：可直接填写 JSESSIONID', 'warning', 2500);
    await loadResourceSpaceForCurrentAccount();
    return;
  }

  if (username !== String(lastValidUsername || '').trim()) {
    pendingUsernameChange = lastValidUsername ? { from: lastValidUsername, to: username } : null;
    if (!accountSwitchInterruptionArmed) prioritizeAccountSwitch();
  }
  highPrioritySwitchTarget = '';
  await doLoginFlow();
});

if (accountHistorySelect instanceof HTMLSelectElement) {
  accountHistorySelect.addEventListener('change', () => {
    if (isSyncingAccountHistorySelect) return;
    adjustAccountHistorySelectWidth();
    const picked = String(accountHistorySelect.value || '').trim();
    if (!picked) return;
    const current = String(usernameInput.value || '').trim();
    if (picked === current) return;
    highPrioritySwitchTarget = picked;
    usernameInput.value = picked;
    usernameInput.dispatchEvent(new Event('change'));
  });
}

jsessionidInput.addEventListener('change', async () => {
  if (jsessionidInput.readOnly) return;
  const v = jsessionidInput.value.trim();
  if (!v) return;
  await setLocal('jsessionid', v);
  await reconcileJsessionidCookies(v);
  isLoginSessionValid = true;
  showToast('已保存 JSESSIONID，正在验证…', 'info', 1500);
  if (isPlatformEnabled('ve')) {
    await reloadVePlatformFromSession({ reloadCourses: true, reloadResourceSpace: true });
  } else {
    await loadResourceSpaceForCurrentAccount();
  }
});

// -------------------- Init --------------------
(async function init() {
  const autoUpdateParam = new URLSearchParams(location.search).get('autoUpdate');
  const autoUpdateMode = autoUpdateParam === '1' || autoUpdateParam === '2';
  await globalThis.BjtuModuleRegistry?.ready;
  await globalThis.__bjtuVeAppReady;
  await globalThis.__bjtuPlatformModulesReady;
  await globalThis.__bjtuOptionalPlatformAdaptersReady;
  setupRightColumnResizer();
  updateTotalProgress();
  updateResourceDownloadTotals();
  if (autoUpdateMode) {
    window.platformEnabled = Object.fromEntries(PLATFORM_IDS.map((id) => [id, false]));
  } else {
    await loadPlatformEnabledFromStorage();
    await loadPlatformVisibleFromStorage();
    await loadPlatformAutoLoginSettings();
  }
  await loadPlatformOrderFromStorage();
  window.BjtuMoocPlatform?.init({
    courseList: courseListDiv,
    escape: escapeHtml,
    toast: showToast,
    setState: (state) => setPlatformLoginState('mooc', state),
    setLoaded: (loaded) => { window.platformLoadedOnce.mooc = !!loaded; },
    setProgress: (completed, total) => setPlatformContentLoadProgress('mooc', completed, total),
    updateEmpty: updateCourseListEmptyPlaceholder,
    scheduleCache: () => scheduleFullscreenCourseCacheSave(200),
    normalizeHtml: normalizeHomeworkContent,
    renderExpandable: renderExpandableHtml,
    isDetailExpanded: isHomeworkDetailExpanded,
    applyExpandableAutoToggle,
    updateCountdowns: updateAllCountdowns,
    animateHomeworkGroupVisibility,
    sortCourseCards: () => sortCourseCardsWithGuard(),
    loginRequired: () => {
      if (window.platformInteractiveLoginPending.mooc || shouldAutoLoginAfterExpiry('mooc')) {
        openMoocLoginAssistPopup(true);
      }
    }
  });
  window.BjtuXuetangxPlatform?.init({
    courseList: courseListDiv,
    escape: escapeHtml,
    toast: showToast,
    setState: (state) => setPlatformLoginState('xuetangx', state),
    setLoaded: (loaded) => { window.platformLoadedOnce.xuetangx = !!loaded; },
    setProgress: (completed, total) => setPlatformContentLoadProgress('xuetangx', completed, total),
    updateEmpty: updateCourseListEmptyPlaceholder,
    scheduleCache: () => scheduleFullscreenCourseCacheSave(200),
    renderExpandable: renderExpandableHtml,
    isDetailExpanded: isHomeworkDetailExpanded,
    updateCountdowns: updateAllCountdowns,
    animateHomeworkGroupVisibility,
    sortCourseCards: () => sortCourseCardsWithGuard()
  });
  await loadCourseHelperLayoutSettings();
  await loadPopupCacheEnabledSetting();
  const showAutoLoadResourcesDisabledNotice = await migrateAutoLoadCourseResourcesDefaultOff();
  await loadAutoLoadCourseResourcesSetting();
  await loadPlatformDetailSettings();
  await loadSaveUploadsEnabledSetting();
  setupOptionsStorageLiveSync();
  document.documentElement.classList.remove('app-options-loading');
  if (showAutoLoadResourcesDisabledNotice) showAutoLoadCourseResourcesDisabledNotice();
  setupPortalUsernameBindMessageListener();
  if (!popupMode && !forceAccountPasswordMigration
    && await globalThis.BjtuAccountStore?.needsPasswordFieldMigration?.()) {
    const migrationUrl = new URL(location.href);
    migrationUrl.searchParams.set('accountInit', '2');
    location.replace(migrationUrl.href);
    return;
  }
  if (forceAccountPasswordMigration) {
    try {
      await globalThis.BjtuAccountLogin?.migratePasswords?.({ showProgress: true });
    } catch (error) {
      showToast('账号密码迁移失败：' + String(error?.message || error), 'error', 5000);
      return;
    }
  }
  const restoredPopupCache = await restorePopupFullscreenCacheIfNeeded();
  refreshPlatformLoginTip();

  if (restoredPopupCache) {
    await loadLoginAccountHistory();
    if (isPlatformEnabled('ve')) {
      const currentUser = await globalThis.BjtuAccountLogin?.getCurrentUserInfo?.().catch(() => null);
      if (currentUser) {
        await globalThis.BjtuAccountLogin?.ensureCurrentAccountStored?.(currentUser).catch(() => null);
      }
    }
    await loadSavedUploadsFromStorage();
    setupSavedUploadsUi();
    lastValidUsername = (await getLocal('username', '')).trim();
    usernameInput.value = lastValidUsername;
    renderLoginAccountHistorySelect(lastValidUsername);
    updateJsessionidState();
    setWelcomeMessage(null);
    refreshUploadSelectVisibility();
    bindCourseCardActionButtons(courseListDiv);
    // popup 缓存恢复分支会提前结束 init；这里必须解除启动期保护，
    // 否则用户第一次手动切换账号会被误判为程序赋值而被忽略。
    initialUsernameSet = false;
    return;
  }

  setupFullscreenCourseCacheObserver();

  await loadLoginAccountHistory();
  try {
    if (forceAccountListInitialization) {
      await globalThis.BjtuAccountLogin?.initialize?.({ force: true, showProgress: true });
    } else {
      await globalThis.BjtuAccountLogin?.ensureInitialized?.({ showProgress: true });
    }
  } catch (error) {
    showToast('账号列表初始化失败：' + String(error?.message || error), 'error', 4000);
  }

  // VE startup owns both course and resource-space loading so account synchronization
  // cannot invalidate an independent resource request and leave its loading UI stale.
  const startupPlatformLoadPromise = autoUpdateMode
    ? Promise.resolve(null)
    : triggerInitialPlatformLoads();

  await loadCurrentXqOptions().catch(() => { });

  // 本地保存已上传文件：加载并绑定 UI
  await loadSavedUploadsFromStorage();
  setupSavedUploadsUi();

  // 不默认使用本地保存账号。
  lastValidUsername = (await getLocal('username', '')).trim();
  let welcomeInfoUserId = '';
  let welcomeInfo = null;
  usernameInput.value = lastValidUsername;
  const settled = await Promise.allSettled([startupPlatformLoadPromise]);
  const startupAccountInfo = (settled[0] && settled[0].status === 'fulfilled') ? settled[0].value : null;
  if (startupAccountInfo?.info) {
    setWelcomeMessage(startupAccountInfo.info);
  } else {
    setWelcomeMessage(null);
  }
  renderLoginAccountHistorySelect(lastValidUsername);
  updateJsessionidState();
  scheduleFullscreenCourseCacheSave(1200);

  await syncJsessionidToUi();

  // Mark session as valid if we have a saved username; avoids unnecessary login prompts
  if (lastValidUsername) isLoginSessionValid = true;

  // 确保 init 完成后的首次账号切换不会被 initialUsernameSet 拦截
  initialUsernameSet = false;
})().catch((error) => {
  console.error('[bjtu] app initialization failed:', error);
  document.documentElement.classList.remove('app-options-loading');
  applyPlatformVisibility();
  updateCourseListEmptyPlaceholder();
});
