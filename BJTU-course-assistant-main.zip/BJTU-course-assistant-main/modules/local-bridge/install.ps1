param(
  [int]$Port = 1896,
  [switch]$SkipStart
)

$InstallerVersion = '1.0.2'
$ErrorActionPreference = 'Stop'
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw 'δ�ҵ� Node.js�����Ȱ�װ Node.js 20 ����߰汾��'
}

Set-Location -LiteralPath $bridgeRoot
npm ci --ignore-scripts
if ($LASTEXITCODE -ne 0) { throw '��װ Bridge ����ʧ��' }

$commandDirectory = Join-Path $env:LOCALAPPDATA 'BJTUCourseAssistant\bin'
New-Item -ItemType Directory -Path $commandDirectory -Force | Out-Null

$commandScriptPath = Join-Path $bridgeRoot 'command.ps1'
$escapedCommandScriptPath = $commandScriptPath.Replace("'", "''")
$launcherText = @"
param([Parameter(ValueFromRemainingArguments=`$true)][string[]]`$BridgeArguments)
`$BJTUCACommandVersion = '$InstallerVersion'
& '$escapedCommandScriptPath' @BridgeArguments
exit `$LASTEXITCODE
"@
foreach ($commandName in @('bjtuca-bridge', 'BJTUCA')) {
  $commandLauncherPath = Join-Path $commandDirectory ($commandName + '.ps1')
  $commandShimPath = Join-Path $commandDirectory ($commandName + '.cmd')
  [System.IO.File]::WriteAllText($commandLauncherPath, $launcherText, [System.Text.Encoding]::GetEncoding(936))
  [System.IO.File]::WriteAllText(
    $commandShimPath,
    "@echo off`r`nsetlocal`r`nset `"BJTUCA_COMMAND_NAME=%~n0`"`r`n(goto) 2>nul & powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0$commandName.ps1`" %*`r`n",
    [System.Text.Encoding]::ASCII
  )
}

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$pathEntries = @($userPath -split ';' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if (-not ($pathEntries | Where-Object { $_.TrimEnd('\') -ieq $commandDirectory.TrimEnd('\') })) {
  $nextUserPath = (@($pathEntries) + $commandDirectory) -join ';'
  [Environment]::SetEnvironmentVariable('Path', $nextUserPath, 'User')
}
if (-not (($env:Path -split ';') | Where-Object { $_.TrimEnd('\') -ieq $commandDirectory.TrimEnd('\') })) {
  $env:Path = "$env:Path;$commandDirectory"
}

Write-Host "Bridge �Ѱ�װ����ǰĿ¼��$bridgeRoot"
Write-Host '��ע�� bjtuca-bridge �� BJTUCA �����������Ŀ¼������'
if ($SkipStart) { return }
Write-Host 'Bridge �������У��� Ctrl+C ��ֹͣ��'
if ($Port -eq 1896) {
  npm start
} else {
  npm start -- --port=$Port
}
