param(
  [int]$Port = 1896,
  [switch]$SkipStart
)

$InstallerVersion = '1.0.10'
$ErrorActionPreference = 'Stop'
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw 'δ�ҵ� Node.js�����Ȱ�װ Node.js 20 ����߰汾��'
}

function Invoke-BridgeDependencyCommand {
  param([string]$Command, [string[]]$CommandArguments, [switch]$Quiet)
  # Windows PowerShell turns native stderr into ErrorRecord objects. Keep those
  # local to this call; dependency checks must be decided by the exit code.
  $ErrorActionPreference = 'Continue'
  $PSNativeCommandUseErrorActionPreference = $false
  $commandOutput = & $Command @CommandArguments 2>&1
  $commandExitCode = $LASTEXITCODE
  if (-not $Quiet) {
    foreach ($line in $commandOutput) { Write-Host $line.ToString() }
  }
  return $commandExitCode
}

Set-Location -LiteralPath $bridgeRoot
$dependencyCheckPath = Join-Path $bridgeRoot 'src\check-dependencies.js'
$dependenciesReady = (Invoke-BridgeDependencyCommand -Command npm -CommandArguments @('ls', '--omit=dev', '--all', '--silent') -Quiet) -eq 0
if ($dependenciesReady) {
  $dependenciesReady = (Invoke-BridgeDependencyCommand -Command node -CommandArguments @($dependencyCheckPath) -Quiet) -eq 0
}
if (-not $dependenciesReady) {
  if ((Invoke-BridgeDependencyCommand -Command npm -CommandArguments @('install', '--ignore-scripts', '--no-audit', '--no-fund')) -ne 0) {
    throw '��װ Bridge ����ʧ��'
  }
  if ((Invoke-BridgeDependencyCommand -Command node -CommandArguments @($dependencyCheckPath)) -ne 0) {
    throw 'Bridge ����У��ʧ�ܣ�δ�����������'
  }
}

$commandDirectory = [System.IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'BJTUCourseAssistant'))
$legacyCommandDirectory = Join-Path $commandDirectory 'bin'
New-Item -ItemType Directory -Path $commandDirectory -Force | Out-Null

$commandScriptPath = Join-Path $bridgeRoot 'command.ps1'
$escapedBridgeRoot = $bridgeRoot.Replace("'", "''")
$launcherText = [System.IO.File]::ReadAllText($commandScriptPath, [System.Text.Encoding]::GetEncoding(936))
$launcherText = $launcherText.Replace(
  '$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path',
  "`$BJTUCACommandVersion = '$InstallerVersion'`r`n`$bridgeRoot = '$escapedBridgeRoot'"
)
$launcherEncoding = [System.Text.UTF8Encoding]::new($true)
foreach ($commandName in @('bjtuca-bridge', 'BJTUCA')) {
  $commandLauncherPath = Join-Path $commandDirectory ($commandName + '.ps1')
  $commandShimPath = Join-Path $commandDirectory ($commandName + '.cmd')
  [System.IO.File]::WriteAllText($commandLauncherPath, $launcherText, $launcherEncoding)
  [System.IO.File]::WriteAllText(
    $commandShimPath,
    "@echo off`r`nset `"BJTUCA_COMMAND_NAME=%~n0`"`r`nset BJTUCA_RAW_ARGUMENTS=%*`r`n(goto) 2>nul & powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0$commandName.ps1`" %* & call set `"BJTUCA_COMMAND_EXIT=%%errorlevel%%`" & set `"BJTUCA_RAW_ARGUMENTS=`" & set `"BJTUCA_COMMAND_NAME=`" & call cmd.exe /d /c exit %%BJTUCA_COMMAND_EXIT%%`r`n",
    [System.Text.Encoding]::ASCII
  )
}

$protocolScriptPath = Join-Path $commandDirectory 'protocol.ps1'
$protocolText = [System.IO.File]::ReadAllText((Join-Path $bridgeRoot 'protocol.ps1'), [System.Text.Encoding]::GetEncoding(936))
$protocolText = $protocolText.Replace(
  '$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path',
  "`$bridgeRoot = '$escapedBridgeRoot'"
)
[System.IO.File]::WriteAllText($protocolScriptPath, $protocolText, $launcherEncoding)
$protocolKey = 'HKCU:\Software\Classes\bjtuca'
New-Item -Path $protocolKey -Force | Out-Null
Set-Item -LiteralPath $protocolKey -Value 'URL:BJTUCA Bridge Protocol'
New-ItemProperty -LiteralPath $protocolKey -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
$protocolCommandKey = Join-Path $protocolKey 'shell\open\command'
New-Item -Path $protocolCommandKey -Force | Out-Null
$powershellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
Set-Item -LiteralPath $protocolCommandKey -Value ('"' + $powershellPath + '" -NoProfile -ExecutionPolicy Bypass -File "' + $protocolScriptPath + '" "%1"')

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$pathEntries = @($userPath -split ';' | ForEach-Object { $_.Trim() } | Where-Object {
  $_ -and $_.TrimEnd('\') -ine $commandDirectory.TrimEnd('\') -and $_.TrimEnd('\') -ine $legacyCommandDirectory.TrimEnd('\')
})
$nextUserPath = (@($pathEntries) + $commandDirectory) -join ';'
if ($nextUserPath -cne $userPath) {
  [Environment]::SetEnvironmentVariable('Path', $nextUserPath, 'User')
}
$processPathEntries = @($env:Path -split ';' | Where-Object {
  $_.Trim() -and $_.Trim().TrimEnd('\') -ine $commandDirectory.TrimEnd('\') -and $_.Trim().TrimEnd('\') -ine $legacyCommandDirectory.TrimEnd('\')
})
$env:Path = (@($processPathEntries) + $commandDirectory) -join ';'
if (Test-Path -LiteralPath $legacyCommandDirectory -PathType Container) {
  if ([System.IO.Path]::GetFullPath((Split-Path -Parent $legacyCommandDirectory)) -ine $commandDirectory) {
    throw '������Ŀ¼У��ʧ��'
  }
  Remove-Item -LiteralPath $legacyCommandDirectory -Recurse -Force
}

Write-Host "Bridge �Ѱ�װ����ǰĿ¼��$bridgeRoot"
Write-Host '��ע�� bjtuca-bridge �� BJTUCA ��� bjtuca://start Э�飬��������Ŀ¼��������������'
if ($SkipStart) { return }
Write-Host 'Bridge �������У��� Ctrl+C ��ֹͣ��'
if ($Port -eq 1896) {
  npm --silent start
} else {
  npm --silent start -- --port=$Port
}
