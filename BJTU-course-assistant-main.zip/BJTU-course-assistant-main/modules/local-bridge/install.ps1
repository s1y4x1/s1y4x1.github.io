param(
  [int]$Port = 1896
)

$ErrorActionPreference = 'Stop'
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw 'δ�ҵ� Node.js�����Ȱ�װ Node.js 20 ����߰汾��'
}

Set-Location -LiteralPath $bridgeRoot
npm ci --ignore-scripts

$commandDirectory = Join-Path $env:LOCALAPPDATA 'BJTUCourseAssistant\bin'
$commandScriptPath = Join-Path $commandDirectory 'bjtuca-bridge.ps1'
$commandShimPath = Join-Path $commandDirectory 'bjtuca-bridge.cmd'
New-Item -ItemType Directory -Path $commandDirectory -Force | Out-Null

$escapedBridgeRoot = $bridgeRoot.Replace("'", "''")
$commandScript = @"
param([Parameter(ValueFromRemainingArguments=`$true)][string[]]`$BridgeArguments)
& npm --prefix '$escapedBridgeRoot' start -- @BridgeArguments
exit `$LASTEXITCODE
"@
$utf8WithBom = [System.Text.UTF8Encoding]::new($true)
[System.IO.File]::WriteAllText($commandScriptPath, $commandScript, $utf8WithBom)
[System.IO.File]::WriteAllText(
  $commandShimPath,
  "@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0bjtuca-bridge.ps1`" %*`r`n",
  [System.Text.Encoding]::ASCII
)

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$pathEntries = @($userPath -split ';' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if (-not ($pathEntries | Where-Object { $_.TrimEnd('\') -ieq $commandDirectory.TrimEnd('\') })) {
  $nextUserPath = (@($pathEntries) + $commandDirectory) -join ';'
  [Environment]::SetEnvironmentVariable('Path', $nextUserPath, 'User')
}
if (-not (($env:Path -split ';') | Where-Object { $_.TrimEnd('\') -ieq $commandDirectory.TrimEnd('\') })) {
  $env:Path = "$env:Path;$commandDirectory"
}

Write-Host "Bridge �Ѱ�װ����ǰĿ¼��$bridgeRoot"
Write-Host '��ע�� bjtuca-bridge �����������Ŀ¼������'
Write-Host 'Bridge �������У��� Ctrl+C ��ֹͣ��'
if ($Port -eq 1896) {
  npm start
} else {
  npm start -- --port=$Port
}
