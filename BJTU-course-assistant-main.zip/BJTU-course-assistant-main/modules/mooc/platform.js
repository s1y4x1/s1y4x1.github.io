const MOOC_LOGIN_ASSIST_URL = 'https://www.icourse163.org/passport/sns/doOAuth.htm?snsType=6&oauthType=login';
let moocLoginAssistPollTimer = null;
let moocLoginAssistChecking = false;
let moocLoginAssistPopupWindowId = null;
let moocLoginAssistPopupTabId = null;
let moocLoginAssistOpening = null;

(function () {
  'use strict';

  let env;
  let courses = [];
  let loadSerial = 0;
  let operationRunning = false;
  let currentOperationCancel = null;
  const expandedGroups = new Map();
  const taskDetailCache = new Map();
  const taskTypes = { video: '视频', document: '文档', discussion: '讨论', hw: '单元作业', quiz: '单元测试', exam: '考试' };
  const defaultVisibleTypes = ['hw', 'quiz', 'exam'];
  let visibleTypes = new Set(defaultVisibleTypes);
  const settingsReady = chrome.storage.local.get('moocActivityTypes').then(({ moocActivityTypes }) => {
    visibleTypes = new Set(Array.isArray(moocActivityTypes) ? moocActivityTypes : defaultVisibleTypes);
    render();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.moocActivityTypes) return;
    visibleTypes = new Set(Array.isArray(changes.moocActivityTypes.newValue) ? changes.moocActivityTypes.newValue : defaultVisibleTypes);
    render();
  });

  const request = async (action, payload = {}) => {
    const response = await chrome.runtime.sendMessage({ type: 'MOOC_REQUEST', action, payload });
    if (!response?.ok) {
      const error = new Error(response?.message || '中国大学MOOC请求失败');
      error.code = response?.code || '';
      throw error;
    }
    return response.data;
  };

  const checkLogin = async () => {
    const response = await chrome.runtime.sendMessage({ type: 'MOOC_LOGIN_STATUS' });
    if (!response?.ok || !response.loggedIn) {
      const error = new Error('未登录中国大学MOOC');
      error.code = 'not-logged-in';
      throw error;
    }
  };

  const formatTime = (value) => {
    const d = new Date(Number(value || 0));
    if (!Number(value) || Number.isNaN(d.getTime())) return '无期限';
    const pad = (v) => String(v).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const typeText = (type) => taskTypes[type];
  const isPaperTask = (task) => ['hw', 'quiz', 'exam'].includes(task.type);
  const actionKind = (type) => type === 'hw' ? 'submit' : (type === 'exam' ? 'exam' : 'quiz');
  const isLongTaskTitle = (value) => Array.from(String(value || '')).reduce(
    (length, character) => length + (/^[\x00-\xff]$/.test(character) ? 1 : 2),
    0
  ) >= 32;
  const GINS_TASK_GAP_MS = 450;
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function isRetryableDetailError(error) {
    const message = String(error?.message || error || '');
    if (/未登录|拒绝|HTTP\s*(?:401|403)|missing.?csrf/i.test(message) || ['not-logged-in', 'missing-csrf'].includes(error?.code)) return false;
    return error?.code === 'rate-limit'
      || /并发|频繁|稍后|繁忙|busy|limit|too many|HTTP\s*429/i.test(message);
  }

  async function requestPaperWithRetry(action, tid, emptyMessage) {
    let lastError = null;
    for (let attempt = 0; attempt < 10; attempt++) {
      try {
        const response = await request(action, { tid: Number(tid) });
        if (response?.result) return response.result;
        lastError = new Error(emptyMessage);
      } catch (error) {
        lastError = error;
        if (!isRetryableDetailError(error)) throw error;
      }
      if (attempt < 9) await sleep(Math.min(400 * (attempt + 1), 2000));
    }
    throw lastError || new Error(emptyMessage);
  }

  async function requestTeachersWithRetry(url) {
    let lastError = null;
    let lastEmptyResult = [];
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        const teachers = await request('course-page', { url });
        if (Array.isArray(teachers) && teachers.length) return teachers;
        lastEmptyResult = Array.isArray(teachers) ? teachers : [];
        lastError = new Error('课程教师解析为空');
      } catch (error) {
        lastError = error;
      }
      if (attempt < 4) await sleep(400 * (attempt + 1));
    }
    if (lastEmptyResult.length) return lastEmptyResult;
    throw lastError || new Error('课程教师获取失败');
  }

  function buildTask(test, type, chapterName) {
    const deadline = Number(test?.deadline || 0);
    const startTime = Number(test?.startTime ?? test?.start_time ?? test?.openTime ?? test?.open_time ?? test?.beginTime ?? 0) || 0;
    const done = test?.userScore !== null && test?.userScore !== undefined && String(test.userScore) !== '';
    const task = {
      id: String(test.id),
      type,
      title: String(test.name || typeText(type)),
      chapterName: String(chapterName || ''),
      deadline,
      startTime,
      userScore: done ? test.userScore : null,
      totalScore: test?.totalScore ?? null,
      done,
      overdue: !done && deadline > 0 && deadline < Date.now()
    };
    task.detail = taskDetailCache.get(`${type}:${task.id}`) || null;
    return task;
  }

  function normalizeTasks(term) {
    const tasks = [];
    for (const chapter of (term?.chapters || [])) {
      for (const item of (chapter?.homeworks || [])) if (item?.test?.id) tasks.push(buildTask(item.test, 'hw', chapter.name));
      for (const item of (chapter?.quizs || [])) if (item?.test?.id) tasks.push(buildTask(item.test, 'quiz', chapter.name));
      if (chapter?.exam?.objectTestVo?.id) tasks.push(buildTask(chapter.exam.objectTestVo, 'exam', chapter.name));
      for (const lesson of (chapter.lessons || [])) {
        for (const unit of (lesson.units || [])) {
          const type = { 1: 'video', 3: 'document', 6: 'discussion' }[unit.contentType];
          if (!type || !unit.id) continue;
          const task = buildTask(unit, type, chapter.name);
          task.contentType = Number(unit.contentType);
          task.contentId = unit.contentId;
          tasks.push(task);
        }
      }
    }
    return tasks;
  }

  function normalizeCourse(panel, term) {
    const id = String(panel?.id || term?.courseId || '');
    const tid = String(panel?.termPanel?.id || term?.id || '');
    const schoolShortName = String(panel?.schoolPanel?.shortName || 'COURSE');
    return {
      id,
      tid,
      name: String(panel?.name || term?.courseName || '中国大学MOOC课程'),
      schoolName: String(panel?.schoolPanel?.name || ''),
      schoolShortName,
      teachers: Array.isArray(panel?.teachers) ? panel.teachers : [],
      url: `https://www.icourse163.org/learn/${encodeURIComponent(schoolShortName)}-${encodeURIComponent(id)}?tid=${encodeURIComponent(tid)}`,
      tasks: normalizeTasks(term),
      detailLoaded: !!term,
      pendingTypeLabels: term ? [] : Object.values(taskTypes)
    };
  }

  function taskUrl(course, task) {
    if (!isPaperTask(task)) {
      const params = new URLSearchParams({ type: String(task.contentType), id: task.id });
      if (task.contentId != null) params.set('cid', String(task.contentId));
      return `${course.url}#/learn/content?${params}`;
    }
    const hash = task.type === 'hw' ? `#/learn/hw?id=${task.id}`
      : (task.type === 'exam' ? `#/learn/examObject?id=${task.id}` : `#/learn/quiz?id=${task.id}`);
    return course.url + hash;
  }

  function sanitizeDetailHtml(value) {
    return globalThis.BjtuHomeworkUi.sanitizeRichHtml(value);
  }

  function buildPaperDetail(paper, correctIds = new Set()) {
    const questions = [...(paper?.objectiveQList || []), ...(paper?.subjectiveQList || [])];
    return questions.map((question, index) => {
      const linesHtml = [];
      for (const option of (question?.optionDtos || [])) {
        const html = sanitizeDetailHtml(option?.name || option?.content || option?.optionContent || option?.id);
        if (html) linesHtml.push(`${correctIds.has(option?.id) ? '<span class="mooc-correct-mark">✓</span> ' : ''}${html}`);
      }
      for (const judge of (question?.judgeDtos || [])) {
        const html = sanitizeDetailHtml(judge?.msg || judge?.content || '');
        if (html) linesHtml.push(html);
      }
      return {
        titleHtml: sanitizeDetailHtml(question?.name || question?.title || question?.content) || `第${index + 1}题`,
        linesHtml
      };
    });
  }

  function renderTaskDetail(course, task, colors) {
    if (task.detailLoading) {
      return `<div class="mooc-task-detail" style="border-top-color:${colors[1]};"><span class="spinner mooc-inline-spinner" style="${globalThis.BjtuHomeworkUi.spinnerPhaseStyle()}"></span> ${globalThis.BjtuHomeworkUi.text.detailLoading}</div>`;
    }
    const questions = Array.isArray(task.detail?.questions) ? task.detail.questions : [];
    if (!questions.length) return '';
    const contentHtml = questions.map((question, index) => `
      <div class="mooc-question-detail">
        <div class="mooc-question-title"><span class="mooc-question-number">第${index + 1}题 ·</span><div class="mooc-question-content">${question.titleHtml || env.escape(question.title || '')}</div></div>
        ${(question.linesHtml?.length || question.lines?.length) ? `<div class="mooc-question-lines">${(question.linesHtml || question.lines || []).map((line) => renderQuestionLine(line, !!question.linesHtml)).join('')}</div>` : ''}
      </div>`).join('');
    const courseId = `mooc-${course.id}`;
    const expandKey = `mooc-detail:${task.type}:${task.id}`;
    const expandable = env.renderExpandable
      ? env.renderExpandable(contentHtml, globalThis.BjtuHomeworkUi.detailOptions({
          hideWhenEmpty: true,
          baseBg: 'rgba(255,255,255,.28)',
          flatDisplay: true,
          courseId,
          expandKey,
          expanded: !!env.isDetailExpanded?.(courseId, expandKey)
        }))
      : contentHtml;
    return `<div class="mooc-task-detail" style="border-top-color:${colors[1]};">${expandable}</div>`;
  }

  function renderQuestionLine(line, isHtml) {
    const html = isHtml ? String(line) : env.escape(line);
    const mark = '<span class="mooc-correct-mark">✓</span>';
    const correct = isHtml && html.startsWith(mark);
    const content = correct ? html.slice(mark.length).trimStart() : html;
    return `<div class="mooc-question-option"><span class="mooc-option-marker">${correct ? mark : ''}</span><div class="mooc-question-content">${content}</div></div>`;
  }

  function renderTeachers(course) {
    const teachers = Array.isArray(course.teachers) ? course.teachers : [];
    if (!teachers.length) return env.escape(course.schoolName || course.schoolShortName);
    return teachers.map((teacher) => {
      const href = String(teacher?.href || '').trim();
      let url = '';
      try { url = href ? new URL(href, 'https://www.icourse163.org/').href : ''; } catch { url = ''; }
      return url
        ? `<a class="mooc-teacher-link" href="${env.escape(url)}" target="_blank" rel="noopener noreferrer">${env.escape(teacher.name)}</a>`
        : env.escape(teacher.name);
    }).join(' / ');
  }

  function clearCards() {
    env?.courseList?.querySelectorAll('.mooc-standalone-card').forEach((node) => node.remove());
    env?.updateEmpty?.();
  }

  function renderTask(course, task) {
    const palette = globalThis.BjtuHomeworkUi.homeworkPalette({ done: task.done, overdue: task.overdue });
    const colors = [palette.background, palette.border, palette.foreground];
    const score = globalThis.BjtuHomeworkUi.scoreBadgeHtml({ userScore: task.userScore, totalScore: task.totalScore, escape: env.escape });
    const goActionText = isPaperTask(task) ? globalThis.BjtuHomeworkUi.actionLabel('mooc', actionKind(task.type), { lead: '前往' }) : `查看${typeText(task.type)}`;
    return globalThis.BjtuHomeworkUi.renderHomeworkCard({
      done: task.done,
      overdue: task.overdue,
      deadline: task.deadline,
      className: `mooc-task${isLongTaskTitle(task.title) ? ' mooc-task--long-title' : ''}`,
      background: palette.background,
      border: palette.border,
      headClass: 'mooc-task-head',
      headStyle: '',
      mainClass: 'mooc-task-main',
      actionsClass: 'mooc-task-actions',
      titleHtml: globalThis.BjtuHomeworkUi.titleHtml({ typeLabel: typeText(task.type), typeHref: taskUrl(course, task), title: task.title, color: palette.foreground, href: taskUrl(course, task), escape: env.escape, className: 'mooc-task-title' }),
      metaHtml: `<div class="mooc-task-meta">${globalThis.BjtuHomeworkUi.deadlineMetaHtml({ deadline: task.deadline, formatted: formatTime(task.deadline), startTime: task.startTime, startFormatted: formatTime(task.startTime), done: task.done, overdue: task.overdue, escape: env.escape })}${task.chapterName ? `<div>${env.escape(task.chapterName)}</div>` : ''}${task.type === 'hw' && task.detail?.tname ? `<div>${env.escape(task.detail.tname)}</div>` : ''}${task.type === 'quiz' && task.detail?.description ? `<div>${sanitizeDetailHtml(task.detail.description)}</div>` : ''}</div>`,
      scoreHtml: score,
      actionsHtml: `<div class="mooc-task-button-row">
          <a class="btn mooc-go-btn" style="background:${colors[2]};" href="${env.escape(taskUrl(course, task))}" target="_blank" rel="noopener noreferrer">${env.escape(goActionText)}</a>
          ${isPaperTask(task) ? `<button class="btn mooc-gins-btn" style="background:${colors[2]};" data-mooc-action="task" data-course-id="${env.escape(course.id)}" data-task-id="${env.escape(task.id)}">通过GinsMooc完成</button>` : ''}
        </div>`,
      detailHtml: renderTaskDetail(course, task, colors)
    });
  }

  function renderToggle(courseId, kind, expanded, count, collapsedText, expandedText) {
    const direction = expanded ? 'up' : 'down';
    const label = `${expanded ? expandedText : collapsedText} (${count})`;
    return `<div class="homework-toggle-row homework-toggle-row--${kind}">
      <button class="btn homework-toggle-btn ${expanded ? 'is-expanded' : ''} homework-toggle-btn--${direction}" data-mooc-action="toggle-${kind}" data-course-id="${env.escape(courseId)}" data-count="${env.escape(String(count))}" data-collapsed-text="${env.escape(collapsedText)}" data-expanded-text="${env.escape(expandedText)}" aria-expanded="${expanded ? 'true' : 'false'}">
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
        <span class="homework-toggle-label">${env.escape(label)}</span>
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
      </button>
    </div>`;
  }

  function render() {
    if (!env?.courseList) return;
    clearCards();
    const baseOrder = Number(env.courseList.dataset.orderBase || 100000) + 120000;
    courses.forEach((course, index) => {
      for (const task of course.tasks) {
        if (!task.done && Number(task.deadline) > 0 && Number(task.deadline) <= Date.now()) task.overdue = true;
      }
      const visibleTasks = course.tasks.filter((task) => visibleTypes.has(task.type));
      const pending = visibleTasks.filter((task) => !task.done && !task.overdue)
        .map((task, taskIndex) => ({ task, taskIndex }))
        .sort((a, b) => (Number(a.task.deadline) > 0 ? Number(a.task.deadline) : Number.MAX_SAFE_INTEGER) - (Number(b.task.deadline) > 0 ? Number(b.task.deadline) : Number.MAX_SAFE_INTEGER) || a.taskIndex - b.taskIndex)
        .map(({ task }) => task);
      const overdue = visibleTasks.filter((task) => task.overdue);
      const done = visibleTasks.filter((task) => task.done);
      const expanded = expandedGroups.get(course.id) || { overdue: false, done: false };
      const pendingHtml = pending.map((task) => renderTask(course, task)).join('');
      const overdueHtml = overdue.map((task) => renderTask(course, task)).join('');
      const doneHtml = done.map((task) => renderTask(course, task)).join('');
      const taskSections = `${pendingHtml}
        ${overdue.length ? renderToggle(course.id, 'overdue', expanded.overdue, overdue.length, '查看逾期作业', '收起逾期作业') : ''}
        ${overdue.length ? `<div class="homework-group homework-group--overdue ${expanded.overdue ? '' : 'is-hidden'}" data-homework-group="overdue" aria-hidden="${expanded.overdue ? 'false' : 'true'}">${overdueHtml}</div>` : ''}
        ${done.length ? renderToggle(course.id, 'done', expanded.done, done.length, '查看已交作业', '收起已交作业') : ''}
        ${done.length ? `<div class="homework-group homework-group--done ${expanded.done ? '' : 'is-hidden'}" data-homework-group="done" aria-hidden="${expanded.done ? 'false' : 'true'}">${doneHtml}</div>` : ''}`;
      const typeLoadingHtml = globalThis.BjtuHomeworkUi.typeLoadingHtml(course.pendingTypeLabels.filter((label) => [...visibleTypes].some((type) => typeText(type) === label)), { escape: env.escape });
      const card = globalThis.BjtuCourseCardUi.createCourseCard({
        courseId: `mooc-${course.id}`,
        className: 'mooc-standalone-card',
        order: baseOrder + index,
        rank: pending.length ? 0 : (overdue.length ? 2 : (done.length ? 4 : 7)),
        titleHtml: `<a href="${env.escape(course.url)}" target="_blank" rel="noopener noreferrer">${env.escape(course.name)}</a>`,
        metaHtml: `<div class="mooc-course-meta">${renderTeachers(course)}</div>`,
        actionsHtml: `<button class="btn mooc-complete-all-btn" data-mooc-action="course" data-course-id="${env.escape(course.id)}">通过GinsMooc完成全部</button>`,
        contentHtml: `${typeLoadingHtml}${course.detailLoaded ? (taskSections.trim() || '<span class="mooc-empty">没有所选类型的作业或课件</span>') : ''}`,
        headerClass: 'mooc-course-head',
        identityClass: 'mooc-course-identity',
        homeworkClass: 'homework-area mooc-homework-area',
        includeResultArea: false,
        wrapActions: false,
        headerStyle: '',
        homeworkStyle: ''
      });
      env.courseList.appendChild(card);
    });
    env.updateEmpty?.();
    env.sortCourseCards?.();
    env.scheduleCache?.();
    setTimeout(() => {
      env.applyExpandableAutoToggle?.(env.courseList);
      env.updateCountdowns?.();
    }, 0);
  }

  async function loadHomeworkDetail(task) {
    task.detailLoading = true;
    render();
    try {
      const paper = await requestPaperWithRetry('homework-paper', task.id, '作业详情为空（可能受到并发限制）');
      task.detail = { questions: buildPaperDetail(paper), tname: String(paper.tname || '') };
      taskDetailCache.set(`${task.type}:${task.id}`, task.detail);
      return paper;
    } finally {
      task.detailLoading = false;
      render();
    }
  }

  async function loadObjectiveDetail(task) {
    task.detailLoading = true;
    render();
    try {
      const [answers, paper] = await Promise.all([
        request('gins-answer', { tid: task.id }).catch(() => ({ data: { questionList: [] } })),
        requestPaperWithRetry('quiz-paper', task.id, '试卷数据为空（可能受到并发限制）')
      ]);
      const correctIds = new Set();
      for (const question of (answers?.data?.questionList || [])) {
        for (const option of (question.optionList || [])) if (option.answer) correctIds.add(option.id);
      }
      task.detail = { description: task.detail?.description || '', questions: buildPaperDetail(paper, correctIds) };
      taskDetailCache.set(`${task.type}:${task.id}`, task.detail);
      return { paper, correctIds };
    } finally {
      task.detailLoading = false;
      render();
    }
  }

  async function loadQuizInfo(task) {
    const info = await requestPaperWithRetry('quiz-info', task.id, '单元测试信息为空');
    task.detail = { ...task.detail, description: String(info.description || '') };
    taskDetailCache.set(`${task.type}:${task.id}`, task.detail);
    render();
  }

  async function hydrateTaskMetadata(course, onTaskLoaded = () => {}) {
    const tasks = course.tasks.filter((task) => task.type === 'hw' || task.type === 'quiz');
    let next = 0;
    const failures = [];
    const workers = Array.from({ length: Math.min(3, tasks.length) }, async () => {
      while (next < tasks.length) {
        const task = tasks[next++];
        try {
          if (task.type === 'hw') await loadHomeworkDetail(task);
          else await loadQuizInfo(task);
        } catch (error) { failures.push(error); }
        finally { onTaskLoaded(task); }
      }
    });
    await Promise.all(workers);
    if (failures.length) throw failures[0];
  }

  async function load() {
    await settingsReady;
    const serial = ++loadSerial;
    env.setState('checking');
    env.setProgress?.(0, 0);
    clearCards();
    try {
      await checkLogin();
      const panels = await request('course-list');
      if (serial !== loadSerial) return;
      courses = (Array.isArray(panels) ? panels : []).map((panel) => normalizeCourse(panel, null));
      render();
      env.setLoaded(true);
      env.setState('online');
      const progressTypes = [...visibleTypes];
      const progressByCourse = courses.map(() => null);
      const updateProgress = () => {
        if (serial !== loadSerial) return;
        const completed = progressByCourse.reduce((sum, states) => {
          if (!states) return sum;
          if (!progressTypes.length) return sum + 1;
          return sum + progressTypes.reduce((typeSum, type) => {
            const state = states.get(type);
            return typeSum + (state.total ? state.completed / state.total : 1);
          }, 0) / progressTypes.length;
        }, 0);
        env.setProgress?.(completed, courses.length);
      };
      env.setProgress?.(0, courses.length);
      let next = 0;
      const workers = Array.from({ length: Math.min(4, courses.length) }, async () => {
        while (next < courses.length && serial === loadSerial) {
          const index = next++;
          const old = courses[index];
          try {
            const [detailResult, teacherResult] = await Promise.allSettled([
              request('course-detail', { tid: Number(old.tid) }),
              requestTeachersWithRetry(old.url)
            ]);
            if (serial !== loadSerial) return;
            if (detailResult.status === 'rejected') throw detailResult.reason;
            const response = detailResult.value;
            const term = response?.result?.mocTermDto || response?.mocTermDto;
            courses[index] = normalizeCourse({
              id: old.id, name: old.name, termPanel: { id: old.tid },
              schoolPanel: { name: old.schoolName, shortName: old.schoolShortName },
              teachers: teacherResult.status === 'fulfilled' ? teacherResult.value : []
            }, term);
            const states = new Map(progressTypes.map((type) => {
              const total = courses[index].tasks.filter((task) => task.type === type).length;
              return [type, { total, completed: type === 'hw' || type === 'quiz' ? 0 : total }];
            }));
            progressByCourse[index] = states;
            updateProgress();
            render();
            await hydrateTaskMetadata(courses[index], (task) => {
              const state = states.get(task.type);
              if (state) state.completed += 1;
              updateProgress();
            });
          } catch (error) {
            if (serial !== loadSerial) return;
            if (error?.code === 'not-logged-in') throw error;
            courses[index].detailLoaded = true;
            courses[index].pendingTypeLabels = [];
          } finally {
            if (serial === loadSerial) {
              progressByCourse[index] = new Map(progressTypes.map((type) => [type, { total: 0, completed: 0 }]));
              updateProgress();
            }
          }
          if (serial === loadSerial) render();
        }
      });
      await Promise.all(workers);
      if (serial !== loadSerial) return;
      env.setLoaded(true);
      env.setState('online');
      env.setProgress?.(courses.length, courses.length);
      render();
    } catch (error) {
      if (serial !== loadSerial) return;
      courses = [];
      clearCards();
      env.setLoaded(false);
      if (error?.code === 'not-logged-in') {
        env.loginRequired?.();
        env.setState(window.platformInteractiveLoginPending?.mooc ? 'checking' : 'offline');
      } else if (error?.code === 'missing-csrf') {
        // 登录成功后两个 Cookie 的写入存在短暂先后顺序；这是可恢复状态，
        // 保持加载中并静默重试，不能向用户报告一次伪失败。
        env.setState('checking');
        if (isPlatformEnabled('mooc')) {
          setTimeout(() => {
            if (isPlatformEnabled('mooc') && serial === loadSerial) void load();
          }, 400);
        }
      } else {
        env.setLoaded(false);
        env.setState('checking');
        env.toast(`中国大学MOOC加载失败：${error?.message || error}`, 'error');
        if (isPlatformEnabled('mooc')) {
          setTimeout(() => {
            if (isPlatformEnabled('mooc') && serial === loadSerial) void load();
          }, 1200);
        }
      }
    }
  }

  function ensureModal() {
    let mask = document.getElementById('mooc-progress-modal');
    if (mask) return mask;
    mask = document.createElement('div');
    mask.id = 'mooc-progress-modal';
    mask.className = 'version-modal-mask mooc-progress-mask';
    mask.innerHTML = `<div class="version-modal-card mooc-progress-card">
      <div class="version-modal-header"><div class="mooc-progress-title"><a href="https://github.com/ginnnnnncc/GinsMooc" target="_blank" rel="noopener noreferrer">GinsMooc</a></div><button class="btn version-close-btn" data-mooc-close title="关闭" aria-label="关闭">×</button></div>
      <div class="mooc-progress-summary">正在准备…</div>
      <div class="progress-bar-container"><div class="progress-bar mooc-progress-bar"></div></div>
      <div class="mooc-progress-log"></div></div>`;
    document.body.appendChild(mask);
    mask.addEventListener('click', (event) => {
      const closeButton = event.target instanceof Element ? event.target.closest('[data-mooc-close]') : null;
      if (operationRunning && closeButton) {
        event.preventDefault();
        currentOperationCancel?.();
        mask.classList.remove('show');
        return;
      }
      if (!operationRunning && (event.target === mask || closeButton)) mask.classList.remove('show');
    });
    return mask;
  }

  function progress(mask, completed, total, text, type = '') {
    mask.querySelector('.mooc-progress-summary').textContent = text;
    mask.querySelector('.mooc-progress-bar').style.width = `${total ? Math.round(completed * 100 / total) : 0}%`;
    const line = document.createElement('div');
    line.className = `mooc-progress-line ${type}`;
    line.textContent = text;
    const log = mask.querySelector('.mooc-progress-log');
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;
  }

  async function completeTask(task) {
    const completed = await request('complete-task', { taskType: task.type, tid: task.id });
    const correctIds = new Set(Array.isArray(completed?.correctIds) ? completed.correctIds : []);
    task.detail = { description: task.detail?.description || '', questions: buildPaperDetail(completed?.paper || {}, correctIds) };
    if (task.type === 'hw') task.detail.tname = String(completed?.paper?.tname || '');
    taskDetailCache.set(`${task.type}:${task.id}`, task.detail);
    render();
    return completed?.response;
  }

  function isTaskSubmittable(task) {
    if (!isPaperTask(task) || !visibleTypes.has(task.type)) return false;
    if (task.overdue) return false;
    if (task.type === 'hw') return true;
    if (task.userScore === null || task.totalScore === null) return true;
    return Number(task.userScore) < Number(task.totalScore);
  }

  async function runTasks(tasks, inspectUnavailable = false) {
    if (operationRunning) return;
    operationRunning = true;
    const operationToken = { cancelled: false, cancelLogged: false };
    const throwIfCancelled = () => {
      if (operationToken.cancelled) throw Object.assign(new Error('操作已取消'), { code: 'cancelled' });
    };
    const mask = ensureModal();
    const close = mask.querySelector('[data-mooc-close]');
    mask.querySelector('.mooc-progress-log').innerHTML = '';
    mask.querySelector('.mooc-progress-bar').style.width = '0%';
    mask.querySelector('.mooc-progress-summary').textContent = '正在准备…';
    mask.classList.add('show');
    close.disabled = false;
    const candidates = inspectUnavailable ? tasks : tasks.filter(isTaskSubmittable);
    let succeeded = 0;
    let inspected = 0;
    currentOperationCancel = () => {
      if (operationToken.cancelled) return;
      operationToken.cancelled = true;
      if (!operationToken.cancelLogged) {
        operationToken.cancelLogged = true;
        progress(mask, 0, 1, '正在取消操作…', 'error');
      }
    };
    try {
      throwIfCancelled();
      if (!candidates.length) throw new Error('没有待完成的任务（均已完成或已截止）');
      for (let i = 0; i < candidates.length; i++) {
        throwIfCancelled();
        const task = candidates[i];
        progress(mask, i, candidates.length, `正在处理：${task.title}`);
        try {
          if (!isTaskSubmittable(task)) {
            if (task.type !== 'hw') await loadObjectiveDetail(task);
            throwIfCancelled();
            inspected++;
            progress(mask, i + 1, candidates.length, `已加载详情：${task.title}（当前不可提交）`, 'success');
            continue;
          }
          await completeTask(task);
          throwIfCancelled();
          succeeded++;
          progress(mask, i + 1, candidates.length, `已完成：${task.title}`, 'success');
          if (i < candidates.length - 1) {
            await sleep(GINS_TASK_GAP_MS);
            throwIfCancelled();
          }
        } catch (error) {
          if (error?.code === 'cancelled') throw error;
          if (error?.code === 'gins-system-error') throw error;
          progress(mask, i + 1, candidates.length, `失败：${task.title}（${error?.message || error}）`, 'error');
        }
      }
      const handled = succeeded + inspected;
      const summary = inspected
        ? `处理完成：提交 ${succeeded} 项，查看详情 ${inspected} 项`
        : `处理完成：成功 ${succeeded}/${candidates.length}`;
      progress(mask, candidates.length, candidates.length, summary, handled === candidates.length ? 'success' : 'error');
    } catch (error) {
      if (error?.code !== 'cancelled') progress(mask, 0, 1, error?.message || String(error), 'error');
    } finally {
      operationRunning = false;
      if (currentOperationCancel && operationToken.cancelled) currentOperationCancel = null;
      else if (currentOperationCancel) currentOperationCancel = null;
      close.disabled = false;
      if (!operationToken.cancelled && succeeded > 0) {
        await load().catch(() => {});
      }
    }
  }

  function handleClick(event) {
    const button = event.target instanceof Element ? event.target.closest('[data-mooc-action]') : null;
    if (!(button instanceof HTMLElement)) return;
    event.preventDefault();
    event.stopPropagation();
    const course = courses.find((item) => item.id === String(button.dataset.courseId || ''));
    if (!course) return;
    if (button.dataset.moocAction === 'toggle-overdue' || button.dataset.moocAction === 'toggle-done') {
      const kind = button.dataset.moocAction === 'toggle-overdue' ? 'overdue' : 'done';
      const state = expandedGroups.get(course.id) || { overdue: false, done: false };
      const expanded = !state[kind];
      expandedGroups.set(course.id, { ...state, [kind]: expanded });

      const card = button.closest('.mooc-standalone-card');
      const group = card?.querySelector(`.homework-group[data-homework-group="${kind}"]`);
      if (!(group instanceof HTMLElement) || typeof env.animateHomeworkGroupVisibility !== 'function') {
        render();
        return;
      }

      const count = String(button.dataset.count || '').trim();
      const text = expanded ? button.dataset.expandedText : button.dataset.collapsedText;
      const label = button.querySelector('.homework-toggle-label');
      if (label) label.textContent = `${text || ''}${count ? ` (${count})` : ''}`;
      button.classList.toggle('is-expanded', expanded);
      button.classList.remove('homework-toggle-btn--up', 'homework-toggle-btn--down');
      button.classList.add(expanded ? 'homework-toggle-btn--up' : 'homework-toggle-btn--down');
      button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      group.dataset.expanded = expanded ? '1' : '0';
      group.setAttribute('aria-hidden', expanded ? 'false' : 'true');
      void Promise.resolve(env.animateHomeworkGroupVisibility(group, expanded)).then((completed) => {
        if (completed && expanded) {
          env.applyExpandableAutoToggle?.(card);
          env.updateCountdowns?.();
        }
      });
      return;
    }
    if (button.dataset.moocAction === 'course') runTasks(course.tasks);
    else {
      const task = course.tasks.find((item) => item.id === String(button.dataset.taskId || ''));
      if (task) runTasks([task], true);
    }
  }

  function assertCachedPlatformReady() {
    if (!isPlatformEnabled('mooc')) {
      throw Object.assign(new Error('中国大学MOOC未启用，请先调用 mooc.login()'), { code: 'LOGIN_REQUIRED' });
    }
    if (String(window.platformLoginState?.mooc || '') !== 'online') {
      throw Object.assign(new Error('中国大学MOOC未登录，请先调用 mooc.login()'), { code: 'LOGIN_REQUIRED' });
    }
  }

  function cachedCourse(course) {
    return {
      id: String(course?.id || ''),
      name: String(course?.name || ''),
      schoolName: String(course?.schoolName || ''),
      url: String(course?.url || ''),
      taskCount: Array.isArray(course?.tasks) ? course.tasks.length : 0,
      loaded: course?.detailLoaded === true
    };
  }

  function cachedTeachers(course) {
    return (Array.isArray(course?.teachers) ? course.teachers : []).map((teacher) => ({
        name: String(typeof teacher === 'string' ? teacher : (teacher?.name || '')).trim(),
        url: (() => {
          try { return typeof teacher !== 'string' && teacher?.href ? new URL(String(teacher.href), 'https://www.icourse163.org/').href : ''; } catch { return ''; }
        })()
      })).filter((teacher) => teacher.name);
  }

  function cachedAssignment(course, task) {
    return {
      id: String(task?.id || ''),
      title: String(task?.title || ''),
      type: typeText(task?.type),
      chapterName: String(task?.chapterName || ''),
      startTime: Number(task?.startTime || 0),
      deadline: Number(task?.deadline || 0),
      status: task?.done ? 'submitted' : (task?.overdue ? 'overdue' : 'pending'),
      userScore: task?.userScore ?? null,
      totalScore: task?.totalScore ?? null,
      details: task?.detail || null,
      actionUrl: taskUrl(course, task) || ''
    };
  }

  function findCachedCourse(courseId) {
    const key = String(courseId || '').trim();
    if (!key) throw new Error('缺少参数 courseId，请先调用 mooc.courseList 获取课程ID');
    const course = courses.find((item) => String(item?.id || '') === key) || null;
    if (!course) throw new Error(`课程ID无效：${key} 不在中国大学MOOC缓存课程列表中，请先调用 mooc.courseList 获取有效ID`);
    return course;
  }

  function cachedAssignments(args = {}, requestedCourseId = '') {
    assertCachedPlatformReady();
    const statusFilter = String(args?.status || 'all').trim().toLowerCase();
    const typeFilter = String(args?.type || 'all').trim();
    const sourceCourses = requestedCourseId ? [findCachedCourse(requestedCourseId)] : courses.slice(0, 60);
    const items = [];
    for (const course of sourceCourses) {
      for (const task of (Array.isArray(course?.tasks) ? course.tasks : [])) {
        const item = cachedAssignment(course, task);
        if (typeFilter !== 'all' && item.type !== typeFilter) continue;
        if (statusFilter !== 'all' && item.status !== statusFilter) continue;
        items.push(requestedCourseId ? item : {
          key: `mooc:${course.id}:${task.id}`,
          courseName: String(course.name || ''),
          ...item
        });
      }
    }
    return requestedCourseId ? items : { total: items.length, items: items.slice(0, 300) };
  }

  window.BjtuMoocPlatform = {
    init(options) {
      env = options;
      env.courseList?.addEventListener('click', handleClick);
    },
    load,
    clear() {
      loadSerial++;
      courses = [];
      clearCards();
      env.setProgress?.(0, 0);
    },
    render,
    getCourses: () => courses,
    courseList() {
      assertCachedPlatformReady();
      return courses.map(cachedCourse);
    },
    assignmentsOf(args = {}) {
      return cachedAssignments(args, String(args?.courseId || ''));
    },
    teachersOf(args = {}) {
      assertCachedPlatformReady();
      return cachedTeachers(findCachedCourse(args?.courseId));
    },
    restore(value) {
      courses = Array.isArray(value) ? value : [];
      courses.forEach((course) => (course.tasks || []).forEach((task) => {
        if (task?.detail && task?.id) taskDetailCache.set(`${task.type}:${task.id}`, task.detail);
      }));
    },
    assignments: (args = {}) => cachedAssignments(args)
  };
})();


// Login assistance UI used by app.html.
function stopMoocLoginAssistWatcher() {
  if (moocLoginAssistPollTimer) {
    clearInterval(moocLoginAssistPollTimer);
    moocLoginAssistPollTimer = null;
  }
  moocLoginAssistChecking = false;
}

function closeMoocLoginAssistPopup(cancelPending = false) {
  if (moocLoginAssistPopupWindowId) {
    chrome.windows.remove(Number(moocLoginAssistPopupWindowId)).catch(() => {});
  }
  moocLoginAssistPopupWindowId = null;
  moocLoginAssistPopupTabId = null;
  stopMoocLoginAssistWatcher();
  if (cancelPending) window.platformInteractiveLoginPending.mooc = false;
}

function failMoocLoginAssistAfterUserClose({ windowId = null, tabId = null } = {}) {
  const matchesWindow = windowId != null && Number(windowId) === Number(moocLoginAssistPopupWindowId);
  const matchesTab = tabId != null && Number(tabId) === Number(moocLoginAssistPopupTabId);
  if (!matchesWindow && !matchesTab) return;
  moocLoginAssistPopupWindowId = null;
  moocLoginAssistPopupTabId = null;
  stopMoocLoginAssistWatcher();
  if (!window.platformInteractiveLoginPending?.mooc) return;
  window.platformInteractiveLoginPending.mooc = false;
  setPlatformLoginState('mooc', 'offline');
}

chrome.windows.onRemoved.addListener((windowId) => failMoocLoginAssistAfterUserClose({ windowId }));
chrome.tabs.onRemoved.addListener((tabId) => failMoocLoginAssistAfterUserClose({ tabId }));

async function checkMoocLoginAssistStatus() {
  if (moocLoginAssistChecking || !window.platformInteractiveLoginPending?.mooc) return false;
  moocLoginAssistChecking = true;
  try {
    if (moocLoginAssistPopupTabId) {
      const tab = await chrome.tabs.get(Number(moocLoginAssistPopupTabId)).catch(() => null);
      if (!tab) {
        failMoocLoginAssistAfterUserClose({ tabId: moocLoginAssistPopupTabId });
        return false;
      }
      if (!String(tab?.url || '').startsWith('https://www.icourse163.org/')) return false;
    }
    const response = await chrome.runtime.sendMessage({ type: 'MOOC_LOGIN_STATUS' });
    if (!response?.ok || !response.loggedIn) return false;
    stopMoocLoginAssistWatcher();
    completeExternalLoginAssist('mooc', true);
    return true;
  } catch {
    return false;
  } finally {
    moocLoginAssistChecking = false;
  }
}

function startMoocLoginAssistWatcher() {
  stopMoocLoginAssistWatcher();
  moocLoginAssistPollTimer = setInterval(() => void checkMoocLoginAssistStatus(), PLATFORM_LOGIN_ASSIST_POLL_INTERVAL_MS);
  void checkMoocLoginAssistStatus();
}

function openMoocLoginAssistPopup(force = false) {
  if (!force && !isPlatformEnabled('mooc')) return;
  window.platformInteractiveLoginPending.mooc = true;
  if (moocLoginAssistPopupWindowId && moocLoginAssistPopupTabId) {
    chrome.windows.update(Number(moocLoginAssistPopupWindowId), { focused: true }).catch(() => {});
    startMoocLoginAssistWatcher();
    return;
  }
  if (moocLoginAssistOpening) return moocLoginAssistOpening;
  const openPopup = async () => {
    const popupWidth = PLATFORM_LOGIN_ASSIST_POPUP_SIZE.width;
    const popupHeight = PLATFORM_LOGIN_ASSIST_POPUP_SIZE.height;
    let left;
    let top;
    try {
      const currentWin = await chrome.windows.getCurrent();
      if ([currentWin?.left, currentWin?.top, currentWin?.width, currentWin?.height].every((value) => Number.isFinite(Number(value)))) {
        left = Math.max(0, Number(currentWin.left) + Math.round((Number(currentWin.width) - popupWidth) / 2));
        top = Math.max(0, Number(currentWin.top) + Math.round((Number(currentWin.height) - popupHeight) / 2));
      }
    } catch {
      left = undefined;
      top = undefined;
    }
    const created = await chrome.windows.create({
      url: MOOC_LOGIN_ASSIST_URL,
      type: 'popup',
      focused: true,
      width: popupWidth,
      height: popupHeight,
      left,
      top
    });
    moocLoginAssistPopupWindowId = Number(created?.id || 0) || null;
    const tab = Array.isArray(created?.tabs) && created.tabs.length ? created.tabs[0] : null;
    moocLoginAssistPopupTabId = Number(tab?.id || 0) || null;
    startMoocLoginAssistWatcher();
  };
  const opening = openPopup().catch(() => {
    window.platformInteractiveLoginPending.mooc = false;
    setPlatformLoginState('mooc', 'offline');
    showToast('打开中国大学MOOC登录弹窗失败，请检查浏览器弹窗权限', 'error', 2200);
  }).finally(() => {
    if (moocLoginAssistOpening === opening) moocLoginAssistOpening = null;
  });
  moocLoginAssistOpening = opening;
  return opening;
}

/* ================= qwen 页面桥（service worker 经 app 页面调用） ================= */

async function moocPageLogin(args = {}) {
  const platform = 'mooc';
  const enabled = typeof isPlatformEnabled === 'function' ? isPlatformEnabled(platform) : true;
  if (enabled) {
    return globalThis.getEnabledPlatformLoginResult(platform);
  }
  if (!enabled && typeof togglePlatformSelection === 'function') {
    try { togglePlatformSelection(platform, { interactive: true }); } catch {}
  }
  if (typeof openMoocLoginAssistPopup === 'function') {
    try { openMoocLoginAssistPopup(true); } catch {}
  }
  return await waitForPlatformLoginResult(platform, Number(args?.timeoutMs) || 120000);
}

globalThis.BjtuMoocPageApi = Object.freeze({
  login: (args) => moocPageLogin(args),
  status: () => ({
    loginState: String(window.platformLoginState?.mooc || 'checking'),
    loggedIn: String(window.platformLoginState?.mooc || '') === 'online',
    loaded: window.platformLoadedOnce?.mooc === true
  }),
  courseList: () => window.BjtuMoocPlatform.courseList(),
  assignments: (args) => window.BjtuMoocPlatform.assignments(args),
  assignments_of_: (args) => window.BjtuMoocPlatform.assignmentsOf(args),
  teachers_of_: (args) => window.BjtuMoocPlatform.teachersOf(args)
});

if (typeof chrome !== 'undefined' && chrome?.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'PAGE_API' || message?.payload?.module !== 'mooc') return false;
    const api = globalThis.BjtuMoocPageApi;
    const fn = api && typeof api[String(message.payload?.fn || '')] === 'function' ? api[String(message.payload.fn)] : null;
    if (!fn) {
      sendResponse({ ok: false, error: 'MOOC 页面接口不存在' });
      return true;
    }
    Promise.resolve(fn(message.payload?.args || {})).then(
      (value) => sendResponse({ ok: true, value }),
      (error) => sendResponse({ ok: false, error: String(error?.message || error), code: String(error?.code || '') })
    );
    return true;
  });
}
