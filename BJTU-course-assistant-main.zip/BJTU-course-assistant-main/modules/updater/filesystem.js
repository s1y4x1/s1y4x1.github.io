(function initBjtuUpdateFileSystem(global) {
  'use strict';

  const INSTALL_LOCK_NAME = 'bjtu-course-assistant-update-install';
  const INVALID_STATE_RETRY_DELAYS = [80, 200];
  const DIRECTORY_DB_NAME = 'BJTUCA-FileSystem';
  const DIRECTORY_STORE = 'handles';
  const DIRECTORY_KEY = 'update-directory';
  let fileConcurrencyDefaultsPromise = null;

  function openDirectoryDatabase(name) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(name, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(DIRECTORY_STORE)) {
          request.result.createObjectStore(DIRECTORY_STORE);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('无法打开扩展目录数据库'));
    });
  }

  async function readDirectoryValue(name, key) {
    const db = await openDirectoryDatabase(name);
    try {
      return await new Promise((resolve, reject) => {
        const request = db.transaction(DIRECTORY_STORE, 'readonly').objectStore(DIRECTORY_STORE).get(key);
        request.onsuccess = () => resolve(request.result ?? null);
        request.onerror = () => reject(request.error || new Error('无法读取扩展目录数据库'));
      });
    } finally {
      db.close();
    }
  }

  async function writeDirectoryValue(handle) {
    const db = await openDirectoryDatabase(DIRECTORY_DB_NAME);
    try {
      await new Promise((resolve, reject) => {
        const transaction = db.transaction(DIRECTORY_STORE, 'readwrite');
        const store = transaction.objectStore(DIRECTORY_STORE);
        if (handle) store.put(handle, DIRECTORY_KEY);
        else store.delete(DIRECTORY_KEY);
        transaction.oncomplete = resolve;
        transaction.onerror = () => reject(transaction.error || new Error('无法保存扩展目录'));
        transaction.onabort = () => reject(transaction.error || new Error('保存扩展目录已中止'));
      });
    } finally {
      db.close();
    }
  }

  async function readDirectoryHandle() {
    await global.__bjtuDatabaseMigrationReady;
    return readDirectoryValue(DIRECTORY_DB_NAME, DIRECTORY_KEY);
  }

  async function storeDirectoryHandle(handle) {
    await global.__bjtuDatabaseMigrationReady;
    await writeDirectoryValue(handle);
  }

  function isInvalidStateError(error) {
    const name = String(error?.name || '').toLowerCase();
    const message = String(error?.message || error || '').toLowerCase();
    return name === 'invalidstateerror'
      || message.includes('state cached in an interface object')
      || message.includes('state had changed since it was read from disk');
  }

  function wait(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
  }

  async function retryInvalidState(operation) {
    let lastError = null;
    for (let attempt = 0; attempt <= INVALID_STATE_RETRY_DELAYS.length; attempt += 1) {
      try {
        return await operation(attempt);
      } catch (error) {
        lastError = error;
        if (!isInvalidStateError(error) || attempt >= INVALID_STATE_RETRY_DELAYS.length) throw error;
        await wait(INVALID_STATE_RETRY_DELAYS[attempt]);
      }
    }
    throw lastError;
  }

  async function withInstallLock(operation, { ifAvailable = false } = {}) {
    if (typeof operation !== 'function') throw new TypeError('更新安装任务无效');
    const lockManager = global.navigator?.locks;
    if (!lockManager || typeof lockManager.request !== 'function') return operation();
    return lockManager.request(INSTALL_LOCK_NAME, { mode: 'exclusive', ifAvailable }, lock => {
      if (!lock) throw Object.assign(new Error('扩展目录正在更新或处理文件，暂时无法检查权限'),{code:'INSTALL_DIRECTORY_BUSY'});
      return operation();
    });
  }

  async function fileMatchesBytes(file, bytes) {
    if (file.size !== bytes.byteLength) return false;
    const reader = file.stream().getReader();
    let offset = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) return offset === bytes.byteLength;
        for (let index = 0; index < value.byteLength; index += 1) {
          if (value[index] !== bytes[offset + index]) return false;
        }
        offset += value.byteLength;
      }
    } finally {
      await reader.cancel();
      reader.releaseLock();
    }
  }

  async function writeFile(root, relativePath, bytes, { skipUnchanged = false, directoryCache } = {}) {
    if (!root) throw new Error('尚未授权更新目录');
    const parts = String(relativePath || '').replace(/\\/g, '/').split('/').filter(Boolean);
    if (!parts.length || parts.some((part) => part === '.' || part === '..')) {
      throw new Error(`更新文件路径无效：${relativePath}`);
    }
    const write = async () => {
      let directory = root;
      let path = '';
      for (const part of parts.slice(0, -1)) {
        path += '/' + part;
        let opened = directoryCache?.get(path);
        if (!opened) {
          opened = directory.getDirectoryHandle(part, { create: true });
          directoryCache?.set(path, opened);
        }
        directory = await opened;
      }
      if (skipUnchanged) {
        try {
          const existing = await directory.getFileHandle(parts.at(-1));
          const content = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
          if (await fileMatchesBytes(await existing.getFile(), content)) return false;
        } catch (error) {
          if (error?.name !== 'NotFoundError') throw error;
        }
      }
      const fileHandle = await directory.getFileHandle(parts.at(-1), { create: true });
      const writable = await fileHandle.createWritable();
      try {
        await writable.write(bytes);
        await writable.close();
      } catch (error) {
        await writable.abort?.().catch(() => {});
        throw error;
      }
      return true;
    };
    return retryInvalidState(() => write().catch((error) => {
      if (isInvalidStateError(error)) directoryCache?.clear();
      throw error;
    }));
  }

  async function removeEntry(root, name, options = { recursive: true }) {
    if (!root) throw new Error('尚未授权更新目录');
    return retryInvalidState(async () => {
      try {
        await root.removeEntry(name, options);
      } catch (error) {
        if (String(error?.name || '').toLowerCase() === 'notfounderror') return;
        throw error;
      }
    });
  }

  function archiveCacheKey(url, version) {
    const key = new URL('https://bjtuca.invalid/update-archive.zip');
    key.searchParams.set('url', new URL(url).href);
    key.searchParams.set('version', String(version || '').replace(/^v/i, ''));
    return key.href;
  }

  function normalizeFileConcurrency(value) {
    if (value === null || value === '') return null;
    const count = Number(value);
    return Number.isSafeInteger(count) && count > 0 ? count : null;
  }

  async function readFileConcurrency() {
    await ensureFileConcurrencyDefaults();
    const stored = await chrome.storage.local.get('updateFileConcurrency');
    return normalizeFileConcurrency(stored.updateFileConcurrency) ?? Infinity;
  }

  function ensureFileConcurrencyDefaults() {
    if (!fileConcurrencyDefaultsPromise) {
      const initialize = async () => {
        const stored = await chrome.storage.local.get('updateFileConcurrencyDefaultsVersion');
        if (stored.updateFileConcurrencyDefaultsVersion === 1) return;
        await chrome.storage.local.set({ updateFileConcurrency: null, updateFileConcurrencyDefaultsVersion: 1 });
      };
      fileConcurrencyDefaultsPromise = (global.navigator?.locks
        ? global.navigator.locks.request('bjtu-ca-file-concurrency-defaults', initialize)
        : initialize()).catch((error) => {
          fileConcurrencyDefaultsPromise = null;
          throw error;
        });
    }
    return fileConcurrencyDefaultsPromise;
  }

  async function resolveFileConcurrency(files, { autoConcurrency = false } = {}) {
    const configured = await readFileConcurrency();
    if (Number.isFinite(configured) || !autoConcurrency) return Math.min(configured,files.length);
    if (!files.length) return 0;
    const cpu = Number(global.navigator?.hardwareConcurrency) || 4;
    const memoryGiB = Number(global.navigator?.deviceMemory) || 4;
    const workerLimit = Math.min(files.length,16,Math.max(2,Math.floor(cpu * 2)));
    const mib = 1024 * 1024;
    const budget = Math.min(256,Math.max(32,memoryGiB * 16)) * mib;
    // Budget for the largest possible in-flight set, including decompression
    // copies and a per-writer allowance. A single oversized file still runs.
    const weights = files.map(file => {
      const size = Math.max(0,Number(file?.entry?.uncompressedSize ?? file?.size ?? 0) || 0);
      return size * 2 + mib;
    }).sort((a,b) => b - a);
    let concurrency = 0, used = 0;
    for (let index = 0; index < workerLimit; index++) {
      if (concurrency && used + weights[index] > budget) break;
      used += weights[index];
      concurrency++;
    }
    return concurrency;
  }

  async function processFiles(files, operation, options = {}) {
    const concurrency = await resolveFileConcurrency(files,options);
    let next = 0;
    let failed = false;
    let failure;
    await Promise.all(Array.from({ length: concurrency }, async () => {
      while (!failed && next < files.length) {
        const file = files[next++];
        try {
          await operation(file);
        } catch (error) {
          if (!failed) {
            failed = true;
            failure = error;
          }
        }
      }
    }));
    if (failed) throw failure;
  }

  function applyReleaseVersionName(bytes, release) {
    if (!release || release.commit || !String(release.name || '').trim()) return bytes;
    const manifest = JSON.parse(new TextDecoder().decode(bytes));
    manifest.version_name = release.manifestVersionName || `${manifest.version} ${String(release.name).trim()}`;
    return new TextEncoder().encode(`${JSON.stringify(manifest, null, 2)}\n`);
  }

  async function readArchiveRelease(files, inflate, release) {
    const file = files.find(({ path }) => path === 'manifest.json');
    if (!file) throw new Error('更新包缺少 manifest.json');
    const manifest = JSON.parse(new TextDecoder().decode(await inflate(file.entry)));
    if (typeof manifest.version !== 'string' || !manifest.version.trim()) throw new Error('更新包缺少扩展版本号');
    const name = manifest.version_name || manifest.version;
    return {
      ...release,
      version: manifest.version,
      manifestVersionName: release.version === manifest.version && release.name
        ? `${manifest.version} ${String(release.name).trim()}` : manifest.version_name || manifest.version,
      name: release.commit ? `${name} (${release.commit.slice(0, 7)})`
        : release.version === manifest.version ? release.name || name : name
    };
  }

  async function readArchive(url, version) {
    const cache = await caches.open('bjtu-ca-update-archive');
    const key = archiveCacheKey(url, version);
    const response = await cache.match(key);
    // 分支压缩包 URL 和版本号可能保持不变；开发包最多复用 5 分钟。
    if (response && /\/zip\/refs\/heads\//.test(url)) {
      const savedAt = Number(response.headers.get('X-BJTUCA-Cached-At'));
      if (!savedAt || Date.now() - savedAt >= 5 * 60 * 1000) {
        await cache.delete(key);
        return null;
      }
    }
    return response ? new Uint8Array(await response.arrayBuffer()) : null;
  }

  async function storeArchive(url, version, bytes) {
    const cache = await caches.open('bjtu-ca-update-archive');
    const key = archiveCacheKey(url, version);
    await cache.put(key, new Response(bytes, { headers: {
      'Content-Type': 'application/zip', 'X-BJTUCA-Cached-At': String(Date.now())
    } }));
    for (const request of await cache.keys()) {
      if (request.url !== key) await cache.delete(request);
    }
  }

  global.BjtuUpdateFileSystem = {
    applyReleaseVersionName,
    readArchiveRelease,
    processFiles,
    ensureFileConcurrencyDefaults,
    normalizeFileConcurrency,
    readFileConcurrency,
    readArchive,
    storeArchive,
    fileMatchesBytes,
    isInvalidStateError,
    retryInvalidState,
    withInstallLock,
    readDirectoryHandle,
    storeDirectoryHandle,
    writeFile,
    writeFileIfChanged: (root, relativePath, bytes, options) =>
      writeFile(root, relativePath, bytes, { ...options, skipUnchanged: true }),
    removeEntry
  };
})(globalThis);
