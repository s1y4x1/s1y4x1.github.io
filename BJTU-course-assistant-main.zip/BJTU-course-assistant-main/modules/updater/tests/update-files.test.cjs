const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const { test } = require('node:test');
const vm = require('node:vm');

const source = (file) => readFileSync(join(__dirname, '..', file), 'utf8');
const context = { Uint8Array, setTimeout: (callback) => queueMicrotask(callback) };
vm.runInNewContext(source('filesystem.js'), context);
const filesystem = context.BjtuUpdateFileSystem;
const missing = () => new DOMException('Missing file', 'NotFoundError');

class Directory {
  directories = new Map();
  files = new Map();

  async getDirectoryHandle(name, { create = false } = {}) {
    if (!this.directories.has(name)) {
      if (!create) throw missing();
      this.directories.set(name, new Directory());
    }
    return this.directories.get(name);
  }

  async getFileHandle(name, { create = false } = {}) {
    if (!this.files.has(name)) {
      if (!create) throw missing();
      this.files.set(name, {
        bytes: new Uint8Array(), writes: 0,
        async getFile() { return new Blob([this.bytes]); },
        async createWritable() {
          const file = this;
          return {
            async write(bytes) { file.bytes = bytes instanceof ArrayBuffer ? new Uint8Array(bytes.slice(0)) : Uint8Array.from(bytes); },
            async close() { file.writes += 1; },
            async abort() {}
          };
        }
      });
    }
    return this.files.get(name);
  }
}

test('unchanged bytes skip writing; same-size changes, new and empty files are written', async () => {
  const root = new Directory();
  const bytes = Uint8Array.of(0, 128, 255);
  assert.equal(await filesystem.writeFileIfChanged(root, 'modules/ve/a.bin', bytes), true);
  const directory = await (await root.getDirectoryHandle('modules')).getDirectoryHandle('ve');
  const file = await directory.getFileHandle('a.bin');
  assert.equal(await filesystem.writeFileIfChanged(root, 'modules/ve/a.bin', bytes), false);
  assert.equal(file.writes, 1);
  assert.equal(await filesystem.writeFileIfChanged(root, 'modules/ve/a.bin', Uint8Array.of(0, 129, 255)), true);
  assert.equal(file.writes, 2);
  assert.equal(await filesystem.writeFileIfChanged(root, 'empty.bin', new Uint8Array()), true);
  assert.equal(await filesystem.writeFileIfChanged(root, 'empty.bin', new Uint8Array()), false);
  assert.equal(await filesystem.writeFileIfChanged(root, 'buffer.bin', bytes.buffer), true);
  assert.equal(await filesystem.writeFileIfChanged(root, 'buffer.bin', bytes.buffer), false);
});

test('chunked comparison detects late changes, retries invalid state, and propagates denied access', async () => {
  const root = new Directory();
  const bytes = new Uint8Array(200000).fill(42);
  await filesystem.writeFileIfChanged(root, 'large.bin', bytes);
  assert.equal(await filesystem.writeFileIfChanged(root, 'large.bin', bytes), false);
  const file = await root.getFileHandle('large.bin');
  const read = file.getFile;
  let attempts = 0;
  file.getFile = async function () {
    if (attempts++ === 0) throw new DOMException('Disk state changed', 'InvalidStateError');
    return read.call(this);
  };
  bytes[bytes.length - 1] = 99;
  assert.equal(await filesystem.writeFileIfChanged(root, 'large.bin', bytes), true);
  assert.equal(attempts, 2);
  const writes = file.writes;
  file.getFile = async () => { throw new DOMException('Denied', 'NotAllowedError'); };
  await assert.rejects(filesystem.writeFileIfChanged(root, 'large.bin', bytes), { name: 'NotAllowedError' });
  assert.equal(file.writes, writes);
  await assert.rejects(filesystem.writeFileIfChanged(root, '../outside', bytes), /路径无效/);
});

function section(text, from, until) {
  const start = text.indexOf(from);
  const end = text.indexOf(until, start);
  assert(start >= 0 && end > start);
  return text.slice(start, end);
}

const checker = source('checker.js');
const background = source('background.js');
const ignored = new Set(['.agents', '.git', '.github', '.mimocode']);
const required = new Set(['ve', 'updater']);
const foregroundSelection = new Function('VERSION_IGNORED_ARCHIVE_DIRECTORIES',
  section(checker, 'function getVersionArchiveComponent(', 'function getArchiveModuleIds(')
  + 'return selectUpdateArchiveFiles;')(ignored);
const backgroundSelection = new Function('IGNORED_ARCHIVE_DIRECTORIES',
  section(background, '  function getArchiveComponent(', '  function getArchiveModuleIds(')
  + 'return selectFiles;')(ignored);
const moduleFilter = new Function('VERSION_REQUIRED_MODULE_IDS',
  section(checker, 'function filterFilesByModules(', 'async function removeUnselectedModuleDirectories(')
  + 'return filterFilesByModules;')(required);

test('both update paths consider every archive component, then honor module selection', () => {
  const files = ['manifest.json', 'run.ps1', 'new-root/a.js', 'modules/ve/a.js',
    'modules/qwen/a.js', 'modules/new-module/a.js', '.git/config'].map(path => ({ path }));
  for (const select of [foregroundSelection, backgroundSelection]) {
    const selected = moduleFilter(select(files), new Set(['new-module']));
    assert.deepEqual(selected.map(file => file.path), [
      'manifest.json', 'run.ps1', 'new-root/a.js', 'modules/ve/a.js', 'modules/new-module/a.js'
    ]);
  }
  for (const text of [checker, background]) {
    assert(!/latestUpdate|updateRule|release\??\.update|fullExtraction/.test(text));
  }
});

test('foreground extraction skips unchanged files, reaches 100%, and clean install writes them again', async () => {
  const root = new Directory();
  await filesystem.writeFile(root, 'modules/ve/same.js', Uint8Array.of(1));
  const files = [
    { name: 'modules/ve/same.js', bytes: Uint8Array.of(1), uncompressedSize: 1 },
    { name: 'new-root/new.js', bytes: Uint8Array.of(2), uncompressedSize: 1 },
    { name: 'modules/disabled/a.js', bytes: Uint8Array.of(3), uncompressedSize: 1 }
  ];
  const states = new Map();
  let percent;
  const env = {
    Uint8Array, performance, VERSION_REQUIRED_MODULE_IDS: required,
    VERSION_EXTRACTION_CONCURRENCY: 4, VERSION_EXTRACTION_PROGRESS_INTERVAL_MS: 80,
    setVersionDownloadBar: state => { percent = state.percent; },
    setVersionDownloadProgressUi() {}, getVersionUpdateDirectoryDisplayName: () => 'test',
    parseZipEntries: () => files, getZipCommonRoot: () => '', normalizeUpdateEntryPath: name => name,
    markVersionUpdateError: error => error, getArchiveModuleIds: () => ['disabled'],
    chooseUpdateModules: async () => new Set(),
    clearVersionUpdateDirectory: async () => { root.files.clear(); root.directories.clear(); },
    removeUnselectedModuleDirectories: async () => {},
    selectUpdateArchiveFiles: foregroundSelection, filterFilesByModules: moduleFilter,
    rememberUpdateModuleIds: async () => {}, renderVersionUpdateFileTree() {},
    setVersionDownloadTransferStatus() {}, setVersionUpdateFileSummary() {},
    setVersionUpdateFileState: (path, state) => states.set(path, state),
    inflateZipEntry: async entry => entry.bytes,
    writeBytesToVersionUpdateDirectory: (bytes, path) => filesystem.writeFileIfChanged(root, path, bytes)
  };
  const extract = new Function('env', 'with(env){'
    + section(checker, 'async function extractUpdateArchiveToDirectory(', 'async function downloadVersionByUrlWithProgress(')
    + 'return extractUpdateArchiveToDirectory;}')(env);
  assert.equal(await extract(new Uint8Array()), 1);
  assert.equal(states.get('modules/ve/same.js'), 'skipped');
  assert.equal(states.get('new-root/new.js'), 'done');
  assert(!states.has('modules/disabled/a.js'));
  assert.equal(percent, 100);
  assert.equal(await extract(new Uint8Array()), 0);
  assert.equal(percent, 100);
  assert.equal(await extract(new Uint8Array(), true), 2);
  assert.equal(states.get('modules/ve/same.js'), 'done');
});

test('background install skips identical bytes, installs new modules, and does not restore removed modules', async () => {
  const root = new Directory();
  await filesystem.writeFile(root, 'modules/ve/same.js', Uint8Array.of(1));
  const files = [
    { name: 'manifest.json', bytes: Uint8Array.of(2) },
    { name: 'modules/ve/same.js', bytes: Uint8Array.of(1) },
    { name: 'modules/new-module/a.js', bytes: Uint8Array.of(3) },
    { name: 'modules/removed/a.js', bytes: Uint8Array.of(4) }
  ];
  const stored = { known: ['ve', 'updater', 'removed'], initialized: true };
  let completed;
  const env = {
    globalThis: { BjtuUpdateFileSystem: filesystem }, REQUIRED_MODULE_IDS: required,
    MODULE_KNOWN_IDS_KEY: 'known', MODULE_KNOWN_IDS_INITIALIZED_KEY: 'initialized', MODULE_SELECTION_KEY: 'selected',
    EXTRACTION_CONCURRENCY: 4,
    chrome: { storage: { local: { get: async () => stored, set: async values => Object.assign(stored, values) } } },
    retryNetworkOperation: operation => operation(), downloadArchive: async () => new Uint8Array(),
    parseZipEntries: () => files,
    normalizeZipFiles: entries => entries.map(entry => ({ entry, path: entry.name })),
    getArchiveModuleIds: list => [...new Set(list.map(({ path }) => path.match(/^modules\/([^/]+)\//)?.[1]).filter(Boolean))],
    getInstalledOptionalModuleIds: async () => [...(root.directories.get('modules')?.directories.keys() || [])],
    selectFiles: backgroundSelection, filterFilesByModules: moduleFilter,
    clearDirectory: async () => { root.files.clear(); root.directories.clear(); },
    removeUnselectedModules: async () => {},
    inflateEntry: async entry => entry.bytes,
    writeFile: (directory, path, bytes) => filesystem.writeFileIfChanged(directory, path, bytes),
    setStatus: async (status, progress) => { completed = progress; }
  };
  const install = new Function('env', 'with(env){'
    + section(background, '  async function installRelease(', '  function normalizeManualRelease(')
    + 'return installRelease;}')(env);
  assert.equal(await install(root, { version: '2', url: 'test', clean: false }), 2);
  assert(stored.selected.includes('new-module'));
  assert(!stored.selected.includes('removed'));
  assert.equal(completed.completed, completed.total);
  assert.equal(await install(root, { version: '2', url: 'test', clean: false }), 0);
  assert.equal(await install(root, { version: '2', url: 'test', clean: true }), 3);
});
