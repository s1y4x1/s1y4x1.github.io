/* Qwen 模块后台：存储设置、查询状态、执行操作、转发聊天。 */
(function initBjtuQwenBackground(global) {
  'use strict';
  if (!global.BJTUCA || !global.BjtuApiSettings) return;

  const SETTINGS_KEYS = ['qwenEnabled', 'qwenFabColorMode', 'qwenModelId', 'qwenThinkingEnabled', 'qwenMaxIterations', 'qwenAlwaysAllow', 'qwenApprovalNotificationMode', 'qwenCompletionNotificationMode'];
  const LOGIN_TAB_ID_KEY = 'qwenLoginTabId';
  const LOGIN_ORIGIN_KEY = 'qwenLoginOrigin';
  const WAF_NOTIFICATION_ID = 'bjtu-qwen-waf-verification';
  const WAF_FLOW_STATE_KEY = 'qwenWafFlowState';
  const CHAT_PERMISSION_SESSIONS_KEY = 'qwenChatPermissionSessions';
  const ASK_NOTIFICATION_PREFIX = 'bjtu-qwen-ask-limit:';
  const COMPLETION_NOTIFICATION_PREFIX = 'bjtu-qwen-complete:';
  const pendingAskNotifications = new Map();
  const chatPermissionSessions = new Map();
  let qwenLoginCompletionPromise = null;
  let qwenLoginPendingToken = '';
  let wafPopupOpenPromise = null;

  async function loadChatPermissionSession(chatId) {
    const id = String(chatId || '');
    if (!id) return {};
    if (chatPermissionSessions.has(id)) return chatPermissionSessions.get(id);
    const stored = await chrome.storage.session.get(CHAT_PERMISSION_SESSIONS_KEY).catch(() => ({}));
    const session = stored?.[CHAT_PERMISSION_SESSIONS_KEY]?.[id];
    const value = session && typeof session === 'object' ? session : {};
    chatPermissionSessions.set(id, value);
    return value;
  }

  async function saveChatPermissionSession(chatId, session) {
    const id = String(chatId || '');
    if (!id) return;
    chatPermissionSessions.set(id, session || {});
    const stored = await chrome.storage.session.get(CHAT_PERMISSION_SESSIONS_KEY).catch(() => ({}));
    const sessions = stored?.[CHAT_PERMISSION_SESSIONS_KEY] && typeof stored[CHAT_PERMISSION_SESSIONS_KEY] === 'object'
      ? { ...stored[CHAT_PERMISSION_SESSIONS_KEY] }
      : {};
    sessions[id] = session || {};
    await chrome.storage.session.set({ [CHAT_PERMISSION_SESSIONS_KEY]: sessions }).catch(() => {});
  }

  async function removeChatPermissionSession(chatId) {
    const id = String(chatId || '');
    if (!id) return;
    chatPermissionSessions.delete(id);
    const stored = await chrome.storage.session.get(CHAT_PERMISSION_SESSIONS_KEY).catch(() => ({}));
    const sessions = stored?.[CHAT_PERMISSION_SESSIONS_KEY] && typeof stored[CHAT_PERMISSION_SESSIONS_KEY] === 'object'
      ? { ...stored[CHAT_PERMISSION_SESSIONS_KEY] }
      : {};
    delete sessions[id];
    await chrome.storage.session.set({ [CHAT_PERMISSION_SESSIONS_KEY]: sessions }).catch(() => {});
  }

  async function findOpenQwenAppTab(excludeTabId = null) {
    const appUrl = chrome.runtime.getURL('app/app.html');
    const tabs = await chrome.tabs.query({}).catch(() => []);
    return tabs
      .filter((tab) => {
        const url = String(tab?.url || tab?.pendingUrl || '');
        return Number(tab?.id) !== Number(excludeTabId)
          && url.startsWith(appUrl)
          && !/[?&]popup=1(?:&|$)/.test(url);
      })
      .sort((left, right) => Number(right?.active === true) - Number(left?.active === true)
        || Number(right?.lastAccessed || 0) - Number(left?.lastAccessed || 0))[0] || null;
  }

  async function readWafFlowState() {
    const stored = await chrome.storage.session.get(WAF_FLOW_STATE_KEY).catch(() => ({}));
    const state = stored?.[WAF_FLOW_STATE_KEY];
    return state && typeof state === 'object' ? state : null;
  }

  async function writeWafFlowState(state) {
    await chrome.storage.session.set({ [WAF_FLOW_STATE_KEY]: state }).catch(() => {});
  }

  async function broadcastWafRetry(state) {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      try {
        const response = await chrome.runtime.sendMessage({
          type: 'QWEN_WAF_VERIFIED_BROADCAST',
          flowId: String(state?.flowId || '')
        });
        if (response?.ok === true && response?.retryStarted === true) return true;
      } catch {
        // 原扩展页面可能仍在恢复前台，稍后重试。
      }
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    return false;
  }

  function normalizeWafValidationUrl(value) {
    try {
      const url = new URL(String(value || ''));
      if (url.protocol !== 'https:' || url.hostname !== 'chat.qwen.ai') return '';
      return url.href;
    } catch {
      return '';
    }
  }

  async function doBeginWafPopupFlow(validationUrl) {
    const url = normalizeWafValidationUrl(validationUrl);
    if (!url) throw new Error('风控响应未提供有效的验证地址');
    const existingState = await readWafFlowState();
    if (existingState?.phase === 'waiting-validation') {
      const existingWindow = await chrome.windows.get(Number(existingState.validationWindowId)).catch(() => null);
      if (existingWindow) {
        await chrome.windows.update(existingWindow.id, { focused: true }).catch(() => null);
        return existingState;
      }
    }

    const currentWindow = await chrome.windows.getLastFocused().catch(() => null);
    const width = 480;
    const height = 640;
    const left = Number.isFinite(currentWindow?.left) && Number.isFinite(currentWindow?.width)
      ? Math.round(currentWindow.left + Math.max(0, (currentWindow.width - width) / 2))
      : undefined;
    const top = Number.isFinite(currentWindow?.top) && Number.isFinite(currentWindow?.height)
      ? Math.round(currentWindow.top + Math.max(0, (currentWindow.height - height) / 2))
      : undefined;
    const validationWindow = await chrome.windows.create({
      url,
      type: 'popup',
      focused: true,
      width,
      height,
      ...(left === undefined ? {} : { left }),
      ...(top === undefined ? {} : { top })
    });
    const validationTabId = Number(validationWindow?.tabs?.[0]?.id);
    if (!Number.isInteger(validationTabId)) {
      if (Number.isInteger(validationWindow?.id)) await chrome.windows.remove(validationWindow.id).catch(() => {});
      throw new Error('无法打开通义千问风控校验窗口');
    }
    const state = {
      flowId: globalThis.crypto?.randomUUID?.() || `waf-${Date.now()}`,
      validationUrl: url,
      validationTabId,
      validationWindowId: Number(validationWindow.id),
      validationPageLoaded: false,
      validationPageUrl: String(validationWindow?.tabs?.[0]?.url || validationWindow?.tabs?.[0]?.pendingUrl || url),
      phase: 'waiting-validation',
      startedAt: Date.now()
    };
    await writeWafFlowState(state);
    const currentValidationTab = await chrome.tabs.get(validationTabId).catch(() => null);
    if (String(currentValidationTab?.status || '') === 'complete') {
      state.validationPageLoaded = true;
      state.validationPageUrl = String(currentValidationTab?.url || currentValidationTab?.pendingUrl || state.validationPageUrl);
      await writeWafFlowState(state);
    }
    if (typeof global.BjtuSystemNotifications?.create === 'function') {
      await global.BjtuSystemNotifications.create(WAF_NOTIFICATION_ID, {
        type: 'basic',
        iconUrl: 'icons/128.png',
        title: '通义千问触发风控校验',
        message: '请在弹出的小窗口中完成验证。验证成功后窗口会自动关闭并重试；直接关闭窗口不会重试。看不到验证？请刷新小窗口。',
        priority: 2,
        requireInteraction: true
      }, 'qwen-waf-verification', true).catch(() => {});
    }
    return state;
  }

  function beginWafPopupFlow(validationUrl) {
    if (!wafPopupOpenPromise) {
      wafPopupOpenPromise = doBeginWafPopupFlow(validationUrl)
        .finally(() => { wafPopupOpenPromise = null; });
    }
    return wafPopupOpenPromise;
  }

  async function finishWafPopupValidation(tabId, nextUrl) {
    const state = await readWafFlowState();
    if (!state || state.phase !== 'waiting-validation' || Number(state.validationTabId) !== Number(tabId)) return;
    const url = String(nextUrl || '');
    if (!url || url === String(state.validationPageUrl || '')) return;
    const retryingState = { ...state, phase: 'retrying', verifiedAt: Date.now() };
    await writeWafFlowState(retryingState);
    await chrome.windows.remove(Number(state.validationWindowId)).catch(() => {});
    await chrome.notifications.clear(WAF_NOTIFICATION_ID).catch(() => false);
    const retryStarted = await broadcastWafRetry(retryingState);
    if (!retryStarted) {
      await chrome.storage.session.remove(WAF_FLOW_STATE_KEY).catch(() => {});
      await chrome.notifications.clear(WAF_NOTIFICATION_ID).catch(() => false);
    }
  }

  async function handleWafPopupTabUpdated(tabId, changeInfo, tab) {
    const state = await readWafFlowState();
    if (!state || state.phase !== 'waiting-validation' || Number(state.validationTabId) !== Number(tabId)) return;
    const observedUrl = String(changeInfo?.url || tab?.url || tab?.pendingUrl || state.validationPageUrl || '');
    if (state.validationPageLoaded !== true) {
      const loaded = changeInfo?.status === 'complete' || String(tab?.status || '') === 'complete';
      await writeWafFlowState({
        ...state,
        validationPageLoaded: loaded,
        validationPageUrl: observedUrl
      });
      return;
    }
    if (changeInfo?.url && observedUrl !== String(state.validationPageUrl || '')) {
      await finishWafPopupValidation(tabId, observedUrl);
    }
  }

  async function cancelWafPopupValidation(tabId) {
    const state = await readWafFlowState();
    if (!state || state.phase !== 'waiting-validation' || Number(state.validationTabId) !== Number(tabId)) return;
    await chrome.storage.session.remove(WAF_FLOW_STATE_KEY).catch(() => {});
    await chrome.notifications.clear(WAF_NOTIFICATION_ID).catch(() => false);
    await chrome.runtime.sendMessage({
      type: 'QWEN_WAF_CANCELLED_BROADCAST',
      flowId: String(state.flowId || '')
    }).catch(() => {});
  }

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo?.url || changeInfo?.status === 'complete') {
      void handleWafPopupTabUpdated(tabId, changeInfo, tab);
    }
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void cancelWafPopupValidation(tabId);
  });

  async function handleWafRetryResult(payload) {
    const state = await readWafFlowState();
    const flowId = String(payload?.flowId || '');
    if (!state || !flowId || String(state.flowId || '') !== flowId) return { ok: false, stale: true };
    if (state.validationWindowId != null) {
      await chrome.storage.session.remove(WAF_FLOW_STATE_KEY).catch(() => {});
      await chrome.notifications.clear(WAF_NOTIFICATION_ID).catch(() => false);
      return { ok: true, completed: true };
    }
    await chrome.storage.session.remove(WAF_FLOW_STATE_KEY).catch(() => {});
    await chrome.notifications.clear(WAF_NOTIFICATION_ID).catch(() => false);
    return { ok: true, completed: payload?.success === true };
  }

  if (typeof chrome === 'object' && chrome?.notifications?.onButtonClicked) {
    chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
      const id = String(notificationId || '');
      if (!id.startsWith(ASK_NOTIFICATION_PREFIX)) return;
      const handler = pendingAskNotifications.get(id);
      if (!handler) return;
      handler(buttonIndex === 0 ? 'continue' : 'stop');
    });
  }

  async function broadcastTokenCaptured(reason = 'login') {
    try {
      await chrome.runtime.sendMessage({ type: 'QWEN_TOKEN_CAPTURED_BROADCAST', reason: String(reason || 'login') });
    } catch {
      // app 页面可能尚未打开
    }
  }

  async function focusQwenAppPage() {
    const appUrl = chrome.runtime.getURL('app/app.html');
    const appTab = await findOpenQwenAppTab();
    const tab = appTab
      ? await chrome.tabs.update(appTab.id, { active: true }).catch(() => appTab)
      : await global.BjtuTabs.create({ url: appUrl, active: true }).catch(() => null);
    if (Number.isInteger(tab?.windowId)) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => null);
  }

  function qwenLoginOpenedFromSidePanel(sender) {
    try {
      const senderUrl = new URL(String(sender?.url || ''));
      return senderUrl.protocol === 'chrome-extension:'
        && senderUrl.host === chrome.runtime.id
        && senderUrl.searchParams.get('view') === 'sidepanel';
    } catch {
      return false;
    }
  }

  async function rememberQwenLoginOrigin(sender) {
    await chrome.storage.session.set({
      [LOGIN_ORIGIN_KEY]: {
        sidePanel: qwenLoginOpenedFromSidePanel(sender),
        openedAt: Date.now()
      }
    }).catch(() => {});
  }

  async function completeQwenLogin(token) {
    const value = String(token || '').trim();
    if (!value) return;
    qwenLoginPendingToken = value;
    if (qwenLoginCompletionPromise) return qwenLoginCompletionPromise;
    qwenLoginCompletionPromise = (async () => {
      const tokenState = await chrome.storage.session.get('qwenToken').catch(() => ({}));
      const authenticated = await global.BjtuQwenClient.tryRefreshLogin({ token: value }).catch(() => false);
      if (!authenticated || qwenLoginPendingToken !== value) return;
      const verifiedState = await chrome.storage.session.get('qwenToken');
      const tokenChanged = String(tokenState?.qwenToken || '') !== String(verifiedState?.qwenToken || '');
      const stored = await chrome.storage.session.get([LOGIN_TAB_ID_KEY, LOGIN_ORIGIN_KEY]).catch(() => ({}));
      const loginTabId = Number(stored?.[LOGIN_TAB_ID_KEY]);
      if (tokenChanged || Number.isInteger(loginTabId)) await broadcastTokenCaptured('login');
      if (!Number.isInteger(loginTabId)) return;
      const loginTab = await chrome.tabs.get(loginTabId).catch(() => null);
      const openedFromSidePanel = stored?.[LOGIN_ORIGIN_KEY]?.sidePanel === true;
      await chrome.storage.session.remove([LOGIN_TAB_ID_KEY, LOGIN_ORIGIN_KEY]).catch(() => {});
      if (loginTab && String(loginTab.url || loginTab.pendingUrl || '').startsWith('https://chat.qwen.ai/')) {
        await chrome.tabs.remove(loginTabId).catch(() => {});
      }
      if (openedFromSidePanel) return;
      await focusQwenAppPage();
    })().finally(() => {
      qwenLoginCompletionPromise = null;
      const nextToken = qwenLoginPendingToken;
      qwenLoginPendingToken = '';
      if (nextToken && nextToken !== value) void completeQwenLogin(nextToken);
    });
    return qwenLoginCompletionPromise;
  }

  async function getSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_KEYS).catch(() => ({}));
    const operationSettings = await global.BjtuApiSettings.get();
    return {
      enabled: stored.qwenEnabled !== false,
      fabColorMode: ['dark', 'light', 'system', 'extension'].includes(stored.qwenFabColorMode)
        ? stored.qwenFabColorMode
        : 'extension',
      modelId: String(stored.qwenModelId || ''),
      ...operationSettings,
      thinkingEnabled: stored.qwenThinkingEnabled === true,
      maxIterations: Number(stored.qwenMaxIterations) > 0 ? Number(stored.qwenMaxIterations) : 6,
      alwaysAllow: stored.qwenAlwaysAllow === true,
      approvalNotificationMode: ['always', 'background', 'never'].includes(stored.qwenApprovalNotificationMode)
        ? stored.qwenApprovalNotificationMode
        : 'background',
      completionNotificationMode: ['always', 'background', 'never'].includes(stored.qwenCompletionNotificationMode)
        ? stored.qwenCompletionNotificationMode
        : 'background'
    };
  }

  async function saveSettings(patch) {
    const next = {};
    if (typeof patch?.enabled === 'boolean') next.qwenEnabled = patch.enabled;
    if (patch?.fabColorMode !== undefined) {
      next.qwenFabColorMode = ['dark', 'light', 'system', 'extension'].includes(patch.fabColorMode)
        ? patch.fabColorMode
        : 'extension';
    }
    if (patch?.modelId !== undefined) next.qwenModelId = String(patch.modelId || '');
    if (patch?.enabledOperations !== undefined || patch?.alwaysAllowedOperations !== undefined) {
      await global.BjtuApiSettings.save(patch);
    }
    if (typeof patch?.thinkingEnabled === 'boolean') next.qwenThinkingEnabled = patch.thinkingEnabled;
    if (patch?.maxIterations !== undefined) {
      next.qwenMaxIterations = Math.max(1, Math.floor(Number(patch.maxIterations) || 6));
    }
    if (typeof patch?.alwaysAllow === 'boolean') next.qwenAlwaysAllow = patch.alwaysAllow;
    if (patch?.approvalNotificationMode !== undefined) {
      next.qwenApprovalNotificationMode = ['always', 'background', 'never'].includes(patch.approvalNotificationMode)
        ? patch.approvalNotificationMode
        : 'background';
    }
    if (patch?.completionNotificationMode !== undefined) {
      next.qwenCompletionNotificationMode = ['always', 'background', 'never'].includes(patch.completionNotificationMode)
        ? patch.completionNotificationMode
        : 'background';
    }
    if (Object.keys(next).length) await chrome.storage.local.set(next);
    return getSettings();
  }

  const activeChatPorts = new Set();
  let sharedChatCreationPromise = null;
  let sharedOpeningInFlight = null;

  async function resolveSharedChatId(client, modelId) {
    const stored = await chrome.storage.local.get('qwenLastChatId').catch(() => ({}));
    const existing = String(stored?.qwenLastChatId || '');
    if (existing) return existing;
    if (!sharedChatCreationPromise) {
      sharedChatCreationPromise = client.newChat(modelId).then(async (chatId) => {
        const id = String(chatId || '');
        if (!id) throw new Error('新建共享会话失败：未返回会话 ID');
        await chrome.storage.local.set({ qwenLastChatId: id });
        return id;
      }).finally(() => {
        sharedChatCreationPromise = null;
      });
    }
    return sharedChatCreationPromise;
  }

  function broadcastSharedChatUpdated(chatId, sourceViewId) {
    const id = String(chatId || '');
    if (!id) return;
    void chrome.runtime.sendMessage({ type: 'QWEN_SHARED_CHAT_UPDATED', chatId: id, sourceViewId }).catch(() => {});
  }

  function postCompletionStreamEvent(port, event) {
    if (event?.streamRestart) port.postMessage({ type: 'streamRestart' });
    if (event?.text) port.postMessage({ type: 'delta', text: event.text });
    if (event?.thinking) port.postMessage({ type: 'thinking', text: event.thinking });
    if (event?.functionCall) port.postMessage({ type: 'functionCall', functionCall: event.functionCall });
    if (event?.functionResult) port.postMessage({ type: 'functionResult', functionResult: event.functionResult });
  }

  async function qwenViewIsInBackground(port, uiState) {
    if (uiState?.visible !== true) return true;
    const senderTab = port?.sender?.tab;
    const windowId = Number(senderTab?.windowId);
    if (Number.isInteger(windowId)) {
      const browserWindow = await chrome.windows.get(windowId).catch(() => null);
      if (browserWindow?.state === 'minimized') return true;
    } else {
      const browserWindow = await chrome.windows.getLastFocused().catch(() => null);
      if (browserWindow?.state === 'minimized') return true;
    }
    if (String(uiState?.context || '') === 'sidepanel') return false;
    const tabId = Number(senderTab?.id);
    if (!Number.isInteger(tabId)) return false;
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    return tab?.active !== true;
  }

  async function notifyQwenBackgroundCompletion(port, uiState, result) {
    const settings = await getSettings();
    if (settings.completionNotificationMode === 'never') return;
    if (settings.completionNotificationMode === 'background'
      && !await qwenViewIsInBackground(port, uiState)) return;
    const responseId = String(result?.responseId || Date.now());
    const tabId = Number(port?.sender?.tab?.id);
    const windowId = Number(port?.sender?.tab?.windowId);
    const context = ['app', 'standalone', 'sidepanel'].includes(String(uiState?.context || ''))
      ? String(uiState.context)
      : 'standalone';
    const notificationId = [
      COMPLETION_NOTIFICATION_PREFIX.slice(0, -1),
      context,
      Number.isInteger(tabId) ? tabId : 0,
      Number.isInteger(windowId) ? windowId : 0,
      encodeURIComponent(String(uiState?.viewId || '')),
      encodeURIComponent(responseId)
    ].join(':');
    const summary = String(result?.final || result?.text || '')
      .replace(/```[\s\S]*?```/g, ' [代码] ')
      .replace(/\s+/g, ' ')
      .trim();
    await new Promise((resolve) => {
      chrome.notifications.create(notificationId, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/128.png'),
        title: '千问助手回复生成完毕',
        message: summary ? summary.slice(0, 180) : '回复已生成完毕，请返回千问助手查看。'
      }, () => {
        void chrome.runtime.lastError;
        resolve();
      });
    });
  }

  async function focusQwenCompletionTarget(notificationId) {
    const id = String(notificationId || '');
    if (!id.startsWith(COMPLETION_NOTIFICATION_PREFIX)) return;
    const parts = id.slice(COMPLETION_NOTIFICATION_PREFIX.length).split(':');
    const context = String(parts[0] || 'standalone');
    const tabId = Number(parts[1]);
    const windowId = Number(parts[2]);
    const viewId = decodeURIComponent(parts[3] || '');
    let tab = Number.isInteger(tabId) && tabId > 0
      ? await chrome.tabs.get(tabId).catch(() => null)
      : null;
    const targetWindowId = Number(tab?.windowId || windowId);
    if (Number.isInteger(targetWindowId) && targetWindowId >= 0) {
      const browserWindow = await chrome.windows.get(targetWindowId).catch(() => null);
      if (browserWindow?.state === 'minimized') {
        await chrome.windows.update(targetWindowId, { state: 'normal', focused: true }).catch(() => null);
      } else {
        await chrome.windows.update(targetWindowId, { focused: true }).catch(() => null);
      }
    }
    if (tab?.id) tab = await chrome.tabs.update(tab.id, { active: true }).catch(() => tab);
    if (context === 'app' && tab?.id) {
      await chrome.runtime.sendMessage({ type: 'QWEN_OPEN_CHAT_PANEL', viewId }).catch(() => null);
      return;
    }
    if (context === 'sidepanel') {
      await chrome.storage.local.set({ sidePanelLastView: 'qwen' }).catch(() => {});
      if (tab?.id) {
        await chrome.sidePanel.open({ tabId: tab.id }).catch(async () => {
          if (Number.isInteger(targetWindowId)) await chrome.sidePanel.open({ windowId: targetWindowId }).catch(() => null);
        });
      } else if (Number.isInteger(targetWindowId)) {
        await chrome.sidePanel.open({ windowId: targetWindowId }).catch(() => null);
      }
      await chrome.runtime.sendMessage({ type: 'QWEN_SHOW_SIDE_PANEL_CHAT' }).catch(() => null);
      return;
    }
    if (!tab) {
      await chrome.tabs.create({ url: chrome.runtime.getURL('modules/qwen/chat.html'), active: true }).catch(() => null);
    }
  }

  if (typeof chrome === 'object' && chrome?.notifications?.onClicked) {
    chrome.notifications.onClicked.addListener((notificationId) => {
      if (!String(notificationId || '').startsWith(COMPLETION_NOTIFICATION_PREFIX)) return;
      void focusQwenCompletionTarget(notificationId).finally(() => {
        chrome.notifications.clear(notificationId, () => void chrome.runtime.lastError);
      });
    });
  }

  if (typeof chrome === 'object' && chrome?.runtime?.onConnect) {
    chrome.runtime.onConnect.addListener((port) => {
      if (String(port.name || '') === 'bjtu-qwen-history-resume') {
        const resumeAbortController = new AbortController();
        let started = false;
        let resumeChatId = '';
        let resumeResponseId = '';
        let disconnected = false;
        port.onDisconnect.addListener(() => {
          disconnected = true;
          resumeAbortController.abort();
        });
        port.onMessage.addListener((message) => {
          if (message?.type === 'stop') {
            if (resumeChatId && resumeResponseId) {
              void global.BjtuQwenClient?.stopGeneration?.({
                chatId: resumeChatId,
                responseId: resumeResponseId
              });
            }
            resumeAbortController.abort(new DOMException('生成中止', 'AbortError'));
            return;
          }
          if (message?.type !== 'resume' || started) return;
          started = true;
          resumeChatId = String(message?.chatId || '');
          resumeResponseId = String(message?.responseId || '');
          void global.BjtuQwenClient.resumeChatHistory(resumeChatId, resumeResponseId, {
            signal: resumeAbortController.signal,
            onEvent: (event) => {
              if (!disconnected) postCompletionStreamEvent(port, event);
            }
          }).then((result) => {
            if (!disconnected) port.postMessage({ type: 'historyResumeDone', ...result });
          }).catch((error) => {
            if (disconnected) return;
            port.postMessage({
              type: error?.name === 'AbortError' ? 'historyResumeStopped' : 'historyResumeError',
              code: String(error?.code || ''),
              message: String(error?.message || error)
            });
          });
        });
        return;
      }
      if (String(port.name || '') !== 'bjtu-qwen-chat') return;
      activeChatPorts.add(port);
      const abortController = new AbortController();
      const turnRef = {};
      let pendingAsk = null;
      let pendingRetry = null;
      let stopRequested = false;
      let loopSession = {};
      let activeThinkingEnabled = null;
      let activeUiState = { context: '', visible: true };
      const settlePendingAsk = (action = 'stop', count = 0, notifyPage = false) => {
        if (!pendingAsk) return;
        const current = pendingAsk;
        pendingAsk = null;
        if (current.notificationId) {
          pendingAskNotifications.delete(current.notificationId);
          chrome.notifications.clear(current.notificationId, () => void chrome.runtime.lastError);
        }
        current.resolve?.({
          action: String(action || 'stop'),
          count: Number(count) || Number(current.count) || 1
        });
        if (notifyPage && !port.disconnected) {
          port.postMessage({ type: 'askResolved', id: current.id });
        }
      };
      const resolveAskOnAbort = () => {
        settlePendingAsk('stop');
      };
      const resolveRetryOnAbort = () => {
        if (pendingRetry) {
          const resolve = pendingRetry.resolve;
          pendingRetry = null;
          resolve?.('stop');
        }
      };
      port.onDisconnect.addListener(() => {
        activeChatPorts.delete(port);
        resolveAskOnAbort();
        resolveRetryOnAbort();
        abortController.abort();
      });
      port.onMessage.addListener((message) => {
        if (message?.type === 'uiState') {
          activeUiState = {
            context: String(message.context || activeUiState.context || ''),
            viewId: String(message.viewId || activeUiState.viewId || ''),
            visible: message.visible === true
          };
          return;
        }
        if (message?.type === 'thinkingChanged') {
          activeThinkingEnabled = message.enabled === true;
          return;
        }
        if (message?.type === 'retryDecision') {
          const retryId = String(message?.retryId || '');
          if (!pendingRetry || (retryId && retryId !== pendingRetry.id)) {
            if (!port.disconnected) port.postMessage({ type: 'retryRejected', retryId });
            return;
          }
          const retryChatId = String(message?.chatId || pendingRetry.chatId || turnRef.chatId || '');
          if (retryChatId) turnRef.chatId = retryChatId;
          const resolve = pendingRetry.resolve;
          pendingRetry = null;
          if (!port.disconnected) port.postMessage({ type: 'retryAccepted', retryId });
          resolve?.(String(message.action || 'stop'));
          return;
        }
        if (message?.type === 'askResponse' && pendingAsk?.id === message.id) {
          const action = String(message.action || 'stop');
          if (action === 'always' && pendingAsk.mode === 'iterate') {
            const askId = pendingAsk.id;
            void saveSettings({ alwaysAllow: true })
              .catch((error) => console.error('[qwen] 保存全局循环许可失败：', error))
              .finally(() => {
                if (pendingAsk?.id === askId) settlePendingAsk(action, message.count);
              });
            return;
          }
          settlePendingAsk(action, message.count);
          return;
        }
        if (message?.type === 'stop') {
          if (stopRequested) return;
          stopRequested = true;
          resolveAskOnAbort();
          resolveRetryOnAbort();
          void (async () => {
            // response_id 由流首个 response.created/delta 事件给出。若用户点得
            // 很早，短暂等待该事件，否则无法构造千问要求的停止请求。
            const deadline = Date.now() + 1200;
            while (turnRef.chatId && !turnRef.responseId && Date.now() < deadline) {
              await new Promise((resolve) => setTimeout(resolve, 25));
            }
            if (turnRef.chatId && turnRef.responseId) {
              void global.BjtuQwenClient?.stopGeneration?.({
                chatId: turnRef.chatId,
                responseId: turnRef.responseId
              });
            }
            abortController.abort(new DOMException('生成中止', 'AbortError'));
          })();
          return;
        }
        if (message?.type !== 'send') return;
        if (!String(message.text || '').trim() && String(message.chatId || '')) return;
        void (async () => {
          let releaseOpeningLock = null;
          try {
            const settings = await getSettings();
            activeThinkingEnabled = typeof message.thinking === 'boolean'
              ? message.thinking
              : settings.thinkingEnabled === true;
            activeUiState = {
              context: String(message?.uiState?.context || ''),
              viewId: String(message?.uiState?.viewId || ''),
              visible: message?.uiState?.visible === true
            };
            const client = global.BjtuQwenClient;
            const operations = global.BJTUCA;
            if (!settings.enabled) throw Object.assign(new Error('通义千问模块已禁用，请先在扩展选项中开启'), { code: 'DISABLED' });
            const modelId = settings.modelId || await resolveDefaultModel(client);
            const groups = await operations.groups();
            const sourceChatId = String(message.chatId || '');
            const requestedChatId = await resolveSharedChatId(client, modelId);
            const keepSourceParent = !sourceChatId || sourceChatId === requestedChatId;
            if (message?.isOpening === true) {
              if (sharedOpeningInFlight?.chatId === requestedChatId) {
                await sharedOpeningInFlight.promise.catch(() => {});
                if (!port.disconnected) {
                  port.postMessage({ type: 'historyReload', chatId: requestedChatId, responseId: '' });
                }
                return;
              }
              let release;
              const promise = new Promise((resolve) => { release = resolve; });
              const lock = { chatId: requestedChatId, promise };
              sharedOpeningInFlight = lock;
              releaseOpeningLock = () => {
                release();
                if (sharedOpeningInFlight === lock) sharedOpeningInFlight = null;
              };
            }
            loopSession = requestedChatId ? await loadChatPermissionSession(requestedChatId) : {};
            const result = await global.BjtuQwenAgent.runTurn({
              modelId,
              userText: String(message.text).trim(),
              chatId: requestedChatId,
              parentId: keepSourceParent ? String(message.parentId || '') : '',
              parentIdExplicit: keepSourceParent && message.editParentGiven === true,
              enabledOps: settings.enabledOperations,
              groups,
              signal: abortController.signal,
              turnRef,
              thinking: activeThinkingEnabled,
              getThinking: () => activeThinkingEnabled === true,
              maxIterations: settings.maxIterations,
              alwaysAllow: settings.alwaysAllow === true,
              alwaysAllowedOperations: settings.alwaysAllowedOperations,
              onAlwaysAllowOperations: async (names) => {
                await saveSettings({ alwaysAllowedOperations: names });
              },
              sessionRef: loopSession,
              onRetryRequest: (info) => new Promise((resolve) => {
                const retryChatId = String(info?.chatId || turnRef.chatId || '');
                const retryId = `retry-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
                pendingRetry = { id: retryId, resolve, chatId: retryChatId };
                const safeMessage = String(info?.message || '请求失败');
                port.postMessage({
                  type: 'retryRequest',
                  retryId,
                  message: safeMessage,
                  code: String(info?.code || ''),
                  validationUrl: String(info?.validationUrl || ''),
                  chatId: retryChatId,
                  afterOperationResult: info?.afterOperationResult === true,
                  operationResult: info?.afterOperationResult === true ? info.operationResult : undefined
                });
              }),
              askUser: async (payload) => {
                const notificationSettings = await getSettings();
                const approvalNotificationMode = notificationSettings.approvalNotificationMode;
                const shouldNotify = approvalNotificationMode === 'always'
                  || (approvalNotificationMode === 'background'
                    && await qwenViewIsInBackground(port, activeUiState));
                return new Promise((resolve) => {
                const id = `ask-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
                const count = Number(payload?.count) || 3;
                const mode = String(payload?.mode || 'iterate');
                const executionMode = String(payload?.executionMode || '');
                const operationNames = Array.isArray(payload?.operationNames)
                  ? payload.operationNames.map(String).filter(Boolean)
                  : [];
                const notificationId = shouldNotify
                  ? `${ASK_NOTIFICATION_PREFIX}${id}`
                  : '';
                pendingAsk = { id, resolve, count, mode, executionMode, operationNames, notificationId };
                if (notificationId) {
                  pendingAskNotifications.set(notificationId, (action) => {
                    settlePendingAsk(action, count, true);
                  });
                }
                abortController.signal.addEventListener('abort', resolveAskOnAbort, { once: true });
                const safeMessage = String(payload?.message || '操作调用次数过多，是否继续？');
                port.postMessage({
                  type: 'ask',
                  id,
                  message: safeMessage,
                  mode,
                  count,
                  executionMode,
                  operationNames
                });
                try {
                  if (notificationId && chrome?.notifications?.create) {
                    chrome.notifications.create(notificationId, {
                      type: 'basic',
                      iconUrl: chrome.runtime.getURL('icons/128.png'),
                      title: mode === 'operation-permission' ? '千问请求执行 JavaScript' : '千问助手',
                      message: safeMessage,
                      priority: 2,
                      requireInteraction: true,
                      buttons: [
                        { title: mode === 'operation-permission' ? '允许一次' : '继续' },
                        { title: mode === 'operation-permission' ? '拒绝' : '终止' }
                      ]
                    });
                  }
                } catch {
                  // 通知失败不影响主流程
                }
                });
              },
              onDelta: (text) => {
                if (port.disconnected) return;
                port.postMessage({ type: 'delta', text });
              },
              onEvent: (event) => {
                if (port.disconnected) return;
                postCompletionStreamEvent(port, event);
                if (event?.operation) port.postMessage({ type: 'operation', operation: event.operation });
                if (event?.operationResult) port.postMessage({ type: 'operationResult', result: event.operationResult });
                if (event?.firstMessage) port.postMessage({ type: 'firstMessage' });
              }
            });
            if (result.chatId) await saveChatPermissionSession(result.chatId, loopSession);
            if (result.chatId) {
              const shared = await chrome.storage.local.get('qwenLastChatId').catch(() => ({}));
              if (String(shared?.qwenLastChatId || '') === String(result.chatId)) {
                broadcastSharedChatUpdated(result.chatId, activeUiState.viewId);
              }
            }
            if (result.stoppedByLimit !== true) {
              await notifyQwenBackgroundCompletion(port, activeUiState, result);
            }
            if (port.disconnected) return;
            if (result.historyReloadRequired === true) {
              port.postMessage({
                type: 'historyReload',
                chatId: result.chatId,
                responseId: String(result.responseId || '')
              });
              return;
            }
            port.postMessage({
              type: 'done',
              text: result.text,
              chatId: result.chatId,
              responseId: String(result.responseId || ''),
              stoppedByLimit: result.stoppedByLimit === true
            });
          } catch (error) {
            if (port.disconnected) return;
            if (turnRef?.chatId) await saveChatPermissionSession(turnRef.chatId, loopSession);
            if (error?.name === 'AbortError' || abortController.signal.aborted) {
              port.postMessage({
                type: 'stopped',
                chatId: String(turnRef?.chatId || ''),
                responseId: String(turnRef?.responseId || ''),
                parentId: String(turnRef?.retryParentId || ''),
                retryText: String(turnRef?.retryText || ''),
                retryParentId: String(turnRef?.retryParentId || '')
              });
              return;
            }
            port.postMessage({
              type: 'error',
              message: String(error?.message || error),
              code: String(error?.code || ''),
              validationUrl: String(error?.validationUrl || ''),
              chatId: String(turnRef?.chatId || ''),
              parentId: String(turnRef?.lastMessageId || '')
            });
          } finally {
            releaseOpeningLock?.();
          }
        })();
      });
    });
  }

  async function resolveDefaultModel(client) {
    const models = await client.fetchModels();
    return String(models[0]?.id || '');
  }

  if (typeof chrome === 'object' && chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      const type = String(message?.type || '');
      if (type === 'QWEN_GET_STATUS') {
        void (async () => {
          const settings = await getSettings();
          const client = global.BjtuQwenClient;
          let loggedIn = false;
          let checkError = '';
          try {
            if (client && message?.payload?.checkLogin) {
              loggedIn = await client.tryRefreshLogin();
            } else {
              loggedIn = client ? await client.isLoggedIn() : false;
            }
          } catch (error) {
            loggedIn = false;
            checkError = String(error?.message || error);
          }
          let modelName = '';
          if (settings.modelId) modelName = settings.modelId;
          sendResponse({ ok: true, ...settings, loggedIn, modelId: settings.modelId, modelName, checkError });
        })();
        return true;
      }
      if (type === 'QWEN_GET_CHAT_HISTORY') {
        void (async () => {
          const chatId = String(message?.payload?.chatId || '');
          const client = global.BjtuQwenClient;
          if (!chatId || !client?.fetchChatHistory) {
            sendResponse({ ok: false, message: '无会话或客户端未就绪' });
            return;
          }
          try {
            const messages = await client.fetchChatHistory(chatId);
            const lastMessage = messages[messages.length - 1];
            const pendingResponseId = String(lastMessage?.role || '') === 'assistant'
              && lastMessage?.content_list === null
              ? String(lastMessage?.id || '')
              : '';
            sendResponse({ ok: true, messages, pendingResponseId });
          } catch (error) {
            sendResponse({
              ok: false,
              code: error?.code || '',
              validationUrl: String(error?.validationUrl || ''),
              message: String(error?.message || error)
            });
          }
        })();
        return true;
      }
      if (type === 'QWEN_DELETE_CHAT') {
        void (async () => {
          const chatId = String(message?.payload?.chatId || '');
          const client = global.BjtuQwenClient;
          if (!chatId || !client?.deleteChat) {
            sendResponse({ ok: false, message: '无会话或客户端未就绪' });
            return;
          }
          try {
            await client.deleteChat(chatId);
            await removeChatPermissionSession(chatId);
            sendResponse({ ok: true });
          } catch (error) {
            sendResponse({ ok: false, message: String(error?.message || error) });
          }
        })();
        return true;
      }
      if (type === 'QWEN_TOKEN_CAPTURED') {
        const token = String(message?.payload?.token || '');
        if (token && global.BjtuQwenClient?.captureToken) void completeQwenLogin(token);
        return false;
      }
      if (type === 'QWEN_TOKEN_CLEARED') {
        void chrome.storage.session.remove('qwenToken').catch(() => {});
        return false;
      }
      if (type === 'QWEN_WAF_RETRY_RESULT') {
        void handleWafRetryResult(message?.payload).then(sendResponse).catch((error) => {
          sendResponse({ ok: false, message: String(error?.message || error) });
        });
        return true;
      }
      if (type === 'QWEN_OPEN_LOGIN') {
        void (async () => {
          try {
            const client = global.BjtuQwenClient;
            if (!client) throw new Error('通义千问客户端未就绪');
            const auth = message?.payload?.auth === true;
            const validationUrl = String(message?.payload?.validationUrl || '');
            if (!auth) {
              if (!validationUrl) throw new Error('风控响应中没有可用的 data.url，无法打开验证窗口');
              const state = await beginWafPopupFlow(validationUrl);
              sendResponse({ ok: true, flowId: state.flowId });
              return;
            }
            await rememberQwenLoginOrigin(sender);
            const openResult = await client.openLoginPage();
            sendResponse({ ok: true, tabId: Number(openResult?.tab?.id) || null });
          } catch (error) {
            sendResponse({ ok: false, message: String(error?.message || error) });
          }
        })();
        return true;
      }
      if (type === 'QWEN_LIST_MODELS') {
        void (async () => {
          try {
            const client = global.BjtuQwenClient;
            if (!client) throw new Error('通义千问客户端未就绪');
            const models = await client.fetchModels();
            sendResponse({ ok: true, models });
          } catch (error) {
            sendResponse({ ok: false, message: String(error?.message || error), code: String(error?.code || '') });
          }
        })();
        return true;
      }
      if (type === 'QWEN_BUILD_SYSTEM_PROMPT') {
        const agent = global.BjtuQwenAgent;
        const operations = global.BJTUCA;
        if (!agent?.buildSystemPrompt) {
          sendResponse({ ok: false, message: '通义千问代理未就绪' });
          return false;
        }
        void (async () => {
          try {
            const qwenDocs = [
              operations?.getDocs?.('api.operationList')?.doc,
              operations?.getDocs?.('api.getDocs')?.doc
            ].filter(Boolean).join('\n\n');
            sendResponse({ ok: true, text: await agent.buildSystemPrompt({ qwenDocs }) });
          } catch (error) {
            sendResponse({ ok: false, message: String(error?.message || error) });
          }
        })();
        return true;
      }
      if (type === 'QWEN_SETTINGS_GET') {
        void getSettings().then((settings) => sendResponse({ ok: true, ...settings }));
        return true;
      }
      if (type === 'QWEN_SETTINGS_SET') {
        void saveSettings(message?.payload || {}).then((settings) => sendResponse({ ok: true, ...settings }));
        return true;
      }
      return false;
    });
  }

  if (typeof chrome === 'object' && chrome?.cookies?.onChanged) {
    chrome.cookies.onChanged.addListener((changeInfo) => {
      const cookie = changeInfo?.cookie;
      if (String(cookie?.name || '') !== 'token') return;
      const domain = String(cookie?.domain || '').replace(/^\./, '').toLowerCase();
      if (domain !== 'chat.qwen.ai' && !domain.endsWith('.qwen.ai')) return;
      if (changeInfo?.removed || !String(cookie?.value || '').trim()) {
        void chrome.storage.session.remove('qwenToken').catch(() => {});
        return;
      }
      void completeQwenLogin(cookie.value);
    });
  }

  // 捕获 chat.qwen.ai 页面自身 API 请求中 baxia 动态生成的反爬标头（bx-ua /
  // bx-umidtoken），存入 session 存储供扩展请求复用，降低触发风控（WAF punish）的概率。
  if (typeof chrome === 'object' && chrome?.webRequest?.onBeforeSendHeaders) {
    chrome.webRequest.onBeforeSendHeaders.addListener(
      (details) => {
        try {
          if (details.initiator !== 'https://chat.qwen.ai') return;
          const headers = details?.requestHeaders || [];
          const pick = (name) => {
            const lower = name.toLowerCase();
            const item = headers.find((h) => String(h?.name || '').toLowerCase() === lower);
            return String(item?.value || '');
          };
          const bxUa = pick('bx-ua');
          if (!bxUa) return;
          void chrome.storage.session.set({
            qwenAntiBotHeaders: {
              bxUa,
              bxUmidtoken: pick('bx-umidtoken'),
              bxVersion: pick('bx-v'),
              capturedAt: Date.now()
            }
          }).catch(() => {});
        } catch {
          // 忽略捕获失败
        }
      },
      { urls: ['https://chat.qwen.ai/api/*'] },
      ['requestHeaders']
    );
  }
})(globalThis);
