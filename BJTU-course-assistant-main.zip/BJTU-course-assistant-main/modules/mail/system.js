(function (global) {
  'use strict';

  const MIS_SSO_URL = 'https://mis.bjtu.edu.cn/osys_sso_email/';
  const MAIL_HOME_URL = 'https://mail.bjtu.edu.cn/';
  const FOLDERS_URL = 'https://mail.bjtu.edu.cn/coremail/XT/jsp/mail.jsp';
  const LIST_THREADS_URL = 'https://mail.bjtu.edu.cn/coremail/s/json';
  const READ_MESSAGE_URL = 'https://mail.bjtu.edu.cn/coremail/XT/jsp/readMessage.jsp';

  const ENABLED_KEY = 'mailMonitorEnabled';
  const INTERVAL_KEY = 'mailMonitorIntervalMinutes';
  const LIST_LIMIT_KEY = 'mailListLimit';
  const SNAPSHOTS_KEY = 'mailSnapshots';
  const PENDING_NOTIFICATIONS_KEY = 'mailPendingNotifications';
  const NOTIFICATION_TARGETS_KEY = 'mailNotificationTargets';
  const STATUS_KEY = 'mailMonitorStatus';
  const ALARM_NAME = 'bjtu-mail-check';
  const NOTIFICATION_PREFIX = 'bjtu-mail-new:';

  const DEFAULT_INTERVAL_MINUTES = 10;
  const MAX_INTERVAL_MINUTES = 525600;
  const DEFAULT_LIST_LIMIT = 10;
  const INBOX_FID = 1;

  let cachedSid = '';
  let cachedInboxTotal = 0;
  let mailCheckPromise = null;
  let mailProcessPromise = Promise.resolve();
  const mailContentCache = new Map();

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
  }

  function shortHash(value) {
    let hash = 2166136261;
    for (const ch of String(value || '')) {
      hash ^= ch.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  async function broadcastData(kind, payload) {
    try {
      chrome.runtime.sendMessage({
        type: 'MAIL_DATA_UPDATED',
        payload: { kind, ...payload, ts: Date.now() }
      }, () => { void chrome.runtime.lastError; });
    } catch {
      // No extension page may be open.
    }
  }

  function createSystemNotification(notificationId, options) {
    if (globalThis.BjtuSystemNotifications?.create) {
      return globalThis.BjtuSystemNotifications.create(notificationId, options, 'mail');
    }
    return new Promise((resolve, reject) => {
      chrome.notifications.create(notificationId, options, () => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message || '创建邮件通知失败'));
        else resolve(notificationId);
      });
    });
  }

  // sid 获取：GET MIS 邮箱 SSO 入口并跟随跳转，最终落在
  // https://mail.bjtu.edu.cn/coremail/main.jsp?sid={sid}（需已完成 CAS 登录）。
  async function resolveMailSid() {
    const response = await fetch(MIS_SSO_URL, {
      credentials: 'include', cache: 'no-store', redirect: 'follow',
      signal: AbortSignal.timeout(20000)
    });
    let parsed = null;
    try { parsed = new URL(String(response.url || '')); } catch { parsed = null; }
    if ((parsed?.hostname === 'sso.bjtu.edu.cn' && /^\/(?:o\/authorize|sso\/login)(?:\/|$)/i.test(parsed.pathname))
        || (parsed?.hostname === 'mis.bjtu.edu.cn' && /^\/auth\//i.test(parsed.pathname))) {
      throw Object.assign(new Error('MIS 尚未登录，请先登录 MIS 后重试'), { code: 'mis-login-required' });
    }
    if (parsed?.hostname === 'cas.bjtu.edu.cn' && /^\/auth\/login(?:\/|$)/i.test(parsed.pathname)) {
      throw Object.assign(new Error('CAS 未登录'), { code: 'not-logged-in' });
    }
    if (parsed?.hostname !== 'mail.bjtu.edu.cn') {
      throw new Error(`邮件系统跳转异常：${String(response.url || '无最终地址')}`);
    }
    let sid = String(parsed.searchParams.get('sid') || '').trim();
    if (!sid) {
      const cookie = await chrome.cookies.get({
        url: 'https://mail.bjtu.edu.cn/', name: 'Coremail.sid'
      }).catch(() => null);
      sid = String(cookie?.value || '').trim();
    }
    if (!sid) throw new Error('未能获取邮件系统 sid');
    return sid;
  }

  // 按统一身份认证的平台选择恢复登录，再重新经 MIS 换取邮箱会话。
  async function loginIdentityForMail() {
    const internals = global.BjtuSsoSystemInternals;
    if (!internals?.loginSelectedSavedAccount) {
      throw Object.assign(new Error('统一身份认证模块不可用，无法自动登录'), { code: 'not-logged-in' });
    }
    await internals.loginSelectedSavedAccount();
    await wait(300);
  }

  async function getMailSid({ allowRelogin = true } = {}) {
    if (cachedSid) return cachedSid;
    try {
      cachedSid = await resolveMailSid();
      return cachedSid;
    } catch (error) {
      if (!allowRelogin || !['not-logged-in', 'mis-login-required'].includes(error?.code)) throw error;
      await loginIdentityForMail();
      cachedSid = await resolveMailSid();
      return cachedSid;
    }
  }

  function invalidateSid() {
    cachedSid = '';
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'include',
      cache: 'no-store',
      signal: AbortSignal.timeout(20000),
      ...options
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    try {
      return JSON.parse(text.trim());
    } catch {
      throw new Error(`响应不是有效 JSON：${text.slice(0, 120)}`);
    }
  }

  // var[1].stats.unreadMessageCount 为未读消息数；异常时退化为扫描含 stats 的目录项。
  function extractUnreadCount(data) {
    const list = Array.isArray(data?.var) ? data.var : [];
    const preferred = Number(list[1]?.stats?.unreadMessageCount);
    if (Number.isFinite(preferred)) return preferred;
    for (const item of list) {
      const count = Number(item?.stats?.unreadMessageCount);
      if (Number.isFinite(count)) return count;
    }
    return null;
  }

  async function fetchUnreadCount(sid) {
    const params = new URLSearchParams({ func: 'getAllFolders', sid, stats: 'true', threads: 'true' });
    const data = await requestJson(`${FOLDERS_URL}?${params.toString()}`, { method: 'POST' });
    if (data?.code !== 'S_OK') throw new Error(`读取邮箱目录失败：${data?.code || '无响应码'}`);
    return extractUnreadCount(data);
  }

  let unreadRefresh;
  function refreshUnreadCount() {
    return unreadRefresh ??= (async () => {
      await mailCheckPromise?.catch(() => {});
      let unreadCount;
      try {
        const sid = await getMailSid({allowRelogin:false});
        try { unreadCount = await fetchUnreadCount(sid); }
        catch {
          invalidateSid();
          unreadCount = await fetchUnreadCount(await getMailSid({allowRelogin:false}));
        }
      } catch (error) {
        if (!['not-logged-in','mis-login-required'].includes(error?.code)) throw error;
        unreadCount = null;
      }
      const save = mailProcessPromise.then(async () => {
        const stored = await chrome.storage.local.get(STATUS_KEY);
        await chrome.storage.local.set({[STATUS_KEY]:{...stored[STATUS_KEY],unreadCount}});
      });
      mailProcessPromise = save.catch(() => {});
      await save;
      return unreadCount;
    })().finally(() => { unreadRefresh = null; });
  }

  function normalizeMailRow(row) {
    const source = row && typeof row === 'object' ? row : {};
    const id = String(source.id || '').trim();
    // 兼容原始响应（flags.read）与已规范化的行（read）。
    const read = typeof source.read === 'boolean' ? source.read : source.flags?.read === true;
    const attached = typeof source.attached === 'boolean'
      ? source.attached
      : source.flags?.attached === true;
    return {
      id,
      fid: Number(source.fid || INBOX_FID),
      subject: String(source.subject || '').replace(/\s+/g, ' ').trim(),
      from: String(source.from || '').replace(/\s+/g, ' ').trim(),
      sender: String(source.sender || '').trim(),
      to: String(source.to || '').replace(/\s+/g, ' ').trim(),
      summary: String(source.summary || '').replace(/\s+/g, ' ').trim(),
      sentDate: String(source.sentDate || '').trim(),
      receivedDate: String(source.receivedDate || '').trim(),
      modifiedDate: String(source.modifiedDate || '').trim(),
      read,
      attached,
      threadMessageCount: Number(source.threadMessageCount || 0)
    };
  }

  function mailFingerprint(row) {
    return JSON.stringify([
      row.subject, row.from, row.receivedDate, row.sentDate,
      row.read, row.threadMessageCount
    ]);
  }

  // limit 允许为 0（此时 summaryWindowSize 同样为 0）；
  // null/留空时不传 limit，summaryWindowSize 取已知收件箱总数（首次未知时退化为 100）。
  async function fetchInboxThreads(sid, limit = null, summaryWindowSizeHint = 0) {
    const params = new URLSearchParams({ func: 'mbox:listThreads', sid });
    const body = {
      start: 0,
      mode: 'count',
      order: 'date',
      desc: true,
      returnTotal: true,
      returnTag: false,
      fid: INBOX_FID,
      mboxa: '',
      topFirst: true
    };
    const hasExplicitLimit = !(limit === null || limit === undefined
      || String(limit).trim() === '');
    const requested = hasExplicitLimit ? Number(limit) : NaN;
    if (Number.isFinite(requested) && requested >= 0) {
      body.limit = Math.floor(requested);
      body.summaryWindowSize = body.limit;
    } else {
      const hint = Math.floor(Number(summaryWindowSizeHint) || 0);
      body.summaryWindowSize = hint > 0 ? hint : 100;
    }
    const data = await requestJson(`${LIST_THREADS_URL}?${params.toString()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json;charset=UTF-8', Accept: 'application/json' },
      body: JSON.stringify(body)
    });
    if (data?.code !== 'S_OK') throw new Error(`读取收件箱失败：${data?.code || '无响应码'}`);
    const rows = (Array.isArray(data?.var) ? data.var : []).map(normalizeMailRow).filter((row) => row.id);
    const total = Number(data?.total ?? rows.length);
    cachedInboxTotal = Number.isFinite(total) ? total : cachedInboxTotal;
    return { rows, total };
  }

  async function fetchMailContent(mid, { allowSessionRetry = true } = {}) {
    const messageId = String(mid || '').trim();
    if (!messageId) throw new Error('缺少邮件 ID');
    const sid = await getMailSid();
    const cacheKey = `${sid}|${messageId}`;
    if (mailContentCache.has(cacheKey)) return mailContentCache.get(cacheKey);
    const data = await requestJson(READ_MESSAGE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        Accept: 'application/json, text/javascript, */*; q=0.01'
      },
      body: new URLSearchParams({ mid: messageId }).toString()
    });
    if (data?.code !== 'S_OK') {
      const message = `${data?.code || '无响应码'}${data?.message ? ` ${data.message}` : ''}`;
      if (allowSessionRetry && /\bFA_SECURITY\b/i.test(message)) {
        invalidateSid();
        return fetchMailContent(messageId, { allowSessionRetry: false });
      }
      throw new Error(`读取邮件内容失败：${message}`);
    }
    const mail = data?.var?.mail;
    const attachments = (Array.isArray(mail?.attachments) ? mail.attachments : [])
      .map((attachment) => ({
        id: String(attachment?.id || '').trim(),
        filename: String(attachment?.filename || '').trim() || '未命名附件',
        contentType: String(attachment?.contentType || '').trim(),
        contentLength: Math.max(0, Number(attachment?.contentLength) || 0),
        estimateSize: Math.max(0, Number(attachment?.estimateSize) || 0)
      }))
      .filter((attachment) => attachment.id);
    const result = { content: mail?.mainPartData?.content, attachments, mid: messageId };
    mailContentCache.set(cacheKey, result);
    if (mailContentCache.size > 100) mailContentCache.delete(mailContentCache.keys().next().value);
    return result;
  }

  async function downloadAuthenticatedMailUrl(rawUrl) {
    const url = new URL(String(rawUrl || ''));
    if (url.protocol !== 'https:' || url.hostname !== 'mail.bjtu.edu.cn' || !url.pathname.startsWith('/coremail/')) {
      throw new Error('只允许下载 BJTU 邮件系统附件');
    }
    await getMailSid();
    const downloadId = await new Promise((resolve, reject) => {
      chrome.downloads.download({ url: url.href, saveAs: false }, (id) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message || '附件下载失败'));
        else resolve(id);
      });
    });
    return { downloadId };
  }

  function normalizeListLimit(value) {
    if (String(value ?? '').trim() === '') return null;
    const number = Math.floor(Number(value));
    return Number.isFinite(number) && number >= 0 ? number : DEFAULT_LIST_LIMIT;
  }

  // 邮箱用户信息：email 为邮箱地址，true_name 为姓名。
  // 部分会话形态下携带 optionalAttrIds 会返回 FA_SECURITY，
  // 因此依次尝试多种请求形态，取首个 S_OK 的响应。
  async function fetchMailUser(sid) {
    const params = new URLSearchParams({ func: 'user:getAttrs', sid: String(sid || '') });
    const url = `${LIST_THREADS_URL}?${params.toString()}`;
    const jsonHeaders = { 'Content-Type': 'application/json;charset=UTF-8', Accept: 'application/json' };
    const attempts = [
      {
        label: 'json:optionalAttrIds',
        options: {
          method: 'POST',
          headers: jsonHeaders,
          body: JSON.stringify({ optionalAttrIds: ['email', 'true_name'] })
        }
      },
      { label: 'json:empty', options: { method: 'POST', headers: jsonHeaders, body: '{}' } },
      { label: 'empty-body', options: { method: 'POST', headers: { Accept: 'application/json' } } },
      {
        label: 'form:optionalAttrIds',
        options: {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
            Accept: 'application/json'
          },
          body: new URLSearchParams({
            optionalAttrIds: JSON.stringify(['email', 'true_name'])
          }).toString()
        }
      }
    ];
    let lastMessage = '';
    for (const attempt of attempts) {
      let data;
      try {
        data = await requestJson(url, attempt.options);
      } catch (error) {
        lastMessage = String(error?.message || error);
        continue;
      }
      if (data?.code !== 'S_OK') {
        lastMessage = `${data?.code || '无响应码'}${data?.message ? ` ${data.message}` : ''}`;
        continue;
      }
      const attrs = data?.var && typeof data.var === 'object' ? data.var : {};
      return {
        email: String(attrs.email || ''),
        trueName: String(attrs.true_name || ''),
        ou: String(attrs['@ou'] || '')
      };
    }
    throw new Error(`读取邮箱用户信息失败：${lastMessage || '所有请求方式均被拒绝'}`);
  }

  async function getCurrentMailUser({ forceNewSid = false } = {}) {
    // 强制重新经 osys_sso_email 换取新 sid，失效时按平台选择使用已保存凭据登录。
    if (forceNewSid) invalidateSid();
    while (true) {
      const sid = await getMailSid();
      try {
        return await fetchMailUser(sid);
      } catch (error) {
        if (!/\bFA_SECURITY\b/i.test(String(error?.message || error))) throw error;
        invalidateSid();
        await wait(1000);
      }
    }
  }

  async function currentAccountKey() {
    try {
      const context = await global.BjtuSsoSystemInternals?.getContext();
      return String(context?.loginName || '').trim() || 'default';
    } catch {
      return 'default';
    }
  }

  function formatMailNotification(row) {
    const summary = String(row.summary || '');
    return [
      `发件人：${row.from || row.sender || '-'}`,
      `时间：${row.receivedDate || row.sentDate || '-'}`,
      summary ? `摘要：${summary.slice(0, 140)}${summary.length > 140 ? '…' : ''}` : ''
    ].filter(Boolean).join('\n');
  }

  // 通知点击后打开对应邮件读取页；映射持久化保存，SW 重启后仍可跳转。
  function buildMailReadUrl(target) {
    const mid = String(target?.mid || '');
    const sid = String(target?.sid || '');
    if (!mid || !sid) return MAIL_HOME_URL;
    const payload = JSON.stringify({
      fid: Number(target?.fid) || INBOX_FID,
      mid,
      mboxa: ''
    });
    return `https://mail.bjtu.edu.cn/coremail/XT/index.jsp?sid=${sid}#mail.read|${payload}`;
  }

  function mailRowsForUi(rows, sid) {
    return (Array.isArray(rows) ? rows : []).map((row) => ({
      ...row,
      readUrl: buildMailReadUrl({ sid, fid: row?.fid, mid: row?.id })
    }));
  }

  async function rememberNotificationTarget(notificationId, target) {
    if (!target?.sid || !target?.mid) return;
    const stored = await chrome.storage.local.get([NOTIFICATION_TARGETS_KEY]).catch(() => ({}));
    const targets = stored?.[NOTIFICATION_TARGETS_KEY] && typeof stored[NOTIFICATION_TARGETS_KEY] === 'object'
      ? { ...stored[NOTIFICATION_TARGETS_KEY] }
      : {};
    targets[notificationId] = { ...target, createdAt: Date.now() };
    const trimmed = Object.fromEntries(Object.entries(targets)
      .sort((a, b) => Number(b[1].createdAt || 0) - Number(a[1].createdAt || 0))
      .slice(0, 100));
    await chrome.storage.local.set({ [NOTIFICATION_TARGETS_KEY]: trimmed }).catch(() => {});
  }

  async function notifyNewMail(row, sid = '') {
    const notificationId = `${NOTIFICATION_PREFIX}${shortHash(`${row.id}|${mailFingerprint(row)}`)}`;
    await createSystemNotification(notificationId, {
      type: 'basic',
      iconUrl: 'icons/128.png',
      title: `收到新邮件：${row.subject || '(无主题)'}`,
      message: formatMailNotification(row),
      priority: 2
    });
    await rememberNotificationTarget(notificationId, { sid, fid: row.fid, mid: row.id });
    return notificationId;
  }

  function normalizePendingNotifications(value) {
    const source = value && typeof value === 'object' ? value : {};
    const result = {};
    for (const [key, item] of Object.entries(source)) {
      const row = normalizeMailRow(item?.row);
      if (!row.id) continue;
      result[key] = {
        row,
        sid: String(item?.sid || ''),
        createdAt: Number(item?.createdAt || Date.now())
      };
    }
    return result;
  }

  async function flushPendingNotifications(pendingOverride = null) {
    const stored = pendingOverride
      ? null
      : await chrome.storage.local.get([PENDING_NOTIFICATIONS_KEY]);
    const pending = normalizePendingNotifications(
      pendingOverride || stored?.[PENDING_NOTIFICATIONS_KEY]
    );
    let changed = false;
    for (const [key, item] of Object.entries(pending)) {
      try {
        await notifyNewMail(item.row, item.sid);
        delete pending[key];
        changed = true;
      } catch {
        // Keep failed notifications for the next alarm instead of losing them.
      }
    }
    if (changed || pendingOverride) {
      await chrome.storage.local.set({ [PENDING_NOTIFICATIONS_KEY]: pending });
    }
    return pending;
  }

  async function processMailRowsInternal(rows, total, unreadCount, source = 'poll', sid = '') {
    const normalizedRows = (Array.isArray(rows) ? rows : []).map(normalizeMailRow)
      .filter((row) => row.id);
    const stored = await chrome.storage.local.get([SNAPSHOTS_KEY, PENDING_NOTIFICATIONS_KEY, ENABLED_KEY]);
    const key = await currentAccountKey();
    const snapshots = stored?.[SNAPSHOTS_KEY] && typeof stored[SNAPSHOTS_KEY] === 'object'
      ? { ...stored[SNAPSHOTS_KEY] }
      : {};
    const previous = snapshots[key]?.rows && typeof snapshots[key].rows === 'object'
      ? snapshots[key].rows
      : null;
    const nextRows = Object.fromEntries(normalizedRows.map((row) => [row.id, row]));
    const changes = [];
    const notificationsEnabled = stored?.[ENABLED_KEY] !== false;
    // 首次检测仅建立基线，避免把历史邮件全部当作新邮件通知。
    if (previous && notificationsEnabled) {
      for (const row of normalizedRows) {
        if (!previous[row.id]) changes.push(row);
      }
    }
    const pending = normalizePendingNotifications(stored?.[PENDING_NOTIFICATIONS_KEY]);
    for (const row of changes) {
      // 已读邮件（如已在其他端阅读过）只入基线，不发系统通知。
      if (row.read === true) continue;
      pending[shortHash(`${key}|new|${row.id}|${mailFingerprint(row)}`)] = {
        row,
        sid,
        createdAt: Date.now()
      };
    }
    const checkedAt = Date.now();
    snapshots[key] = { rows: nextRows, updatedAt: checkedAt };
    await chrome.storage.local.set({
      [SNAPSHOTS_KEY]: snapshots,
      [PENDING_NOTIFICATIONS_KEY]: pending,
      [STATUS_KEY]: {
        status: 'ok', total, unreadCount,
        count: normalizedRows.length, changes: changes.length, checkedAt
      }
    });
    broadcastData('threads', {
      rows: mailRowsForUi(normalizedRows, sid), total, unreadCount, checkedAt
    });
    const remainingPending = await flushPendingNotifications(pending);
    return {
      count: normalizedRows.length,
      changes: changes.length,
      pendingNotifications: Object.keys(remainingPending).length,
      baseline: !previous,
      rows: normalizedRows,
      total,
      unreadCount,
      checkedAt
    };
  }

  function processMailRows(rows, total, unreadCount, source = 'poll', sid = '') {
    const run = mailProcessPromise.then(
      () => processMailRowsInternal(rows, total, unreadCount, source, sid)
    );
    mailProcessPromise = run.catch(() => {});
    return run;
  }

  async function checkMail(source = 'poll', { force = false, listLimit } = {}) {
    if (mailCheckPromise) return mailCheckPromise;
    mailCheckPromise = (async () => {
      const settings = await chrome.storage.local.get([ENABLED_KEY, LIST_LIMIT_KEY, STATUS_KEY]);
      if (!force && settings?.[ENABLED_KEY] === false) return { skipped: true };
      // 显式传入 listLimit 时优先使用（undefined 表示跟随选项设置）。
      const effectiveListLimit = listLimit === undefined
        ? normalizeListLimit(settings?.[LIST_LIMIT_KEY] ?? DEFAULT_LIST_LIMIT)
        : normalizeListLimit(listLimit);
      // 不传 limit 时 summaryWindowSize 使用已知收件箱总数。
      const summaryWindowSizeHint = cachedInboxTotal
        || Number(settings?.[STATUS_KEY]?.total) || 0;
      try {
        await flushPendingNotifications();
        let sid = await getMailSid();
        let unreadCount;
        let threads;
        try {
          [unreadCount, threads] = await Promise.all([
            fetchUnreadCount(sid), fetchInboxThreads(sid, effectiveListLimit, summaryWindowSizeHint)
        ]);
        } catch (error) {
          // sid 可能已过期：重置后经 CAS 重新获取一次。
          invalidateSid();
          sid = await getMailSid();
          [unreadCount, threads] = await Promise.all([
            fetchUnreadCount(sid), fetchInboxThreads(sid, effectiveListLimit, summaryWindowSizeHint)
          ]).catch(() => { throw error; });
        }
        return await processMailRows(threads.rows, threads.total, unreadCount, source, sid);
      } catch (error) {
        invalidateSid();
        await chrome.storage.local.set({
          [STATUS_KEY]: {
            status: 'error', error: String(error?.message || error),
            code: String(error?.code || ''), checkedAt: Date.now()
          }
        }).catch(() => {});
        broadcastData('status', {});
        throw error;
      }
    })().finally(() => { mailCheckPromise = null; });
    return mailCheckPromise;
  }

  function normalizeIntervalMinutes(value) {
    const minutes = Math.round(Number(value));
    return Number.isFinite(minutes) && minutes >= 1 && minutes <= MAX_INTERVAL_MINUTES
      ? minutes
      : DEFAULT_INTERVAL_MINUTES;
  }

  async function ensureAlarm() {
    const stored = await chrome.storage.local.get([INTERVAL_KEY]).catch(() => ({}));
    const interval = normalizeIntervalMinutes(stored?.[INTERVAL_KEY]);
    const existing = await chrome.alarms.get(ALARM_NAME).catch(() => null);
    if (existing && Number(existing.periodInMinutes || 0) === interval) return existing;
    if (existing) await chrome.alarms.clear(ALARM_NAME).catch(() => false);
    chrome.alarms.create(ALARM_NAME, { delayInMinutes: interval, periodInMinutes: interval });
    return chrome.alarms.get(ALARM_NAME).catch(() => null);
  }

  function scheduleMailChecks() {
    checkMail('scheduled').catch(() => {});
  }

  async function buildMailContext() {
    const stored = await chrome.storage.local.get([
      ENABLED_KEY, INTERVAL_KEY, LIST_LIMIT_KEY, STATUS_KEY
    ]);
    let casLoginName = '';
    try {
      const casContext = await global.BjtuSsoSystemInternals?.getContext();
      casLoginName = String(casContext?.loginName || '');
    } catch {
      casLoginName = '';
    }
    return {
      ok: true,
      enabled: stored?.[ENABLED_KEY] !== false,
      intervalMinutes: normalizeIntervalMinutes(stored?.[INTERVAL_KEY]),
      listLimit: normalizeListLimit(stored?.[LIST_LIMIT_KEY] ?? DEFAULT_LIST_LIMIT),
      status: stored?.[STATUS_KEY] || null,
      casLoginName
    };
  }

  async function checkMailForUi(args = {}) {
    const options = args && typeof args === 'object' ? args : {};
    const result = await checkMail('manual', {
      force: true,
      listLimit: Object.prototype.hasOwnProperty.call(options, 'limit')
        ? options.limit
        : undefined
    });
    return {
      ...result,
      rows: mailRowsForUi(result?.rows, cachedSid)
    };
  }

  if (typeof chrome === 'object' && chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === 'MAIL_REFRESH_UNREAD_COUNT') {
        refreshUnreadCount().then(
          unreadCount => sendResponse({ok:true,unreadCount}),
          error => sendResponse({ok:false,message:String(error?.message || error)})
        );
        return true;
      }
      if (message?.type === 'MAIL_GET_CONTEXT') {
        buildMailContext()
          .then((result) => sendResponse(result))
          .catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
        return true;
      }
      if (message?.type === 'MAIL_LOAD_THREADS') {
        checkMailForUi(message?.payload || {})
          .then((result) => sendResponse({ ok: true, ...result }))
          .catch((error) => sendResponse({
            ok: false,
            code: String(error?.code || ''),
            message: String(error?.message || error)
          }));
        return true;
      }
      if (message?.type === 'MAIL_OPEN_MESSAGE') {
        const mid = String(message?.payload?.mid || '').trim();
        const fid = Number(message?.payload?.fid) || INBOX_FID;
        if (!mid) {
          sendResponse({ ok: false, message: '缺少邮件 ID' });
          return false;
        }
        void getMailSid().then((sid) => globalThis.BjtuTabs.create({
          url: buildMailReadUrl({ sid, fid, mid }),
          active: true
        })).then(() => sendResponse({ ok: true })).catch((error) => {
          sendResponse({ ok: false, message: String(error?.message || error) });
        });
        return true;
      }
      if (message?.type === 'MAIL_GET_MESSAGE_ATTACHMENTS' || message?.type === 'MAIL_GET_MESSAGE_CONTENT') {
        fetchMailContent(message?.payload?.mid)
          .then((result) => {
            if (message.type === 'MAIL_GET_MESSAGE_ATTACHMENTS') {
              sendResponse({ ok: true, attachments: result.attachments, mid: result.mid });
            } else {
              if (typeof result.content !== 'string') throw new Error('邮件正文响应中没有 var.mail.mainPartData.content');
              sendResponse({ ok: true, content: result.content, mid: result.mid });
            }
          })
          .catch((error) => sendResponse({
            ok: false,
            code: String(error?.code || ''),
            message: String(error?.message || error)
          }));
        return true;
      }
      if (message?.type === 'MAIL_DOWNLOAD_AUTHENTICATED_URL') {
        downloadAuthenticatedMailUrl(message?.payload?.url)
          .then((result) => sendResponse({ ok: true, ...result }))
          .catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
        return true;
      }
      if (message?.type === 'MAIL_GET_USER_INFO') {
        getCurrentMailUser(message?.payload || {})
          .then((result) => sendResponse({ ok: true, ...result }))
          .catch(async (error) => {
            if (error?.code === 'identity-no-saved-account' && message.payload?.promptIdentityLogin === true
                && message.payload?.identityPanelVisible !== true) {
              await global.BjtuSsoSystemInternals?.openLoginOptions?.(_sender.url).catch(() => {});
            }
            sendResponse({ ok: false, code: String(error?.code || ''), message: String(error?.message || error) });
          });
        return true;
      }
      // 纯探测：只检查能否取得 sid，不触发 CAS 自动登录。
      if (message?.type === 'MAIL_LOGIN_STATUS') {
        resolveMailSid()
          .then((sid) => sendResponse({ ok: true, loggedIn: true, sid }))
          .catch((error) => sendResponse({
            ok: false,
            loggedIn: false,
            code: String(error?.code || ''),
            message: String(error?.message || error)
          }));
        return true;
      }
      return false;
    });

    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm?.name === ALARM_NAME) scheduleMailChecks();
    });

    chrome.runtime.onInstalled.addListener(() => { void ensureAlarm(); scheduleMailChecks(); });
    chrome.runtime.onStartup.addListener(() => { void ensureAlarm(); scheduleMailChecks(); });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local'
        || (!changes[ENABLED_KEY] && !changes[INTERVAL_KEY])) return;
      void ensureAlarm();
      if (changes[ENABLED_KEY]) {
        if (changes[ENABLED_KEY].newValue !== false) checkMail('enabled').catch(() => {});
        else chrome.storage.local.remove([PENDING_NOTIFICATIONS_KEY]).catch(() => {});
      }
    });

    chrome.notifications.onClicked.addListener((notificationId) => {
      if (!String(notificationId || '').startsWith(NOTIFICATION_PREFIX)) return;
      void (async () => {
        let url = MAIL_HOME_URL;
        try {
          const stored = await chrome.storage.local.get([NOTIFICATION_TARGETS_KEY]);
          const targets = stored?.[NOTIFICATION_TARGETS_KEY];
          const target = targets?.[notificationId];
          url = buildMailReadUrl(target);
          if (target) {
            delete targets[notificationId];
            await chrome.storage.local.set({ [NOTIFICATION_TARGETS_KEY]: targets });
          }
        } catch {
          // Fall back to the mailbox home page.
        }
        await globalThis.BjtuTabs.create({ url, active: true }).catch(() => {});
        chrome.notifications.clear(notificationId, () => void chrome.runtime.lastError);
      })();
    });

    void ensureAlarm();
  }

  global.BjtuMailSystemInternals = {
    getContext: () => buildMailContext(),
    checkNow: (args) => checkMailForUi(args),
    getUserInfo: (args) => getCurrentMailUser(args),
    resolveMailSid,
    getMailSid,
    extractUnreadCount,
    normalizeMailRow,
    mailFingerprint,
    parseInboxResponse: (data) => ({
      rows: (Array.isArray(data?.var) ? data.var : []).map(normalizeMailRow),
      total: Number(data?.total ?? 0)
    })
  };
})(globalThis);
