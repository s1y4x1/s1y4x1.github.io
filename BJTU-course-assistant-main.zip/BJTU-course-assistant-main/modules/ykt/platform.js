const YKT_WECHAT_QR_LOGIN_URL = 'https://open.weixin.qq.com/connect/qrconnect?appid=wxda8c70bb118d342b&scope=snsapi_login&redirect_uri=https://www.yuketang.cn/api/v3/user/login/wechat-web-callback';
const YKT_WECHAT_LOGIN_SUCCESS_URL_PREFIX = 'https://www.yuketang.cn/authorize/wx-qrlogin?success=1';
let yktLoginAssistPollTimer = null;
let yktLoginAssistPopupWindowId = null;
let yktLoginAssistPopupTabId = null;
let yktLoginAssistCompleting = false;
let yktLoginAssistChecking = false;

// Platform-specific functions extracted from app.js. Shared helpers remain global.


function isYktHomeworkPending(hw) {
  if (Number(hw?.__actype ?? hw?.actype) === 14) {
    return hw?.attend_status !== true && hw?.is_finished !== true;
  }
  return !isYktHomeworkDone(hw) && !isDeadlinePassed(hw?.end);
}

function isYktHomeworkOverdue(hw) {
  if (Number(hw?.__actype ?? hw?.actype) === 14) {
    return hw?.attend_status !== true && hw?.is_finished === true;
  }
  return !isYktHomeworkDone(hw) && isDeadlinePassed(hw?.end);
}

function formatYktDateTime(ts) {
  const n = parseDeadlineToTs(ts);
  if (!n) return '无';
  const d = new Date(n);
  if (Number.isNaN(d.getTime())) return '无';
  const pad = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}


function removeYktLoginSection() {
  const old = document.getElementById('ykt-extra-wrapper');
  if (old) old.remove();
}

function clearYktStandaloneCards() {
  const cards = courseListDiv.querySelectorAll('.ykt-standalone-card');
  cards.forEach((n) => n.remove());
  updateCourseListEmptyPlaceholder();
}

function stopYktLoginAssistWatcher() {
  if (yktLoginAssistPollTimer) {
    clearInterval(yktLoginAssistPollTimer);
    yktLoginAssistPollTimer = null;
  }
}

function isYktLoginSuccessUrl(url) {
  try {
    const parsed = new URL(String(url || '').trim());
    const expected = new URL(YKT_WECHAT_LOGIN_SUCCESS_URL_PREFIX);
    return parsed.origin === expected.origin
      && parsed.pathname === expected.pathname
      && parsed.searchParams.get('success') === '1';
  } catch {
    return false;
  }
}

function failYktLoginAssistAfterUserClose({ windowId = null, tabId = null } = {}) {
  const matchesWindow = windowId != null
    && Number(windowId) === Number(yktLoginAssistPopupWindowId);
  const matchesTab = tabId != null
    && Number(tabId) === Number(yktLoginAssistPopupTabId);
  if ((!matchesWindow && !matchesTab) || yktLoginAssistCompleting) return;
  yktLoginAssistPopupWindowId = null;
  yktLoginAssistPopupTabId = null;
  stopYktLoginAssistWatcher();
  if (!window.platformInteractiveLoginPending?.ykt) return;
  window.platformInteractiveLoginPending.ykt = false;
  setPlatformLoginState('ykt', 'offline');
}

if (chrome?.windows?.onRemoved) {
  chrome.windows.onRemoved.addListener((windowId) => {
    failYktLoginAssistAfterUserClose({ windowId });
  });
}

if (chrome?.tabs?.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    failYktLoginAssistAfterUserClose({ tabId });
  });
}

function isYktSiteUrl(url) {
  try {
    return new URL(String(url || '').trim()).origin === YKT_BASE;
  } catch {
    return false;
  }
}

async function completeYktLoginAssist() {
  if (yktLoginAssistCompleting) return;
  yktLoginAssistCompleting = true;
  await closeYktLoginAssistPopup(false);
  completeExternalLoginAssist('ykt', true);
}

async function getYktLoginAssistPopupTabs() {
  const tabs = [];
  const knownTabId = Number(yktLoginAssistPopupTabId || 0);
  if (knownTabId) {
    const knownTab = await chrome.tabs.get(knownTabId).catch(() => null);
    if (knownTab) tabs.push(knownTab);
  }
  const knownWindowId = Number(yktLoginAssistPopupWindowId || 0);
  if (knownWindowId) {
    const windowTabs = await chrome.tabs.query({ windowId: knownWindowId }).catch(() => []);
    for (const tab of windowTabs) {
      if (!tabs.some((item) => Number(item?.id) === Number(tab?.id))) tabs.push(tab);
    }
  }
  const current = tabs.find((tab) => isYktLoginSuccessUrl(tab?.url))
    || tabs.find((tab) => isYktSiteUrl(tab?.url))
    || tabs[0]
    || null;
  if (current?.id) yktLoginAssistPopupTabId = Number(current.id);
  return tabs;
}

async function verifyYktLoginAfterPopupClosed() {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    if (!window.platformInteractiveLoginPending?.ykt) return false;
    try {
      const response = await fetchYktJson(YKT_COURSE_LIST_API);
      if (Number(response?.errcode) === 0) {
        await completeYktLoginAssist();
        return true;
      }
    } catch {
      // The login callback may still be committing the session cookie.
    }
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
  return false;
}

async function checkYktLoginAssistPopupUrl() {
  if (yktLoginAssistChecking || yktLoginAssistCompleting) return false;
  if (!window.platformInteractiveLoginPending?.ykt) return false;
  if (!yktLoginAssistPopupTabId && !yktLoginAssistPopupWindowId) return false;
  yktLoginAssistChecking = true;
  try {
    const tabs = await getYktLoginAssistPopupTabs();
    if (tabs.some((tab) => isYktLoginSuccessUrl(tab?.url))) {
      await completeYktLoginAssist();
      return true;
    }
    // The OAuth callback may replace/close its tab before the final YKT URL is
    // observable. The authenticated API is the authoritative completion signal.
    const response = await fetchYktJson(YKT_COURSE_LIST_API).catch(() => null);
    if (Number(response?.errcode) === 0) {
      await completeYktLoginAssist();
      return true;
    }
  } catch {
    // Keep the known IDs until verification finishes. A transient tabs.get failure can
    // happen during the success redirect while the popup window is still open.
    stopYktLoginAssistWatcher();
    void (async () => {
      if (await verifyYktLoginAfterPopupClosed()) return;
      const popupStillOpen = yktLoginAssistPopupWindowId
        ? await chrome.windows.get(Number(yktLoginAssistPopupWindowId)).then(() => true).catch(() => false)
        : false;
      if (popupStillOpen && window.platformInteractiveLoginPending?.ykt) {
        startYktLoginAssistWatcher();
} else {
        yktLoginAssistPopupWindowId = null;
        yktLoginAssistPopupTabId = null;
        window.platformInteractiveLoginPending.ykt = false;
        if (String(window.platformLoginState?.ykt || '') === 'checking') {
          setPlatformLoginState('ykt', 'offline');
        }
      }
    })();
  } finally {
    yktLoginAssistChecking = false;
  }
  return false;
}

function startYktLoginAssistWatcher() {
  stopYktLoginAssistWatcher();
  yktLoginAssistPollTimer = setInterval(() => {
    void checkYktLoginAssistPopupUrl();
  }, PLATFORM_LOGIN_ASSIST_POLL_INTERVAL_MS);
  void checkYktLoginAssistPopupUrl();
}

async function closeYktLoginAssistPopup(cancelPending = false) {
  const knownWindowId = Number(yktLoginAssistPopupWindowId || 0);
  const knownTabId = Number(yktLoginAssistPopupTabId || 0);
  yktLoginAssistPopupWindowId = null;
  yktLoginAssistPopupTabId = null;
  stopYktLoginAssistWatcher();
  if (cancelPending) {
    window.platformInteractiveLoginPending.ykt = false;
  }
  let windowId = knownWindowId;
  if (!windowId && knownTabId) {
    const tab = await chrome.tabs.get(knownTabId).catch(() => null);
    windowId = Number(tab?.windowId || 0);
  }
  if (windowId) {
    const removed = await chrome.windows.remove(windowId).then(() => true).catch(() => false);
    if (removed) return;
  }
  if (knownTabId) await chrome.tabs.remove(knownTabId).catch(() => {});
}

function openYktLoginAssistPopup(force = false) {
  if (!force && !isPlatformEnabled('ykt')) return;
  yktLoginAssistCompleting = false;
  window.platformInteractiveLoginPending.ykt = true;
  if (yktLoginAssistPopupWindowId && yktLoginAssistPopupTabId) {
    chrome.windows.update(Number(yktLoginAssistPopupWindowId), { focused: true }).catch(() => {});
    startYktLoginAssistWatcher();
    return;
  }
  const openPopup = async () => {
    const popupWidth = PLATFORM_LOGIN_ASSIST_POPUP_SIZE.width;
    const popupHeight = PLATFORM_LOGIN_ASSIST_POPUP_SIZE.height;
    let left;
    let top;
    try {
      const currentWin = await chrome.windows.getCurrent();
      if (Number.isFinite(Number(currentWin?.left)) && Number.isFinite(Number(currentWin?.top)) && Number.isFinite(Number(currentWin?.width)) && Number.isFinite(Number(currentWin?.height))) {
        left = Math.max(0, Number(currentWin.left) + Math.round((Number(currentWin.width) - popupWidth) / 2));
        top = Math.max(0, Number(currentWin.top) + Math.round((Number(currentWin.height) - popupHeight) / 2));
      }
    } catch {
      left = undefined;
      top = undefined;
    }

    const created = await chrome.windows.create({
      url: YKT_WECHAT_QR_LOGIN_URL,
      type: 'popup',
      focused: true,
      width: popupWidth,
      height: popupHeight,
      left,
      top
    });
    yktLoginAssistPopupWindowId = Number(created?.id || 0) || null;
    const tab = Array.isArray(created?.tabs) && created.tabs.length ? created.tabs[0] : null;
    yktLoginAssistPopupTabId = Number(tab?.id || 0) || null;
    startYktLoginAssistWatcher();
  };
  openPopup().catch(() => {
    showToast('打开雨课堂登录弹窗失败，请检查浏览器弹窗权限', 'error', 2200);
  });
}

function renderYktNeedLoginMessage() {
  const shouldOpenAssist = !!window.platformInteractiveLoginPending?.ykt
    || globalThis.shouldAutoLoginAfterExpiry?.('ykt') === true;
  removeYktLoginSection();
  window.platformLoadedOnce.ykt = false;
  clearPlatformData('ykt');
  rerenderAllHomeworkAreas();

  if (shouldOpenAssist) {
    // 二维码登录弹窗将打开：保持 checking，等弹窗关闭后再给出登录结果。
    setPlatformLoginState('ykt', 'checking');
    openYktLoginAssistPopup(true);
    return;
  }

  setPlatformLoginState('ykt', 'offline');
  closeYktLoginAssistPopup(true);
  window.platformNeedLogin.ykt = false;
  refreshPlatformLoginTip();
}


async function fetchYktExamPaper(courseId, examId) {
  const cid = String(courseId || '').trim();
  const eid = String(examId || '').trim();
  if (!eid) return null;

  const LOCK_MSG_RE = /同一时间只允许打开一份试卷|如需打开新的试卷，请在封面处跳转/;
  const MAX_ATTEMPTS = 4;
  let examRequestBase = YKT_EXAM_BASE;

  const establishExamSession = async () => {
    if (!cid) return '';
    await ensureYktDirectRequestHeaders();
    const csrfToken = await getYktCsrfToken();
    const tokenHeaders = {
      ...YKT_HEADERS,
      'university-id': '0',
      'Content-Type': 'application/json;charset=UTF-8'
    };
    if (csrfToken) tokenHeaders['x-csrftoken'] = csrfToken;

    // /v2/web/trans/:cid/:eid 本身只是 SPA 外壳。真正的页面逻辑先调用
    // /v/exam/gen_token，再访问考试域名的 /login 写入考试会话。
    const tokenResponse = await fetch(`${YKT_BASE}/v/exam/gen_token`, {
      method: 'POST',
      credentials: 'include',
      cache: 'no-store',
      headers: tokenHeaders,
      body: JSON.stringify({ exam_id: eid, classroom_id: cid })
    });
    const tokenText = await tokenResponse.text();
    let tokenData = null;
    try { tokenData = JSON.parse(tokenText); } catch {}
    if (!tokenResponse.ok || tokenData?.errcode || tokenData?.success !== true) return '';

    const grant = tokenData?.data || {};
    const crypt = String(grant?.token || '').trim();
    const userId = String(grant?.user_id || '').trim();
    if (!crypt || !userId) return '';
    let examBase = String(grant?.exam_host || YKT_EXAM_BASE).trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(examBase)) examBase = `https://${examBase.replace(/^\/+/, '')}`;
    const next = `${examBase}/result/${encodeURIComponent(eid)}?isFrom=2`;
    const loginUrl = new URL(`${examBase}/login`);
    loginUrl.searchParams.set('exam_id', eid);
    loginUrl.searchParams.set('user_id', userId);
    loginUrl.searchParams.set('crypt', crypt);
    loginUrl.searchParams.set('next', next);
    loginUrl.searchParams.set('language', 'zh');
    const loginResponse = await fetch(loginUrl.href, {
      method: 'GET',
      credentials: 'include',
      redirect: 'follow',
      cache: 'no-store',
      headers: { Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8' }
    });
    return loginResponse.ok ? examBase : '';
  };

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const establishedBase = await establishExamSession().catch(() => '');
    if (establishedBase) examRequestBase = establishedBase;

    try {
      const res = await fetch(`${examRequestBase}/exam_room/show_paper?exam_id=${encodeURIComponent(eid)}`, {
        method: 'GET',
        credentials: 'include',
        headers: { Accept: 'application/json, text/plain, */*' },
        cache: 'no-store'
      });
      if (Number(res.status) === 401 || Number(res.status) === 403) return null;

      const text = await res.text();
      const data = JSON.parse(String(text || '{}'));
      if (Number(data?.errcode) === 0) {
        const paper = data?.data;
        if (!paper || !Array.isArray(paper.problems)) return null;
        const resultsResponse = await fetch(`${examRequestBase}/exam_room/problem_results?exam_id=${encodeURIComponent(eid)}`, {
          method: 'GET', credentials: 'include', cache: 'no-store',
          headers: { Accept: 'application/json, text/plain, */*' }
        });
        if (!resultsResponse.ok) throw new Error(`考试作答结果 HTTP ${resultsResponse.status}`);
        const results = await resultsResponse.json();
        if (Number(results?.errcode) !== 0 || !Array.isArray(results?.data?.problem_results)) {
          throw new Error(results?.errmsg || results?.message || '考试作答结果获取失败');
        }
        return {
          ...paper,
          problems: paper.problems.map((problem, index) => ({
            ...problem,
            grade: results.data.problem_results[index]?.grade ?? null,
            finished: results.data.problem_results[index]?.finished ?? null
          }))
        };
      }

      const errText = `${String(data?.errmsg || '')} ${String(data?.message || '')}`;
      if (!LOCK_MSG_RE.test(errText) || attempt >= MAX_ATTEMPTS) {
        throw Object.assign(new Error(String(data?.errmsg || data?.message || '考试详情获取失败')), { yktApiError: true });
      }
    } catch (error) {
      if (error?.yktApiError) throw error;
      if (attempt >= MAX_ATTEMPTS) return null;
    }

    await new Promise((r) => setTimeout(r, 240));
  }

  return null;
}

async function fetchYktHomeworkDetail(homework) {
  if (Number(homework?.__actype) !== 14) {
    const paper = await fetchYktExamPaper(homework?.course_id || homework?.classroom_id, homework?.exam_id || '');
    if (!paper) throw new Error('考试详情或作答结果获取失败');
    return paper;
  }
  const lessonId = String(homework?.courseware_id || '').trim();
  if (!lessonId) throw new Error('课堂缺少 courseware_id');
  const report = await fetchYktClassroomReport(lessonId);
  const problems = [];
  for (const [key, label] of [['problem', '课堂练习'], ['quiz', '随堂测验']]) {
    const students = report[key];
    if (!Array.isArray(students)) continue;
    for (const item of students) {
      if (!item || typeof item !== 'object') continue;
      let cover = '';
      if (item.cover) {
        try {
          const url = new URL(String(item.cover), YKT_BASE);
          if (/^https?:$/.test(url.protocol)) cover = url.href;
        } catch { }
      }
      problems.push({
        ...item,
        TypeText: label,
        Body: cover ? `<img src="${escapeHtml(cover)}" alt="${label}题目" loading="lazy">` : ''
      });
    }
  }
  return { problems, classroom_report_question_count: report.questionCount };
}

function renderYktProblemsHtml(problemList, isExam = false) {
  const list = Array.isArray(problemList) ? problemList : [];
  if (!list.length) return '';
  return list.map((p, i) => {
    const typeText = String(p?.TypeText || p?.Type || '题目类型').trim();
    const rawOptions = Array.isArray(p?.Options) ? p.Options : [];
    const answered = isExam ? p?.finished : p?.isAnswered;
    const totalScore = isExam ? p?.Score ?? p?.score : p?.problemscore ?? p?.Score;
    const earnedScore = isExam ? p?.grade : p?.score;
    return globalThis.BjtuHomeworkUi.questionDetailHtml({
      index: Number(p?.index) || i + 1,
      typeText,
      score: totalScore,
      metaItems: [
        answered === undefined || answered === null ? ''
          : ([true, 1, '1', 'true'].includes(answered) ? '已作答' : '未作答'),
        earnedScore === undefined || earnedScore === null ? '' : `得分：${earnedScore}`
      ],
      bodyHtml: globalThis.BjtuHomeworkUi.sanitizeRichHtml(p?.Body || ''),
      options: rawOptions.map((option) => ({
        key: option?.key ?? option?.Key ?? '',
        valueHtml: globalThis.BjtuHomeworkUi.sanitizeRichHtml(
          option?.value ?? option?.Value ?? (typeof option === 'string' ? option : '')
        )
      })),
      emptyBodyHtml: '<span style="color:#999;">无题目内容</span>',
      escape: escapeHtml
    });
  }).join('');
}

async function loadDeferredYktHomeworkDetails(courseId, kind) {
  const cid = String(courseId || '').trim();
  const groupKind = String(kind || '').trim();
  if (!cid || !['done', 'overdue'].includes(groupKind)) return;
  const loadVersion = Number(window.platformLoadVersion?.ykt || 0);
  const isCancelled = () => (
    !isPlatformEnabled('ykt')
    || loadVersion !== Number(window.platformLoadVersion?.ykt || 0)
  );
  if (isCancelled()) return;
  window.yktDeferredDetailLoadPromises ||= {};
  const promiseKey = `${cid}:${groupKind}`;
  if (window.yktDeferredDetailLoadPromises[promiseKey]) return window.yktDeferredDetailLoadPromises[promiseKey];

  const run = (async () => {
    let items = Array.isArray(window.yktMatchedHomeworkByCourseId?.[cid])
      ? window.yktMatchedHomeworkByCourseId[cid]
      : [];
    if (!items.length && cid.startsWith('ykt-')) {
      const classroomId = cid.slice(4);
      const standalone = (window.yktStandaloneCourses || []).find((course) => String(course?.classroom_id || '') === classroomId);
      items = Array.isArray(standalone?.homeworks) ? standalone.homeworks : [];
    }
    const targets = items.filter((hw) => {
      if (![5, 14].includes(Number(hw?.__actype))) return false;
      if (!['deferred', 'failed', ''].includes(String(hw?.exam_detail_state || '').trim())) return false;
      return groupKind === 'done' ? isYktHomeworkDone(hw) : isYktHomeworkOverdue(hw);
    });
    if (!targets.length) return;

    targets.forEach((hw) => { hw.exam_detail_state = 'queued'; });
    rerenderAllHomeworkAreas();
    renderYktStandaloneCourses();

    for (const hw of targets) {
        if (isCancelled()) return;
        hw.exam_detail_state = 'loading';
        rerenderAllHomeworkAreas();
        renderYktStandaloneCourses();
        const detailKey = String(hw?.detail_cache_key || '').trim();
        try {
          if ([5, 14].includes(Number(hw?.__actype))) {
            const paper = await fetchYktHomeworkDetail(hw);
            if (paper?.title) hw.title = paper.title;
            hw.detail_problems = Array.isArray(paper?.problems) ? paper.problems : [];
            hw.classroom_report_question_count = paper?.classroom_report_question_count;
          }
          hw.exam_detail_state = 'done';
          if (detailKey) {
            window.yktDetailCacheByKey[detailKey] = {
              state: 'done', title: hw.title,
              detail_problems: Array.isArray(hw.detail_problems) ? hw.detail_problems : [],
              classroom_report_question_count: hw.classroom_report_question_count,
              promise: null
            };
          }
        } catch (error) {
          hw.exam_detail_state = 'failed';
          hw.exam_detail_error = String(error?.message || '');
          if (detailKey) window.yktDetailCacheByKey[detailKey] = { ...(window.yktDetailCacheByKey[detailKey] || {}), state: 'failed', error: hw.exam_detail_error, promise: null };
        }
        rerenderAllHomeworkAreas();
        renderYktStandaloneCourses();
    }
  })().finally(() => { delete window.yktDeferredDetailLoadPromises[promiseKey]; });
  window.yktDeferredDetailLoadPromises[promiseKey] = run;
  return run;
}

function renderYktHomeworkItems(courseId, items) {
  const visibleTypes = new Set(Array.isArray(window.yktActivityTypes) ? window.yktActivityTypes.map(Number) : [14, 15, 5, 9]);
  const list = (items || []).filter((item) => {
    const actype = Number(item?.__actype);
    return visibleTypes.has(actype);
  });
  if (!list.length) return '';
  return list.map((it, idx) => {
    const done = isYktHomeworkDone(it);
    const overdue = !done && isYktHomeworkOverdue(it);
    const progress = Number(it?.progress ?? 0);
    const problemCount = Number(it?.problem_count ?? 0);
    const examProgress = Number(it?.__actype) === 5 ? getYktExamProgress(it) : null;
    const progressText = Number(it?.__actype) === 5
      ? (examProgress ? `${examProgress.completed}/${examProgress.total}` : '')
      : (problemCount > 0 ? `${progress}/${problemCount}` : '');
    const isVideoActivity = Number(it?.__actype) === 15;
    const progressHtml = isVideoActivity
      ? globalThis.BjtuHomeworkUi.progressHtml({
          ratio: it?.video_progress_ratio,
          loading: !!it?.video_progress_loading,
          escape: escapeHtml,
          color: '#5096f5'
        })
      : (progressText ? `<div style="font-size:12px;color:#666;">进度：${escapeHtml(progressText)}</div>` : '');
    const hasScore = it?.score !== null && it?.score !== undefined && String(it.score) !== '';
    const palette = globalThis.BjtuHomeworkUi.homeworkPalette({ done, overdue });
    const actionText = globalThis.BjtuHomeworkUi.actionLabel(
      'ykt',
      done ? 'view' : (Number(it?.__actype) === 15 ? 'learn' : 'submit')
    );
    const titleScoreBadge = globalThis.BjtuHomeworkUi.scoreBadgeHtml({
      userScore: hasScore ? it.score : null,
      totalScore: hasScore ? it.total_score : null,
      escape: escapeHtml
    });
    const deadline = it?.end || it?.deadline || '';
    const yktIdSeed = String(it?.id || it?.courseware_id || it?.classroom_id || idx).trim();
    const expandKey = `ykt:${yktIdSeed}`;
    const expanded = isHomeworkDetailExpanded(courseId, expandKey);
    const actype = Number(it?.__actype);
    const isClassroomActivity = actype === 14;
    const activityTypeLabel = YKT_ACTIVITY_TYPE_LABELS[actype] || '';
    const isExam = actype === 5;
    const examDetail = isExam || isClassroomActivity ? renderYktProblemsHtml(it?.detail_problems || [], isExam) : '';
    let detailStatusHtml = '';
    if ((isExam || isClassroomActivity) && !examDetail) {
      const state = String(it?.exam_detail_state || '').trim();
      if (state === 'loading') {
        detailStatusHtml = `<div style="margin-top:6px; font-size:12px; color:${done ? '#166534' : '#9a3412'}; display:flex; align-items:center; gap:6px;"><span class="spinner" style="width:10px; height:10px; border-width:1px; border-color:${done ? '#16a34a' : '#ea580c'}; border-top-color:transparent;${globalThis.BjtuHomeworkUi.spinnerPhaseStyle()}"></span>${globalThis.BjtuHomeworkUi.text.detailLoading}</div>`;
      } else if (state === 'queued') {
        detailStatusHtml = `<div style="margin-top:6px; font-size:12px; color:${done ? '#166534' : '#9a3412'}; display:flex; align-items:center; gap:6px;"><span class="spinner" style="width:10px; height:10px; border-width:1px; border-color:${done ? '#16a34a' : '#ea580c'}; border-top-color:transparent;${globalThis.BjtuHomeworkUi.spinnerPhaseStyle()}"></span>${globalThis.BjtuHomeworkUi.text.detailQueued}</div>`;
      } else if (state === 'failed') {
        detailStatusHtml = `<div style="margin-top:6px; font-size:12px; color:#b45309;">${escapeHtml(it?.exam_detail_error || globalThis.BjtuHomeworkUi.text.detailFailed)}</div>`;
      }
    }
    const detailExpandable = examDetail
      ? renderExpandableHtml(examDetail, globalThis.BjtuHomeworkUi.detailOptions({
          emptyHtml: '<span style="color:#999;">无题目内容</span>',
          baseBg: done ? 'rgba(232,245,233,0.75)' : 'rgba(255,243,224,0.78)',
          flatDisplay: true,
          courseId,
          expandKey,
          expanded
        }))
      : '';
    return globalThis.BjtuHomeworkUi.renderHomeworkCard({
      done,
      overdue,
      deadline: isClassroomActivity ? '' : deadline,
      background: palette.background,
      border: palette.border,
      titleHtml: globalThis.BjtuHomeworkUi.titleHtml({ typeLabel: activityTypeLabel, typeHref: it.link, title: it.title || '雨课堂作业', color: palette.foreground, href: it.link, escape: escapeHtml }),
      metaHtml: `${globalThis.BjtuHomeworkUi.deadlineMetaHtml({
        deadline: isClassroomActivity ? '' : deadline,
        formatted: isClassroomActivity ? '' : formatYktDateTime(it?.end),
        startTime: it?.create_time ?? '',
        startFormatted: formatYktDateTime(it?.create_time),
        done,
        overdue,
        loading: !!Number(it?.__loading),
        showCountdown: !isClassroomActivity,
        escape: escapeHtml
      })}${progressHtml}`,
      scoreHtml: titleScoreBadge,
      actionsHtml: globalThis.BjtuHomeworkUi.renderActionLink({ href: it.link, label: actionText, color: palette.action, escape: escapeHtml }),
      detailHtml: `${detailExpandable ? `<div style="margin-top:3px;border-top:1px dashed ${palette.border}40;padding-top:0;">${detailExpandable}</div>` : ''}${detailStatusHtml}`
    });
  }).join('');
}

function renderYktStandaloneCourses() {
  return preserveCoursePlatformScroll(renderYktStandaloneCoursesNow);
}

function renderYktStandaloneCoursesNow() {
  removeYktLoginSection();
  clearYktStandaloneCards();
  const courses = window.yktStandaloneCourses || [];
  if (!courses.length) {
    updateCourseListEmptyPlaceholder();
    return;
  }

  const baseOrder = Number(courseListDiv.dataset.orderBase || 100000);
  courses.forEach((c, idx) => {
    const courseId = `ykt-${String(c.classroom_id || idx)}`;
    const courseLink = yktCourseLink(c.classroom_id);
    const teacherName = String(c.teacher_name || '').trim();
    const subText = `${teacherName ? `${teacherName} · ` : ''}${String(c.name || '').trim()}`;
    const card = globalThis.BjtuCourseCardUi.createCourseCard({
      courseId,
      className: 'ykt-standalone-card',
      order: baseOrder + idx,
      titleHtml: `<a href="${courseLink}" target="_blank" rel="noopener noreferrer" style="color:#5096f5;text-decoration:none;line-height:1.3;">${escapeHtml(c.course_name || c.name || '雨课堂课程')}</a>`,
      metaHtml: `<div class="ykt-course-meta" style="font-size:12px;color:#666;line-height:1.35;">${escapeHtml(subText)}</div>`,
      actionsHtml: '<button class="btn" style="background:#9C27B0;display:none;" data-action="videos">回放下载</button>'
    });
    courseListDiv.appendChild(card);

    if (!window.courseHomeworkData[courseId]) {
      window.courseHomeworkData[courseId] = { list: [], showOverdue: !!window.courseShowOverdueById[courseId], showDone: !!window.courseShowDoneById[courseId] };
    }
    renderHomeworkList(courseId);

    window.courseHomeworkData[courseId] = { list: [], showOverdue: !!window.courseShowOverdueById[courseId], showDone: !!window.courseShowDoneById[courseId] };
    window.yktMatchedHomeworkByCourseId[courseId] = c.homeworks || [];

    renderHomeworkList(courseId);
  });
  updateCourseListEmptyPlaceholder();
}

function buildYktEntryHomeworks(entry, acts) {
  const homeworksRaw = (Array.isArray(acts) ? acts : []).map((a) => {
    const isExam = Number(a?.__actype) === 5;
    const isCard = Number(a?.__actype) === 15;
    const isClassroomActivity = Number(a?.__actype) === 14;
    const examId = a?.courseware_id ?? a?.exam_id ?? a?.examId ?? a?.id ?? '';
    const coursewareId = a?.courseware_id;
    const leafId = a?.content?.leaf_id ?? a?.leaf_id ?? '';
    const detailKey = isExam ? `5:${String(a?.course_id || entry.classroomId)}:${String(examId || '')}`
      : isClassroomActivity ? `14:${String(entry.classroomId)}:${String(coursewareId || '')}` : '';
    const cache = detailKey ? window.yktDetailCacheByKey[detailKey] : null;
    return {
      title: a?.title || '雨课堂作业',
      end: getYktActivityDeadline(a),
      type: a?.type,
      done: (a?.view && a?.view?.done) !== undefined ? !!(a?.view && a?.view?.done) : undefined,
      unfinished: a?.unfinished,
      total: a?.total,
      progress: a?.progress,
      problem_count: a?.problem_count,
      score: a?.score,
      total_score: a?.total_score,
      attend_status: a?.attend_status,
      is_finished: a?.is_finished,
      create_time: a?.create_time,
      link: isExam
        ? yktExamLink(a?.course_id || entry.classroomId, coursewareId)
        : (isClassroomActivity
            ? yktClassroomReportLink(entry.classroomId, coursewareId, a?.id)
            : (isCard && String(leafId || '').trim()
            ? yktVideoStudentLink(entry.classroomId, leafId)
            : yktHomeworkLink(entry.classroomId, coursewareId, a?.id))),
      courseware_id: coursewareId,
      leaf_id: leafId,
      video_total_done: undefined,
      video_progress_ratio: undefined,
      video_progress_loading: isCard && !!String(coursewareId || '').trim(),
      id: a?.id,
      exam_id: examId,
      __actype: a?.__actype,
      detail_problems: Array.isArray(cache?.detail_problems) ? cache.detail_problems : [],
      classroom_report_question_count: cache?.classroom_report_question_count,
      detail_content: a?.content ?? null,
      exam_detail_state: cache?.state === 'done' ? 'done' : (cache?.state === 'failed' ? 'failed' : ''),
      exam_detail_error: cache?.error || '',
      detail_cache_key: detailKey,
      course_id: a?.course_id || entry.classroomId,
      classroom_id: entry.classroomId
    };
  });
  const seen = new Set();
  return homeworksRaw.filter((homework) => {
    const key = `${homework.classroom_id}-${homework.courseware_id}-${homework.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function loadYktCoursesAndHomework(courses, loadVersion = 0) {
  const isStale = () => (
    !isPlatformEnabled('ykt')
    || !!(loadVersion && loadVersion !== (window.platformLoadVersion?.ykt || 0))
  );
  if (isStale()) return;
  if (!isPlatformEnabled('ykt')) {
    clearPlatformData('ykt');
    window.yktHomeworkLoadingByCourse = {};
    window.yktHomeworkPendingTypesByCourse = {};
    rerenderAllHomeworkAreas();
    return;
  }
  setPlatformLoginState('ykt', 'checking');
  const strictMatchMap = new Map();

  let listResp;
  try {
    listResp = await fetchYktJson(YKT_COURSE_LIST_API);
  } catch {
    if (isStale()) return;
    renderYktNeedLoginMessage();
    return;
  }

  if (isStale()) return;
  if (Number(listResp?.errcode) !== 0) {
    window.platformLoadedOnce.ykt = true;
    renderYktNeedLoginMessage();
    return;
  }

  window.yktMatchedHomeworkByCourseId = {};
  window.yktStandaloneCourses = [];
  window.yktMatchedCourseLinkByCourseId = {};
  window.yktCourseGroupsSnapshot = [];
  window.yktHomeworkLoadingByCourse = {};
  window.yktHomeworkPendingTypesByCourse = {};

  setPlatformLoginState('ykt', 'online');
  window.platformLoadedOnce.ykt = true;
  removeYktLoginSection();

  const yktCourses = listResp?.data?.list || [];
  const requestedActypes = [...new Set(
    (Array.isArray(window.yktActivityTypes) ? window.yktActivityTypes : [14, 15, 5, 9])
      .map(Number)
      .filter((actype) => YKT_ACTIVITY_TYPE_LABELS[actype])
  )];
  const entries = [];
  const boundCourseIds = new Set();

  for (const item of yktCourses) {
    const classroomId = item?.classroom_id;
    if (!classroomId) continue;
    const name = String(item?.name || '');
    const courseName = String(item?.course?.name || item?.name || '').trim();
    const strictToken = normalizeTail10Token(item?.university_course_series_id || '');
    const matched = strictToken ? strictMatchMap.get(strictToken) : null;
    const boundCourseId = matched?.courseId ? String(matched.courseId) : '';

    const entry = {
      item,
      classroomId: String(classroomId),
      universityId: pickYktUniversityId(item, listResp?.data),
      boundCourseId,
      name,
      courseName,
      strictToken,
      homeworks: []
    };
    entries.push(entry);

    window.yktCourseGroupsSnapshot.push({
      token: strictToken || '',
      strictToken,
      name,
      teacher_name: item?.teacher?.name || '',
      classroom_id: item?.classroom_id,
      course_name: courseName || '雨课堂课程',
      homeworks: []
    });

    if (boundCourseId) {
      if (!window.yktMatchedHomeworkByCourseId[boundCourseId]) window.yktMatchedHomeworkByCourseId[boundCourseId] = [];
      window.yktMatchedCourseLinkByCourseId[boundCourseId] = yktCourseLink(item?.classroom_id);
      window.yktHomeworkLoadingByCourse[boundCourseId] = true;
      window.yktHomeworkPendingTypesByCourse[boundCourseId] = requestedActypes.map((actype) => YKT_ACTIVITY_TYPE_LABELS[actype]);
      boundCourseIds.add(boundCourseId);
    } else {
      const sid = `ykt-${String(classroomId)}`;
      window.yktHomeworkLoadingByCourse[sid] = true;
      window.yktHomeworkPendingTypesByCourse[sid] = requestedActypes.map((actype) => YKT_ACTIVITY_TYPE_LABELS[actype]);
      window.yktStandaloneCourses.push({
        name,
        teacher_name: item?.teacher?.name || '',
        classroom_id: item?.classroom_id,
        course_name: item?.course?.name || item?.name || '雨课堂课程',
        homeworks: []
      });
    }
  }

  boundCourseIds.forEach((cid) => renderHomeworkList(cid));
  renderYktStandaloneCourses();
  // 作业列表尚在发现阶段，先保留加载态；发现完成后立即切换为逐份作业详情进度。
  setPlatformContentLoadProgress('ykt', 0, 1);
  const detailQueue = [];

  const getCurrentBoundCourseId = (entry) => String(entry?.boundCourseId || '');

  const rerenderEntryCard = (entry) => {
    if (isStale()) return;
    const boundCourseId = getCurrentBoundCourseId(entry);
    if (boundCourseId) {
      renderHomeworkList(boundCourseId);
    } else {
      renderHomeworkList(`ykt-${entry.classroomId}`);
    }
  };
  const courseTasks = entries.map(async (entry, idx) => {
    if (isStale()) return;
    const acts = [];
    const updateIncrementalResult = (actype) => {
      entry.homeworks = buildYktEntryHomeworks(entry, acts);
      const snap = window.yktCourseGroupsSnapshot[idx];
      if (snap) snap.homeworks = entry.homeworks;
      const standaloneId = `ykt-${entry.classroomId}`;
      const remaining = window.yktHomeworkPendingTypesByCourse[standaloneId]
        || requestedActypes.map((item) => YKT_ACTIVITY_TYPE_LABELS[item]);
      const displayIds = [standaloneId, entry.boundCourseId, getCurrentBoundCourseId(entry)].filter(Boolean);
      displayIds.forEach((courseId) => {
        window.yktHomeworkPendingTypesByCourse[courseId] = (window.yktHomeworkPendingTypesByCourse[courseId] || remaining)
          .filter((label) => label !== YKT_ACTIVITY_TYPE_LABELS[actype]);
      });
      rematchExternalByVeCourses('ykt');
      rerenderAllHomeworkAreas();
      renderYktStandaloneCourses();
    };
    await Promise.allSettled(requestedActypes.map(async (actype) => {
      try {
        const url = `${YKT_BASE}/v2/api/web/logs/learn/${encodeURIComponent(String(entry.classroomId))}?actype=${actype}&page=0&offset=100`;
        const response = await fetchYktJson(url);
        if (isStale()) return;
        const hasExplicitError = (response?.errcode !== undefined && Number(response.errcode) !== 0)
          || response?.success === false;
        if (!hasExplicitError && Array.isArray(response?.data?.activities)) {
          acts.push(...response.data.activities.map((activity) => ({ ...activity, __actype: actype })));
        }
      } finally {
        if (!isStale()) updateIncrementalResult(actype);
      }
    }));
    if (isStale()) return;

    const homeworks = buildYktEntryHomeworks(entry, acts);

    entry.homeworks = homeworks;
    const snap = window.yktCourseGroupsSnapshot[idx];
    if (snap) snap.homeworks = homeworks;

    window.yktHomeworkLoadingByCourse[`ykt-${entry.classroomId}`] = false;
    if (entry.boundCourseId) window.yktHomeworkLoadingByCourse[entry.boundCourseId] = false;
    const currentBound = getCurrentBoundCourseId(entry);
    if (currentBound) window.yktHomeworkLoadingByCourse[currentBound] = false;

    rematchExternalByVeCourses('ykt');
    rerenderAllHomeworkAreas();
    renderYktStandaloneCourses();

    let queuedChanged = false;
    homeworks.forEach((hw) => {
      const actype = Number(hw?.__actype);
      if (![5, 14].includes(actype) || !String(actype === 14 ? hw?.courseware_id || '' : hw?.exam_id || '').trim()) return;
      if (!hw.exam_detail_state) {
        hw.exam_detail_state = 'queued';
        queuedChanged = true;
      }
      detailQueue.push({ entry, hw });
    });
    if (queuedChanged) rerenderEntryCard(entry);
  });

  await Promise.allSettled(courseTasks);
  if (isStale()) return;

  const progressByCourse = entries.map((entry) => {
    const typeStates = new Map();
    requestedActypes.forEach((actype) => {
      const items = entry.homeworks.filter((homework) => Number(homework?.__actype) === actype);
      const immediatelyComplete = actype === 9
        ? items.length
        : ([5, 14].includes(actype) ? items.filter((homework) => !String(actype === 14 ? homework?.courseware_id || '' : homework?.exam_id || '').trim()).length : 0);
      typeStates.set(actype, { total: items.length, completed: immediatelyComplete });
    });
    return typeStates;
  });
  const updateDetailProgress = () => {
    if (isStale()) return;
    if (!entries.length || !requestedActypes.length) {
      setPlatformContentLoadProgress('ykt', 0, 0);
      return;
    }
    const completed = progressByCourse.reduce((courseSum, typeStates) => {
      const courseProgress = requestedActypes.reduce((typeSum, actype) => {
        const state = typeStates.get(actype);
        return typeSum + (state?.total ? Math.min(state.completed / state.total, 1) : 1);
      }, 0) / requestedActypes.length;
      return courseSum + courseProgress;
    }, 0);
    setPlatformContentLoadProgress('ykt', completed, entries.length);
  };
  const markHomeworkDetailLoaded = (entry, homework) => {
    const courseIndex = entries.indexOf(entry);
    const state = progressByCourse[courseIndex]?.get(Number(homework?.__actype));
    if (!state) return;
    state.completed = Math.min(state.total, state.completed + 1);
    updateDetailProgress();
  };
  updateDetailProgress();

  for (const entry of entries) {
    if (isStale()) return;
    const videos = entry.homeworks.filter((hw) => Number(hw?.__actype) === 15);
    if (!videos.length) continue;
    const coursewareIds = videos.map((hw) => hw?.courseware_id).filter((id) => String(id || '').trim());
    let coursewareProgress = {};
    if (coursewareIds.length) {
      try {
        coursewareProgress = await fetchYktCoursewareProgress(
          String(entry.classroomId || '').trim(),
          coursewareIds,
          entry.universityId
        );
      } catch (error) {
        console.warn('[bjtu] ykt pub_new_pro failed:', String(error?.message || error));
      }
    }
    videos.forEach((hw) => {
      const videoProgress = normalizeYktVideoProgress(
        coursewareProgress?.[String(hw?.courseware_id || '')],
        hw?.leaf_id
      );
      hw.video_progress_loading = false;
      hw.video_total_done = videoProgress ? videoProgress.totalDone : undefined;
      hw.video_progress_ratio = videoProgress ? videoProgress.ratio : undefined;
      markHomeworkDetailLoaded(entry, hw);
    });
    rematchExternalByVeCourses('ykt');
    rerenderAllHomeworkAreas();
    renderYktStandaloneCourses();
  }
  if (detailQueue.length) await new Promise((resolve) => setTimeout(resolve, 80));

  for (const task of detailQueue) {
    if (isStale()) return;
    const { entry, hw } = task;
    const actype = Number(hw?.__actype);
    const detailKey = String(hw?.detail_cache_key || '').trim();
    const cache = detailKey ? window.yktDetailCacheByKey[detailKey] : null;

    if (cache?.state === 'done' && actype !== 14) {
      if (cache.title) hw.title = cache.title;
      hw.detail_problems = Array.isArray(cache.detail_problems) ? cache.detail_problems : [];
      hw.exam_detail_state = 'done';
      rerenderEntryCard(entry);
      markHomeworkDetailLoaded(entry, hw);
      continue;
    }

    if (cache?.state === 'loading' && cache?.promise) {
      hw.exam_detail_state = 'loading';
      await cache.promise.catch(() => {});
      const latest = window.yktDetailCacheByKey[detailKey] || {};
      if (latest.title) hw.title = latest.title;
      hw.detail_problems = Array.isArray(latest.detail_problems) ? latest.detail_problems : [];
      hw.classroom_report_question_count = latest.classroom_report_question_count;
      hw.exam_detail_state = latest.state === 'done' ? 'done' : 'failed';
      hw.exam_detail_error = latest.error || '';
      rerenderEntryCard(entry);
      markHomeworkDetailLoaded(entry, hw);
      continue;
    }

    hw.exam_detail_state = 'loading';
    rerenderEntryCard(entry);

    try {
      if (detailKey) {
        window.yktDetailCacheByKey[detailKey] = {
          ...(window.yktDetailCacheByKey[detailKey] || {}),
          state: 'loading',
          title: hw.title,
          detail_problems: Array.isArray(hw.detail_problems) ? hw.detail_problems : []
        };
      }

      if (isStale() || !isPlatformEnabled('ykt')) return;
      const p = fetchYktHomeworkDetail(hw);
      if (detailKey) window.yktDetailCacheByKey[detailKey].promise = p;
      const examPaper = await p;
      if (examPaper?.title) hw.title = examPaper.title;
      hw.detail_problems = Array.isArray(examPaper?.problems) ? examPaper.problems : [];
      hw.classroom_report_question_count = examPaper?.classroom_report_question_count;

      hw.exam_detail_state = 'done';
      if (detailKey) {
        window.yktDetailCacheByKey[detailKey] = {
          ...(window.yktDetailCacheByKey[detailKey] || {}),
          state: 'done',
          title: hw.title,
          detail_problems: Array.isArray(hw.detail_problems) ? hw.detail_problems : [],
          classroom_report_question_count: hw.classroom_report_question_count,
          promise: null
        };
      }
    } catch (error) {
      hw.exam_detail_state = 'failed';
      hw.exam_detail_error = String(error?.message || '');
      if (detailKey) {
        window.yktDetailCacheByKey[detailKey] = {
          ...(window.yktDetailCacheByKey[detailKey] || {}),
          state: 'failed',
          error: hw.exam_detail_error,
          promise: null
        };
      }
    }

    rerenderEntryCard(entry);
    markHomeworkDetailLoaded(entry, hw);
  }
  setPlatformContentLoadProgress('ykt', entries.length, entries.length);
}

function scheduleYktLoad(courses, loadVersion = 0) {
  if (!isPlatformEnabled('ykt')) return Promise.resolve();
  const list = Array.isArray(courses) ? courses : [];
  if (!window.__yktLoadSerialPromise) window.__yktLoadSerialPromise = Promise.resolve();
  window.__yktLoadSerialPromise = window.__yktLoadSerialPromise
    .catch(() => {})
    .then(() => loadYktCoursesAndHomework(list, loadVersion));
  return window.__yktLoadSerialPromise;
}

// 供 qwen 模块（service worker）经 app 页面消息桥调用的雨课堂接口
async function waitYktPageDataReady(timeoutMs = 120000) {
  if (String(window.platformLoginState?.ykt || '') !== 'online') return false;
  if (typeof window.waitForPlatformDataReady === 'function') {
    const ready = await window.waitForPlatformDataReady('ykt', timeoutMs);
    if (!ready) return false;
  }
  const pending = window.__yktLoadSerialPromise;
  if (pending && typeof pending.then === 'function') await pending.catch(() => {});
  return String(window.platformLoginState?.ykt || '') === 'online';
}

async function yktPageCourseList() {
  if (String(window.platformLoginState?.ykt || '') === 'online') await waitYktPageDataReady();
  const listResp = await fetchYktJson(YKT_COURSE_LIST_API);
  if (Number(listResp?.errcode) !== 0) {
    return { ok: false, loggedIn: false, courses: [], message: '未登录或会话已失效' };
  }
  const yktCourses = Array.isArray(listResp?.data?.list) ? listResp.data.list : [];
  const courses = yktCourses
    .map((item) => ({
      classroomId: String(item?.classroom_id || '').trim(),
      name: String(item?.name || '').trim(),
      courseName: String(item?.course?.name || item?.name || '').trim(),
      teacher: String(item?.teacher?.name || '').trim(),
      universityId: pickYktUniversityId(item, listResp?.data) || ''
    }))
    .filter((course) => course.classroomId);
  return { ok: true, loggedIn: true, courses };
}

function stripYktLeafId(value, seen = new WeakSet()) {
  if (value === null || typeof value !== 'object') return value;
  if (seen.has(value)) return '[循环引用]';
  seen.add(value);
  if (Array.isArray(value)) return value.map((item) => stripYktLeafId(item, seen));
  const output = {};
  for (const [key, child] of Object.entries(value)) {
    if (key === 'leaf_id' || key === 'leafId') continue;
    output[key] = stripYktLeafId(child, seen);
  }
  return output;
}

function yktHomeworkForPageApi(homework) {
  const source = homework && typeof homework === 'object' ? homework : {};
  const output = stripYktLeafId(source);
  output.done = isYktHomeworkDone(source);
  output.overdue = isYktHomeworkOverdue(source);
  if (Number(source?.__actype ?? source?.actype) === 5) {
    output.progress = getYktExamProgress(source)?.completed ?? null;
  }
  if (Number(source?.__actype ?? source?.actype) === 15) {
    const rawRatio = source?.video_progress_ratio;
    let ratio = rawRatio === null || rawRatio === undefined ? NaN : Number(rawRatio);
    if (!Number.isFinite(ratio)) {
      const totalDone = Number(source?.video_total_done);
      ratio = totalDone === 1 ? 1 : 0;
    }
    output.progress = Math.max(0, Math.min(1, ratio));
    delete output.video_progress_ratio;
    delete output.video_total_done;
    delete output.video_progress_loading;
  }
  return output;
}

async function yktPageCourseHomework(classroomId) {
  const cid = String(classroomId || '').trim();
  if (!cid) return { ok: false, classroomId: '', homework: [], message: '缺少 classroomId' };
  if (String(window.platformLoginState?.ykt || '') === 'online') {
    const ready = await waitYktPageDataReady();
    if (!ready) return { ok: false, loggedIn: false, classroomId: cid, homework: [], message: '雨课堂未登录或数据未加载完毕' };
    const snapshot = (Array.isArray(window.yktCourseGroupsSnapshot) ? window.yktCourseGroupsSnapshot : [])
      .find((course) => String(course?.classroom_id || '') === cid);
    if (snapshot) {
      return {
        ok: true,
        loggedIn: true,
        ready: true,
        classroomId: cid,
        homework: (Array.isArray(snapshot.homeworks) ? snapshot.homeworks : []).map(yktHomeworkForPageApi)
      };
    }
  }
  const actypes = [14, 15, 5, 9];
  const urls = actypes.map((actype) => `${YKT_BASE}/v2/api/web/logs/learn/${encodeURIComponent(cid)}?actype=${actype}&page=0&offset=100`);
  const settled = await Promise.allSettled(urls.map((url) => fetchYktJson(url)));
  const acts = [];
  settled.forEach((result, index) => {
    if (result.status !== 'fulfilled') return;
    const lr = result.value;
    const hasError = (lr?.errcode !== undefined && Number(lr.errcode) !== 0) || lr?.success === false;
    if (!hasError && Array.isArray(lr?.data?.activities)) {
      acts.push(...lr.data.activities.map((a) => ({ ...a, __actype: actypes[index] })));
    }
  });
  const homework = acts.map((a) => {
    const isExam = Number(a?.__actype) === 5;
    const isCard = Number(a?.__actype) === 15;
    const isClassroomActivity = Number(a?.__actype) === 14;
    const examId = a?.courseware_id ?? a?.exam_id ?? a?.examId ?? a?.id ?? '';
    const coursewareId = a?.courseware_id;
    const leafId = a?.content?.leaf_id ?? a?.leaf_id ?? '';
    return {
      ...a,
      __actype: Number(a?.__actype),
      id: a?.id,
      title: a?.title || '雨课堂作业',
      end: getYktActivityDeadline(a),
      type: a?.type,
      actype: Number(a?.__actype),
      activityType: YKT_ACTIVITY_TYPE_LABELS[Number(a?.__actype)] || '',
      done: (a?.view && a?.view?.done) !== undefined ? !!(a?.view && a?.view?.done) : undefined,
      unfinished: a?.unfinished,
      total: a?.total,
      progress: a?.progress,
      problem_count: a?.problem_count,
      score: a?.score,
      total_score: a?.total_score,
      attend_status: a?.attend_status,
      is_finished: a?.is_finished,
      create_time: a?.create_time,
      link: isExam
        ? yktExamLink(a?.course_id || cid, coursewareId)
        : (isClassroomActivity
            ? yktClassroomReportLink(cid, coursewareId, a?.id)
            : (isCard && String(leafId || '').trim()
            ? yktVideoStudentLink(cid, leafId)
            : yktHomeworkLink(cid, coursewareId, a?.id))),
      courseware_id: coursewareId,
      leaf_id: leafId,
      classroom_id: cid,
      detail_content: a?.content ?? null,
      view: a?.view ?? null
    };
  });
  const videoCoursewareIds = homework
    .filter((item) => Number(item?.__actype) === 15)
    .map((item) => item?.courseware_id)
    .filter((id) => String(id || '').trim());
  await Promise.all(homework.filter((item) => Number(item.__actype) === 14 && item.courseware_id).map(async (item) => {
    const detail = await fetchYktHomeworkDetail(item);
    item.detail_problems = detail.problems;
    item.classroom_report_question_count = detail.classroom_report_question_count;
  }));
  if (videoCoursewareIds.length) {
    try {
      const listResp = await fetchYktJson(YKT_COURSE_LIST_API);
      const courses = Array.isArray(listResp?.data?.list) ? listResp.data.list : [];
      const course = courses.find((item) => String(item?.classroom_id || '') === cid);
      const progressMap = await fetchYktCoursewareProgress(
        cid,
        videoCoursewareIds,
        pickYktUniversityId(course, listResp?.data)
      );
      homework.forEach((item) => {
        if (Number(item?.__actype) !== 15) return;
        const progress = normalizeYktVideoProgress(
          progressMap?.[String(item?.courseware_id || '')],
          item?.leaf_id
        );
        item.video_total_done = progress?.totalDone;
        item.video_progress_ratio = progress?.ratio;
      });
    } catch (error) {
      console.warn('[bjtu] ykt page api progress failed:', String(error?.message || error));
    }
  }
  const successfulResponses = settled.filter((result) => result.status === 'fulfilled'
    && !((result.value?.errcode !== undefined && Number(result.value.errcode) !== 0) || result.value?.success === false));
  if (!successfulResponses.length) {
    return { ok: false, loggedIn: false, classroomId: cid, homework: [], message: '雨课堂未登录或会话已失效' };
  }
  return {
    ok: true,
    loggedIn: true,
    classroomId: cid,
    homework: homework.map(yktHomeworkForPageApi)
  };
}

async function yktPageAssignmentSnapshot() {
  if (typeof globalThis.isPlatformEnabled === 'function' && !globalThis.isPlatformEnabled('ykt')) {
    throw Object.assign(new Error('雨课堂未启用，请先调用 ykt.login()'), { code: 'LOGIN_REQUIRED' });
  }
  if (String(window.platformLoginState?.ykt || '') !== 'online') {
    throw Object.assign(new Error('雨课堂未登录，请先调用 ykt.login()'), { code: 'LOGIN_REQUIRED' });
  }
  const ready = await waitYktPageDataReady();
  if (!ready) throw Object.assign(new Error('雨课堂数据尚未加载完毕，请先调用 ykt.login()'), { code: 'LOGIN_REQUIRED' });
  return {
    courses: (Array.isArray(window.yktCourseGroupsSnapshot) ? window.yktCourseGroupsSnapshot : []).map((course) => ({
      classroomId: String(course?.classroom_id || '').trim(),
      courseName: String(course?.course_name || course?.name || '').trim(),
      teacher: String(course?.teacher_name || '').trim(),
      homework: (Array.isArray(course?.homeworks) ? course.homeworks : []).map(yktHomeworkForPageApi)
    }))
  };
}

async function yktPageLogin(args = {}) {
  const platform = 'ykt';
  const enabled = typeof isPlatformEnabled === 'function' ? isPlatformEnabled(platform) : true;
  if (enabled) {
    return globalThis.getEnabledPlatformLoginResult(platform);
  } else if (typeof togglePlatformSelection === 'function') {
    try { togglePlatformSelection(platform, { interactive: true }); } catch {}
  }
  return await waitForPlatformLoginResult(platform, Number(args?.timeoutMs) || 120000);
}

globalThis.BjtuYktPageApi = Object.freeze({
  courseList: () => yktPageCourseList(),
  courseHomework: (args) => yktPageCourseHomework(String(args?.classroomId || '').trim()),
  assignmentSnapshot: () => yktPageAssignmentSnapshot(),
  login: (args) => yktPageLogin(args)
});

if (typeof chrome !== 'undefined' && chrome?.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'PAGE_API' || message?.payload?.module !== 'ykt') return false;
    const api = globalThis.BjtuYktPageApi;
    const fn = api && typeof api[String(message.payload?.fn || '')] === 'function' ? api[String(message.payload.fn)] : null;
    if (!fn) {
      sendResponse({ ok: false, error: '雨课堂页面接口不存在' });
      return true;
    }
    Promise.resolve(fn(message.payload?.args || {})).then(
      (value) => sendResponse({ ok: true, value }),
      (error) => sendResponse({ ok: false, error: String(error?.message || error) })
    );
    return true;
  });
}
