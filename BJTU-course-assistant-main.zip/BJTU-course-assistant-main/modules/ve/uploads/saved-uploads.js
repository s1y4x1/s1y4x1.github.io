// -------------------- Saved Uploads (本地保存本次上传过的文件) --------------------
const SAVED_UPLOADS_KEY = 'savedUploadedFiles';
const SAVE_UPLOADS_ENABLED_KEY = 'saveUploadedFilesEnabled';

async function loadSavedUploadsFromStorage() {
  try {
    const raw = await chrome.storage.local.get([SAVED_UPLOADS_KEY, SAVE_UPLOADS_ENABLED_KEY]);
    const list = raw?.[SAVED_UPLOADS_KEY];
    window.savedUploadedFiles = Array.isArray(list) ? list.filter((it) => it && it.url && it.visitName) : [];
    if (typeof raw?.[SAVE_UPLOADS_ENABLED_KEY] === 'boolean') {
      window.saveUploadedFilesEnabled = raw[SAVE_UPLOADS_ENABLED_KEY];
    }
  } catch {
    window.savedUploadedFiles = [];
  }
}

async function persistSavedUploads() {
  try {
    await chrome.storage.local.set({ [SAVED_UPLOADS_KEY]: window.savedUploadedFiles });
  } catch {
    // ignore quota / IO errors
  }
}

async function persistSaveUploadsEnabled() {
  try {
    await chrome.storage.local.set({ [SAVE_UPLOADS_ENABLED_KEY]: !!window.saveUploadedFilesEnabled });
  } catch {
    // ignore
  }
}

async function addSavedUpload(file, serverData, convertedUrl) {
  if (!window.saveUploadedFilesEnabled) return;
  const visitName = String(serverData?.visitName || '').trim();
  const url = String(convertedUrl || '').trim();
  if (!visitName || !url) return;
  const fileName = String(file?.name || '').trim() || '(未命名)';
  const fileSize = Number(file?.size || 0);
  const entry = {
    id: `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    fileName,
    fileSize,
    visitName,
    url,
    savedAt: Date.now()
  };
  const list = Array.isArray(window.savedUploadedFiles) ? window.savedUploadedFiles : [];
  const existingIdx = list.findIndex((it) => it && it.visitName === visitName);
  if (existingIdx >= 0) {
    list[existingIdx] = entry;
  } else {
    list.unshift(entry);
  }
  window.savedUploadedFiles = list;
  await persistSavedUploads();
}

async function removeSavedUpload(id) {
  const target = String(id || '').trim();
  if (!target) return;
  const list = Array.isArray(window.savedUploadedFiles) ? window.savedUploadedFiles : [];
  window.savedUploadedFiles = list.filter((it) => it && it.id !== target);
  // Clean up the synthesized meta entry so the checkbox can no longer find the file.
  if (window.uploadedFileMetaById) {
    delete window.uploadedFileMetaById[`saved_${target}`];
  }
  await persistSavedUploads();
  renderSavedUploadsSection();
}

let savedUploadsToggleAnimationSerial = 0;

function updateSavedUploadsToggleButton(section, expanded) {
  const button = section?.querySelector('[data-action="toggle-saved-uploads"]');
  if (!(button instanceof HTMLButtonElement)) return;
  const count = Array.isArray(window.savedUploadedFiles) ? window.savedUploadedFiles.length : 0;
  const text = expanded ? button.dataset.expandedText : button.dataset.collapsedText;
  button.classList.toggle('is-expanded', expanded);
  button.classList.toggle('homework-toggle-btn--up', expanded);
  button.classList.toggle('homework-toggle-btn--down', !expanded);
  button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  const label = button.querySelector('.homework-toggle-label');
  if (label instanceof HTMLElement) label.textContent = `${text || ''} (${count})`;
}

function animateSavedUploadsItems(section, expanding, initialHeight) {
  const list = section.querySelector('.saved-uploads-list');
  if (!(list instanceof HTMLElement)) return Promise.resolve(false);
  const interrupted = !!list.__heightMotion && !!list.__listTransition
    && list.__listTransition.open !== expanding;
  const scrollMotionEnabled = interrupted
    ? list.__listTransition.scroll
    : expanding ? window.scrollExpandHomeworkLists === true : window.scrollCollapseHomeworkLists !== false;
  const transition = { open: expanding, scroll: scrollMotionEnabled };
  list.__listTransition = transition;
  const previousScrollMotion = list.__scrollListMotion;
  const previousFraction = list.__savedUploadsFade?.getFraction();
  list.__heightMotion?.cancel();
  list.__savedUploadsFade?.reset();
  delete list.__savedUploadsFade;
  if (!scrollMotionEnabled && previousScrollMotion) {
    previousScrollMotion.reset();
    delete list.__scrollListMotion;
  }

  const from = initialHeight ?? list.getBoundingClientRect().height;
  const fullHeight = Math.max(list.scrollHeight, from, previousScrollMotion?.fullHeight || 0, 1);
  list.style.boxSizing = 'border-box';
  list.style.height = `${from}px`;
  list.style.overflow = 'hidden';
  const motion = scrollMotionEnabled
    ? previousScrollMotion || createListScrollMotion(list, fullHeight)
    : createTopDownListFade(list.children);
  if (scrollMotionEnabled) list.__scrollListMotion = motion;
  else list.__savedUploadsFade = motion;
  const startFraction = previousFraction ?? Math.min(1, from / fullHeight);

  return animateHeightWithMotion(list, from, expanding ? fullHeight : 0, (height, progress) => {
    list.style.height = `${height}px`;
    motion.update(scrollMotionEnabled ? height : expanding
      ? startFraction + (1 - startFraction) * progress
      : startFraction * (1 - progress));
  }).then((completed) => {
    if (!completed) return false;
    if (list.__listTransition === transition) delete list.__listTransition;
    motion.reset();
    if (scrollMotionEnabled) delete list.__scrollListMotion;
    else delete list.__savedUploadsFade;
    list.style.height = '';
    list.style.boxSizing = '';
    list.style.overflow = '';
    return completed;
  });
}

function renderSavedUploadsSection() {
  const section = document.getElementById('saved-uploads-section');
  if (!(section instanceof HTMLElement)) return;
  const list = Array.isArray(window.savedUploadedFiles) ? window.savedUploadedFiles : [];
  const count = list.length;
  if (count === 0) {
    section.innerHTML = '';
    section.dataset.expanded = '0';
    return;
  }
  const expanded = section.dataset.expanded === '1';
  const collapsedText = '查看全部已上传文件';
  const expandedText = '收起全部已上传文件';
  const toggleLabel = `${expanded ? expandedText : collapsedText} (${count})`;
  const direction = expanded ? 'up' : 'down';

  // Register synthesized metas so saved files can be selected as homework attachments.
  if (!window.uploadedFileMetaById) window.uploadedFileMetaById = {};
  for (const it of list) {
    if (!it || !it.id || !it.visitName || !it.url) continue;
    const synthId = `saved_${it.id}`;
    const nameParts = splitFileName(it.fileName || '');
    window.uploadedFileMetaById[synthId] = {
      fileNameNoExt: String(nameParts?.fileNameNoExt || ''),
      fileExtName: String(nameParts?.fileExtName || ''),
      fileSize: String(Number(it.fileSize || 0) || 0),
      visitName: String(it.visitName || ''),
      pid: '',
      ftype: 'insert'
    };
  }

  const cardsHtml = list.map((it) => {
    const entryId = String(it.id || '').trim();
    if (!entryId) return '';
    const synthFileId = `saved_${entryId}`;
    const name = escapeHtml(it.fileName || '(未命名)');
    const sizeBytes = Number(it.fileSize || 0);
    const size = renderFileSizeText(sizeBytes, formatSize(sizeBytes));
    const url = String(it.url || '').trim();
    const safeUrl = escapeHtml(url);
    const safeHref = escapeHtml(url);
    const safeEntryId = escapeHtml(entryId);
    const safeSynthFileId = escapeHtml(synthFileId);
    const timeText = it.savedAt ? new Date(it.savedAt).toLocaleString('zh-CN', { hour12: false }) : '';
    const timeHtml = timeText ? ` <span class="resource-time-inline">上传时间: ${escapeHtml(timeText)}</span>` : '';
    return `
      <div class="file-item" data-saved-upload-id="${safeEntryId}" data-resource-id="${safeSynthFileId}">
        <div class="upload-file-head-row" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
          <div class="saved-upload-main">
            <label class="upload-select-wrap">
              <input type="checkbox" class="submit-file-check" data-file-id="${safeSynthFileId}">
              作为作业附件
            </label>
            <strong class="saved-upload-name">${name}</strong>
            <span class="inline-status" style="font-size:12px; margin-left:8px; color:#2e7d32;">已上传</span>
            <span class="size-progress" style="margin-left:5px;">${size}</span>${timeHtml}
          </div>
          <div class="saved-upload-actions">
            <button type="button" class="btn saved-upload-delete" data-action="delete-saved-upload" data-saved-upload-id="${safeEntryId}" style="padding:2px 8px; font-size:12px; background-color:#f44336;">删除</button>
          </div>
        </div>
        <div class="upload-link-row">
          <a class="url-link" href="${safeHref}" target="_blank" rel="noopener noreferrer">${safeUrl}</a>
          <button type="button" class="btn saved-upload-copy" data-action="copy-saved-upload" data-saved-upload-id="${safeEntryId}" style="padding:2px 8px; font-size:12px; white-space:nowrap;">复制</button>
          <button type="button" class="btn saved-upload-download" data-action="download-saved-upload" data-saved-upload-id="${safeEntryId}" data-url="${safeHref}" data-filename="${escapeHtml(it.fileName || '')}" style="padding:2px 8px; font-size:12px; white-space:nowrap; background:#1e3a8a;">下载</button>
        </div>
        <div class="resource-download-progress" style="display:none;">
          <div class="progress-bar-container"><div class="progress-bar"></div></div>
          <div class="resource-download-meta">
            <span class="resource-dl-status"></span>
            <span class="resource-dl-size"></span>
            <span class="resource-dl-speed"></span>
            <span class="resource-dl-eta"></span>
          </div>
        </div>
      </div>
    `;
  }).join('');

  section.innerHTML = `
    <div class="homework-toggle-row homework-toggle-row--saved-uploads">
      <button class="btn homework-toggle-btn ${expanded ? 'is-expanded' : ''} homework-toggle-btn--${direction}" data-action="toggle-saved-uploads" data-collapsed-text="${escapeHtml(collapsedText)}" data-expanded-text="${escapeHtml(expandedText)}" aria-expanded="${expanded ? 'true' : 'false'}">
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
        <span class="homework-toggle-label">${escapeHtml(toggleLabel)}</span>
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
      </button>
    </div>
    ${expanded ? `<div class="saved-uploads-list">${cardsHtml}<div class="saved-uploads-divider" aria-hidden="true"></div></div>` : ''}
  `;
  if (typeof refreshUploadSelectVisibility === 'function') {
    refreshUploadSelectVisibility();
  }
}

function setupSavedUploadsUi() {
  const cb = document.getElementById('save-uploads-enabled');
  if (cb instanceof HTMLInputElement) {
    cb.checked = !!window.saveUploadedFilesEnabled;
    cb.addEventListener('change', () => {
      window.saveUploadedFilesEnabled = !!cb.checked;
      persistSaveUploadsEnabled();
    });
  }
  const invertBtn = document.getElementById('invert-save-uploads-btn');
  if (invertBtn) {
    invertBtn.addEventListener('click', () => {
      document.querySelectorAll('#file-list .file-item input.submit-file-check').forEach(cb => { cb.checked = !cb.checked; });
      document.querySelectorAll('#saved-uploads-section[data-expanded="1"] .saved-uploads-list > .file-item input.submit-file-check').forEach(cb => { cb.checked = !cb.checked; });
    });
  }
  const section = document.getElementById('saved-uploads-section');
  if (section instanceof HTMLElement) {
    section.addEventListener('click', async (e) => {
      const t = e.target;
      if (!(t instanceof Element)) return;

      // Handle action buttons first
      const actionEl = t.closest('[data-action]');
      if (actionEl instanceof HTMLElement) {
        const action = String(actionEl.dataset.action || '').trim();
        if (action === 'toggle-saved-uploads') {
          const expanded = section.dataset.expanded === '1';
          const serial = ++savedUploadsToggleAnimationSerial;
          if (!expanded) {
            const hasItems = !!section.querySelector('.saved-uploads-list');
            section.dataset.expanded = '1';
            if (hasItems) updateSavedUploadsToggleButton(section, true);
            else renderSavedUploadsSection();
            void animateSavedUploadsItems(section, true, hasItems ? undefined : 0);
            return;
          }
          section.dataset.expanded = '0';
          updateSavedUploadsToggleButton(section, false);
          await animateSavedUploadsItems(section, false);
          if (serial === savedUploadsToggleAnimationSerial && section.dataset.expanded === '0') {
            renderSavedUploadsSection();
          }
          return;
        }
        if (action === 'delete-saved-upload') {
          const id = String(actionEl.dataset.savedUploadId || '').trim();
          if (id) removeSavedUpload(id);
          return;
        }
        if (action === 'copy-saved-upload') {
          const id = String(actionEl.dataset.savedUploadId || '').trim();
          const entry = (window.savedUploadedFiles || []).find((it) => it && it.id === id);
          if (entry && entry.url) {
            navigator.clipboard.writeText(entry.url).then(() => {
              showToast('链接已复制', 'success', 1200);
            }).catch(() => {
              if (typeof showToast === 'function') {
                showToast('复制失败，请手动复制链接', 'error', 2000);
              }
            });
          }
          return;
        }
        if (action === 'cancel-saved-upload') {
          const id = `saved_${String(actionEl.dataset.savedUploadId || '').trim()}`;
          if (id) cancelResourceDownload(id);
          return;
        }
        if (action === 'download-saved-upload') {
          const url = String(actionEl.dataset.url || '').trim();
          const filename = String(actionEl.dataset.filename || '').trim() || '下载';
          const entryId = String(actionEl.dataset.savedUploadId || '').trim();
          const savedEntry = (window.savedUploadedFiles || []).find((it) => it && String(it.id || '').trim() === entryId);
          const sizeBytes = Math.max(0, Number(savedEntry?.fileSize) || 0);
          if (url) {
            try {
              await enqueueResourceDownload({
                id: `saved_${entryId}`,
                name: filename,
                url: url,
                extName: filename.includes('.') ? filename.split('.').pop() : '',
                sizeMb: sizeBytes > 0 ? formatSize(sizeBytes) : '-',
                sizeMbRaw: sizeBytes / (1024 * 1024),
                inputTime: ''
              });
            } catch (e) {
              showToast(`下载失败：${String(e?.message || e)}`, 'error', 2000);
            }
          }
          return;
        }
        return;
      }

      // Click on a head row (not on button/link/input) toggles the checkbox
      const row = t.closest('.upload-file-head-row');
      if (!(row instanceof HTMLElement)) return;
      if (t.closest('button,a,input,textarea,select,label')) return;
      const cb = row.querySelector('input.submit-file-check');
      if (!(cb instanceof HTMLInputElement)) return;
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }
  renderSavedUploadsSection();
}
