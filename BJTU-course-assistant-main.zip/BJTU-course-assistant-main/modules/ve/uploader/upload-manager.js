// -------------------- Upload --------------------
const VE_SUPPORTED_UPLOAD_ACCEPT = globalThis.BjtuVeUploadCommon.accept;
let veUploadSessionCheckPromise = null;
const veUploadJobs = new Set();
let veUploadHashOrder = 0;
let veDuplicateDialog = null;

function applyVeUploadAccountInfo(userInfo) {
  const info = userInfo && typeof userInfo === 'object' ? userInfo : null;
  const loginName = String(info?.loginName || info?.userId || '').trim();
  if (!loginName) return null;
  const roleName = String(info?.roleName || '').trim();
  window.currentAccountLoginName = loginName;
  window.isTeacherAccount = /教师|老师|助教/.test(roleName);
  isLoginSessionValid = true;
  if (typeof setPlatformLoginState === 'function') setPlatformLoginState('ve', 'online');
  return info;
}

async function ensureVeUploadSession() {
  if (veUploadSessionCheckPromise) return veUploadSessionCheckPromise;
  veUploadSessionCheckPromise = (async () => {
    let userInfo = await globalThis.BjtuAccountLogin?.getCurrentUserInfo?.().catch(() => null);
    if (applyVeUploadAccountInfo(userInfo)) return userInfo;

    isLoginSessionValid = false;
    if (typeof setPlatformLoginState === 'function') setPlatformLoginState('ve', 'offline');
    const account = String(usernameInput?.value || '').trim();
    if (!account) {
      promptLoginIfPossible('请先输入智慧课程平台账号并登录后再上传文件');
      throw Object.assign(new Error('请先登录智慧课程平台后再上传文件'), { code: 'LOGIN_REQUIRED' });
    }

    const result = typeof doLoginFlow === 'function' ? await doLoginFlow({ reloadPlatform: false }) : null;
    if (result?.ok !== true) {
      throw Object.assign(new Error(String(result?.message || '智慧课程平台登录失败或已取消')), { code: 'LOGIN_REQUIRED' });
    }
    userInfo = result?.userInfo
      || await globalThis.BjtuAccountLogin?.getCurrentUserInfo?.().catch(() => null);
    if (!applyVeUploadAccountInfo(userInfo)) {
      throw Object.assign(new Error('智慧课程平台登录流程完成，但未能确认当前账号'), { code: 'LOGIN_REQUIRED' });
    }
    return userInfo;
  })().finally(() => {
    veUploadSessionCheckPromise = null;
  });
  return veUploadSessionCheckPromise;
}

function getVeUploadUrl({ manualJsessionMode = false, jsessionid = '' } = {}) {
  return globalThis.BjtuVeUploadCommon.uploadUrl(
    window.isTeacherAccount ? '教师' : '学生',
    manualJsessionMode ? String(jsessionid || '').trim() : ''
  );
}

function processQueue() {
  while (activeUploads < maxParallelUploads && uploadQueue.length > 0) {
    const task = uploadQueue.shift();
    activeUploads++;
    task();
  }
}

function runPendingLoginCallbacks() {
  const cbs = pendingLoginCallbacks;
  pendingLoginCallbacks = [];
  cbs.forEach(fn => {
    try { fn(); } catch {}
  });
  return cbs.length;
}

function handleLoginRequired(retryCallback, message) {
  if (globalThis.shouldAutoLoginAfterExpiry?.('ve') !== true) {
    const hasUsername = !!String(usernameInput?.value || '').trim();
    if (!hasUsername) {
      showToast(message || globalThis.BjtuPlatformLoginUi.loginRequiredHtml('ve'), 'warning', 3500, true);
    }
    return;
  }
  if (retryCallback) {
    pendingLoginCallbacks.push(retryCallback);
  }
  promptLoginIfPossible(message || '请输入账号登录');
}


function buildUploadMetaFromKnownFile(file, known) {
  const nameParts = splitFileName(file?.name || known?.fileName || known?.name || '');
  return {
    fileNameNoExt: String(nameParts.fileNameNoExt || safeDecodeUploadNamePart(known?.fileNameNoExt) || '').trim(),
    fileExtName: String(nameParts.fileExtName || known?.fileExtName || '').trim(),
    fileSize: Number(known?.fileSize || file?.size || 0),
    sha256: known?.sha256,
    visitName: String(known?.visitName || '').trim(),
    pid: '',
    ftype: 'insert',
    fileName: String(file?.name || known?.fileName || known?.name || '').trim(),
    url: String(known?.url || '').trim()
  };
}

function safeDecodeUploadNamePart(v) {
  const raw = String(v || '');
  try {
    return decodeURIComponent(raw);
  } catch {
    return raw;
  }
}

function findAlreadyUploadedFile(file, sha256) {
  const savedList = Array.isArray(window.savedUploadedFiles) ? window.savedUploadedFiles : [];
  const saved = savedList.find((item) => item?.sha256 === sha256
    && String(item?.visitName || '').trim() && String(item?.url || '').trim());
  if (saved) return { source: '本地记录', ...buildUploadMetaFromKnownFile(file, saved) };

  const current = Object.values(window.uploadedFileMetaById || {})
    .find((meta) => meta?.sha256 === sha256 && meta?.visitName);
  if (current) return { source: '本页已上传', ...buildUploadMetaFromKnownFile(file, current) };
  return null;
}

async function promptDuplicateUploadConfirmation(entry) {
  if (veDuplicateDialog) return veDuplicateDialog.add(entry);
  const entries = [];
  let listEl;
  let closeDialog = () => {};
  const add = (value) => new Promise((resolve) => {
    entries.push({ ...value, resolve });
    if (listEl) renderEntry(entries.at(-1), entries.length - 1);
  });
  const result = add(entry);
  veDuplicateDialog = { add, remove(job) {
    const index = entries.findIndex((item) => item.job === job && !item.withdrawn);
    if (index < 0) return;
    entries[index].withdrawn = true;
    entries[index].resolve(null);
    listEl?.querySelector(`[data-duplicate-index="${index}"]`)?.closest('label')?.remove();
    if (entries.every((item) => item.withdrawn)) closeDialog();
  } };
  void chrome.runtime.sendMessage({ type: 'VE_UPLOAD_CONFIRMATION_FOCUS' }).catch(() => {});
  try {
    await globalThis.__bjtuUploadDuplicateDialogReady;
  } catch (error) {
    veDuplicateDialog = null;
    entries.forEach((item) => item.resolve(null));
    showToast(`重复文件确认界面加载失败：${error?.message || error}`, 'error');
    return result;
  }
  const modal = document.getElementById('upload-duplicate-modal');
  listEl = document.getElementById('upload-duplicate-list');
  const invertBtn = document.getElementById('upload-duplicate-invert');
  const cancelBtn = document.getElementById('upload-duplicate-cancel');
  const confirmBtn = document.getElementById('upload-duplicate-confirm');
  if (!(modal instanceof HTMLElement) || !(listEl instanceof HTMLElement) || !(confirmBtn instanceof HTMLButtonElement)) {
    veDuplicateDialog = null;
    entries.forEach((item) => item.resolve(null));
    return result;
  }

  function renderEntry(entry, idx) {
    if (entry.withdrawn) return;
    const file = entry?.file;
    const known = entry?.known || {};
    const name = String(file?.name || known.fileName || '(未命名)').trim();
    const sizeBytes = Number(file?.size || known.fileSize || 0);
    listEl.insertAdjacentHTML('beforeend', `
      <label class="upload-duplicate-row">
        <input type="checkbox" data-duplicate-index="${idx}">
        <span class="upload-duplicate-fileline">
          <span class="upload-duplicate-name">${escapeHtml(name)}</span>
          <span class="upload-duplicate-size">${renderFileSizeText(sizeBytes)}</span>
        </span>
      </label>
    `);
  }
  listEl.replaceChildren();
  entries.forEach(renderEntry);

  {
    const cleanup = () => {
      modal.style.display = 'none';
      veDuplicateDialog = null;
      confirmBtn.removeEventListener('click', onConfirm);
      if (invertBtn instanceof HTMLButtonElement) invertBtn.removeEventListener('click', onInvert);
      if (cancelBtn instanceof HTMLButtonElement) cancelBtn.removeEventListener('click', onCancel);
      modal.removeEventListener('mousedown', onMaskPointerDown);
      modal.removeEventListener('mouseup', onMaskPointerUp);
    };
    closeDialog = cleanup;
    const onInvert = () => {
      listEl.querySelectorAll('input[type="checkbox"][data-duplicate-index]').forEach((el) => {
        if (el instanceof HTMLInputElement) el.checked = !el.checked;
      });
    };
    const onConfirm = () => {
      const selected = new Set();
      listEl.querySelectorAll('input[type="checkbox"][data-duplicate-index]:checked').forEach((el) => {
        if (el instanceof HTMLInputElement) selected.add(Number(el.dataset.duplicateIndex));
      });
      cleanup();
      entries.forEach((entry, index) => entry.resolve(selected.has(index)));
    };
    const onCancel = () => {
      cleanup();
      entries.forEach((entry) => entry.resolve(null));
    };
    const onMaskPointerDown = (e) => {
      modal.dataset.mdownMask = e.target === modal ? '1' : '0';
    };
    const onMaskPointerUp = (e) => {
      if (e.target === modal && modal.dataset.mdownMask === '1') {
        onCancel();
      }
      delete modal.dataset.mdownMask;
    };
    if (invertBtn instanceof HTMLButtonElement) invertBtn.addEventListener('click', onInvert);
    if (cancelBtn instanceof HTMLButtonElement) cancelBtn.addEventListener('click', onCancel);
    confirmBtn.addEventListener('click', onConfirm);
    modal.addEventListener('mousedown', onMaskPointerDown);
    modal.addEventListener('mouseup', onMaskPointerUp);
    modal.style.display = 'flex';
    if (entries.every((item) => item.withdrawn)) cleanup();
  }
  return result;
}

function renderAlreadyUploadedFile(file, fileId, known) {
  const url = String(known?.url || '').trim();
  if (!url) return false;
  const hasVisitName = !!String(known?.visitName || '').trim();
  if (!window.filesData) window.filesData = {};
  window.filesData[fileId] = { size: Number(file?.size || 0), uploaded: Number(file?.size || 0) };
  if (hasVisitName) {
    window.uploadedFileMetaById[fileId] = buildUploadMetaFromKnownFile(file, known);
  }

  const item = document.createElement('div');
  item.className = 'file-item';
  item.dataset.uploadFileId = fileId;
  item.dataset.duplicateUpload = '1';
  const source = escapeHtml(String(known?.source || '已上传').trim());
  const safeName = escapeHtml(String(file?.name || known?.fileName || '(未命名)').trim());
  const safeUrl = escapeHtml(url);
  const sizeBytes = Number(file?.size || known?.fileSize || 0);
  const checkboxHtml = hasVisitName
    ? `<label class="upload-select-wrap"><input type="checkbox" class="submit-file-check" data-file-id="${escapeHtml(fileId)}"> 作为作业附件</label>`
    : '<span class="upload-select-wrap" style="display:none;"></span>';
  item.innerHTML = `
    <div class="upload-file-head-row" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
      <div>
        ${checkboxHtml}
        <strong>${safeName}</strong>
        <span class="inline-status" style="font-size:12px; margin-left:8px; color:#2e7d32;">${source}</span>
        <span class="size-progress" style="margin-left:5px;">(${renderFileSizeText(sizeBytes)})</span>
      </div>
      <div></div>
    </div>
    <div class="upload-link-row">
      <a class="url-link" href="${safeUrl}" target="_blank" rel="noopener noreferrer">${safeUrl}</a>
      <button type="button" class="btn duplicate-upload-copy" style="padding:2px 8px; font-size:12px; white-space:nowrap;">复制</button>
    </div>
  `;
  const copyBtn = item.querySelector('.duplicate-upload-copy');
  if (copyBtn instanceof HTMLButtonElement) {
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(url).then(() => {
        showToast('链接已复制', 'success', 1200);
      });
    });
  }
  fileList.prepend(item);
  refreshUploadSelectVisibility();
  updateTotalProgress();
  return true;
}

function enqueueUploadFile(file) {
  const fileId = Math.random().toString(36).slice(2);
  const job = { file, fileId, cancelled: false, sha256: '', pause() {} };
  veUploadJobs.add(job);
  job.hash = globalThis.BjtuVeUploadCommon.fileHash(file).then((sha256) => {
    job.sha256 = sha256;
    job.hashOrder = ++veUploadHashOrder;
    return sha256;
  });
  job.validation = (async () => {
    const sha256 = await job.hash;
    if (job.cancelled) return { action: 'cancel' };
    // The first completed hash is the original, so unrelated slow hashes never
    // delay detection and duplicate dependencies cannot form a cycle.
    const previous = [...veUploadJobs].find((other) => !other.cancelled
      && other.hashOrder < job.hashOrder && other.sha256 === sha256);
    const known = findAlreadyUploadedFile(file, sha256);
    if (!known && !previous) return { action: 'continue' };
    job.pause();
    const selected = await promptDuplicateUploadConfirmation({ file, known, job });
    if (job.cancelled || selected === null) return { action: 'cancel' };
    if (selected) return { action: 'continue' };
    if (!known) job.waitForExistingUpload();
    const reused = known || await previous.result.catch(() => null);
    // The original might itself fail or be cancelled while confirmation is open.
    if (!reused?.visitName) return { action: 'continue' };
    return { action: 'reuse', known: { ...reused, sha256 } };
  })();
  // Install the rejection handler before starting network I/O.
  job.validation.catch(() => {});
  window.filesData[fileId] = { size: file.size, uploaded: 0 };
  const completion = uploadFile(file, fileId, job);
  job.result = completion.catch(() => null);
  completion.finally(() => veUploadJobs.delete(job)).catch(() => {});
  return completion;
}

function uploadFile(file, fileId, job) {
  let completionSettled = false;
  let resolveCompletion;
  let rejectCompletion;
  const completion = new Promise((resolve, reject) => {
    resolveCompletion = resolve;
    rejectCompletion = reject;
  });
  const completeUpload = (value) => {
    if (completionSettled) return;
    completionSettled = true;
    resolveCompletion(value);
  };
  const failUpload = (message, code = '') => {
    job.cancelled = true;
    veDuplicateDialog?.remove(job);
    if (completionSettled) return;
    completionSettled = true;
    rejectCompletion(Object.assign(new Error(String(message || '上传失败')), { code: String(code || '') }));
  };
  const item = document.createElement('div');
  item.className = 'file-item';
  item.dataset.uploadFileId = fileId;
  item.innerHTML = `
    <div class="upload-file-head-row" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
      <div>
        <label class="upload-select-wrap" style="display:none;">
          <input type="checkbox" class="submit-file-check" data-file-id="${fileId}">
          作为作业附件
        </label>
        <strong>${file.name}</strong>
        <span class="inline-status" style="font-size:12px; margin-left:8px; color:#6b7280;">排队中…</span>
        <span class="size-progress" style="margin-left:5px;">(${renderFileSizePair(0, file.size)})</span>
        <span class="speed-display" style="font-size:12px; color:#666; margin-left:10px;"></span>
        <span class="eta-display" style="font-size:12px; color:#6b7280; margin-left:10px;"></span>
      </div>
      <div>
        <button class="btn retry-btn" style="padding:2px 8px; font-size:12px; background-color:#2196F3; display:none; margin-right:5px;">重试</button>
        <button class="btn cancel-btn" style="padding:2px 8px; font-size:12px; background-color:#f44336;">取消</button>
      </div>
    </div>
    <div class="progress-bar-container"><div class="progress-bar" style="width:0%"></div></div>
  `;
  fileList.prepend(item);

  const progressBar = item.querySelector('.progress-bar');
  const inlineStatus = item.querySelector('.inline-status');
  const cancelBtn = item.querySelector('.cancel-btn');
  const retryBtn = item.querySelector('.retry-btn');
  const speedDisplay = item.querySelector('.speed-display');
  const etaDisplay = item.querySelector('.eta-display');
  const sizeProgressDisplay = item.querySelector('.size-progress');
  const uploadSelectWrap = item.querySelector('.upload-select-wrap');

  let isRunning = false;
  let cancelRequested = false;
  let xhrRef = null;
  let autoRetryQueuedByLogin = false;
  let authRetryCount = 0;
  let duplicatePaused = false;
  let resumeAfterPause = false;
  let validationResult = null;

  job.waitForExistingUpload = () => {
    setInlineStatus('等待已有上传任务完成后显示', 'warning');
  };

  const resumeValidatedUpload = () => {
    if (cancelRequested || completionSettled) return;
    duplicatePaused = false;
    if (isRunning) resumeAfterPause = true;
    else {
      uploadQueue.push(performUpload);
      processQueue();
    }
  };
  const reuseValidatedUpload = (known) => {
    if (completionSettled) return;
    item.remove();
    renderAlreadyUploadedFile(file, fileId, known);
    completeUpload({ fileName: file.name, fileSize: file.size, mimeType: file.type || '',
      url: known.url, visitName: known.visitName, reused: true });
  };
  job.pause = () => {
    duplicatePaused = true;
    setInlineStatus('检测到重复文件，等待选择…', 'warning');
    setSpeedDisplay(speedDisplay, 0, '');
    if (etaDisplay) etaDisplay.textContent = '';
    delete window.activeSpeeds[fileId];
    updateTotalSpeed();
    const index = uploadQueue.indexOf(performUpload);
    if (index >= 0) uploadQueue.splice(index, 1);
    if (xhrRef) xhrRef.abort();
  };
  job.validation.then((decision) => {
    validationResult = decision;
    if (job.cancelled || completionSettled) return;
    if (decision.action === 'cancel') {
      cancelRequested = true;
      job.cancelled = true;
      setInlineStatus('已取消重复文件上传', 'warning');
      cancelBtn.style.display = 'none';
      delete window.filesData[fileId];
      updateTotalProgress();
      completeUpload({ cancelled: true, message: '用户取消了重复文件上传；已发送到服务器的数据无法撤回。' });
    } else if (decision.action === 'reuse') {
      reuseValidatedUpload(decision.known);
    } else if (duplicatePaused) {
      resumeValidatedUpload();
    }
  }, (error) => {
    job.pause();
    setInlineStatus(`计算文件散列失败：${error?.message || error}`, 'error');
    showRetry();
    failUpload(error?.message || '计算文件散列失败');
  });

  const showRetry = () => {
    cancelBtn.style.display = 'none';
    retryBtn.style.display = 'inline-block';
  };

  const setInlineStatus = (text = '', tone = 'normal') => {
    if (!inlineStatus) return;
    inlineStatus.textContent = String(text || '');
    if (!text) {
      inlineStatus.style.color = '#6b7280';
      return;
    }
    if (tone === 'error') {
      inlineStatus.style.color = '#c62828';
    } else if (tone === 'warning') {
      inlineStatus.style.color = '#b45309';
    } else if (tone === 'success') {
      inlineStatus.style.color = '#2e7d32';
    } else {
      inlineStatus.style.color = '#6b7280';
    }
  };

  const doCancelUiAndAccounting = (statusText = '已取消') => {
    setInlineStatus(statusText, 'warning');
    if (etaDisplay) etaDisplay.textContent = '';
    setSpeedDisplay(speedDisplay, 0, '');
    progressBar.style.backgroundColor = '#999';
    showRetry();
    // remove from aggregated speed
    delete window.activeSpeeds[fileId];
    updateTotalSpeed();
    // cancelled files should not count in total progress
    if (window.filesData[fileId]) {
      delete window.filesData[fileId];
      updateTotalProgress();
    }
    failUpload(statusText, 'USER_CANCELLED');
  };

  const queueAutoRetryAfterLogin = () => {
    if (autoRetryQueuedByLogin) return;
    autoRetryQueuedByLogin = true;
    handleLoginRequired(() => {
      autoRetryQueuedByLogin = false;
      if (cancelRequested) return;
      retryBtn.style.display = 'none';
      cancelBtn.style.display = 'inline-block';
      setInlineStatus('登录恢复，自动重试中…', 'warning');
      if (etaDisplay) etaDisplay.textContent = '';
      isRunning = false;
      xhrRef = null;
      if (!window.filesData[fileId]) {
        window.filesData[fileId] = { size: file.size, uploaded: 0 };
        updateTotalProgress();
      }
      uploadQueue.push(performUpload);
      processQueue();
    }, '登录已失效，请输入账号登录');
  };

  retryBtn.onclick = () => {
    if (completionSettled) {
      item.remove();
      enqueueUploadFile(file).catch(() => {});
      return;
    }
    autoRetryQueuedByLogin = false;
    retryBtn.style.display = 'none';
    cancelBtn.style.display = 'inline-block';
    setInlineStatus('准备重试…', 'warning');
    if (etaDisplay) etaDisplay.textContent = '';
    cancelRequested = false;
    isRunning = false;
    xhrRef = null;
    if (!window.filesData[fileId]) {
      window.filesData[fileId] = { size: file.size, uploaded: 0 };
      updateTotalProgress();
    }
    uploadQueue.push(performUpload);
    processQueue();
  };

  cancelBtn.onclick = () => {
    job.cancelled = true;
    veDuplicateDialog?.remove(job);
    if (duplicatePaused) {
      cancelRequested = true;
      doCancelUiAndAccounting();
      return;
    }
    autoRetryQueuedByLogin = false;
    if (!isRunning) {
      cancelRequested = true;
      const idx = uploadQueue.indexOf(performUpload);
      if (idx >= 0) uploadQueue.splice(idx, 1);
      doCancelUiAndAccounting();
      return;
    }

    cancelRequested = true;
    if (xhrRef) {
      try { xhrRef.abort(); } catch {}
    } else doCancelUiAndAccounting();
  };

  const performUpload = async () => {
    let slotReleased = false;
    const releaseSlot = () => {
      if (slotReleased) return;
      slotReleased = true;
      activeUploads--;
      processQueue();
    };
    if (duplicatePaused || job.cancelled || completionSettled) {
      releaseSlot();
      return;
    }
    cancelRequested = false;
    isRunning = true;
    try {
      await ensureVeUploadSession();
    } catch (error) {
      setInlineStatus(String(error?.message || '请先登录智慧课程平台'), 'warning');
      showRetry();
      isRunning = false;
      xhrRef = null;
      releaseSlot();
      failUpload(error?.message || '请先登录智慧课程平台', error?.code || 'LOGIN_REQUIRED');
      return;
    }
    if (duplicatePaused || job.cancelled || completionSettled) {
      isRunning = false;
      releaseSlot();
      if (resumeAfterPause) { resumeAfterPause = false; resumeValidatedUpload(); }
      return;
    }
    const manualJsessionMode = !usernameInput.value.trim();
    const jsid = (jsessionidInput.value.trim() || await getLocal('jsessionid', '')).trim();
    if (duplicatePaused || job.cancelled || completionSettled) {
      isRunning = false;
      releaseSlot();
      if (resumeAfterPause) { resumeAfterPause = false; resumeValidatedUpload(); }
      return;
    }
    if (manualJsessionMode && !jsid) {
      setInlineStatus('等待登录…', 'warning');
      if (etaDisplay) etaDisplay.textContent = '';
      queueAutoRetryAfterLogin();
      showRetry();
      isRunning = false;
      xhrRef = null;
      releaseSlot();
      return;
    }

    // A duplicate decision may arrive while session preparation is pending.
    // This run can continue directly because no request has been aborted yet.
    resumeAfterPause = false;
    setInlineStatus('上传中…', 'normal');
    if (window.filesData[fileId]) window.filesData[fileId].uploaded = 0;
    progressBar.style.width = '0%';
    sizeProgressDisplay.innerHTML = `(${renderFileSizePair(0, file.size)})`;
    progressBar.style.backgroundColor = '#4CAF50';

    const fd = new FormData();
    fd.append('file', file);

    await new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhrRef = xhr;
      const start = Date.now();
      let lastLoaded = 0;
      let lastTime = start;
      const progressSamples = [];
      const speedId = fileId;
      window.activeSpeeds[speedId] = 0;
      updateTotalSpeed();

      const finishUploadTransfer = () => {
        setSpeedDisplay(speedDisplay, 0, '');
        if (etaDisplay) etaDisplay.textContent = '';
        delete window.activeSpeeds[speedId];
        updateTotalSpeed();
      };

      const uploadUrl = getVeUploadUrl({ manualJsessionMode, jsessionid: jsid });
      xhr.open('POST', uploadUrl, true);
      xhr.withCredentials = true;
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
      xhr.setRequestHeader('Upgrade-Insecure-Requests', '1');

      xhr.onabort = () => {
        finishUploadTransfer();
        if (!duplicatePaused) doCancelUiAndAccounting();
        xhrRef = null;
        resolve();
      };

      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        const fileSize = Math.max(0, Number(file.size || 0));
        const visibleLoaded = fileSize > 0
          ? Math.min(fileSize, Math.max(0, Number(e.loaded || 0)))
          : Math.max(0, Number(e.loaded || 0));
        const percent = fileSize > 0
          ? Math.min(100, Math.max(0, (visibleLoaded / fileSize) * 100))
          : (e.total > 0 ? Math.min(100, Math.max(0, (e.loaded / e.total) * 100)) : 0);
        progressBar.style.width = percent + '%';
        progressBar.textContent = '';
        sizeProgressDisplay.innerHTML = `(${renderFileSizePair(visibleLoaded, fileSize)})`;

        // speed: update on every progress event so very fast uploads still show non-zero throughput.
        const now = Date.now();
        const dt = (now - lastTime) / 1000;
        const elapsed = Math.max((now - start) / 1000, 0.001);
        const db = Math.max(0, e.loaded - lastLoaded);
        let spd = 0;
        if (dt > 0.04) {
          spd = db / dt;
        } else {
          // fallback to average speed when progress callbacks are too dense or upload is near-instant
          spd = e.loaded / elapsed;
        }
        const smoothed = pushAndCalcRecentSpeed(progressSamples, e.loaded, now);
        const speedForEta = smoothed > 0 ? smoothed : spd;
        if (Number.isFinite(speedForEta) && speedForEta >= 0) {
          setSpeedDisplay(speedDisplay, speedForEta);
          window.activeSpeeds[speedId] = speedForEta;
          const remainingBytes = fileSize > 0 ? Math.max(0, fileSize - visibleLoaded) : Math.max(0, e.total - e.loaded);
          if (etaDisplay) {
            etaDisplay.textContent = remainingBytes > 0 && speedForEta > 0
              ? `剩余: ${formatEta(remainingBytes / speedForEta)}`
              : '剩余: 0秒';
          }
          updateTotalSpeed();
        }
        lastLoaded = e.loaded;
        lastTime = now;

        if (window.filesData[fileId]) {
          window.filesData[fileId].uploaded = visibleLoaded;
          updateTotalProgress();
        }
        if (percent >= 100) finishUploadTransfer();
      };

      xhr.upload.onload = finishUploadTransfer;

      xhr.onload = async () => {
        xhrRef = null;
        finishUploadTransfer();
        // Hashing or a duplicate choice must not occupy a network concurrency
        // slot, especially when reusing a file still waiting in the queue.
        releaseSlot();
        if (globalThis.isVeSessionInvalidResponse?.(xhr.responseText, xhr.responseURL)) {
          if (authRetryCount < 1) {
            authRetryCount += 1;
            setInlineStatus('登录状态已失效，正在重新登录…', 'warning');
            progressBar.style.width = '0%';
            sizeProgressDisplay.innerHTML = `(${renderFileSizePair(0, file.size)})`;
            const recovered = await globalThis.reauthenticateVeSessionOnly?.().catch(() => false);
            if (recovered && !cancelRequested) {
              setInlineStatus('登录已恢复，正在重新上传…', 'warning');
              uploadQueue.unshift(performUpload);
              resolve();
              return;
            }
          }
          setInlineStatus('上传失败：登录已失效', 'error');
          progressBar.style.backgroundColor = '#f44336';
          showRetry();
          failUpload('智慧课程平台重新登录失败或已取消', 'LOGIN_REQUIRED');
          resolve();
          return;
        }
        if (xhr.status !== 200) {
          setInlineStatus(`上传失败 HTTP ${xhr.status}`, 'error');
          progressBar.style.backgroundColor = '#f44336';
          showRetry();
          failUpload(`上传失败：HTTP ${xhr.status}`);
          resolve();
          return;
        }
        try {
          const data = JSON.parse(xhr.responseText || '{}');
          if (data.visitName) {
            setInlineStatus('上传完成，等待散列校验…');
            const decision = validationResult || await job.validation;
            if (job.cancelled || completionSettled || decision.action !== 'continue') { resolve(); return; }
            const convertedUrl = convertVisitNameToUrl(data.visitName);
            progressBar.style.width = '100%';
            progressBar.textContent = '';
            sizeProgressDisplay.innerHTML = `(${renderFileSizePair(file.size, file.size)})`;
            setInlineStatus('上传完成', 'success');

            await addSavedUpload(file, data, convertedUrl);

            const nameParts = splitFileName(file.name);
            window.uploadedFileMetaById[fileId] = {
              fileNameNoExt: String(data.fileNameNoExt || encodeURIComponent(nameParts.fileNameNoExt || '') || '').trim(),
              fileExtName: String(data.fileExtName || nameParts.fileExtName || '').trim(),
              fileSize: Number(data.fileSize || file.size || 0),
              sha256: await globalThis.BjtuVeUploadCommon.fileHash(file),
              visitName: String(data.visitName || '').trim(),
              pid: '',
              ftype: 'insert',
              fileName: String(file.name || '').trim(),
              url: convertedUrl
            };
            if (uploadSelectWrap instanceof HTMLElement) {
              uploadSelectWrap.style.display = 'none';
            }
            refreshUploadSelectVisibility();

            // Hide progress bar container and render link + copy button at the same position
            const pc = item.querySelector('.progress-bar-container');
            if (pc) {
              const row = document.createElement('div');
              row.className = 'upload-link-row';
              const a = document.createElement('a');
              a.className = 'url-link';
              a.href = convertedUrl;
              a.target = '_blank';
              a.rel = 'noopener noreferrer';
              a.textContent = convertedUrl;
              a.style.color = '#4CAF50';
              a.style.fontWeight = '700';
              a.style.textDecoration = 'none';
              const btn = document.createElement('button');
              btn.className = 'btn';
              btn.style.padding = '2px 8px';
              btn.style.fontSize = '12px';
              btn.style.whiteSpace = 'nowrap';
              btn.textContent = '复制';
              btn.addEventListener('click', () => {
                navigator.clipboard.writeText(convertedUrl).then(() => {
                  showToast('链接已复制', 'success', 1200);
                });
              });
              row.appendChild(a);
              row.appendChild(btn);
              pc.replaceWith(row);
            }

            if (window.filesData[fileId]) {
              window.filesData[fileId].uploaded = file.size;
              updateTotalProgress();
            }
            cancelBtn.style.display = 'none';
            completeUpload({
              fileName: String(file.name || ''),
              fileSize: Number(file.size || 0),
              mimeType: String(file.type || ''),
              url: convertedUrl,
              visitName: String(data.visitName || '')
            });
          } else {
            const msg = data.ERRMSG || '未知错误';
            setInlineStatus(`上传失败：${msg}`, 'error');
            progressBar.style.backgroundColor = '#f44336';
            if (String(msg).includes('不合法') || String(msg).includes('登录')) {
              isLoginSessionValid = false;
              queueAutoRetryAfterLogin();
            }
            showRetry();
            failUpload(msg, /登录|不合法/.test(String(msg)) ? 'LOGIN_REQUIRED' : '');
          }
        } catch {
          const raw = String(xhr.responseText || '').trim();
          // Server sometimes returns plain text, e.g. “上传文件类型不支持,请更换文件！”
          const msg = raw ? escapeHtml(raw).slice(0, 300) : '返回非 JSON';
          setInlineStatus(`上传失败：${msg}`, 'error');
          progressBar.style.backgroundColor = '#f44336';
          showRetry();
          failUpload(raw || '上传接口返回非 JSON');
        }
        resolve();
      };

      xhr.onerror = () => {
        xhrRef = null;
        // If user already requested cancel, treat as cancel
        if (cancelRequested) {
          doCancelUiAndAccounting();
          resolve();
          return;
        }
        setSpeedDisplay(speedDisplay, 0, '');
        if (etaDisplay) etaDisplay.textContent = '';
        delete window.activeSpeeds[speedId];
        updateTotalSpeed();
        setInlineStatus('网络请求失败', 'error');
        progressBar.style.backgroundColor = '#f44336';
        showRetry();
        failUpload('网络请求失败');
        resolve();
      };

      if (cancelRequested) {
        try { xhr.abort(); } catch {}
        return;
      }

      xhr.send(fd);
    });

    isRunning = false;
    xhrRef = null;
    releaseSlot();
    if (resumeAfterPause) { resumeAfterPause = false; resumeValidatedUpload(); }
  };

  uploadQueue.push(performUpload);
  processQueue();
  return completion;
}

// -------------------- Events --------------------
let dropZoneFilePickerOpening = false;
dropZone.addEventListener('click', async (event) => {
  const target = event?.target;
  if (target === fileInput
    || (target instanceof Element && target.closest('#paste-file-btn,button,a,input,label'))
    || dropZoneFilePickerOpening) return;
  dropZoneFilePickerOpening = true;
  try {
    await ensureVeUploadSession();
    fileInput.click();
  } catch {
    // 登录流程自身负责提示；登录失败或取消时不打开文件选择器。
  } finally {
    dropZoneFilePickerOpening = false;
  }
});
dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.remove('dragover', 'dragover-invalid', 'dragover-text');
  const dt = e.dataTransfer;
  if (!dt) return;
  const types = Array.from(dt.types || []);
  if (types.includes('Files')) {
    dropZone.classList.add('dragover');
  } else if (types.includes('text/plain') || types.includes('text/html')) {
    dropZone.classList.add('dragover-text');
  } else {
    dropZone.classList.add('dragover-invalid');
  }
});
dropZone.addEventListener('dragleave', (e) => {
  e.preventDefault();
  dropZone.classList.remove('dragover', 'dragover-invalid', 'dragover-text');
});
dropZone.addEventListener('drop', async (e) => {
  e.preventDefault();
  dropZone.classList.remove('dragover', 'dragover-invalid', 'dragover-text');

  const dt = e.dataTransfer;
  const types = Array.from(dt?.types || []);
  if (types.includes('Files')) {
    const files = await clipboardDataToFiles(dt);
    if (files.length) {
      processFilesForUpload(files);
    } else {
      showToast('未找到可上传的文件', 'warning', 1800);
    }
    return;
  }

  const textFiles = await convertTextDropToFiles(dt);
  processFilesForUpload(textFiles);
});

fileInput.addEventListener('change', handleFiles);

if (dropZone instanceof HTMLElement) {
  dropZone.tabIndex = 0;
}

function cloneFileWithPath(file, relativePath = '') {
  const name = String(relativePath || file?.webkitRelativePath || file?.name || 'pasted-file').replace(/^[/\\]+/, '');
  if (!name || name === file.name) return file;
  return new File([file], name, { type: file.type || '', lastModified: file.lastModified || Date.now() });
}

function readFileEntry(entry, basePath = '') {
  return new Promise((resolve) => {
    try {
      entry.file((file) => {
        const rel = `${basePath || ''}${file.name || entry.name || 'file'}`;
        resolve([cloneFileWithPath(file, rel)]);
      }, () => resolve([]));
    } catch {
      resolve([]);
    }
  });
}

async function readDirectoryEntry(entry, basePath = '') {
  const dirPath = `${basePath || ''}${entry.name || 'folder'}/`;
  const reader = entry.createReader();
  const children = [];
  while (true) {
    const batch = await new Promise((resolve) => {
      try { reader.readEntries(resolve, () => resolve([])); } catch { resolve([]); }
    });
    if (!batch.length) break;
    children.push(...batch);
  }
  const nested = await Promise.all(children.map((child) => readEntryFiles(child, dirPath)));
  return nested.flat();
}

async function readEntryFiles(entry, basePath = '') {
  if (!entry) return [];
  if (entry.isFile) return readFileEntry(entry, basePath);
  if (entry.isDirectory) return readDirectoryEntry(entry, basePath);
  return [];
}

async function clipboardDataToFiles(dt) {
  if (!dt) return [];
  const items = Array.from(dt.items || []);
  // 先同步提取所有 entry，避免 async 中 DataTransfer 作废导致后续条目丢失
  const tasks = items.map((item) => {
    const entry = typeof item.webkitGetAsEntry === 'function' ? item.webkitGetAsEntry() : null;
    if (entry) return readEntryFiles(entry);
    if (item.kind === 'file') {
      const file = item.getAsFile();
      return file ? [file] : [];
    }
    return [];
  });
  const nested = await Promise.all(tasks);
  const files = nested.flat();
  if (!files.length && dt.files?.length) files.push(...Array.from(dt.files));
  return files;
}

async function handleClipboardUploadPaste(e) {
  const active = document.activeElement;
  if (active && (
    active instanceof HTMLInputElement ||
    active instanceof HTMLTextAreaElement ||
    active.isContentEditable
  )) return;
  const files = await clipboardDataToFiles(e.clipboardData);
  if (!files.length) return;
  e.preventDefault();
  processFilesForUpload(files);
}

document.addEventListener('paste', (e) => {
  handleClipboardUploadPaste(e).catch((err) => {
    showToast(`粘贴失败：${String(err?.message || err)}`, 'error', 3000);
  });
});

const pasteFileBtn = document.getElementById('paste-file-btn');
if (pasteFileBtn) {
  pasteFileBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    try {
      const { files, textCount } = await globalThis.BjtuVeUploadCommon.readClipboardFiles();
      if (!files.length) {
        showToast('没有读取到可上传的内容；若已复制文件，请在页面按 Ctrl+V 粘贴', 'warning', 3000);
        return;
      }
      await ensureVeUploadSession();
      const nonTextCount = files.length - textCount;
      if (textCount > 0 && nonTextCount === 0) {
        showToast(`已将剪贴板文本转为 ${files.length} 个文件，正在上传…`, 'info', 3000);
      } else if (textCount > 0) {
        showToast(`已粘贴 ${nonTextCount} 个文件，${textCount} 个文本已转为文件，正在上传…`, 'info', 3000);
      }
      processFilesForUpload(files);
    } catch (err) {
      if (String(err?.message || err).includes('clipboard-read')) {
        showToast('没有剪贴板读取权限，请授予后重试', 'error', 3000);
      } else {
        showToast(`粘贴失败：${String(err?.message || err)}`, 'error', 3000);
      }
    }
  });
}

fileList.addEventListener('click', (e) => {
  const rawTarget = e.target;
  const t = rawTarget instanceof Element
    ? rawTarget
    : (rawTarget && rawTarget.nodeType === Node.TEXT_NODE ? rawTarget.parentElement : null);
  if (!(t instanceof Element)) return;
  const row = t.closest('.upload-file-head-row');
  if (!(row instanceof HTMLElement)) return;
  if (t.closest('button,a,input,textarea,select,label')) return;
  const cb = row.querySelector('input.submit-file-check');
  if (!(cb instanceof HTMLInputElement)) return;
  cb.checked = !cb.checked;
  cb.dispatchEvent(new Event('change', { bubbles: true }));
});

async function processFilesForUpload(files, { waitForCompletion = false } = {}) {
  if (!files || !files.length) return;
  let filesList = Array.from(files).filter(Boolean);
  if (!filesList.length) return;

  const unsupportedFiles = filesList.filter((file) => !globalThis.BjtuVeUploadCommon.extensions.includes(globalThis.BjtuVeUploadCommon.fileExtension(file)));
  if (unsupportedFiles.length && !globalThis.BjtuVeUploadCommon.confirmUnsupportedFiles(unsupportedFiles)) {
    const unsupportedSet = new Set(unsupportedFiles);
    filesList = filesList.filter((file) => !unsupportedSet.has(file));
    if (!filesList.length) {
      if (waitForCompletion) {
        throw Object.assign(new Error('用户取消上传不受支持的文件'), { code: 'USER_CANCELLED' });
      }
      return [];
    }
  }

  try {
    await ensureVeUploadSession();
  } catch (error) {
    if (waitForCompletion) throw error;
    return [];
  }

  const tasks = filesList.map(enqueueUploadFile);
  updateTotalProgress();
  if (waitForCompletion) {
    const results = await Promise.all(tasks);
    const uploaded = results.filter((result) => !result?.cancelled);
    if (results.some((result) => result?.cancelled)) {
      return { fileList: uploadResultsToFileList(uploaded),
        message: '用户取消了重复文件上传；其他文件不受影响，已发送到服务器的数据无法撤回。' };
    }
    return uploaded;
  }
  tasks.forEach((task) => task.catch(() => {}));
  return [];
}

function uploadResultsToFileList(uploaded) {
  return (Array.isArray(uploaded) ? uploaded : []).map(globalThis.BjtuVeUploadCommon.fileListItem).filter(Boolean);
}

function handleFiles(e) {
  const files = e.target.files || e.dataTransfer.files;
  processFilesForUpload(files);
}

function decodeApiUploadBase64(value) {
  const source = String(value || '').trim().replace(/^data:[^,]*;base64,/i, '').replace(/\s+/g, '');
  if (!source) return new Uint8Array();
  let binary;
  try { binary = atob(source); } catch { throw new Error('base64 文件内容无效'); }
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function buildApiUploadFile(args = {}) {
  if (args?.__localFile instanceof File) return args.__localFile;
  let fileName = String(args?.fileName || args?.name || '').trim();
  const requestedMimeType = String(args?.mimeType || args?.type || '').trim();
  let blob;
  if (args?.dataBase64 !== undefined || args?.base64 !== undefined) {
    blob = new Blob([decodeApiUploadBase64(args.dataBase64 ?? args.base64)], { type: requestedMimeType || 'application/octet-stream' });
  } else if (Array.isArray(args?.bytes)) {
    const values = args.bytes.map((item) => Number(item));
    if (values.some((item) => !Number.isInteger(item) || item < 0 || item > 255)) {
      throw new Error('bytes 必须是由 0 至 255 整数组成的数组');
    }
    blob = new Blob([new Uint8Array(values)], { type: requestedMimeType || 'application/octet-stream' });
  } else if (args?.text !== undefined || args?.content !== undefined) {
    blob = new Blob([String(args.text ?? args.content ?? '')], { type: requestedMimeType || 'text/plain' });
  } else if (String(args?.url || '').trim()) {
    const sourceUrl = new URL(String(args.url).trim()).href;
    const sourceHost = new URL(sourceUrl).hostname;
    const response = await fetch(sourceUrl, {
      credentials: sourceHost === '127.0.0.1' || sourceHost === 'localhost' ? 'omit' : 'include',
      cache: 'no-store'
    });
    if (!response.ok) throw new Error(`获取待上传文件失败：HTTP ${response.status}`);
    blob = await response.blob();
    if (!fileName) {
      const inferredName = new URL(response.url || sourceUrl).pathname.split('/').filter(Boolean).pop() || 'upload.bin';
      try { fileName = decodeURIComponent(inferredName); } catch { fileName = inferredName; }
    }
  } else {
    throw new Error('缺少文件内容：请提供 text/content、base64/dataBase64、bytes 或 url');
  }
  if (!fileName) throw new Error('缺少参数 fileName');
  return new File([blob], fileName, { type: requestedMimeType || blob.type || 'application/octet-stream', lastModified: Date.now() });
}

function selectLocalFilesForApi({ accept = VE_SUPPORTED_UPLOAD_ACCEPT } = {}) {
  return new Promise((resolve, reject) => {
    if (!(fileInput instanceof HTMLInputElement)) {
      reject(new Error('页面文件选择器不存在'));
      return;
    }
    const previousAccept = fileInput.accept;
    fileInput.accept = String(accept || VE_SUPPORTED_UPLOAD_ACCEPT).trim();
    fileInput.value = '';
    let settled = false;
    let focusTimer = 0;
    const cleanup = () => {
      clearTimeout(focusTimer);
      globalThis.removeEventListener('focus', onWindowFocus, true);
      fileInput.removeEventListener('change', onChange, true);
      fileInput.removeEventListener('cancel', onCancel, true);
      fileInput.accept = previousAccept;
    };
    const finish = (files) => {
      if (settled) return;
      settled = true;
      cleanup();
      const list = Array.from(files || []).filter((file) => file instanceof File);
      if (list.length) resolve(list);
      else reject(Object.assign(new Error('用户取消选择文件'), { code: 'USER_CANCELLED' }));
    };
    const onChange = (event) => {
      event.stopImmediatePropagation();
      finish(fileInput.files);
    };
    const onCancel = (event) => {
      event.stopImmediatePropagation();
      finish([]);
    };
    const onWindowFocus = () => {
      clearTimeout(focusTimer);
      focusTimer = setTimeout(() => finish(fileInput.files), 300);
    };
    fileInput.addEventListener('change', onChange, { capture: true, once: true });
    fileInput.addEventListener('cancel', onCancel, { capture: true, once: true });
    globalThis.addEventListener('focus', onWindowFocus, true);
    try { fileInput.click(); } catch (error) {
      settled = true;
      cleanup();
      reject(error);
    }
  });
}

async function uploadFileForApi(args = {}) {
  await ensureVeUploadSession();
  const hasSerializedSource = args?.dataBase64 !== undefined || args?.base64 !== undefined
    || Array.isArray(args?.bytes) || args?.text !== undefined || args?.content !== undefined
    || !!String(args?.url || '').trim();
  const files = hasSerializedSource
    ? [await buildApiUploadFile(args)]
    : await selectLocalFilesForApi({ accept: args?.accept });
  const results = await processFilesForUpload(files, { waitForCompletion: true });
  if (results?.message) return results;
  const uploaded = Array.isArray(results) ? results : [];
  return { fileList: uploadResultsToFileList(uploaded) };
}

globalThis.BjtuVeUploadApi = Object.freeze({
  uploadFile: uploadFileForApi,
  ensureSession: ensureVeUploadSession,
  getUploadUrl: getVeUploadUrl
});

async function convertTextDropToFiles(dt) {
  if (!dt) return [];
  const types = Array.from(dt.types || []);
  const files = [];

  if (types.includes('text/html')) {
    const html = dt.getData('text/html');
    if (html) {
      files.push(new File([new Blob([html], { type: 'text/html' })], 'pasted-content.html', { type: 'text/html' }));
      return files;
    }
  }

  if (types.includes('text/plain')) {
    const text = dt.getData('text/plain');
    if (text) {
      files.push(new File([new Blob([text], { type: 'text/plain' })], 'pasted-content.txt', { type: 'text/plain' }));
      return files;
    }
  }

  return files;
}

copyAllBtn.addEventListener('click', () => {
  let textToCopy = '';
  const appendChecked = (container) => {
    container.querySelectorAll('input.submit-file-check:checked').forEach(cb => {
      const item = cb.closest('.file-item');
      if (!item) return;
      const linkEl = item.querySelector('.url-link');
      if (!linkEl) return;
      const name = item.querySelector('strong')?.textContent || '';
      textToCopy += `${name}\n${linkEl.href}\n\n`;
    });
  };
  appendChecked(document.querySelector('#file-list'));
  const savedSection = document.querySelector('#saved-uploads-section[data-expanded="1"]');
  if (savedSection) appendChecked(savedSection);
  textToCopy = textToCopy.trim();
  if (!textToCopy) {
    showToast('请先选择文件', 'warning', 1200);
    return;
  }
  navigator.clipboard.writeText(textToCopy).then(() => {
    showToast('已复制选中链接', 'success', 1200);
  });
});
