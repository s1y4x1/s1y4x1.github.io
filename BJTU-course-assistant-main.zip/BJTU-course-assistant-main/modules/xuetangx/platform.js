(function initBjtuXuetangxPlatform(global) {
  'use strict';

  const BASE = 'https://www.xuetangx.com';
  const COURSE_LIST_URL = `${BASE}/api/v1/lms/user/user-courses`;
  const LOGIN_HEADER_RULE_IDS = Object.freeze([914309, 914310]);
  const SECOND_CSRF_COOKIE_RULE_ID = 914312;
  const COURSE_STATUS_LABELS = Object.freeze({
    1: '正在上课',
    2: '即将开课',
    3: '已结课',
    4: '已退课'
  });
  const ACTIVITY_TYPES = Object.freeze({
    6: { label: '视频', path: 'video', action: 'learn' },
    7: { label: '图文', path: 'article', action: 'view' },
    8: { label: '直播', path: 'liveunit', action: 'view' },
    10: { label: '讨论', path: 'discussion', action: 'view' },
    11: { label: '作业', path: 'exercise', action: 'submit' },
    12: { label: '考试', path: 'exam', action: 'exam' }
  });
  const DEFAULT_VISIBLE_STATUSES = Object.freeze([1]);
  const DEFAULT_VISIBLE_ACTIVITY_TYPES = Object.freeze(Object.keys(ACTIVITY_TYPES).map(Number));
  const CHAPTER_LEAF_TYPE_TO_ACTIVITY_TYPE = Object.freeze({
    0: 6,
    2: 8,
    3: 7,
    4: 10,
    6: 11
  });
  const THEME_COLOR = '#1769fe';
  const expandedGroups = new Map();
  let env = null;
  let courses = [];
  let loadSerial = 0;
  let qrLoginCancelled = false;
  let qrLoginSocket = null;
  let qrLoginState = null;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const escape = (value) => env?.escape?.(String(value ?? '')) ?? String(value ?? '');

  function formatTime(value) {
    const timestamp = Number(value || 0);
    const date = new Date(timestamp);
    if (!timestamp || Number.isNaN(date.getTime())) return '无期限';
    const pad = (part) => String(part).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function formatProgress(value) {
    const ratio = Math.max(0, Math.min(1, Number(value) || 0));
    const percent = ratio * 100;
    if (percent >= 99.95) return '100%';
    if (percent >= 10) return `${percent.toFixed(1).replace(/\.0$/, '')}%`;
    return `${percent.toFixed(2).replace(/0+$/, '').replace(/\.$/, '')}%`;
  }

  function normalizeSchedule(value) {
    const number = Number(value);
    if (!Number.isFinite(number) || number <= 0) return 0;
    return Math.max(0, Math.min(1, number > 1 ? number / 100 : number));
  }

  function normalizeVisibleStatuses(value) {
    const source = Array.isArray(value) ? value : DEFAULT_VISIBLE_STATUSES;
    const statuses = [...new Set(source.map(Number).filter((item) => COURSE_STATUS_LABELS[item]))];
    return statuses.length ? statuses : [...DEFAULT_VISIBLE_STATUSES];
  }

  async function getVisibleStatuses() {
    const stored = await chrome.storage.local.get(['xuetangxCourseStatuses']).catch(() => ({}));
    return normalizeVisibleStatuses(stored.xuetangxCourseStatuses);
  }

  async function getVisibleActivityTypes() {
    const stored = await chrome.storage.local.get(['xuetangxActivityTypes']).catch(() => ({}));
    const source = Array.isArray(stored.xuetangxActivityTypes)
      ? stored.xuetangxActivityTypes
      : DEFAULT_VISIBLE_ACTIVITY_TYPES;
    return new Set(source.map(Number).filter((item) => ACTIVITY_TYPES[item]));
  }

  async function ensureDirectLoginHeaders() {
    if (!chrome?.declarativeNetRequest?.updateSessionRules) return;
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [...LOGIN_HEADER_RULE_IDS],
      addRules: [
        {
          id: LOGIN_HEADER_RULE_IDS[0],
          priority: 1,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [{ header: 'Origin', operation: 'set', value: BASE }]
          },
          condition: {
            regexFilter: '^wss://www\\.xuetangx\\.com/wsapp/(?:[?#].*)?$',
            initiatorDomains: [chrome.runtime.id],
            resourceTypes: ['websocket']
          }
        },
        {
          id: LOGIN_HEADER_RULE_IDS[1],
          priority: 1,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [
              { header: 'Origin', operation: 'set', value: BASE },
              { header: 'Referer', operation: 'set', value: `${BASE}/` }
            ]
          },
          condition: {
            urlFilter: '||www.xuetangx.com/api/v1/u/login/wx/',
            initiatorDomains: [chrome.runtime.id],
            resourceTypes: ['xmlhttprequest']
          }
        }
      ]
    });
  }

  async function getXuetangxCsrfToken() {
    const cookies = await chrome.cookies.getAll({ url: `${BASE}/` }).catch(() => []);
    const csrfCookie = cookies.find((cookie) => ['csrftoken', 'csrf_token', 'x_csrftoken'].includes(String(cookie?.name || '').toLowerCase()));
    if (!csrfCookie?.value) return '';
    try { return decodeURIComponent(csrfCookie.value); } catch { return String(csrfCookie.value); }
  }

  function normalizeCsrfToken(value) {
    let token = String(value || '').trim();
    if (/^csrftoken\s*=/i.test(token)) token = token.slice(token.indexOf('=') + 1).split(';', 1)[0].trim();
    try { return decodeURIComponent(token); } catch { return token; }
  }

  let secondCookieRequestQueue = Promise.resolve();

  async function updateSecondCsrfCookieRule(cookieHeader) {
    if (!chrome?.declarativeNetRequest?.updateSessionRules) return false;
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [SECOND_CSRF_COOKIE_RULE_ID],
      addRules: [{
        id: SECOND_CSRF_COOKIE_RULE_ID,
        priority: 1000,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
            header: 'cookie',
            operation: 'set',
            value: String(cookieHeader || '')
          }]
        },
        condition: {
          urlFilter: '||www.xuetangx.com/api/v1/lms/exercise/',
          initiatorDomains: [chrome.runtime.id],
          resourceTypes: ['xmlhttprequest']
        }
      }]
    });
    return true;
  }

  async function removeSecondCsrfCookieRule() {
    if (!chrome?.declarativeNetRequest?.updateSessionRules) return;
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [SECOND_CSRF_COOKIE_RULE_ID]
    }).catch(() => {});
  }

  function fetchWithSecondCsrfCookie(url, options, cookieHeader) {
    const run = secondCookieRequestQueue.then(async () => {
      const ruleInstalled = await updateSecondCsrfCookieRule(cookieHeader);
      try {
        return await fetch(String(url), {
          ...options,
          credentials: 'omit'
        });
      } finally {
        if (ruleInstalled) await removeSecondCsrfCookieRule();
      }
    });
    secondCookieRequestQueue = run.catch(() => {});
    return run;
  }

  async function requestJson(url, serial, csrfOverride = '', cookieOverride = '') {
    if (serial !== loadSerial) throw Object.assign(new Error('学堂在线加载已取消'), { code: 'cancelled' });
    const explicitCsrf = normalizeCsrfToken(csrfOverride);
    const csrf = explicitCsrf || await getXuetangxCsrfToken();
    const cookieHeader = String(cookieOverride || '').trim();
    const headers = {
      accept: 'application/json, text/plain, */*',
      'x-client': 'web',
      xtbz: 'xt'
    };
    if (csrf) headers['x-csrftoken'] = csrf;
    if (explicitCsrf) headers.cookie = cookieHeader || `csrftoken=${encodeURIComponent(csrf)}`;
    let result = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (serial !== loadSerial) throw Object.assign(new Error('学堂在线加载已取消'), { code: 'cancelled' });
      try {
        const response = explicitCsrf
          ? await fetchWithSecondCsrfCookie(String(url), {
            method: 'GET',
            headers,
            cache: 'no-store'
          }, cookieHeader)
          : await fetch(String(url), {
          method: 'GET',
          headers,
          credentials: 'include',
          cache: 'no-store'
        });
        const text = await response.text();
        let data = null;
        try { data = JSON.parse(text); } catch {}
        result = {
          ok: response.ok,
          status: response.status,
          responseUrl: response.url,
          data,
          text: data ? '' : text.slice(0, 500)
        };
        if (response.status !== 429 && response.status < 500) break;
      } catch (error) {
        result = { ok: false, status: 0, error: String(error?.message || error) };
      }
      if (attempt < 2) await sleep(400 * (attempt + 1));
    }
    const hasStructuredApiError = !!result?.data && result.data.success === false;
    if ((!result?.ok && !hasStructuredApiError) || !result?.data) {
      const loginLike = [401, 403].includes(Number(result?.status))
        || /login|登录|<!doctype|<html/i.test(String(result?.text || result?.responseUrl || ''));
      const error = new Error(loginLike
        ? '未登录学堂在线'
        : `学堂在线请求失败${result?.status ? `（HTTP ${result.status}）` : ''}：${result?.error || result?.text || '响应不是 JSON'}`);
      error.code = loginLike ? 'not-logged-in' : 'request-failed';
      throw error;
    }
    return result.data;
  }

  function hasAnswer(value) {
    if (value === undefined || value === null) return false;
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === 'object') return Object.keys(value).length > 0;
    return String(value).trim() !== '';
  }

  function problemIsFillBlank(problem) {
    const content = problem?.content || {};
    const typeText = String(content.TypeText || content.type_text || content.Type || problem?.type_text || problem?.type || '').trim();
    return (Array.isArray(content.Blanks) && content.Blanks.length > 0) || /填空/.test(typeText);
  }

  function problemIsJudgement(problem) {
    const content = problem?.content || {};
    const typeText = String(content.TypeText || content.type_text || content.Type || problem?.type_text || problem?.type || '').trim();
    return /判断|正误|对错/.test(typeText);
  }

  function problemIsSubjective(problem) {
    const content = problem?.content || {};
    const type = String(content.Type || problem?.Type || problem?.type || '').trim();
    const typeText = String(content.TypeText || content.type_text || problem?.TypeText || problem?.type_text || '').trim();
    return /^ShortAnswer$/i.test(type) || /主观题/.test(typeText);
  }

  function normalizeFillAnswers(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    return Object.fromEntries(Object.entries(value).map(([key, answer]) => {
      const item = Array.isArray(answer) ? answer[0] : (answer && typeof answer === 'object' ? answer.answer : answer);
      return [String(key), item === undefined || item === null ? '' : String(item)];
    }));
  }

  function normalizeChoiceAnswer(value) {
    const source = Array.isArray(value) ? value : [value];
    return source
      .filter((item) => item !== undefined && item !== null && String(item).trim() !== '')
      .map((item) => String(item));
  }

  function answerForSubmit(problem, answerData) {
    if (problemIsFillBlank(problem)) {
      const answers = normalizeFillAnswers(answerData?.answers ?? answerData?.answer);
      return hasAnswer(answers) ? { answers, answer: '' } : null;
    }
    const answer = normalizeChoiceAnswer(answerData?.answer);
    return answer.length ? { answers: {}, answer } : null;
  }

  function answerFromSecondProblem(problem) {
    const userAnswer = problem?.user?.answer;
    if (!hasAnswer(userAnswer)) return null;
    if (problemIsFillBlank(problem)) {
      const answers = typeof userAnswer === 'object' && !Array.isArray(userAnswer)
        ? normalizeFillAnswers(userAnswer)
        : { '1': String(userAnswer) };
      return hasAnswer(answers) ? { answers, answer: '' } : null;
    }
    const answer = normalizeChoiceAnswer(userAnswer);
    return answer.length ? { answers: {}, answer } : null;
  }

  function secondProblemHasSubmittedAnswer(problem) {
    return !!problem?.user
      && Object.prototype.hasOwnProperty.call(problem.user, 'answer')
      && problem.user.answer !== undefined
      && problem.user.answer !== null;
  }

  function probeAnswerForProblem(problem) {
    if (problemIsFillBlank(problem)) return { answers: {}, answer: '' };
    if (problemIsJudgement(problem)) return { answers: {}, answer: ['true'] };
    const options = Array.isArray(problem?.content?.Options) ? problem.content.Options : [];
    const firstKey = options.find((option) => option?.key !== undefined && option?.key !== null)?.key;
    return { answers: {}, answer: [String(firstKey ?? 'A')] };
  }

  function problemIdOf(problem) {
    return String(problem?.problem_id ?? problem?.problemId ?? problem?.id ?? '').trim();
  }

  function integerId(value) {
    const number = Number(value);
    return Number.isSafeInteger(number) && number > 0 ? number : 0;
  }

  function buildProblemApplyPayload(course, task, problem, answer) {
    const payload = {
      leaf_id: integerId(problem?.leaf_id ?? problem?.leafId ?? task.chapterLeafId),
      classroom_id: integerId(course.classroomId),
      exercise_id: integerId(task.exerciseTypeId || task.exerciseId),
      problem_id: integerId(problemIdOf(problem)),
      sign: String(course.sign || ''),
      answers: answer?.answers || {},
      answer: answer?.answer ?? []
    };
    if (!payload.leaf_id || !payload.exercise_id || !payload.problem_id || !payload.classroom_id || !payload.sign) {
      throw new Error('题目响应缺少提交所需的 ID 或 sign');
    }
    return payload;
  }

  function rateLimitWaitSeconds(response, data) {
    const detail = String(data?.detail || '');
    const match = detail.match(/Expected\s+available\s+in\s+([\d.]+)\s+seconds?/i);
    if (match) {
      const seconds = Number(match[1]);
      if (Number.isFinite(seconds) && seconds >= 0) return seconds;
    }
    return Number(response?.status) === 429 ? 1 : null;
  }

  async function waitForProblemApplyRateLimit(response, data, serial) {
    const seconds = rateLimitWaitSeconds(response, data);
    if (seconds === null) return false;
    if (serial !== loadSerial) throw Object.assign(new Error('学堂在线操作已取消'), { code: 'cancelled' });
    await sleep(Math.max(100, Math.ceil(seconds * 1000)));
    if (serial !== loadSerial) throw Object.assign(new Error('学堂在线操作已取消'), { code: 'cancelled' });
    return true;
  }

  async function postProblemApply(payload, csrfOverride, serial, cookieOverride = '') {
    if (serial !== loadSerial) throw Object.assign(new Error('学堂在线操作已取消'), { code: 'cancelled' });
    const explicitCsrf = normalizeCsrfToken(csrfOverride);
    const csrf = explicitCsrf || await getXuetangxCsrfToken();
    const cookieHeader = String(cookieOverride || '').trim();
    const headers = {
      accept: 'application/json, text/plain, */*',
      'content-type': 'application/json',
      'x-client': 'web',
      xtbz: 'xt'
    };
    if (csrf) headers['x-csrftoken'] = csrf;
    if (explicitCsrf) headers.cookie = cookieHeader || `csrftoken=${encodeURIComponent(csrf)}`;
    let response = null;
    let data = null;
    while (true) {
      try {
        const requestOptions = {
          method: 'POST',
          headers,
          cache: 'no-store',
          body: JSON.stringify(payload)
        };
        response = explicitCsrf
          ? await fetchWithSecondCsrfCookie(`${BASE}/api/v1/lms/exercise/problem_apply/`, requestOptions, cookieHeader)
          : await fetch(`${BASE}/api/v1/lms/exercise/problem_apply/`, {
            ...requestOptions,
            credentials: 'include'
          });
        const text = await response.text();
        data = null;
        try { data = JSON.parse(text); } catch {}
        if (!data) throw new Error(text.slice(0, 300) || `HTTP ${response.status}`);
      } catch (error) {
        if (error?.code === 'cancelled') throw error;
        const wrapped = new Error(`学堂在线提交请求失败${response?.status ? `（HTTP ${response.status}）` : ''}：${error?.message || error}`);
        wrapped.code = 'request-failed';
        throw wrapped;
      }
      if (!await waitForProblemApplyRateLimit(response, data, serial)) break;
    }
    if (!response.ok || data?.success !== true) {
      const error = new Error(String(data?.msg || `学堂在线提交失败（HTTP ${response.status}）`));
      error.code = Number(data?.error_code) === 80001 ? 'no-chance' : (response.status === 401 || response.status === 403 ? 'not-logged-in' : 'submit-failed');
      error.errorCode = Number(data?.error_code) || 0;
      error.response = data;
      throw error;
    }
    return data;
  }

  function normalizeCookieValue(value, name) {
    let cookie = String(value || '').trim();
    const prefix = new RegExp(`^${name}\\s*=`, 'i');
    if (prefix.test(cookie)) cookie = cookie.slice(cookie.indexOf('=') + 1).split(';', 1)[0].trim();
    try { return decodeURIComponent(cookie); } catch { return cookie; }
  }

  async function getSecondCredentialsForUse() {
    const stored = await chrome.storage.local.get([
      'xuetangxSecondCsrfToken',
      'xuetangxSecondSessionId'
    ]).catch(() => ({}));
    const secondCsrf = normalizeCsrfToken(stored?.xuetangxSecondCsrfToken);
    const secondSessionId = normalizeCookieValue(stored?.xuetangxSecondSessionId, 'sessionid');
    if (!secondCsrf) throw new Error('请先在扩展选项中填写学堂在线第二账号 csrftoken');
    if (!secondSessionId) throw new Error('请先在扩展选项中填写学堂在线第二账号 sessionid');
    const currentCsrf = normalizeCsrfToken(await getXuetangxCsrfToken());
    if (!currentCsrf) throw new Error('无法读取当前学堂在线 csrftoken，请先登录主账号');
    if (currentCsrf === secondCsrf) {
      throw new Error('当前登录账号与第二账号相同，请先切换到主账号后再查答并提交');
    }
    return {
      csrf: secondCsrf,
      cookie: `csrftoken=${encodeURIComponent(secondCsrf)}; sessionid=${encodeURIComponent(secondSessionId)}`
    };
  }

  async function submitAnswersFromSecondAccount(course, task, { secondCredentials = null, silent = false } = {}) {
    if (task.secondAnswerBusy) return;
    task.secondAnswerBusy = true;
    render();
    const serial = loadSerial;
    try {
      const credentials = secondCredentials || await getSecondCredentialsForUse();
      const verifiedSecondCsrf = credentials.csrf;
      if (!task.exerciseTypeId || !task.exerciseSkuId) throw new Error('作业参数尚未加载完成，请稍后重试');
      const listUrl = `${BASE}/api/v1/lms/exercise/get_exercise_list/${encodeURIComponent(task.exerciseTypeId)}/${encodeURIComponent(task.exerciseSkuId)}/`;
      const secondList = await requestJson(listUrl, serial, verifiedSecondCsrf, credentials.cookie);
      if (secondList?.success === false) throw new Error(secondList?.msg || '第二账号题目接口返回失败');
      const secondProblems = Array.isArray(secondList?.data?.problems) ? secondList.data.problems : [];
      if (!secondProblems.length) throw new Error('第二账号未获取到题目');
      const primaryProblems = Array.isArray(task.exerciseProblems) ? task.exerciseProblems : [];
      const primaryById = new Map(primaryProblems.map((problem) => [problemIdOf(problem), problem]));
      let submitted = 0;
      let skipped = 0;
      let unavailable = 0;
      for (let index = 0; index < secondProblems.length; index += 1) {
        const secondProblem = secondProblems[index];
        const primaryProblem = primaryById.get(problemIdOf(secondProblem));
        if (problemIsSubjective(secondProblem) || problemIsSubjective(primaryProblem)) {
          skipped += 1;
          continue;
        }
        const maxCount = Number(primaryProblem?.user?.count ?? secondProblem?.user?.count ?? 0);
        const myCount = Number(primaryProblem?.user?.my_count ?? 0);
        if (maxCount > 0 && myCount >= maxCount) {
          skipped += 1;
          continue;
        }
        let answer = answerFromSecondProblem(secondProblem);
        if (!answer && !secondProblemHasSubmittedAnswer(secondProblem)) {
          try {
            const probe = await postProblemApply(
              buildProblemApplyPayload(course, task, secondProblem, probeAnswerForProblem(secondProblem)),
              verifiedSecondCsrf,
              serial,
              credentials.cookie
            );
            answer = answerForSubmit(secondProblem, probe?.data);
          } catch (error) {
            if (error?.code === 'no-chance') unavailable += 1;
            else throw error;
          }
        }
        if (!answer) {
          unavailable += 1;
          continue;
        }
        try {
          await postProblemApply(buildProblemApplyPayload(course, task, secondProblem, answer), '', serial);
          submitted += 1;
        } catch (error) {
          if (error?.code === 'no-chance') skipped += 1;
          else throw error;
        }
      }
      if (submitted || secondProblems.length) {
        const refreshed = await requestJson(listUrl, serial);
        if (refreshed?.success === true) {
          task.exerciseProblems = Array.isArray(refreshed?.data?.problems) ? refreshed.data.problems : task.exerciseProblems;
          task.done = task.exerciseProblems.length > 0
            && task.exerciseProblems.every((problem) => Number(problem?.user?.my_count) > 0);
          task.overdue = !task.done && task.deadline > 0 && task.deadline < Date.now();
        }
      }
      render();
      const summary = { submitted, skipped, unavailable };
      if (!silent) {
        env?.toast?.(`学堂在线：已提交 ${submitted} 题${skipped ? `，跳过 ${skipped} 题` : ''}${unavailable ? `，${unavailable} 题未取得答案` : ''}`, submitted ? 'success' : 'info');
      }
      return summary;
    } catch (error) {
      if (!silent && error?.code !== 'cancelled') env?.toast?.(`学堂在线第二账号查答失败：${error?.message || error}`, 'error');
      return { submitted: 0, skipped: 0, unavailable: 0, error };
    } finally {
      task.secondAnswerBusy = false;
      if (serial === loadSerial) render();
    }
  }

  async function submitAllAnswersFromSecondAccount(course) {
    if (course.secondAnswerAllBusy) return;
    const tasks = course.tasks.filter((task) => task.typeId === 11);
    if (!tasks.length) {
      env?.toast?.('当前课程没有可提交的学堂在线作业', 'info');
      return;
    }
    course.secondAnswerAllBusy = true;
    render();
    try {
      const secondCredentials = await getSecondCredentialsForUse();
      const total = { submitted: 0, skipped: 0, unavailable: 0, failed: 0 };
      for (const task of tasks) {
        const result = await submitAnswersFromSecondAccount(course, task, { secondCredentials, silent: true });
        total.submitted += Number(result?.submitted || 0);
        total.skipped += Number(result?.skipped || 0);
        total.unavailable += Number(result?.unavailable || 0);
        if (result?.error && result.error.code !== 'cancelled') total.failed += 1;
      }
      env?.toast?.(`学堂在线：全部作业已处理，提交 ${total.submitted} 题${total.skipped ? `，跳过 ${total.skipped} 题` : ''}${total.unavailable ? `，${total.unavailable} 题未取得答案` : ''}${total.failed ? `，失败 ${total.failed} 项` : ''}`, total.failed ? 'error' : (total.submitted ? 'success' : 'info'));
    } catch (error) {
      if (error?.code !== 'cancelled') env?.toast?.(`学堂在线批量查答失败：${error?.message || error}`, 'error');
    } finally {
      course.secondAnswerAllBusy = false;
      render();
    }
  }

  function cancelQrLogin() {
    qrLoginCancelled = true;
    if (global.platformInteractiveLoginPending) global.platformInteractiveLoginPending.xuetangx = false;
    loadSerial += 1;
    hideQrLoginModal();
    void stopQrLoginSocket();
    env?.setState?.('offline');
  }

  function getQrLoginModal() {
    let modal = document.getElementById('xuetangx-login-modal');
    if (modal) return modal;
    modal = document.createElement('div');
    modal.id = 'xuetangx-login-modal';
    modal.className = 'version-modal-mask platform-qr-login-mask xuetangx-login-mask';
    modal.innerHTML = `<div class="version-modal-card platform-qr-login-card xuetangx-login-card">
      <div class="version-modal-header">
        <div class="platform-qr-login-title xuetangx-login-title">登录学堂在线</div>
        <button type="button" class="btn version-close-btn" data-xuetangx-login-close title="关闭" aria-label="关闭">×</button>
      </div>
      <div class="platform-qr-login-body xuetangx-login-body">
        <div class="platform-qr-login-status xuetangx-login-status"><span class="spinner xuetangx-inline-spinner"></span> 正在获取登录二维码…</div>
        <img class="platform-qr-login-image xuetangx-login-qr" alt="学堂在线微信登录二维码" hidden>
        <div class="platform-qr-login-tip xuetangx-login-tip">请使用微信扫码登录</div>
      </div>
    </div>`;
    modal.addEventListener('click', (event) => {
      if (!event.target.closest('[data-xuetangx-login-close]')) return;
      cancelQrLogin();
    });
    modal.addEventListener('pointerdown', (event) => {
      modal.dataset.pointerStartedOnMask = event.target === modal ? '1' : '0';
    });
    modal.addEventListener('pointerup', (event) => {
      const shouldClose = event.target === modal && modal.dataset.pointerStartedOnMask === '1';
      delete modal.dataset.pointerStartedOnMask;
      if (shouldClose) cancelQrLogin();
    });
    document.body.appendChild(modal);
    return modal;
  }

  function showQrLoginModal(ticket = '') {
    const modal = getQrLoginModal();
    const image = modal.querySelector('.xuetangx-login-qr');
    const status = modal.querySelector('.xuetangx-login-status');
    if (ticket && image instanceof HTMLImageElement) {
      if (image.src !== ticket) image.src = ticket;
      image.hidden = false;
      if (status) status.textContent = '等待扫码确认…';
    } else {
      if (image instanceof HTMLImageElement) image.hidden = true;
      if (status) status.innerHTML = '<span class="spinner xuetangx-inline-spinner"></span> 正在获取登录二维码…';
    }
    modal.classList.add('show');
  }

  function hideQrLoginModal() {
    document.getElementById('xuetangx-login-modal')?.classList.remove('show');
  }

  async function startQrLoginSocket() {
    await ensureDirectLoginHeaders();
    await stopQrLoginSocket();
    const state = { status: 'connecting', ticket: '', loginid: null, expiresAt: 0, error: '' };
    qrLoginState = state;
    try {
      const socket = new WebSocket('wss://www.xuetangx.com/wsapp/');
      qrLoginSocket = socket;
      socket.addEventListener('open', () => {
        if (qrLoginState !== state) return;
        state.status = 'requesting';
        socket.send(JSON.stringify({ op: 'requestlogin', role: 'web', version: '1.4', purpose: 'login', xtbz: 'xt', 'x-client': 'web' }));
      });
      socket.addEventListener('message', (event) => {
        if (qrLoginState !== state) return;
        let message = null;
        try { message = JSON.parse(String(event.data || '')); } catch { return; }
        if (message?.op === 'requestlogin' && message.ticket) {
          state.status = 'waiting';
          state.ticket = String(message.ticket);
          state.loginid = message.loginid ?? null;
          state.expiresAt = Date.now() + Math.max(1, Number(message.expire_seconds) || 60) * 1000;
        } else if (message?.op === 'loginsuccess') {
          state.status = 'success';
          state.token = String(message.token || '');
          state.userId = message.u_id ?? message.UserID ?? null;
        }
      });
      socket.addEventListener('error', () => {
        if (qrLoginState === state && state.status !== 'success') {
          state.status = 'error';
          state.error = '登录连接失败';
        }
      });
      socket.addEventListener('close', () => {
        if (qrLoginState === state && state.status !== 'success') state.status = 'closed';
      });
      return true;
    } catch (error) {
      state.status = 'error';
      state.error = String(error?.message || error);
      return false;
    }
  }

  function readQrLoginState() {
    return qrLoginState ? { ...qrLoginState } : null;
  }

  async function stopQrLoginSocket() {
    const socket = qrLoginSocket;
    qrLoginSocket = null;
    try { socket?.close(); } catch {}
    qrLoginState = null;
  }

  async function getXuetangxDistinctId() {
    const cookies = await chrome.cookies.getAll({ url: `${BASE}/` }).catch(() => []);
    const raw = String(cookies.find((cookie) => cookie?.name === 'sensorsdata2015jssdkcross')?.value || '');
    if (!raw) return '';
    let value = raw;
    try { value = decodeURIComponent(value); } catch {}
    try {
      const parsed = JSON.parse(value);
      return String(parsed?.distinct_id ?? parsed?.distinctId ?? parsed?.props?.distinct_id ?? '');
    } catch {}
    return String(value.match(/(?:distinct_id|distinctId)["'=:\s]+([^"'&,}\s]+)/i)?.[1] || '');
  }

  async function completeWechatLogin(token) {
    const sessionToken = String(token || '').trim();
    if (!sessionToken) throw new Error('学堂在线扫码登录未返回 token');
    await ensureDirectLoginHeaders();
    const csrf = await getXuetangxCsrfToken();
    const distinctId = await getXuetangxDistinctId();
    const payload = {
      s_s: sessionToken,
      preset_properties: {
        '$timezone_offset': new Date().getTimezoneOffset(),
        '$screen_height': Number(globalThis.screen?.height || 0),
        '$screen_width': Number(globalThis.screen?.width || 0),
        '$lib': 'js',
        '$lib_version': '1.19.14',
        '$latest_traffic_source_type': '直接流量',
        '$latest_search_keyword': '未取到值_直接打开',
        '$latest_referrer': '',
        '$is_first_day': false,
        '$referrer': `${BASE}/`,
        '$referrer_host': 'www.xuetangx.com',
        '$url': `${BASE}/`,
        '$url_path': '/',
        '$title': '学堂在线 - 精品在线课程学习平台',
        '_distinct_id': distinctId
      },
      page_name: '首页'
    };
    const headers = {
      accept: 'application/json, text/plain, */*',
      'content-type': 'application/json;charset=UTF-8',
      'x-client': 'web',
      xtbz: 'xt'
    };
    if (csrf) headers['x-csrftoken'] = csrf;
    let result;
    try {
      const response = await fetch(`${BASE}/api/v1/u/login/wx/`, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        credentials: 'include',
        cache: 'no-store'
      });
      const text = await response.text();
      let data = null;
      try { data = JSON.parse(text); } catch {}
      result = {
        ok: response.ok && data?.success !== false,
        status: response.status,
        data,
        message: data?.msg || data?.message || (data ? '' : text.slice(0, 300))
      };
    } catch (error) {
      result = { ok: false, status: 0, message: String(error?.message || error) };
    }
    if (!result?.ok) {
      throw new Error(`学堂在线微信登录失败${result?.status ? `（HTTP ${result.status}）` : ''}${result?.message ? `：${result.message}` : ''}`);
    }
    return result.data;
  }

  async function waitForQrLogin(serial) {
    qrLoginCancelled = false;
    showQrLoginModal();
    while (serial === loadSerial && !qrLoginCancelled) {
      showQrLoginModal();
      await startQrLoginSocket();
      while (serial === loadSerial && !qrLoginCancelled) {
        const state = readQrLoginState();
        if (!state) break;
        if (state.ticket) showQrLoginModal(state.ticket);
        if (state.status === 'success') {
          const status = document.querySelector('#xuetangx-login-modal .xuetangx-login-status');
          if (status) status.innerHTML = '<span class="spinner xuetangx-inline-spinner"></span> 正在完成登录…';
          await completeWechatLogin(state.token);
          hideQrLoginModal();
          await stopQrLoginSocket();
          env?.toast?.('学堂在线登录成功', 'success');
          return true;
        }
        if (state.status === 'error' || state.status === 'closed' || (state.expiresAt && Date.now() >= state.expiresAt)) break;
        await sleep(500);
      }
      await stopQrLoginSocket();
      if (!qrLoginCancelled && serial === loadSerial) await sleep(500);
    }
    throw Object.assign(new Error('已取消学堂在线扫码登录'), { code: 'cancelled' });
  }

  function collectEvaluationLeaves(scoreData) {
    const map = new Map();
    const visit = (value) => {
      if (!value || typeof value !== 'object') return;
      if (Array.isArray(value)) {
        value.forEach(visit);
        return;
      }
      const id = value?.score_info?.leaf_id ?? value?.id;
      const tagId = Number(value?.evaluation_tag?.id ?? value?.etag_info?.etag_id ?? 0);
      if (id && (tagId || value.score_info || value.time_info)) map.set(String(id), value);
      Object.values(value).forEach(visit);
    };
    visit(scoreData?.score_detail || []);
    return map;
  }

  function flattenEvaluationLeaves(scoreData) {
    const rows = [];
    const visit = (value, path = []) => {
      if (!value || typeof value !== 'object') return;
      if (Array.isArray(value)) {
        value.forEach((item) => visit(item, path));
        return;
      }
      const leafId = value?.score_info?.leaf_id ?? value?.id;
      const tagId = Number(value?.evaluation_tag?.id ?? value?.etag_info?.etag_id ?? 0);
      if (leafId && tagId) {
        const timeInfo = value.time_info || {};
        rows.push({
          id: leafId,
          name: value.name || value?.evaluation_tag?.name || value?.etag_info?.etag_name,
          leaf_type: value.type,
          start_time: timeInfo.start_time,
          score_deadline: timeInfo.score_deadline,
          end_time: timeInfo.end_time,
          is_locked: timeInfo.is_locked,
          chapterPath: path
        });
        return;
      }
      const nextPath = value.name ? [...path, String(value.name)] : path;
      Object.values(value).forEach((item) => visit(item, nextPath));
    };
    visit(scoreData?.score_detail || [], []);
    return rows;
  }

  function flattenChapterLeaves(root) {
    const rows = [];
    const walk = (node, path = []) => {
      if (!node || typeof node !== 'object') return;
      const nextPath = node.name ? [...path, String(node.name)] : path;
      for (const leaf of (Array.isArray(node.leaf_list) ? node.leaf_list : [])) {
        if (!leaf?.id || leaf.is_show === false) continue;
        rows.push({ ...leaf, chapterPath: nextPath });
      }
      for (const child of (Array.isArray(node.children) ? node.children : [])) walk(child, nextPath);
      for (const section of (Array.isArray(node.section_list) ? node.section_list : [])) walk(section, nextPath);
    };
    walk(root, []);
    return rows;
  }

  function activityType(leaf, evaluationLeaf) {
    const tagId = Number(evaluationLeaf?.evaluation_tag?.id ?? evaluationLeaf?.etag_info?.etag_id ?? 0);
    if (ACTIVITY_TYPES[tagId]) return { id: tagId, ...ACTIVITY_TYPES[tagId] };
    const chapterType = CHAPTER_LEAF_TYPE_TO_ACTIVITY_TYPE[Number(leaf?.leaf_type)];
    if (ACTIVITY_TYPES[chapterType]) return { id: chapterType, ...ACTIVITY_TYPES[chapterType] };
    const title = String(leaf?.name || '');
    if (/考试|考核/.test(title)) return { id: 12, ...ACTIVITY_TYPES[12] };
    if (/讨论/.test(title)) return { id: 10, ...ACTIVITY_TYPES[10] };
    if (/作业|测试|习题|练习/.test(title)) return { id: 11, ...ACTIVITY_TYPES[11] };
    const fallbackId = tagId || Number(leaf?.leaf_type) || -1;
    return { id: fallbackId, label: `活动${fallbackId > 0 ? ` ${fallbackId}` : ''}`, path: 'activity', action: 'view' };
  }

  function taskUrl(course, task) {
    return `${BASE}/learn/space/${encodeURIComponent(course.courseSign)}/${encodeURIComponent(course.sign)}/${encodeURIComponent(course.classroomId)}/${encodeURIComponent(task.path)}/${encodeURIComponent(task.id)}`;
  }

  function courseUrl(course) {
    return `${BASE}/learn/space/${encodeURIComponent(course.courseSign)}/${encodeURIComponent(course.sign)}/${encodeURIComponent(course.classroomId)}`;
  }

  function buildCourse(panel) {
    return {
      id: String(panel?.classroom_id || panel?.product_id || panel?.sku_id || ''),
      classroomId: String(panel?.classroom_id || ''),
      sign: String(panel?.sign || panel?.course_sign || ''),
      courseSign: String(panel?.course_sign || panel?.sign || ''),
      name: String(panel?.name || '学堂在线课程'),
      status: Number(panel?.status || 0),
      cover: String(panel?.cover || panel?.mobile_cover || ''),
      classStart: Number(panel?.class_start || 0),
      classEnd: Number(panel?.class_end || 0),
      teachers: [],
      tasks: [],
      totalSchedule: 0,
      score: null,
      detailLoaded: false,
      pendingTypeLabels: []
    };
  }

  function hydrateCourse(course, basicInfo, chapterResponse, scheduleResponse, evaluationResponse, visibleActivityTypes) {
    const teachers = basicInfo?.data?.teacher_list ?? basicInfo?.teacher_list ?? [];
    const chapterRoot = chapterResponse?.data?.course_chapter ?? chapterResponse?.course_chapter;
    const schedules = scheduleResponse?.data?.leaf_schedules ?? scheduleResponse?.leaf_schedules ?? {};
    const totalSchedule = scheduleResponse?.data?.total_schedule ?? scheduleResponse?.total_schedule ?? 0;
    const scoreData = evaluationResponse?.data ?? evaluationResponse ?? {};
    const evaluationLeaves = collectEvaluationLeaves(scoreData);
    const chapterLeaves = flattenChapterLeaves(chapterRoot);
    const leaves = chapterLeaves.length ? chapterLeaves : flattenEvaluationLeaves(scoreData);
    course.teachers = (Array.isArray(teachers) ? teachers : [])
      .map((teacher) => String(teacher?.name || '').trim()).filter(Boolean);
    course.totalSchedule = normalizeSchedule(totalSchedule);
    course.score = scoreData?.total_score_and_schedule || null;
    course.tasks = leaves.map((leaf) => {
      const evaluationLeaf = evaluationLeaves.get(String(leaf.id)) || {};
      const type = activityType(leaf, evaluationLeaf);
      const schedule = normalizeSchedule(schedules[String(leaf.id)] ?? evaluationLeaf?.schedule ?? 0);
      const timeInfo = evaluationLeaf?.time_info || {};
      const deadline = [timeInfo.score_deadline, leaf.score_deadline, timeInfo.end_time, leaf.end_time, course.classEnd]
        .map(Number).find((value) => Number.isFinite(value) && value > 0) || 0;
      const scoreInfo = evaluationLeaf?.score_info || {};
      const userScore = Number.isFinite(Number(scoreInfo.user_score)) ? Number(scoreInfo.user_score) : null;
      const totalScore = Number.isFinite(Number(scoreInfo.leaf_score)) ? Number(scoreInfo.leaf_score) : null;
      const hasFullScore = Number.isFinite(Number(userScore))
        && Number.isFinite(Number(totalScore))
        && Number(totalScore) > 0
        && Number(userScore) >= Number(totalScore);
      const discussionUnsubmitted = type.id === 10
        && !(deadline > 0 && deadline < Date.now())
        && !hasFullScore;
      const done = discussionUnsubmitted
        ? false
        : (type.id === 11
          ? false
          : (type.id === 6
            ? schedule >= 0.9995
            : (evaluationLeaf?.quiz_commit === true || evaluationLeaf?.is_done === true || schedule >= 0.9995)));
      return {
        id: String(leaf.id),
        chapterLeafId: String(leaf.id),
        leafInfoId: String(leaf.leafinfo_id ?? evaluationLeaf?.leafinfo_id ?? ''),
        title: String(leaf.name || type.label),
        typeId: type.id,
        typeLabel: type.label,
        path: type.path,
        action: type.action,
        chapterPath: Array.isArray(leaf.chapterPath) ? leaf.chapterPath : [],
        startTime: Number(timeInfo.start_time ?? leaf.start_time ?? 0) || 0,
        deadline,
        schedule,
        done,
        overdue: !done && deadline > 0 && deadline < Date.now(),
        userScore,
        totalScore,
        locked: timeInfo.is_locked === true || leaf.is_locked === true
      };
    }).filter((task) => visibleActivityTypes.has(task.typeId));
    if (!Object.keys(schedules || {}).length && course.tasks.length) {
      course.totalSchedule = course.tasks.reduce((sum, task) => sum + task.schedule, 0) / course.tasks.length;
    }
    course.detailLoaded = true;
    return course;
  }

  function formatExerciseProblem(problem, fallbackIndex) {
    const content = problem?.content || {};
    const index = Number(problem?.index) || fallbackIndex + 1;
    const typeText = String(content.TypeText || content.type_text || '题目').trim();
    const score = problem?.score ?? content.score ?? content.Score;
    const bodyHtml = global.BjtuHomeworkUi.sanitizeRichHtml(content.Body || content.body || '');
    const options = Array.isArray(content.Options) ? content.Options : [];
    const blanks = Array.isArray(content.Blanks) ? content.Blanks : [];
    const blankHtml = blanks.map((blank, blankIndex) => {
      const blankNumber = Number(blank?.Num) || blankIndex + 1;
      const blankScore = Number(blank?.Score);
      const parts = [
        `第${blankNumber}空`,
        Number.isFinite(blankScore) ? `${blankScore}分` : '',
        blank?.CaseSensitive === true ? '区分大小写' : '不区分大小写',
        blank?.FuzzyMatch === true ? '模糊匹配' : '精确匹配'
      ].filter(Boolean);
      return `<div class="homework-question-option">${escape(parts.join(' · '))}</div>`;
    }).join('');
    const user = problem?.user || {};
    const submissionParts = [];
    if (user.my_count !== undefined || user.count !== undefined) {
      submissionParts.push(`提交次数 ${escape(user.my_count ?? 0)}/${escape(user.count ?? 0)}`);
    }
    if (problem?.max_retry !== undefined && problem?.max_retry !== null) {
      submissionParts.push(`最大重试 ${escape(problem.max_retry)} 次`);
    }
    return global.BjtuHomeworkUi.questionDetailHtml({
      index,
      typeText,
      score,
      metaItems: submissionParts,
      bodyHtml,
      options: options.map((option) => ({
        key: option?.key ?? '',
        valueHtml: global.BjtuHomeworkUi.sanitizeRichHtml(option?.value ?? '')
      })),
      extraLinesHtml: blankHtml,
      escape
    });
  }

  function renderExerciseDetail(course, task, palette) {
    if (task.exerciseDetailLoading) {
      return `<div class="xuetangx-task-detail" style="border-top-color:${palette.border};"><span class="spinner xuetangx-inline-spinner" style="${global.BjtuHomeworkUi.spinnerPhaseStyle()}"></span> ${global.BjtuHomeworkUi.text.detailLoading}</div>`;
    }
    if (task.exerciseDetailError) {
      return `<div class="xuetangx-task-detail xuetangx-task-detail--error" style="border-top-color:${palette.border};">${escape(task.exerciseDetailError)}</div>`;
    }
    const problems = Array.isArray(task.exerciseProblems) ? task.exerciseProblems : [];
    if (!problems.length) return '';
    const contentHtml = problems.map(formatExerciseProblem).join('');
    const courseId = `xuetangx-${course.id}`;
    const expandKey = `xuetangx-exercise:${task.id}`;
    const expandable = env?.renderExpandable
      ? env.renderExpandable(contentHtml, global.BjtuHomeworkUi.detailOptions({
          hideWhenEmpty: true,
          baseBg: 'rgba(255,255,255,.28)',
          flatDisplay: true,
          courseId,
          expandKey,
          expanded: !!env.isDetailExpanded?.(courseId, expandKey)
        }))
      : contentHtml;
    return `<div class="xuetangx-task-detail" style="border-top-color:${palette.border};">${expandable}</div>`;
  }

  async function loadExerciseDetails(course, serial, progress) {
    const tasks = course.tasks.filter((task) => task.typeId === 11 && task.chapterLeafId);
    let cursor = 0;
    const workers = Array.from({ length: Math.min(3, tasks.length) }, async () => {
      while (cursor < tasks.length && serial === loadSerial) {
        const task = tasks[cursor++];
        task.exerciseDetailLoading = true;
        try {
          const leafInfo = await requestJson(
            `${BASE}/api/v1/lms/learn/leaf_info/${encodeURIComponent(course.classroomId)}/${encodeURIComponent(task.chapterLeafId)}/?sign=${encodeURIComponent(course.sign)}`,
            serial
          );
          if (leafInfo?.success === false) throw new Error(leafInfo?.msg || '作业叶节点接口返回失败');
          const exerciseTypeId = String(leafInfo?.data?.content_info?.leaf_type_id ?? '').trim();
          const exerciseSkuId = String(leafInfo?.data?.sku_id ?? '').trim();
          if (!exerciseTypeId || !exerciseSkuId) {
            throw new Error('作业叶节点响应缺少 leaf_type_id 或 sku_id');
          }
          task.exerciseTypeId = exerciseTypeId;
          task.exerciseId = String(
            leafInfo?.data?.exercise_id
              ?? leafInfo?.data?.content_info?.exercise_id
              ?? exerciseTypeId
          ).trim();
          task.exerciseSkuId = exerciseSkuId;
          const response = await requestJson(
            `${BASE}/api/v1/lms/exercise/get_exercise_list/${encodeURIComponent(exerciseTypeId)}/${encodeURIComponent(exerciseSkuId)}/`,
            serial
          );
          if (response?.success === false) throw new Error(response?.msg || '题目接口返回失败');
          task.exerciseProblems = Array.isArray(response?.data?.problems) ? response.data.problems : [];
          task.done = task.exerciseProblems.length > 0
            && task.exerciseProblems.every((problem) => Number(problem?.user?.my_count) > 0);
          task.overdue = !task.done && task.deadline > 0 && task.deadline < Date.now();
          task.exerciseDetailError = '';
        } catch (error) {
          if (error?.code === 'not-logged-in' || error?.code === 'cancelled') throw error;
          task.exerciseProblems = [];
          task.exerciseDetailError = `作业详情获取失败：${error?.message || error}`;
        } finally {
          task.exerciseDetailLoading = false;
          progress?.completeItem?.(course, 11);
        }
      }
    });
    await Promise.all(workers);
  }

  function clearCards() {
    env?.courseList?.querySelectorAll('.xuetangx-standalone-card').forEach((node) => node.remove());
    env?.updateEmpty?.();
  }

  function renderTask(course, task) {
    const palette = global.BjtuHomeworkUi.homeworkPalette({ done: task.done, overdue: task.overdue });
    const scoreVisible = task.done || Number(task.userScore) > 0;
    const score = global.BjtuHomeworkUi.scoreBadgeHtml({
      userScore: task.userScore,
      totalScore: task.totalScore,
      visible: scoreVisible,
      escape
    });
    const actionLabel = global.BjtuHomeworkUi.actionLabel('xuetangx', task.action, { lead: '去' });
    const chapter = task.chapterPath.filter(Boolean).slice(1).join(' / ');
    const secondAnswerButton = task.typeId === 11
      ? `<button type="button" class="btn xuetangx-second-answer-btn" data-xuetangx-action="second-answer-submit" data-course-id="${escape(course.id)}" data-task-id="${escape(task.id)}" style="background:${escape(palette.action)}; padding:2px 6px; font-size:12px; text-decoration:none; color:#fff;" ${task.secondAnswerBusy ? 'disabled' : ''}>${escape(task.secondAnswerBusy ? '提交中…' : '第二账号查答并提交')}</button>`
      : '';
    return global.BjtuHomeworkUi.renderHomeworkCard({
      done: task.done,
      className: 'xuetangx-task',
      background: palette.background,
      border: palette.border,
      headClass: 'xuetangx-task-head',
      mainClass: 'xuetangx-task-main',
      actionsClass: 'xuetangx-task-actions',
      titleHtml: global.BjtuHomeworkUi.titleHtml({ typeLabel: task.typeLabel, typeHref: taskUrl(course, task), title: task.title, color: palette.foreground, href: taskUrl(course, task), escape, className: 'xuetangx-task-title' }),
      metaHtml: `${global.BjtuHomeworkUi.deadlineMetaHtml({ deadline: task.deadline, formatted: formatTime(task.deadline), startTime: task.startTime, startFormatted: formatTime(task.startTime), done: task.done, overdue: task.overdue, escape })}${chapter ? `<div class="xuetangx-task-meta">${escape(chapter)}</div>` : ''}
        ${global.BjtuHomeworkUi.progressHtml({ ratio: task.schedule, escape, color: THEME_COLOR })}`,
      actionsHtml: `${score}${secondAnswerButton}${global.BjtuHomeworkUi.renderActionLink({
        href: taskUrl(course, task),
        label: actionLabel,
        color: palette.action,
        className: 'btn xuetangx-go-btn',
        escape
      })}`,
      detailHtml: task.typeId === 11 ? renderExerciseDetail(course, task, palette) : ''
    });
  }

  function renderToggle(courseId, kind, expanded, count) {
    const labels = global.BjtuHomeworkUi.toggleLabels(kind);
    const label = expanded ? labels.expanded : labels.collapsed;
    return `<div class="homework-toggle-row homework-toggle-row--${kind}">
      <button class="btn homework-toggle-btn ${expanded ? 'is-expanded homework-toggle-btn--up' : 'homework-toggle-btn--down'}" data-xuetangx-action="toggle-${kind}" data-course-id="${escape(courseId)}" data-count="${escape(count)}" data-collapsed-text="${escape(labels.collapsed)}" data-expanded-text="${escape(labels.expanded)}" aria-expanded="${expanded ? 'true' : 'false'}">
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
        <span class="homework-toggle-label">${escape(label)} (${escape(count)})</span>
        <span class="homework-toggle-side" aria-hidden="true"><span class="homework-toggle-line"></span><span class="homework-toggle-arrow"></span><span class="homework-toggle-line"></span></span>
      </button>
    </div>`;
  }

  function render() {
    if (!env?.courseList) return;
    clearCards();
    const baseOrder = Number(env.courseList.dataset.orderBase || 100000) + 140000;
    courses.forEach((course, index) => {
      const pending = course.tasks.filter((task) => !task.done && !task.overdue)
        .map((task, taskIndex) => ({ task, taskIndex }))
        .sort((a, b) => (Number(a.task.deadline) > 0 ? Number(a.task.deadline) : Number.MAX_SAFE_INTEGER) - (Number(b.task.deadline) > 0 ? Number(b.task.deadline) : Number.MAX_SAFE_INTEGER) || a.taskIndex - b.taskIndex)
        .map(({ task }) => task);
      const overdue = course.tasks.filter((task) => task.overdue);
      const done = course.tasks.filter((task) => task.done);
      const expanded = expandedGroups.get(course.id) || { overdue: false, done: false };
      const taskSections = `${pending.map((task) => renderTask(course, task)).join('')}
        ${overdue.length ? renderToggle(course.id, 'overdue', expanded.overdue, overdue.length) : ''}
        ${overdue.length ? `<div class="homework-group homework-group--overdue ${expanded.overdue ? '' : 'is-hidden'}" data-homework-group="overdue" aria-hidden="${expanded.overdue ? 'false' : 'true'}">${overdue.map((task) => renderTask(course, task)).join('')}</div>` : ''}
        ${done.length ? renderToggle(course.id, 'done', expanded.done, done.length) : ''}
        ${done.length ? `<div class="homework-group homework-group--done ${expanded.done ? '' : 'is-hidden'}" data-homework-group="done" aria-hidden="${expanded.done ? 'false' : 'true'}">${done.map((task) => renderTask(course, task)).join('')}</div>` : ''}`;
      const typeLoadingHtml = global.BjtuHomeworkUi.typeLoadingHtml(course.pendingTypeLabels, { escape });
      const score = course.score;
      const scoreText = score
        ? ` · 成绩 ${escape(score.user_score ?? 0)}${score.title ? `（${escape(score.title)}）` : ''}`
        : '';
      const meta = `${course.teachers.length ? escape(course.teachers.join(' / ')) : '教师信息加载中'} · ${escape(COURSE_STATUS_LABELS[course.status] || '未知状态')} · 总进度 ${escape(formatProgress(course.totalSchedule))}${scoreText}`;
    const card = global.BjtuCourseCardUi.createCourseCard({
        courseId: `xuetangx-${course.id}`,
        className: 'xuetangx-standalone-card',
        order: baseOrder + index,
        rank: pending.length ? 0 : (overdue.length ? 2 : (done.length ? 4 : 7)),
        titleHtml: `<a href="${escape(courseUrl(course))}" target="_blank" rel="noopener noreferrer">${escape(course.name)}</a>`,
        metaHtml: `<div class="xuetangx-course-meta">${meta}</div><div class="xuetangx-course-identity-actions"><button type="button" class="btn xuetangx-second-answer-all-btn" data-xuetangx-action="second-answer-submit-all" data-course-id="${escape(course.id)}" style="background:${escape(THEME_COLOR)}; padding:2px 6px; font-size:12px; text-decoration:none; color:#fff;" ${course.secondAnswerAllBusy ? 'disabled' : ''}>${escape(course.secondAnswerAllBusy ? '处理中…' : '查答并提交全部')}</button></div>`,
        contentHtml: `${typeLoadingHtml}${course.detailLoaded
          ? (course.loadError
            ? `<span class="xuetangx-empty">课程详情加载失败：${escape(course.loadError)}</span>`
            : (taskSections.trim() || '<span class="xuetangx-empty">暂无学习活动</span>'))
          : ''}`,
        headerClass: 'xuetangx-course-head',
        identityClass: 'xuetangx-course-identity',
        homeworkClass: 'homework-area xuetangx-homework-area',
        includeResultArea: false,
        wrapActions: false
      });
      env.courseList.appendChild(card);
    });
    env.updateEmpty?.();
    env.sortCourseCards?.();
    env.scheduleCache?.();
    setTimeout(() => env.updateCountdowns?.(), 0);
  }

  async function loadCourseDetails(course, serial, visibleActivityTypes, progress) {
    const query = `cid=${encodeURIComponent(course.classroomId)}&sign=${encodeURIComponent(course.sign)}`;
    const [basic, chapter, schedule, evaluation] = await Promise.all([
      requestJson(`${BASE}/api/v1/lms/product/get_product_basic_info/?sign=${encodeURIComponent(course.sign)}`, serial),
      requestJson(`${BASE}/api/v1/lms/kg/kg_learn_chapter/?${query}`, serial),
      requestJson(`${BASE}/api/v1/lms/learn/course/schedule?${query}`, serial),
      requestJson(`${BASE}/api/v1/lms/learn/get_evaluation_detail/?${query}`, serial)
    ]);
    if (serial !== loadSerial) return;
    const endedError = (response) => course.status === 3
      && response?.success === false
      && Number(response?.error_code) === 80013;
    const failed = [basic, evaluation].find((response) => response?.success === false)
      || [chapter, schedule].find((response) => response?.success === false && !endedError(response));
    if (failed) throw new Error(failed.msg || '学堂在线课程详情接口返回失败');
    hydrateCourse(
      course,
      basic,
      endedError(chapter) ? { data: { course_chapter: null }, success: true } : chapter,
      endedError(schedule) ? { data: { leaf_schedules: {}, total_schedule: 0 }, success: true } : schedule,
      evaluation,
      visibleActivityTypes
    );
    course.pendingTypeLabels = [];
    render();
    progress?.defineCourse?.(course);
    await loadExerciseDetails(course, serial, progress);
  }

  async function load() {
    const serial = ++loadSerial;
    env?.setState?.('checking');
    env?.setProgress?.(0, 0);
    clearCards();
    try {
      const [visibleStatuses, visibleActivityTypes] = await Promise.all([
        getVisibleStatuses(),
        getVisibleActivityTypes()
      ]);
      const response = await requestJson(COURSE_LIST_URL, serial);
      if (serial !== loadSerial) return;
      if (response?.success !== true || !response?.data || !Array.isArray(response.data.product_list)) {
        const error = new Error(response?.msg || '未登录学堂在线');
        error.code = 'not-logged-in';
        throw error;
      }
      courses = response.data.product_list
        .filter((panel) => visibleStatuses.includes(Number(panel?.status)))
        .map(buildCourse).filter((course) => course.id && course.classroomId && course.sign);
      const visibleTypeLabels = [...visibleActivityTypes]
        .map((typeId) => ACTIVITY_TYPES[typeId]?.label).filter(Boolean);
      courses.forEach((course) => { course.pendingTypeLabels = [...visibleTypeLabels]; });
      env?.setLoaded?.(true);
      env?.setState?.('online');
      const visibleTypeIds = [...visibleActivityTypes];
      const progressByCourse = new Map(courses.map((course) => [course.id, new Map()]));
      const updateDetailProgress = () => {
        if (serial !== loadSerial) return;
        if (!courses.length || !visibleTypeIds.length) {
          env?.setProgress?.(0, 0);
          return;
        }
        const completed = courses.reduce((courseSum, course) => {
          const typeStates = progressByCourse.get(course.id);
          const courseProgress = visibleTypeIds.reduce((typeSum, typeId) => {
            const state = typeStates?.get(typeId);
            if (!state) return typeSum;
            return typeSum + (state.total ? Math.min(state.completed / state.total, 1) : 1);
          }, 0) / visibleTypeIds.length;
          return courseSum + courseProgress;
        }, 0);
        env?.setProgress?.(completed, courses.length);
      };
      const detailProgress = {
        defineCourse(course) {
          const typeStates = progressByCourse.get(course.id);
          if (!typeStates) return;
          visibleTypeIds.forEach((typeId) => {
            const items = course.tasks.filter((task) => task.typeId === typeId);
            typeStates.set(typeId, {
              total: items.length,
              completed: typeId === 11
                ? items.filter((task) => !task.chapterLeafId).length
                : items.length
            });
          });
          updateDetailProgress();
        },
        completeItem(course, typeId) {
          const state = progressByCourse.get(course.id)?.get(typeId);
          if (!state) return;
          state.completed = Math.min(state.total, state.completed + 1);
          updateDetailProgress();
        },
        completeCourse(course) {
          const typeStates = progressByCourse.get(course.id);
          if (!typeStates) return;
          visibleTypeIds.forEach((typeId) => typeStates.set(typeId, { total: 0, completed: 0 }));
          updateDetailProgress();
        }
      };
      updateDetailProgress();
      render();

      let cursor = 0;
      const workers = Array.from({ length: Math.min(4, courses.length) }, async () => {
        while (cursor < courses.length && serial === loadSerial) {
          const index = cursor++;
          try {
            await loadCourseDetails(courses[index], serial, visibleActivityTypes, detailProgress);
          } catch (error) {
            if (error?.code === 'not-logged-in' || error?.code === 'cancelled') throw error;
            courses[index].detailLoaded = true;
            courses[index].loadError = String(error?.message || error);
            courses[index].pendingTypeLabels = [];
          } finally {
            if (serial === loadSerial) {
              if (!progressByCourse.get(courses[index].id)?.size) detailProgress.completeCourse(courses[index]);
              render();
            }
          }
        }
      });
      await Promise.all(workers);
      if (serial !== loadSerial) return;
      env?.setProgress?.(courses.length, courses.length);
      env?.setLoaded?.(true);
      env?.setState?.('online');
      render();
    } catch (error) {
      if (serial !== loadSerial || error?.code === 'cancelled') return;
      courses = [];
      clearCards();
      env?.setLoaded?.(false);
      if (error?.code === 'not-logged-in') {
        const shouldOpenLogin = global.platformInteractiveLoginPending?.xuetangx === true
          || global.shouldAutoLoginAfterExpiry?.('xuetangx') === true;
        if (!shouldOpenLogin) {
          env?.setState?.('offline');
          return;
        }
        env?.setState?.('checking');
        try {
          await waitForQrLogin(serial);
          if (serial === loadSerial && !qrLoginCancelled) return load();
        } catch (loginError) {
          if (loginError?.code !== 'cancelled' && serial === loadSerial) {
            hideQrLoginModal();
            await stopQrLoginSocket();
            env?.toast?.(`学堂在线扫码登录失败：${loginError?.message || loginError}`, 'error');
            env?.setState?.('offline');
          }
        }
      } else {
        env?.setState?.('checking');
        env?.toast?.(`学堂在线加载失败：${error?.message || error}`, 'error');
        setTimeout(() => {
          if (serial === loadSerial && global.isPlatformEnabled?.('xuetangx')) void load();
        }, 1200);
      }
    }
  }

  function handleClick(event) {
    const button = event.target instanceof Element ? event.target.closest('[data-xuetangx-action]') : null;
    if (!(button instanceof HTMLElement)) return;
    const course = courses.find((item) => item.id === String(button.dataset.courseId || ''));
    if (!course || button.dataset.animating === '1') return;
    if (button.dataset.xuetangxAction === 'second-answer-submit') {
      const task = course.tasks.find((item) => item.id === String(button.dataset.taskId || ''));
      if (task) void submitAnswersFromSecondAccount(course, task);
      return;
    }
    if (button.dataset.xuetangxAction === 'second-answer-submit-all') {
      void submitAllAnswersFromSecondAccount(course);
      return;
    }
    const kind = button.dataset.xuetangxAction === 'toggle-done' ? 'done' : 'overdue';
    const state = expandedGroups.get(course.id) || { overdue: false, done: false };
    const expanded = !state[kind];
    expandedGroups.set(course.id, { ...state, [kind]: expanded });
    const card = button.closest('.xuetangx-standalone-card');
    const group = card?.querySelector(`.homework-group[data-homework-group="${kind}"]`);
    if (!(group instanceof HTMLElement) || typeof env?.animateHomeworkGroupVisibility !== 'function') {
      render();
      return;
    }
    const count = String(button.dataset.count || '');
    const text = expanded ? button.dataset.expandedText : button.dataset.collapsedText;
    const label = button.querySelector('.homework-toggle-label');
    if (label) label.textContent = `${text} (${count})`;
    button.classList.toggle('is-expanded', expanded);
    button.classList.toggle('homework-toggle-btn--up', expanded);
    button.classList.toggle('homework-toggle-btn--down', !expanded);
    button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    button.dataset.animating = '1';
    group.dataset.expanded = expanded ? '1' : '0';
    group.setAttribute('aria-hidden', expanded ? 'false' : 'true');
    env.animateHomeworkGroupVisibility(group, expanded);
    setTimeout(() => { delete button.dataset.animating; }, 240);
  }

  global.BjtuXuetangxPlatform = {
    init(options) {
      env = options;
      env.courseList?.addEventListener('click', handleClick);
    },
    load,
    render,
    clear() {
      loadSerial += 1;
      qrLoginCancelled = true;
      courses = [];
      expandedGroups.clear();
      clearCards();
      env?.setProgress?.(0, 0);
      hideQrLoginModal();
      void stopQrLoginSocket();
    },
    getCourses: () => courses,
    restore(value) {
      courses = Array.isArray(value) ? value : [];
    },
    themeColor: THEME_COLOR
  };

  /* ================= qwen 页面桥（service worker 经 app 页面调用） ================= */

  async function waitForXuetangxPageReady(timeoutMs = 120000) {
    if (typeof globalThis.waitForPlatformDataReady !== 'function') return false;
    return globalThis.waitForPlatformDataReady('xuetangx', timeoutMs);
  }

  async function xuetangxPageCourseList() {
    const state = String(globalThis.platformLoginState?.xuetangx || 'checking');
    const ready = state !== 'offline' && await waitForXuetangxPageReady();
    const loginState = String(globalThis.platformLoginState?.xuetangx || 'checking');
    return {
      ready,
      loaded: Array.isArray(courses) && courses.length > 0,
      loginState,
      loggedIn: loginState === 'online',
      courses: (Array.isArray(courses) ? courses : []).map((course) => ({
        classroomId: String(course?.classroomId || course?.id || ''),
        name: String(course?.name || ''),
        sign: String(course?.sign || course?.courseSign || ''),
        teachers: Array.isArray(course?.teachers) ? course.teachers : [],
        status: Number(course?.status || 0),
        totalSchedule: Number(course?.totalSchedule || 0),
        score: Number(course?.score || 0),
        taskCount: Array.isArray(course?.tasks) ? course.tasks.length : 0
      }))
    };
  }

  async function xuetangxPageHomeworkOf(classroomId) {
    const key = String(classroomId || '').trim();
    if (!key) return { ok: false, message: '缺少参数 classroomId，请先调用 xuetangx.courseList 获取教室ID' };
    const loginState = String(globalThis.platformLoginState?.xuetangx || 'checking');
    if (loginState !== 'online') return { ok: false, code: 'LOGIN_REQUIRED', loggedIn: false, message: '学堂在线未登录，请先调用 xuetangx.login' };
    const ready = await waitForXuetangxPageReady();
    if (!ready) return { ok: false, message: '学堂在线课程与作业尚未加载完毕' };
    const course = (Array.isArray(courses) ? courses : []).find((c) => String(c?.classroomId || c?.id || '') === key) || null;
    if (!course) return { ok: false, message: `教室ID无效：${key} 不在学堂在线课程列表中，请先调用 xuetangx.courseList 获取有效ID` };
    return {
      ok: true,
      classroomId: String(course?.classroomId || course?.id || ''),
      name: String(course?.name || ''),
      teachers: Array.isArray(course?.teachers) ? course.teachers : [],
      totalSchedule: Number(course?.totalSchedule || 0),
      score: Number(course?.score || 0),
      homework: (Array.isArray(course?.tasks) ? course.tasks : []).map((task) => ({
        id: task?.id,
        chapterLeafId: task?.chapterLeafId,
        title: task?.title,
        typeId: Number(task?.typeId || 0),
        typeLabel: String(task?.typeLabel || ''),
        startTime: task?.startTime,
        deadline: task?.deadline,
        schedule: Number(task?.schedule || 0),
        done: !!task?.done,
        overdue: !!task?.overdue,
        userScore: Number(task?.userScore || 0),
        totalScore: Number(task?.totalScore || 0),
        locked: !!task?.locked,
        details: Array.isArray(task?.exerciseProblems)
          ? { problems: task.exerciseProblems }
          : null,
        action: task?.action
      }))
    };
  }

  async function xuetangxPageLoginStatus() {
    const state = String(globalThis.platformLoginState?.xuetangx || 'checking');
    return { loginState: state, loggedIn: state === 'online', loaded: Array.isArray(courses) && courses.length > 0 };
  }

  async function xuetangxPageLogin(args = {}) {
    const platform = 'xuetangx';
    const enabled = typeof globalThis.isPlatformEnabled === 'function' ? globalThis.isPlatformEnabled(platform) : true;
    if (enabled) {
      const current = globalThis.getEnabledPlatformLoginResult(platform);
      if (current?.ready === true) return current;
      return globalThis.waitForPlatformLoginResult(platform, Number(args?.timeoutMs) || 120000);
    } else if (typeof globalThis.togglePlatformSelection === 'function') {
      try { globalThis.togglePlatformSelection(platform, { interactive: true }); } catch {}
    }
    return await waitForPlatformLoginResult(platform, Number(args?.timeoutMs) || 120000);
  }

  globalThis.BjtuXuetangxPageApi = Object.freeze({
    courseList: () => xuetangxPageCourseList(),
    homework_of_: (args) => xuetangxPageHomeworkOf(String(args?.classroomId || args?.courseId || '').trim()),
    status: () => xuetangxPageLoginStatus(),
    login: (args) => xuetangxPageLogin(args)
  });

  if (typeof chrome !== 'undefined' && chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== 'PAGE_API' || message?.payload?.module !== 'xuetangx') return false;
      const api = globalThis.BjtuXuetangxPageApi;
      const fn = api && typeof api[String(message.payload?.fn || '')] === 'function' ? api[String(message.payload.fn)] : null;
      if (!fn) {
        sendResponse({ ok: false, error: 'XUETANGX 页面接口不存在' });
        return true;
      }
      Promise.resolve(fn(message.payload?.args || {})).then(
        (value) => sendResponse({ ok: true, value }),
        (error) => sendResponse({ ok: false, error: String(error?.message || error), code: String(error?.code || '') })
      );
      return true;
    });
  }
})(globalThis);
