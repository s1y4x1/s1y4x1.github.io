(function initBjtuColors(global) {
  'use strict';

  const storageKey = 'colorSettings';
  const gradientKey = 'homeworkDeadlineGradientEnabled';
  const marqueeKey = 'homeworkMarqueeEnabled';
  const defaults = Object.freeze({
    backgroundLight: global.BjtuTheme.backgroundDefaults.light, backgroundDark: global.BjtuTheme.backgroundDefaults.dark,
    cardLight: global.BjtuTheme.cardDefaults.light, cardDark: global.BjtuTheme.cardDefaults.dark,
    button: '#1976d2', courseCard: '#ffffff', fileCard: '#ffffff',
    pendingCard: '#fff5e6', overdueCard: '#ffe6e6', doneCard: '#e6ffe6',
    resource: '#1e3a8a', replay: '#9c27b0', assessment: '#0f766e', archive: '#0369a1',
    copy: '#45a049', download: '#1e3a8a', teacherPendingCard: '#dbeafe', teacherOverdueCard: '#ede9fe'
  });
  const labels = {
    background: '背景',
    card: '卡片',
    button: '操作按钮', courseCard: '课程卡片', fileCard: '文件卡片',
    pendingCard: '未交作业', overdueCard: '逾期作业', doneCard: '已交作业',
    resource: '资源下载', replay: '回放下载', assessment: '课程考核记录表下载', archive: '归档下载',
    copy: '复制', download: '下载', teacherPendingCard: '未了作业（教师）', teacherOverdueCard: '过时作业（教师）'
  };
  let settings = {};
  let gradientEnabled = true;
  let marqueeEnabled = true;
  const reportedExpiredCourses = new WeakMap();
  const animatedCards = new Set();
  const visibleCards = new WeakSet();
  const appearanceByCard = new WeakMap();
  const pendingAnimationStates = new WeakMap();
  const effectsObserver = typeof IntersectionObserver === 'function' ? new IntersectionObserver((entries) => {
    for (const entry of entries) {
      const card = entry.target;
      if (!animatedCards.has(card) || !card.isConnected) continue;
      if (entry.isIntersecting) visibleCards.add(card);
      else visibleCards.delete(card);
      syncCardAnimation(card);
    }
  }, {rootMargin:'32px'}) : null;
  const homeworkAnimationPeriods = {
    homeworkUrgencyBreathe: '--homework-breathe-period',
    homeworkUrgencyBlink: '--homework-blink-period',
    homeworkBorderMarquee: '--homework-marquee-period'
  };

  function nextHomeworkPeriod(card) {
    return Math.log2(1 + Math.max(0, deadlineTime(card.dataset.homeworkDeadline) - Date.now()) / 3600000) + 0.5;
  }

  function syncCardAnimation(card) {
    const active = animatedCards.has(card) && (!effectsObserver || visibleCards.has(card))
      && !document.hidden && document.documentElement.dataset.animationEnabled !== 'false';
    if (card.classList.contains('homework-marquee') === active) return;
    if (active) {
      const period = `${nextHomeworkPeriod(card)}s`;
      for (const property of Object.values(homeworkAnimationPeriods)) setProperty(card,property,period);
    }
    card.classList.toggle('homework-marquee',active);
    const saved = pendingAnimationStates.get(card);
    if (active && saved) restoreCardAnimations(card,saved.animations,saved.time);
  }

  function observeCardAnimation(card, eligible) {
    if (eligible && !animatedCards.has(card)) {
      animatedCards.add(card);
      effectsObserver?.observe(card);
    } else if (!eligible && animatedCards.delete(card)) {
      effectsObserver?.unobserve(card);
      visibleCards.delete(card);
      pendingAnimationStates.delete(card);
    }
    syncCardAnimation(card);
  }

  function homeworkAnimations(card) {
    return card.getAnimations({ subtree: true }).filter((animation) => homeworkAnimationPeriods[animation.animationName]
      && animation.effect.getComputedTiming().iterations === Infinity);
  }

  document.addEventListener('animationiteration', (event) => {
    const property = homeworkAnimationPeriods[event.animationName];
    const card = event.target;
    if (!property || !card.matches('.hw-card-item.homework-marquee')) return;
    const animation = homeworkAnimations(card).find((item) => item.animationName === event.animationName
      && (item.effect.pseudoElement || '') === (event.pseudoElement || ''));
    if (!animation || animation.currentTime === null) return;
    const previousDuration = animation.effect.getComputedTiming().duration;
    const currentTime = animation.currentTime;
    if (!(previousDuration > 0)) return;
    const duration = nextHomeworkPeriod(card) * 1000;
    // CSS timing is resolved lazily; override it explicitly before preserving phase.
    animation.effect.updateTiming({ duration });
    animation.currentTime = currentTime * duration / previousDuration;
  });

  function homeworkAnimationKey(card) {
    const title = card.querySelector('[data-homework-title]');
    return JSON.stringify([card.closest('[data-course-rankable="1"]')?.dataset.courseId,
      title?.dataset.homeworkTitle, title?.querySelector('a')?.getAttribute('href'), card.dataset.homeworkDeadline]);
  }

  function captureAnimations(root, selector = '.hw-card-item') {
    const states = new Map();
    root.querySelectorAll(selector).forEach((card) => {
      if (!card.classList.contains('homework-marquee')) return;
      const animations = homeworkAnimations(card).filter((animation) => animation.currentTime !== null).map((animation) => ({
        name: animation.animationName,
        pseudoElement: animation.effect.pseudoElement || '',
        duration: animation.effect.getComputedTiming().duration,
        currentTime: animation.currentTime,
        playbackRate: animation.playbackRate
      }));
      if (animations.length) states.set(homeworkAnimationKey(card), animations);
    });
    return { states, time: document.timeline.currentTime };
  }

  function restoreAnimations(root, snapshot, selector = '.hw-card-item') {
    const cards = [...root.querySelectorAll(selector)];
    refreshCards(cards);
    if (!snapshot.states.size) return;
    cards.forEach((card) => {
      const saved = snapshot.states.get(homeworkAnimationKey(card));
      if (!saved) return;
      if (card.classList.contains('homework-marquee')) restoreCardAnimations(card,saved,snapshot.time);
      else if (animatedCards.has(card)) pendingAnimationStates.set(card,{animations:saved,time:snapshot.time});
    });
  }

  function restoreCardAnimations(card, saved, time) {
    pendingAnimationStates.delete(card);
    const elapsed = document.timeline.currentTime - time;
    homeworkAnimations(card).forEach((animation) => {
      const state = saved.find((item) => item.name === animation.animationName
        && item.pseudoElement === (animation.effect.pseudoElement || ''));
      if (!state) return;
      animation.effect.updateTiming({ duration: state.duration });
      animation.playbackRate = state.playbackRate;
      animation.currentTime = state.currentTime + elapsed * state.playbackRate;
    });
  }
  function normalize(value) {
    return Object.fromEntries(Object.keys(defaults)
      .filter((key) => /^#[0-9a-f]{6}$/i.test(String(value?.[key] || '')))
      .map((key) => [key, value[key].toLowerCase()]));
  }

  function interpolate(from, to, weight) {
    const channels = [1, 3, 5].map((offset) => {
      const a = parseInt(from.slice(offset, offset + 2), 16);
      const b = parseInt(to.slice(offset, offset + 2), 16);
      return Math.round(a + (b - a) * weight).toString(16).padStart(2, '0');
    });
    return `#${channels.join('')}`;
  }

  function deadlineTime(value) {
    const raw = String(value ?? '').trim();
    if (!raw) return NaN;
    if (/^[+-]?\d+(?:\.\d+)?$/.test(raw)) {
      const n = Number(raw);
      return n > 0 ? (n < 1e12 ? n * 1000 : n) : NaN;
    }
    const time = Date.parse(raw);
    return Number.isFinite(time) ? time : Date.parse(raw.replace(/-/g, '/'));
  }

  function urgency(deadline, now = Date.now()) {
    const time = deadlineTime(deadline);
    return Number.isFinite(time) ? Math.pow(2, -Math.max(0, time - now) / 86400000) : 0;
  }

  function luminance(color) {
    const values = [1, 3, 5].map((offset) => {
      const value = parseInt(color.slice(offset, offset + 2), 16) / 255;
      return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    });
    return values[0] * 0.2126 + values[1] * 0.7152 + values[2] * 0.0722;
  }

  function foreground(color) {
    return luminance(color) > 0.179 ? '#111827' : '#f8fafc';
  }

  function setProperty(element, name, value) {
    if (element.style.getPropertyValue(name) !== value) element.style.setProperty(name, value);
  }

  function toneVersion(color, transformLightness, transformSaturation = (value) => value) {
    // HSL: preserve hue; adjust lightness and optionally saturation.
    const channels = [1, 3, 5].map((offset) => parseInt(color.slice(offset, offset + 2), 16) / 255);
    const min = Math.min(...channels);
    const max = Math.max(...channels);
    const range = max - min;
    const lightness = (max + min) / 2;
    const saturation = range ? range / (1 - Math.abs(2 * lightness - 1)) : 0;
    const nextLightness = transformLightness(lightness);
    const chroma = (1 - Math.abs(2 * nextLightness - 1)) * transformSaturation(saturation);
    const offset = nextLightness - chroma / 2;
    return '#' + channels.map((value) => Math.round(255 * (range ? offset + chroma * (value - min) / range : nextLightness)).toString(16).padStart(2, '0')).join('');
  }

  const vividColorCache = new Map();
  function vividVersion(background) {
    if (vividColorCache.has(background)) return vividColorCache.get(background);
    const makeColor = (lightness) => toneVersion(background, () => lightness, (saturation) => Math.max(saturation, 0.9));
    // Use the brightest high-saturation shade that keeps white button text and
    // card titles readable, including the darkest phase of the card's breathing.
    let lower = 0;
    let upper = 0.48;
    const titleOnLightCard = foreground(background) === '#111827';
    for (let i = 0; i < 18; i += 1) {
      const lightness = (lower + upper) / 2;
      const color = makeColor(lightness);
      const ink = luminance(color) + 0.05;
      const readable = 1.05 / ink >= 4.5
        && (!titleOnLightCard || (luminance(interpolate(background, color, 0.08)) + 0.05) / ink >= 4.5);
      if (readable) lower = lightness;
      else upper = lightness;
    }
    const color = makeColor(lower);
    if (vividColorCache.size >= 512) vividColorCache.clear();
    vividColorCache.set(background, color);
    return color;
  }

  function refreshCards(cards = document.querySelectorAll('.hw-card-item')) {
    const now = Date.now();
    const expiredCourseIds = new Set();
    cards.forEach((card) => {
      const done = card.dataset.homeworkDone === '1';
      const teacher = card.dataset.homeworkTeacher === '1';
      const time = deadlineTime(card.dataset.homeworkDeadline);
      const expired = !done && Number.isFinite(time) && time <= now;
      const overdue = card.dataset.homeworkOverdue === '1' || expired;
      if (expired && card.dataset.homeworkOverdue !== '1') {
        const course = card.closest('.file-item[data-course-rankable="1"]');
        if (course?.dataset.courseId) {
          let reported = reportedExpiredCourses.get(course);
          if (!reported) reportedExpiredCourses.set(course, reported = new Set());
          const key = homeworkAnimationKey(card);
          // A homework-area rerender creates new card nodes. Keep expiry identity
          // on the owning course so replacement nodes cannot recursively notify.
          if (!reported.has(key)) {
            reported.add(key);
            expiredCourseIds.add(course.dataset.courseId);
          }
        }
      }
      const active = gradientEnabled && !teacher && card.dataset.homeworkGradient !== '0'
        && !done && !overdue && Number.isFinite(time) && time > now;
      const key = teacher ? (overdue ? 'teacherOverdueCard' : 'teacherPendingCard')
        : done ? 'doneCard' : overdue ? 'overdueCard' : 'pendingCard';
      const c = !teacher && !done && !overdue && Number.isFinite(time)
        ? Math.pow(2, -Math.max(0, time - now) / 86400000) : 0;
      const effects = marqueeEnabled && !teacher && !done && !overdue && Number.isFinite(time) && time > now;
      const background = active
        ? interpolate(settings.pendingCard || defaults.pendingCard, settings.overdueCard || defaults.overdueCard, c)
        : settings[key] || defaults[key];
      const intensity = c.toFixed(4), appearance = appearanceByCard.get(card);
      if (!appearance || appearance.background !== background || appearance.intensity !== intensity) {
        const action = vividVersion(background), text = foreground(background);
        setProperty(card, '--homework-card-background', background);
        setProperty(card, '--homework-card-action', action);
        setProperty(card, '--homework-card-title', text === '#111827' ? action : '#f8fafc');
        setProperty(card, '--homework-card-foreground', text);
        setProperty(card, '--homework-card-border', action);
        setProperty(card, '--homework-card-glow', toneVersion(background, () => 0.62));
        setProperty(card, '--homework-card-breathe-background', interpolate(background, action, 0.025 + 0.055 * c));
        setProperty(card, '--homework-urgency', intensity);
        setProperty(card, '--homework-marquee-opacity', (0.28 + 0.72 * c).toFixed(4));
        appearanceByCard.set(card,{background,intensity});
      }
      observeCardAnimation(card,effects);
      for (const [name, enabled] of [
        ['homework-deadline-gradient', active],
        ['homework-pending', !teacher && !done && !overdue]
      ]) {
        if (card.classList.contains(name) !== enabled) card.classList.toggle(name, enabled);
      }
    });
    if (expiredCourseIds.size) {
      document.dispatchEvent(new CustomEvent('bjtu-homework-expired', { detail: { courseIds: [...expiredCourseIds] } }));
    }
  }

  function refreshEditor() {
    document.querySelectorAll('[data-component-color]').forEach((input) => {
      const previousKey = input.dataset.componentColor;
      const surface = previousKey.match(/^(background|card)(Light|Dark)$/);
      const key = surface ? currentSurfaceKey(surface[1]) : previousKey;
      input.dataset.componentColor = key;
      const value = settings[key] || defaults[key];
      if (key !== previousKey || document.activeElement !== input) input.value = value;
      const reset = input.closest('label').querySelector('button');
      reset.dataset.resetColor = key;
      reset.hidden = !settings[key];
    });
    const toggle = document.getElementById('homeworkDeadlineGradientEnabled');
    if (toggle) toggle.checked = gradientEnabled;
    const marqueeToggle = document.getElementById('homeworkMarqueeEnabled');
    if (marqueeToggle) marqueeToggle.checked = marqueeEnabled;
  }

  function currentSurfaceKey(category) {
    return category + (document.documentElement.dataset.colorScheme === 'dark' ? 'Dark' : 'Light');
  }

  function apply(value = settings, gradient = gradientEnabled, marquee = marqueeEnabled) {
    settings = normalize(value);
    gradientEnabled = gradient !== false;
    marqueeEnabled = marquee !== false;
    global.BjtuTheme.applyBackgroundColors(settings);
    Object.keys(defaults).forEach((key) => {
      document.documentElement.toggleAttribute(`data-custom-color-${key.toLowerCase()}`, !!settings[key]);
      if (settings[key] || ['resource', 'replay', 'assessment', 'archive', 'copy', 'download'].includes(key)) {
        const color = settings[key] || defaults[key];
        setProperty(document.documentElement, `--bjtu-color-${key}`, color);
        setProperty(document.documentElement, `--bjtu-color-${key}-foreground`, ['button', 'resource', 'replay', 'assessment', 'archive', 'copy', 'download'].includes(key) ? '#ffffff' : foreground(color));
      } else {
        document.documentElement.style.removeProperty(`--bjtu-color-${key}`);
        document.documentElement.style.removeProperty(`--bjtu-color-${key}-foreground`);
      }
    });
    refreshCards();
    refreshEditor();
  }

  function init() {
    const grid = document.getElementById('componentColorGrid');
    if (grid) {
      grid.innerHTML = Object.keys(labels).map((name) => {
        const key = name === 'background' || name === 'card' ? currentSurfaceKey(name) : name;
        return `<label class="component-color-item"><span>${labels[name]}</span><input type="color" data-component-color="${key}" value="${defaults[key]}" aria-label="${labels[name]}颜色"><button class="font-size-default" type="button" data-reset-color="${key}" hidden>默认</button></label>`;
      }).join('');
      grid.addEventListener('input', (event) => {
        const key = event.target.dataset.componentColor;
        if (!key) return;
        apply({ ...settings, [key]: event.target.value });
        void chrome.storage.local.set({ [storageKey]: { ...settings } });
      });
      grid.addEventListener('click', (event) => {
        const key = event.target.dataset.resetColor;
        if (!key) return;
        event.preventDefault();
        const next = { ...settings };
        delete next[key];
        apply(next);
        void chrome.storage.local.set({ [storageKey]: next });
      });
      document.getElementById('homeworkDeadlineGradientEnabled').addEventListener('change', (event) => {
        apply(settings, event.target.checked);
        void chrome.storage.local.set({ [gradientKey]: gradientEnabled });
      });
      document.getElementById('homeworkMarqueeEnabled').addEventListener('change', (event) => {
        apply(settings, gradientEnabled, event.target.checked);
        void chrome.storage.local.set({ [marqueeKey]: marqueeEnabled });
      });
    }
    refreshEditor();
    refreshCards();
    const pendingCards = new Set();
    let scheduled = false;
    new MutationObserver((records) => {
      records.forEach((record) => {
        if (record.type === 'attributes' && record.target.matches('.hw-card-item')) pendingCards.add(record.target);
        record.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node.matches('.hw-card-item')) pendingCards.add(node);
          node.querySelectorAll('.hw-card-item').forEach((card) => pendingCards.add(card));
        });
        for (const node of record.removedNodes) {
          if (node.nodeType !== 1 || node.isConnected) continue;
          if (animatedCards.has(node)) observeCardAnimation(node,false);
          for (const card of node.querySelectorAll('.hw-card-item')) {
            if (animatedCards.has(card)) observeCardAnimation(card,false);
            pendingCards.delete(card);
          }
          pendingCards.delete(node);
        }
      });
      if (!pendingCards.size || scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => {
        scheduled = false;
        refreshCards([...pendingCards].filter((card) => card.isConnected));
        pendingCards.clear();
      });
    }).observe(document.body, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ['data-homework-done', 'data-homework-overdue', 'data-homework-deadline', 'data-homework-teacher', 'data-homework-gradient']
    });
    setInterval(() => { if (!document.hidden) refreshCards(); },1000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshCards();
      else animatedCards.forEach(syncCardAnimation);
    });
    global.addEventListener('bjtu-animation-change', () => animatedCards.forEach(syncCardAnimation));
  }

  global.BjtuColors = Object.freeze({ storageKey, gradientKey, marqueeKey, defaults, normalize, interpolate, deadlineTime, urgency, apply, captureAnimations, restoreAnimations });
  void chrome.storage.local.get([storageKey, gradientKey, marqueeKey]).then((stored) => apply(stored[storageKey] || {}, stored[gradientKey] !== false, stored[marqueeKey] !== false));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || (!changes[storageKey] && !changes[gradientKey] && !changes[marqueeKey])) return;
    apply(changes[storageKey] ? (changes[storageKey].newValue || {}) : settings,
      changes[gradientKey] ? changes[gradientKey].newValue !== false : gradientEnabled,
      changes[marqueeKey] ? changes[marqueeKey].newValue !== false : marqueeEnabled);
  });
  global.addEventListener('bjtu-theme-change', refreshEditor);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})(globalThis);
