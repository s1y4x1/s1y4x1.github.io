var POPUP_CACHE_ENABLED_KEY = window.POPUP_CACHE_ENABLED_KEY = 'popupUseFullscreenCacheEnabled';
var SIDE_PANEL_CACHE_ENABLED_KEY = window.SIDE_PANEL_CACHE_ENABLED_KEY = 'sidePanelUseFullscreenCacheEnabled';
var POPUP_FULLSCREEN_CACHE_KEY = window.POPUP_FULLSCREEN_CACHE_KEY = 'popupFullscreenCourseCache';
var HOMEWORK_REMINDER_SNAPSHOT_KEY = 'homeworkReminderSnapshot';

window.popupUseFullscreenCacheEnabled = true;
window.sidePanelUseFullscreenCacheEnabled = true;
window.__popupUsingFullscreenCache = false;

function isSidePanelCacheView() {
  return new URLSearchParams(String(location.search || '')).get('view') === 'sidepanel';
}

function useFullscreenCacheForCurrentCompactView() {
  return isSidePanelCacheView()
    ? window.sidePanelUseFullscreenCacheEnabled
    : window.popupUseFullscreenCacheEnabled;
}

function shouldSaveFullscreenCourseCache() {
  return window.popupUseFullscreenCacheEnabled || window.sidePanelUseFullscreenCacheEnabled;
}

async function loadPopupCacheEnabledSetting() {
  try {
    const data = await chrome.storage.local.get([POPUP_CACHE_ENABLED_KEY, SIDE_PANEL_CACHE_ENABLED_KEY]);
    window.popupUseFullscreenCacheEnabled = data[POPUP_CACHE_ENABLED_KEY] === undefined
      ? true
      : !!data[POPUP_CACHE_ENABLED_KEY];
    window.sidePanelUseFullscreenCacheEnabled = data[SIDE_PANEL_CACHE_ENABLED_KEY] === undefined
      ? true
      : !!data[SIDE_PANEL_CACHE_ENABLED_KEY];
  } catch {
    window.popupUseFullscreenCacheEnabled = true;
    window.sidePanelUseFullscreenCacheEnabled = true;
  }
  return useFullscreenCacheForCurrentCompactView();
}

function safeStorageClone(value, fallback) {
  try {
    return JSON.parse(JSON.stringify(value, (_key, val) => {
      if (typeof val === 'function') return undefined;
      if (val && typeof val.then === 'function') return undefined;
      if (val instanceof Set) return Array.from(val);
      return val;
    }));
  } catch {
    return fallback;
  }
}

function resetCachedPanelButton(btn, text, progressClass, progressProp) {
  if (!(btn instanceof HTMLElement)) return;
  btn.disabled = false;
  btn.style.opacity = '1';
  btn.style.pointerEvents = 'auto';
  btn.classList.remove(progressClass);
  btn.classList.remove('courseware-list-loading');
  btn.classList.remove('replay-list-loading');
  btn.style.removeProperty(progressProp);
  btn.textContent = text;
}

function collapseRestoredCoursePanelsForPopup(root) {
  if (!(root instanceof HTMLElement)) return;
  root.querySelectorAll('.file-item').forEach((card) => {
    if (!(card instanceof HTMLElement)) return;
    delete card.dataset.resultView;
    const area = card.querySelector('.result-area');
    if (area instanceof HTMLElement) {
      area.innerHTML = '';
      area.style.display = 'none';
      area.style.maxHeight = '0px';
      area.style.opacity = '0';
      area.style.overflow = 'hidden';
      area.dataset.animOpen = '0';
    }
    card.querySelectorAll('.replay-shadow-area').forEach((el) => el.remove());
  });
  root.querySelectorAll('.expandable-box').forEach((box) => {
    if (!(box instanceof HTMLElement)) return;
    box.classList.remove('expanded');
    box.dataset.expanded = '0';
    const body = box.querySelector('.expandable-body');
    if (body instanceof HTMLElement) {
      body.style.removeProperty('max-height');
      body.style.removeProperty('overflow');
      body.style.removeProperty('overflow-x');
      body.style.removeProperty('overflow-y');
    }
    const toggle = box.querySelector('.expandable-toggle');
    if (toggle instanceof HTMLElement) {
      toggle.textContent = toggle.dataset.openText || '点击展开详情';
    }
  });
  root.querySelectorAll('.homework-group[data-homework-group="overdue"], .homework-group[data-homework-group="done"]').forEach((group) => {
    if (!(group instanceof HTMLElement)) return;
    group.classList.add('is-hidden');
    group.classList.remove('homework-group-animating');
    group.dataset.expanded = '0';
    group.setAttribute('aria-hidden', 'true');
    group.style.removeProperty('max-height');
    group.style.removeProperty('opacity');
    group.style.removeProperty('transform');
    group.style.removeProperty('overflow');
  });
  root.querySelectorAll('.homework-toggle-btn[data-homework-toggle-kind], .homework-toggle-btn[data-mooc-action="toggle-overdue"], .homework-toggle-btn[data-mooc-action="toggle-done"], .homework-toggle-btn[data-xuetangx-action="toggle-overdue"], .homework-toggle-btn[data-xuetangx-action="toggle-done"]').forEach((btn) => {
    if (!(btn instanceof HTMLElement)) return;
    btn.classList.remove('is-expanded', 'homework-toggle-btn--up');
    btn.classList.add('homework-toggle-btn--down');
    btn.setAttribute('aria-expanded', 'false');
    delete btn.dataset.animating;
    const label = btn.querySelector('.homework-toggle-label');
    const count = String(btn.dataset.count || '').trim();
    const collapsedText = String(btn.dataset.collapsedText || '').trim();
    if (label instanceof HTMLElement && collapsedText) {
      label.textContent = `${collapsedText}${count ? ` (${count})` : ''}`;
    }
  });
  root.querySelectorAll('.force-score-publish-row').forEach((el) => el.remove());
  root.querySelectorAll('.submit-panel').forEach((panel) => {
    if (panel instanceof HTMLElement) panel.style.display = 'none';
  });
  root.querySelectorAll('button[data-action="courseware"]').forEach((btn) => {
    resetCachedPanelButton(btn, '资源下载', 'courseware-link-progress', '--courseware-progress');
  });
  root.querySelectorAll('button[data-action="videos"]').forEach((btn) => {
    resetCachedPanelButton(btn, '回放下载', 'replay-link-progress', '--replay-progress');
  });
}

function unwrapPlatformCourseColumnsForPopup(root) {
  if (!(root instanceof HTMLElement)) return;
  root.querySelectorAll(':scope > .platform-course-column').forEach((column) => {
    column.querySelectorAll(':scope > .platform-course-column-body > .file-item[data-course-rankable="1"]').forEach((card) => {
      root.appendChild(card);
    });
    column.remove();
  });
  root.querySelectorAll(':scope > .platform-column-resizer').forEach((resizer) => resizer.remove());
  root.classList.remove('platform-split-grid');
  root.style.removeProperty('grid-template-columns');
}

function getCollapsedCourseHomeworkDataForPopup() {
  const data = safeStorageClone(window.courseHomeworkData, {});
  Object.values(data).forEach((course) => {
    if (!course) return;
    course.showOverdue = false;
    course.showDone = false;
    delete course.justExpanded;
    delete course.justCollapsed;
  });
  return data;
}

function normalizeRestoredCachesForPopup() {
  Object.values(window.coursewareCacheByCourseId || {}).forEach((cache) => {
    if (!cache) return;
    cache.rpLinksFetching = false;
  });
  Object.values(window.videoReplayCacheByCourseId || {}).forEach((cache) => {
    if (!cache) return;
    cache.linksFetching = false;
  });
  Object.values(window.courseCardStateById || {}).forEach((state) => {
    if (!state) return;
    state.replayListLoading = false;
    state.coursewareListLoading = false;
  });
}

function getPopupCacheTimestampText(ts) {
  const d = new Date(Number(ts || 0));
  if (Number.isNaN(d.getTime())) return '未知时间';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function compactCacheViewLabel() {
  return isSidePanelCacheView() ? '边栏' : '弹出窗口';
}

function showPopupCacheNotice(cache) {
  let el = document.getElementById('popup-cache-notice');
  if (!el) {
    el = document.createElement('div');
    el.id = 'popup-cache-notice';
    el.style.cssText = 'margin:0 0 8px;padding:7px 10px;border:1px solid #f59e0b;border-radius:6px;background:#fffbeb;color:#92400e;font-size:12px;line-height:1.45;';
    const host = document.querySelector('.right-column') || courseListDiv?.parentElement || document.body;
    const resizer = host?.querySelector?.('.right-column-resizer');
    if (resizer?.nextSibling) host.insertBefore(el, resizer.nextSibling);
    else if (host?.firstChild) host.insertBefore(el, host.firstChild);
    else host?.appendChild(el);
  }
  el.classList.remove('popup-cache-loading');
  const savedAt = getPopupCacheTimestampText(cache?.savedAt);
  el.textContent = `于 ${savedAt} 缓存。如需更新，请重启平台或全屏打开。`;
}

function waitForPopupCachePaint() {
  return new Promise((resolve) => {
    if (typeof requestAnimationFrame !== 'function') {
      setTimeout(resolve, 0);
      return;
    }
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });
}

function showPopupCacheLoadingFrame() {
  if (!popupMode) return;
  showPopupCacheNotice(null);
  const notice = document.getElementById('popup-cache-notice');
  if (!notice) return;
  notice.classList.add('popup-cache-loading');
  notice.setAttribute('role', 'status');
  notice.innerHTML = `
    <span class="spinner" aria-hidden="true"></span>
    <span>正在读取缓存…</span>
  `;
}

async function renderPopupCachedCoursesProgressively({
  canRenderStructuredVeCache,
  hasStructuredExternalData,
  cache
}) {
  if (!courseListDiv) return;
  if (canRenderStructuredVeCache) {
    const courses = Array.isArray(window.currentVeCourseList) ? window.currentVeCourseList : [];
    const batchSize = 4;
    courseListDiv.innerHTML = '';
    for (let offset = 0; offset < courses.length; offset += batchSize) {
      renderCourseList(courses.slice(offset, offset + batchSize), {
        cachedOnly: true,
        append: offset > 0,
        deferExternal: true,
        orderOffset: offset
      });
      await Promise.resolve(window.veHomeworkLoadPromise).catch(() => {});
      updateCourseListEmptyPlaceholder();
      await waitForPopupCachePaint();
    }
  } else if (hasStructuredExternalData) {
    courseListDiv.innerHTML = '';
  } else {
    courseListDiv.innerHTML = String(cache.courseListHtml || '');
    return;
  }

  const renderers = [
    isPlatformEnabled('ykt') && typeof renderYktStandaloneCourses === 'function'
      ? () => renderYktStandaloneCourses()
      : null,
    isPlatformEnabled('mrjzy') && typeof renderMrjzyStandaloneCourses === 'function'
      ? () => renderMrjzyStandaloneCourses()
      : null,
    isPlatformEnabled('jlgj') && typeof renderJlgjStandaloneCourses === 'function'
      ? () => renderJlgjStandaloneCourses()
      : null,
    isPlatformEnabled('xuetangx') && window.platformLoadedOnce?.xuetangx
      ? () => window.BjtuXuetangxPlatform?.render()
      : null,
    isPlatformEnabled('mooc')
      ? () => window.BjtuMoocPlatform?.render()
      : null
  ].filter(Boolean);
  for (const render of renderers) {
    render();
    await waitForPopupCachePaint();
  }
}

function restoreFullscreenCacheStateForBackground(cache) {
  if (!cache || typeof cache !== 'object') return;
  window.platformLoginState = { ...window.platformLoginState, ...(cache.platformLoginState || {}) };
  window.platformLoginChecked = { ...window.platformLoginChecked, ...(cache.platformLoginChecked || {}) };
  window.platformLoadedOnce = { ...window.platformLoadedOnce, ...(cache.platformLoadedOnce || {}) };
  window.platformNeedLogin = { ...window.platformNeedLogin, ...(cache.platformNeedLogin || {}) };
  window.courseHomeworkData = cache.courseHomeworkData || {};
  window.yktMatchedHomeworkByCourseId = cache.yktMatchedHomeworkByCourseId || {};
  window.yktMatchedCourseLinkByCourseId = cache.yktMatchedCourseLinkByCourseId || {};
  window.yktStandaloneCourses = Array.isArray(cache.yktStandaloneCourses) ? cache.yktStandaloneCourses : [];
  window.yktCourseGroupsSnapshot = Array.isArray(cache.yktCourseGroupsSnapshot) ? cache.yktCourseGroupsSnapshot : [];
  window.mrjzyMatchedHomeworkByCourseId = cache.mrjzyMatchedHomeworkByCourseId || {};
  window.mrjzyStandaloneCourses = Array.isArray(cache.mrjzyStandaloneCourses) ? cache.mrjzyStandaloneCourses : [];
  window.mrjzyCourseGroupsSnapshot = Array.isArray(cache.mrjzyCourseGroupsSnapshot) ? cache.mrjzyCourseGroupsSnapshot : [];
  window.jlgjMatchedHomeworkByCourseId = cache.jlgjMatchedHomeworkByCourseId || {};
  window.jlgjStandaloneCourses = Array.isArray(cache.jlgjStandaloneCourses) ? cache.jlgjStandaloneCourses : [];
  window.jlgjCourseGroupsSnapshot = Array.isArray(cache.jlgjCourseGroupsSnapshot) ? cache.jlgjCourseGroupsSnapshot : [];
  window.BjtuMoocPlatform?.restore(cache.moocCourses || []);
  window.BjtuXuetangxPlatform?.restore(cache.xuetangxCourses || []);
  window.courseCardStateById = cache.courseCardStateById || {};
  window.videoReplayCacheByCourseId = cache.videoReplayCacheByCourseId || {};
  window.coursewareCacheByCourseId = cache.coursewareCacheByCourseId || {};
  window.homeworkScoreCacheByKey = cache.homeworkScoreCacheByKey || {};
  window.homeworkNoteAttachmentCacheByKey = cache.homeworkNoteAttachmentCacheByKey || {};
  window.veTeacherMetaByCourseId = cache.veTeacherMetaByCourseId || {};
  window.veCourseTeachersMetaByCourseId = cache.veCourseTeachersMetaByCourseId || {};
  window.resourceSpaceItems = Array.isArray(cache.resourceSpaceItems) ? cache.resourceSpaceItems : [];
  if (resourceSpaceList) resourceSpaceList.innerHTML = String(cache.resourceSpaceHtml || '');
  if (resourceSpaceStatus) resourceSpaceStatus.textContent = String(cache.resourceSpaceStatusText || '');
  if (resourceSpaceCount) resourceSpaceCount.textContent = String(cache.resourceSpaceCountText || '');
  if (xqSelect && cache.xqSelectHtml) {
    xqSelect.innerHTML = String(cache.xqSelectHtml || '');
    xqSelect.value = String(cache.xqSelectValue || '');
  }
}

async function saveFullscreenCourseCache({ force = false } = {}) {
  if (popupMode || (!force && !shouldSaveFullscreenCourseCache()) || !courseListDiv) return;
  const cache = {
    version: 1,
    structuredCourseCache: true,
    savedAt: Date.now(),
    platformEnabled: safeStorageClone(window.platformEnabled, {}),
    platformLoginState: safeStorageClone(window.platformLoginState, {}),
    platformLoginChecked: safeStorageClone(window.platformLoginChecked, {}),
    platformLoadedOnce: safeStorageClone(window.platformLoadedOnce, {}),
    platformNeedLogin: safeStorageClone(window.platformNeedLogin, {}),
    currentVeCourseList: safeStorageClone(window.currentVeCourseList, []),
    courseHomeworkData: getCollapsedCourseHomeworkDataForPopup(),
    yktMatchedHomeworkByCourseId: safeStorageClone(window.yktMatchedHomeworkByCourseId, {}),
    yktMatchedCourseLinkByCourseId: safeStorageClone(window.yktMatchedCourseLinkByCourseId, {}),
    yktStandaloneCourses: safeStorageClone(window.yktStandaloneCourses, []),
    yktCourseGroupsSnapshot: safeStorageClone(window.yktCourseGroupsSnapshot, []),
    mrjzyMatchedHomeworkByCourseId: safeStorageClone(window.mrjzyMatchedHomeworkByCourseId, {}),
    mrjzyStandaloneCourses: safeStorageClone(window.mrjzyStandaloneCourses, []),
    mrjzyCourseGroupsSnapshot: safeStorageClone(window.mrjzyCourseGroupsSnapshot, []),
    jlgjMatchedHomeworkByCourseId: safeStorageClone(window.jlgjMatchedHomeworkByCourseId, {}),
    jlgjStandaloneCourses: safeStorageClone(window.jlgjStandaloneCourses, []),
    jlgjCourseGroupsSnapshot: safeStorageClone(window.jlgjCourseGroupsSnapshot, []),
    moocCourses: safeStorageClone(window.BjtuMoocPlatform?.getCourses?.(), []),
    xuetangxCourses: safeStorageClone(window.BjtuXuetangxPlatform?.getCourses?.(), []),
    courseCardStateById: safeStorageClone(window.courseCardStateById, {}),
    videoReplayCacheByCourseId: safeStorageClone(window.videoReplayCacheByCourseId, {}),
    coursewareCacheByCourseId: safeStorageClone(window.coursewareCacheByCourseId, {}),
    homeworkScoreCacheByKey: safeStorageClone(window.homeworkScoreCacheByKey, {}),
    homeworkNoteAttachmentCacheByKey: safeStorageClone(window.homeworkNoteAttachmentCacheByKey, {}),
    veTeacherMetaByCourseId: safeStorageClone(window.veTeacherMetaByCourseId, {}),
    veCourseTeachersMetaByCourseId: safeStorageClone(window.veCourseTeachersMetaByCourseId, {}),
    resourceSpaceItems: [],
    currentAccountLoginName: String(window.currentAccountLoginName || ''),
    isTeacherAccount: !!window.isTeacherAccount,
    courseListHtml: '',
    resourceSpaceHtml: '',
    resourceSpaceStatusText: String(resourceSpaceStatus?.textContent || ''),
    resourceSpaceCountText: String(resourceSpaceCount?.textContent || ''),
    xqSelectHtml: String(xqSelect?.innerHTML || ''),
    xqSelectValue: String(xqSelect?.value || '')
  };
  try {
    await chrome.storage.local.set({ [POPUP_FULLSCREEN_CACHE_KEY]: cache });
  } catch (e) {
    try { console.warn('[bjtu] save popup cache failed:', e); } catch {}
  }
}

function detectReminderPlatform(item, courseCard) {
  if (item.classList.contains('xuetangx-task') || String(courseCard?.id || '').startsWith('course-xuetangx-')) return '学堂在线';
  if (item.classList.contains('mooc-task') || String(courseCard?.id || '').startsWith('course-mooc-')) return '中国大学MOOC';
  const hrefs = Array.from(item.querySelectorAll('a[href]')).map((link) => String(link.href || '')).join(' ');
  if (/xuetangx\.com/i.test(hrefs)) return '学堂在线';
  if (/yuketang\.cn/i.test(hrefs)) return '雨课堂';
  if (/lulufind\.com|mrzuoye\.com/i.test(hrefs)) return '每日交作业';
  if (/jielong\.com/i.test(hrefs)) return '接龙管家';
  return '智慧课程平台';
}

function collectPendingHomeworkItems({ futureDeadlineOnly = false } = {}) {
  if (!courseListDiv) return [];
  const now = Date.now();
  const seen = new Set();
  const items = [];
  courseListDiv.querySelectorAll('.hw-card-item').forEach((homework) => {
    const countdown = homework.querySelector('.deadline-countdown[data-deadline]');
    const deadline = countdown
      ? (typeof parseDeadlineToTs === 'function'
        ? parseDeadlineToTs(countdown.dataset.deadline)
        : Number(countdown.dataset.deadline || 0))
      : 0;
    if (futureDeadlineOnly && (!deadline || deadline <= now)) return;
    const courseCard = homework.closest('.file-item');
    if (!(homework instanceof HTMLElement) || !(courseCard instanceof HTMLElement)) return;
    if (homework.dataset.homeworkDone === '1') return;
    const courseName = String(courseCard.querySelector('.course-card-title')?.textContent || '未知课程').replace(/\s+/g, ' ').trim();
    const titleElement = homework.querySelector('.mooc-task-title, .xuetangx-task-title')
      || Array.from(homework.querySelectorAll('div')).find((node) => node instanceof HTMLElement && node.style.fontWeight === 'bold');
    const title = String(titleElement?.textContent || '未交作业').replace(/\s+/g, ' ').trim();
    const platform = detectReminderPlatform(homework, courseCard);
    const actionUrl = String(homework.querySelector('a.btn[href]')?.href || courseCard.querySelector('.course-card-title a[href]')?.href || '');
    const key = `${platform}|${courseName}|${title}|${deadline}`;
    if (seen.has(key)) return;
    seen.add(key);
    items.push({ key, platform, courseName, title, deadline, actionUrl });
  });
  return items;
}

function collectHomeworkReminderSnapshot() {
  return collectPendingHomeworkItems({ futureDeadlineOnly: true });
}

let homeworkReminderSnapshotTimer = null;

function normalizeHomeworkReminderAccounts(snapshot) {
  if (snapshot?.accounts && typeof snapshot.accounts === 'object' && !Array.isArray(snapshot.accounts)) {
    return Object.fromEntries(Object.entries(snapshot.accounts).map(([account, entry]) => [
      String(account || 'default'),
      {
        updatedAt: Number(entry?.updatedAt || 0),
        items: Array.isArray(entry?.items) ? entry.items : []
      }
    ]));
  }
  if (!Array.isArray(snapshot?.items)) return {};
  return {
    [String(snapshot?.account || 'default')]: {
      updatedAt: Number(snapshot?.updatedAt || 0),
      items: snapshot.items
    }
  };
}

const HOMEWORK_REMINDER_PLATFORM_LABELS = Object.freeze({
  ve: '智慧课程平台',
  ykt: '雨课堂',
  mrjzy: '每日交作业',
  jlgj: '接龙管家',
  mooc: '中国大学MOOC',
  xuetangx: '学堂在线'
});

async function saveHomeworkReminderSnapshotNow() {
  const now = Date.now();
  const account = String(window.currentAccountLoginName || 'default').trim() || 'default';
  const currentItems = collectHomeworkReminderSnapshot();
  const stored = await chrome.storage.local.get([HOMEWORK_REMINDER_SNAPSHOT_KEY]).catch(() => ({}));
  const previousSnapshot = stored?.[HOMEWORK_REMINDER_SNAPSHOT_KEY];
  const accounts = normalizeHomeworkReminderAccounts(previousSnapshot);
  const previousItems = Array.isArray(accounts[account]?.items) ? accounts[account].items : [];
  const authoritativePlatforms = new Set();
  Object.entries(HOMEWORK_REMINDER_PLATFORM_LABELS).forEach(([platform, label]) => {
    const online = window.platformLoginState?.[platform] === 'online';
    const loaded = window.platformLoadedOnce?.[platform] === true
      || currentItems.some((item) => item?.platform === label);
    if (online && loaded) authoritativePlatforms.add(label);
  });

  // 登录失效的平台不再出现在当前 DOM 中，但其已知作业仍须继续提醒。
  // 只替换本次已成功加载的平台数据，其他平台保留上次快照。
  const mergedItems = [
    ...previousItems.filter((item) => !authoritativePlatforms.has(String(item?.platform || ''))),
    ...currentItems.filter((item) => authoritativePlatforms.has(String(item?.platform || '')))
  ];
  accounts[account] = { updatedAt: now, items: mergedItems };
  const snapshot = {
    version: 2,
    updatedAt: now,
    account,
    accounts
  };
  await chrome.storage.local.set({ [HOMEWORK_REMINDER_SNAPSHOT_KEY]: snapshot });
  return snapshot;
}

function scheduleHomeworkReminderSnapshotSave(delayMs = 500) {
  if (popupMode) return;
  if (homeworkReminderSnapshotTimer) clearTimeout(homeworkReminderSnapshotTimer);
  homeworkReminderSnapshotTimer = setTimeout(async () => {
    homeworkReminderSnapshotTimer = null;
    try {
      await saveHomeworkReminderSnapshotNow();
    } catch (error) {
      try { console.warn('[bjtu] save homework reminder snapshot failed:', error); } catch {}
    }
  }, Math.max(100, Number(delayMs) || 500));
}

let popupCourseCacheSaveTimer = null;
function scheduleFullscreenCourseCacheSave(delayMs = 900) {
  if (!popupMode) scheduleHomeworkReminderSnapshotSave(Math.min(500, Number(delayMs) || 500));
  if (popupMode || !shouldSaveFullscreenCourseCache()) return;
  if (popupCourseCacheSaveTimer) clearTimeout(popupCourseCacheSaveTimer);
  popupCourseCacheSaveTimer = setTimeout(() => {
    popupCourseCacheSaveTimer = null;
    saveFullscreenCourseCache().catch(() => {});
  }, Math.max(120, Number(delayMs) || 900));
}

function setupFullscreenCourseCacheObserver() {
  if (popupMode || !courseListDiv) return;
  try {
    const mo = new MutationObserver((mutations) => {
      const relevant = mutations.some((mutation) => {
        const target = mutation.target instanceof Element ? mutation.target : mutation.target?.parentElement;
        return !(target instanceof Element && target.closest('.deadline-countdown'));
      });
      if (relevant) scheduleFullscreenCourseCacheSave();
    });
    mo.observe(courseListDiv, { childList: true, subtree: true, attributes: true, characterData: true });
    if (resourceSpaceList) mo.observe(resourceSpaceList, { childList: true, subtree: true, attributes: true, characterData: true });
  } catch {
    // ignore
  }
}

function restorePopupPlatformStates(cache) {
  window.platformLoginState = { ...window.platformLoginState, ...(cache?.platformLoginState || {}) };
  window.platformLoginChecked = { ...window.platformLoginChecked, ...(cache?.platformLoginChecked || {}) };
  window.platformLoadedOnce = { ...window.platformLoadedOnce, ...(cache?.platformLoadedOnce || {}) };
  window.platformNeedLogin = { ...window.platformNeedLogin, ...(cache?.platformNeedLogin || {}) };
  PLATFORM_IDS.forEach((id) => {
    if (window.platformLoadedOnce?.[id] === true && window.platformLoginState?.[id] === 'checking') {
      window.platformLoginState[id] = 'online';
    }
  });
}

async function restorePopupFullscreenCacheIfNeeded() {
  if (!popupMode || !useFullscreenCacheForCurrentCompactView()) return false;
  window.__popupUsingFullscreenCache = true;
  showPopupCacheLoadingFrame();
  await waitForPopupCachePaint();
  let cache = null;
  try {
    const data = await chrome.storage.local.get([POPUP_FULLSCREEN_CACHE_KEY]);
    cache = data[POPUP_FULLSCREEN_CACHE_KEY] || null;
  } catch {
    cache = null;
  }
  const veModuleAvailable = globalThis.BjtuModuleRegistry?.has('ve') === true;
  const hasStructuredVeData = (cache?.backgroundStructuredVe === true || cache?.structuredCourseCache === true)
    && Array.isArray(cache?.currentVeCourseList);
  const hasStructuredExternalData = [
    cache?.yktCourseGroupsSnapshot,
    cache?.yktStandaloneCourses,
    cache?.mrjzyCourseGroupsSnapshot,
    cache?.mrjzyStandaloneCourses,
    cache?.jlgjCourseGroupsSnapshot,
    cache?.jlgjStandaloneCourses,
    cache?.moocCourses,
    cache?.xuetangxCourses
  ].some((list) => Array.isArray(list) && list.length > 0);
  const canRenderStructuredVeCache = veModuleAvailable
    && hasStructuredVeData
    && typeof renderCourseList === 'function';
  if (!cache || (!canRenderStructuredVeCache
      && !hasStructuredExternalData
      && !String(cache.courseListHtml || '').trim())) {
    window.platformEnabled = sanitizePlatformEnabled(cache?.platformEnabled || window.platformEnabled, window.platformEnabled);
    restorePopupPlatformStates(cache);
    refreshPlatformLoginTip();
    showPopupCacheNotice(cache);
    if (courseListDiv) {
      courseListDiv.innerHTML = '<div style="color:#666;padding:6px 0;">暂无全屏缓存内容，请全屏打开后加载一次。</div>';
    }
    if (resourceSpaceStatus) setResourceSpaceStatus(`${compactCacheViewLabel()}使用缓存；暂无资源空间缓存`, 'warning');
    return true;
  }

  window.platformEnabled = sanitizePlatformEnabled(cache.platformEnabled || {}, window.platformEnabled);
  restorePopupPlatformStates(cache);
  window.currentVeCourseList = veModuleAvailable && Array.isArray(cache.currentVeCourseList)
    ? cache.currentVeCourseList
    : [];
  window.courseHomeworkData = cache.courseHomeworkData || {};
  Object.values(window.courseHomeworkData).forEach((data) => {
    if (!data) return;
    data.showOverdue = false;
    data.showDone = false;
    data.justExpanded = false;
    data.justCollapsed = false;
  });
  window.courseShowOverdueById = {};
  window.courseShowDoneById = {};
  window.homeworkDetailExpandedByCourse = {};
  window.yktMatchedHomeworkByCourseId = cache.yktMatchedHomeworkByCourseId || {};
  window.yktMatchedCourseLinkByCourseId = cache.yktMatchedCourseLinkByCourseId || {};
  window.yktStandaloneCourses = Array.isArray(cache.yktStandaloneCourses) ? cache.yktStandaloneCourses : [];
  window.yktCourseGroupsSnapshot = Array.isArray(cache.yktCourseGroupsSnapshot) ? cache.yktCourseGroupsSnapshot : [];
  window.mrjzyMatchedHomeworkByCourseId = cache.mrjzyMatchedHomeworkByCourseId || {};
  window.mrjzyStandaloneCourses = Array.isArray(cache.mrjzyStandaloneCourses) ? cache.mrjzyStandaloneCourses : [];
  window.mrjzyCourseGroupsSnapshot = Array.isArray(cache.mrjzyCourseGroupsSnapshot) ? cache.mrjzyCourseGroupsSnapshot : [];
  window.jlgjMatchedHomeworkByCourseId = cache.jlgjMatchedHomeworkByCourseId || {};
  window.jlgjStandaloneCourses = Array.isArray(cache.jlgjStandaloneCourses) ? cache.jlgjStandaloneCourses : [];
  window.jlgjCourseGroupsSnapshot = Array.isArray(cache.jlgjCourseGroupsSnapshot) ? cache.jlgjCourseGroupsSnapshot : [];
  window.BjtuMoocPlatform?.restore(cache.moocCourses || []);
  window.BjtuXuetangxPlatform?.restore(cache.xuetangxCourses || []);
  window.courseCardStateById = cache.courseCardStateById || {};
  window.videoReplayCacheByCourseId = cache.videoReplayCacheByCourseId || {};
  window.coursewareCacheByCourseId = cache.coursewareCacheByCourseId || {};
  window.homeworkScoreCacheByKey = cache.homeworkScoreCacheByKey || {};
  window.homeworkNoteAttachmentCacheByKey = cache.homeworkNoteAttachmentCacheByKey || {};
  window.veTeacherMetaByCourseId = cache.veTeacherMetaByCourseId || {};
  window.veCourseTeachersMetaByCourseId = cache.veCourseTeachersMetaByCourseId || {};
  window.resourceSpaceItems = Array.isArray(cache.resourceSpaceItems) ? cache.resourceSpaceItems : [];
  window.currentAccountLoginName = String(cache.currentAccountLoginName || '');
  window.isTeacherAccount = !!cache.isTeacherAccount;
  normalizeRestoredCachesForPopup();
  if ((canRenderStructuredVeCache || hasStructuredExternalData)
      && typeof rematchExternalByVeCourses === 'function') {
    rematchExternalByVeCourses();
  }

  if (courseListDiv) {
    await renderPopupCachedCoursesProgressively({
      canRenderStructuredVeCache,
      hasStructuredExternalData,
      cache
    });
    unwrapPlatformCourseColumnsForPopup(courseListDiv);
    collapseRestoredCoursePanelsForPopup(courseListDiv);
  }
  if (resourceSpaceList) resourceSpaceList.innerHTML = String(cache.resourceSpaceHtml || '');
  if (resourceSpaceStatus) setResourceSpaceStatus(cache.resourceSpaceStatusText || `${compactCacheViewLabel()}使用缓存`, 'warning');
  if (resourceSpaceCount && cache.resourceSpaceCountText) resourceSpaceCount.textContent = String(cache.resourceSpaceCountText);
  if (xqSelect && cache.xqSelectHtml) {
    xqSelect.innerHTML = String(cache.xqSelectHtml || '');
    xqSelect.value = String(cache.xqSelectValue || '');
  }
  refreshPlatformLoginTip();
  applyPlatformVisibility();
  showPopupCacheNotice(cache);
  return true;
}
