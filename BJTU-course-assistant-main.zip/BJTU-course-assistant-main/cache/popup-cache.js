var POPUP_CACHE_ENABLED_KEY = window.POPUP_CACHE_ENABLED_KEY = 'popupUseFullscreenCacheEnabled';
var SIDE_PANEL_CACHE_ENABLED_KEY = window.SIDE_PANEL_CACHE_ENABLED_KEY = 'sidePanelUseFullscreenCacheEnabled';
var POPUP_FULLSCREEN_CACHE_KEY = window.POPUP_FULLSCREEN_CACHE_KEY = 'popupFullscreenCourseCache';

window.popupUseFullscreenCacheEnabled = true;
window.sidePanelUseFullscreenCacheEnabled = true;
window.__popupUsingFullscreenCache = false;

function isSidePanelCacheView() {
  return new URLSearchParams(String(location.search || '')).get('view') === 'sidepanel';
}

function useFullscreenCacheForCurrentCompactView() {
  return isSidePanelCacheView()
    ? window.sidePanelUseFullscreenCacheEnabled
    : window.popupUseFullscreenCacheEnabled;
}

function shouldSaveFullscreenCourseCache() {
  return window.popupUseFullscreenCacheEnabled || window.sidePanelUseFullscreenCacheEnabled;
}

async function loadPopupCacheEnabledSetting() {
  try {
    const data = await chrome.storage.local.get([POPUP_CACHE_ENABLED_KEY, SIDE_PANEL_CACHE_ENABLED_KEY]);
    window.popupUseFullscreenCacheEnabled = data[POPUP_CACHE_ENABLED_KEY] === undefined
      ? true
      : !!data[POPUP_CACHE_ENABLED_KEY];
    window.sidePanelUseFullscreenCacheEnabled = data[SIDE_PANEL_CACHE_ENABLED_KEY] === undefined
      ? true
      : !!data[SIDE_PANEL_CACHE_ENABLED_KEY];
  } catch {
    window.popupUseFullscreenCacheEnabled = true;
    window.sidePanelUseFullscreenCacheEnabled = true;
  }
  return useFullscreenCacheForCurrentCompactView();
}

function safeStorageClone(value, fallback) {
  try {
    return JSON.parse(JSON.stringify(value, (_key, val) => {
      if (typeof val === 'function') return undefined;
      if (val && typeof val.then === 'function') return undefined;
      if (val instanceof Set) return Array.from(val);
      return val;
    }));
  } catch {
    return fallback;
  }
}

function resetCachedPanelButton(btn, text, progressClass, progressProp) {
  if (!(btn instanceof HTMLElement)) return;
  btn.disabled = false;
  btn.style.opacity = '1';
  btn.style.pointerEvents = 'auto';
  btn.classList.remove(progressClass);
  btn.classList.remove('courseware-list-loading');
  btn.classList.remove('replay-list-loading');
  btn.style.removeProperty(progressProp);
  btn.textContent = text;
}

function collapseRestoredCoursePanelsForPopup(root) {
  if (!(root instanceof HTMLElement)) return;
  root.querySelectorAll('.file-item').forEach((card) => {
    if (!(card instanceof HTMLElement)) return;
    delete card.dataset.resultView;
    const area = card.querySelector('.result-area');
    if (area instanceof HTMLElement) {
      area.innerHTML = '';
      area.style.display = 'none';
      area.style.maxHeight = '0px';
      area.style.opacity = '0';
      area.style.overflow = 'hidden';
      area.dataset.animOpen = '0';
    }
    card.querySelectorAll('.replay-shadow-area').forEach((el) => el.remove());
  });
  root.querySelectorAll('.expandable-box').forEach((box) => {
    if (!(box instanceof HTMLElement)) return;
    box.classList.remove('expanded');
    box.dataset.expanded = '0';
    const body = box.querySelector('.expandable-body');
    if (body instanceof HTMLElement) {
      body.style.removeProperty('max-height');
      body.style.removeProperty('overflow');
      body.style.removeProperty('overflow-x');
      body.style.removeProperty('overflow-y');
    }
    const toggle = box.querySelector('.expandable-toggle');
    if (toggle instanceof HTMLElement) {
      toggle.textContent = toggle.dataset.openText || '点击展开详情';
    }
  });
  root.querySelectorAll('.homework-group[data-homework-group="overdue"], .homework-group[data-homework-group="done"]').forEach((group) => {
    if (!(group instanceof HTMLElement)) return;
    group.classList.add('is-hidden');
    group.classList.remove('homework-group-animating');
    group.dataset.expanded = '0';
    group.setAttribute('aria-hidden', 'true');
    group.style.removeProperty('max-height');
    group.style.removeProperty('opacity');
    group.style.removeProperty('transform');
    group.style.removeProperty('overflow');
  });
  root.querySelectorAll('.homework-toggle-btn[data-homework-toggle-kind], .homework-toggle-btn[data-mooc-action="toggle-overdue"], .homework-toggle-btn[data-mooc-action="toggle-done"], .homework-toggle-btn[data-xuetangx-action="toggle-overdue"], .homework-toggle-btn[data-xuetangx-action="toggle-done"]').forEach((btn) => {
    if (!(btn instanceof HTMLElement)) return;
    btn.classList.remove('is-expanded', 'homework-toggle-btn--up');
    btn.classList.add('homework-toggle-btn--down');
    btn.setAttribute('aria-expanded', 'false');
    delete btn.dataset.animating;
    const label = btn.querySelector('.homework-toggle-label');
    const count = String(btn.dataset.count || '').trim();
    const collapsedText = String(btn.dataset.collapsedText || '').trim();
    if (label instanceof HTMLElement && collapsedText) {
      label.textContent = `${collapsedText}${count ? ` (${count})` : ''}`;
    }
  });
  root.querySelectorAll('.force-score-publish-row').forEach((el) => el.remove());
  root.querySelectorAll('.submit-panel').forEach((panel) => {
    if (panel instanceof HTMLElement) panel.style.display = 'none';
  });
  root.querySelectorAll('button[data-action="courseware"]').forEach((btn) => {
    resetCachedPanelButton(btn, '资源下载', 'courseware-link-progress', '--courseware-progress');
  });
  root.querySelectorAll('button[data-action="videos"]').forEach((btn) => {
    resetCachedPanelButton(btn, '回放下载', 'replay-link-progress', '--replay-progress');
  });
}

function unwrapPlatformCourseColumnsForPopup(root) {
  if (!(root instanceof HTMLElement)) return;
  root.querySelectorAll(':scope > .platform-course-column').forEach((column) => {
    column.querySelectorAll(':scope > .platform-course-column-body > .file-item[data-course-rankable="1"]').forEach((card) => {
      root.appendChild(card);
    });
    column.remove();
  });
  root.querySelectorAll(':scope > .platform-column-resizer').forEach((resizer) => resizer.remove());
  root.classList.remove('platform-split-grid');
  root.style.removeProperty('grid-template-columns');
}

function getCollapsedCourseHomeworkDataForPopup() {
  const data = safeStorageClone(window.courseHomeworkData, {});
  Object.values(data).forEach((course) => {
    if (!course) return;
    course.showOverdue = false;
    course.showDone = false;
    delete course.justExpanded;
    delete course.justCollapsed;
  });
  return data;
}

function normalizeRestoredCachesForPopup() {
  Object.values(window.coursewareCacheByCourseId || {}).forEach((cache) => {
    if (!cache) return;
    cache.rpLinksFetching = false;
  });
  Object.values(window.videoReplayCacheByCourseId || {}).forEach((cache) => {
    if (!cache) return;
    cache.linksFetching = false;
  });
  Object.values(window.courseCardStateById || {}).forEach((state) => {
    if (!state) return;
    state.replayListLoading = false;
    state.coursewareListLoading = false;
  });
}

function getPopupCacheTimestampText(ts) {
  const d = new Date(Number(ts || 0));
  if (Number.isNaN(d.getTime())) return '未知时间';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function compactCacheViewLabel() {
  return isSidePanelCacheView() ? '边栏' : '弹出窗口';
}

function showPopupCacheNotice(cache) {
  let el = document.getElementById('popup-cache-notice');
  if (!el) {
    el = document.createElement('div');
    el.id = 'popup-cache-notice';
    el.style.cssText = 'margin:0 0 8px;padding:7px 10px;border:1px solid #f59e0b;border-radius:6px;background:#fffbeb;color:#92400e;font-size:12px;line-height:1.45;';
    const host = document.querySelector('.right-column') || courseListDiv?.parentElement || document.body;
    const resizer = host?.querySelector?.('.right-column-resizer');
    if (resizer?.nextSibling) host.insertBefore(el, resizer.nextSibling);
    else if (host?.firstChild) host.insertBefore(el, host.firstChild);
    else host?.appendChild(el);
  }
  el.classList.remove('popup-cache-loading');
  const savedAt = getPopupCacheTimestampText(cache?.savedAt);
  el.textContent = `于 ${savedAt} 缓存。如需更新，请重启平台或全屏打开。`;
}

function waitForPopupCachePaint() {
  return new Promise((resolve) => {
    if (typeof requestAnimationFrame !== 'function') {
      setTimeout(resolve, 0);
      return;
    }
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });
}

function showPopupCacheLoadingFrame() {
  if (!popupMode) return;
  showPopupCacheNotice(null);
  const notice = document.getElementById('popup-cache-notice');
  if (!notice) return;
  notice.classList.add('popup-cache-loading');
  notice.setAttribute('role', 'status');
  notice.innerHTML = `
    <span class="spinner" aria-hidden="true"></span>
    <span>正在读取缓存…</span>
  `;
}

async function renderPopupCachedCoursesProgressively({
  canRenderStructuredVeCache,
  hasStructuredExternalData,
  cache
}) {
  if (!courseListDiv) return;
  if (canRenderStructuredVeCache) {
    const courses = Array.isArray(window.currentVeCourseList) ? window.currentVeCourseList : [];
    const batchSize = 4;
    courseListDiv.innerHTML = '';
    for (let offset = 0; offset < courses.length; offset += batchSize) {
      renderCourseList(courses.slice(offset, offset + batchSize), {
        cachedOnly: true,
        append: offset > 0,
        deferExternal: true,
        orderOffset: offset
      });
      await Promise.resolve(window.veHomeworkLoadPromise).catch(() => {});
      updateCourseListEmptyPlaceholder();
      await waitForPopupCachePaint();
    }
  } else if (hasStructuredExternalData) {
    courseListDiv.innerHTML = '';
  } else {
    courseListDiv.innerHTML = String(cache.courseListHtml || '');
    return;
  }

  const renderers = [
    isPlatformEnabled('ykt') && typeof renderYktStandaloneCourses === 'function'
      ? () => renderYktStandaloneCourses()
      : null,
    isPlatformEnabled('mrjzy') && typeof renderMrjzyStandaloneCourses === 'function'
      ? () => renderMrjzyStandaloneCourses()
      : null,
    isPlatformEnabled('jlgj') && typeof renderJlgjStandaloneCourses === 'function'
      ? () => renderJlgjStandaloneCourses()
      : null,
    isPlatformEnabled('xuetangx') && window.platformLoadedOnce?.xuetangx
      ? () => window.BjtuXuetangxPlatform?.render()
      : null,
    isPlatformEnabled('citel') && window.platformLoadedOnce?.citel
      ? () => window.BjtuCitelPlatform?.render()
      : null,
    isPlatformEnabled('mooc')
      ? () => window.BjtuMoocPlatform?.render()
      : null
  ].filter(Boolean);
  for (const render of renderers) {
    render();
    await waitForPopupCachePaint();
  }
}

function restoreFullscreenCacheStateForBackground(cache) {
  if (!cache || typeof cache !== 'object') return;
  window.platformLoginState = { ...window.platformLoginState, ...(cache.platformLoginState || {}) };
  window.platformLoginChecked = { ...window.platformLoginChecked, ...(cache.platformLoginChecked || {}) };
  window.platformLoadedOnce = { ...window.platformLoadedOnce, ...(cache.platformLoadedOnce || {}) };
  window.platformNeedLogin = { ...window.platformNeedLogin, ...(cache.platformNeedLogin || {}) };
  window.courseHomeworkData = cache.courseHomeworkData || {};
  window.yktMatchedHomeworkByCourseId = cache.yktMatchedHomeworkByCourseId || {};
  window.yktMatchedCourseLinkByCourseId = cache.yktMatchedCourseLinkByCourseId || {};
  window.yktStandaloneCourses = Array.isArray(cache.yktStandaloneCourses) ? cache.yktStandaloneCourses : [];
  window.yktCourseGroupsSnapshot = Array.isArray(cache.yktCourseGroupsSnapshot) ? cache.yktCourseGroupsSnapshot : [];
  window.mrjzyMatchedHomeworkByCourseId = cache.mrjzyMatchedHomeworkByCourseId || {};
  window.mrjzyStandaloneCourses = Array.isArray(cache.mrjzyStandaloneCourses) ? cache.mrjzyStandaloneCourses : [];
  window.mrjzyCourseGroupsSnapshot = Array.isArray(cache.mrjzyCourseGroupsSnapshot) ? cache.mrjzyCourseGroupsSnapshot : [];
  window.mrjzySnapshotUpdatedAt = Number(cache.mrjzySnapshotUpdatedAt || 0);
  window.jlgjMatchedHomeworkByCourseId = cache.jlgjMatchedHomeworkByCourseId || {};
  window.jlgjStandaloneCourses = Array.isArray(cache.jlgjStandaloneCourses) ? cache.jlgjStandaloneCourses : [];
  window.jlgjCourseGroupsSnapshot = Array.isArray(cache.jlgjCourseGroupsSnapshot) ? cache.jlgjCourseGroupsSnapshot : [];
  window.BjtuMoocPlatform?.restore(cache.moocCourses || []);
  window.BjtuXuetangxPlatform?.restore(cache.xuetangxCourses || []);
  window.BjtuCitelPlatform?.restore(cache.citelCourses || []);
  window.courseCardStateById = cache.courseCardStateById || {};
  window.videoReplayCacheByCourseId = cache.videoReplayCacheByCourseId || {};
  window.coursewareCacheByCourseId = cache.coursewareCacheByCourseId || {};
  window.homeworkScoreCacheByKey = cache.homeworkScoreCacheByKey || {};
  window.homeworkNoteAttachmentCacheByKey = cache.homeworkNoteAttachmentCacheByKey || {};
  window.veTeacherMetaByCourseId = cache.veTeacherMetaByCourseId || {};
  window.veCourseTeachersMetaByCourseId = cache.veCourseTeachersMetaByCourseId || {};
  window.resourceSpaceItems = Array.isArray(cache.resourceSpaceItems) ? cache.resourceSpaceItems : [];
  if (resourceSpaceList) resourceSpaceList.innerHTML = String(cache.resourceSpaceHtml || '');
  if (resourceSpaceStatus) resourceSpaceStatus.textContent = String(cache.resourceSpaceStatusText || '');
  if (resourceSpaceCount) resourceSpaceCount.textContent = String(cache.resourceSpaceCountText || '');
  if (xqSelect && cache.xqSelectHtml) {
    xqSelect.innerHTML = String(cache.xqSelectHtml || '');
    xqSelect.value = String(cache.xqSelectValue || '');
  }
}

function collectOmniboxSearchIndex() {
  const courses = [...courseListDiv.querySelectorAll('.file-item[data-course-rankable="1"]')].flatMap((card) => {
    const title = card.querySelector('.course-card-title');
    const link = title?.querySelector('a[href]');
    return link ? [{ kind: 'course', title: String(title.textContent || '').trim(),
      platform: getCourseCardPlatform(card), url: link.href }] : [];
  });
  return courses.concat(collectPendingHomeworkItems().map((item) => ({ kind: 'homework', title: item.title,
    platform: item.platform, courseName: item.courseName, url: item.actionUrl })));
}

let fullscreenCourseCacheSavePromise = null;
let fullscreenCourseCacheSaveRequested = false;
let fullscreenCourseCacheForceRequested = false;
const fullscreenCourseCacheComplete = new Set();
const cacheCourseFields = {
  ykt: ['yktCourseGroupsSnapshot', 'yktStandaloneCourses', 'yktMatchedHomeworkByCourseId', 'yktMatchedCourseLinkByCourseId'],
  mrjzy: ['mrjzyCourseGroupsSnapshot', 'mrjzyStandaloneCourses', 'mrjzyMatchedHomeworkByCourseId'],
  jlgj: ['jlgjCourseGroupsSnapshot', 'jlgjStandaloneCourses', 'jlgjMatchedHomeworkByCourseId'],
  mooc: ['moocCourses'], xuetangx: ['xuetangxCourses'], citel: ['citelCourses']
};
const veCacheFields = ['currentVeCourseList', 'courseHomeworkData', 'courseCardStateById',
  'videoReplayCacheByCourseId', 'coursewareCacheByCourseId', 'homeworkScoreCacheByKey',
  'homeworkNoteAttachmentCacheByKey', 'veTeacherMetaByCourseId', 'veCourseTeachersMetaByCourseId',
  'currentAccountLoginName', 'isTeacherAccount', 'xqSelectHtml', 'xqSelectValue'];
const cacheCourseKeys = {
  ve: (item) => item.id ?? item.cId ?? item.courseId ?? item.course_id,
  ykt: (item) => item.classroom_id,
  mrjzy: (item) => item.classNum || item.divClass,
  jlgj: (item) => item.groupId || item.name,
  mooc: (item) => item.tid || item.id,
  xuetangx: (item) => item.id, citel: (item) => item.id
};
const cacheTaskKeys = {
  ve: (item) => item.id ?? item.noteId ?? item.courseNoteId ?? item.upId ?? item.UPID
    ?? item.snId ?? item.noteSnId ?? item.workId ?? item.homeworkId,
  ykt: (item) => [item.__actype, item.courseware_id, item.id].join(':'),
  mrjzy: (item) => item.workId || item.link, jlgj: (item) => item.threadId || item.link,
  mooc: (item) => [item.type, item.id].join(':'), xuetangx: (item) => [item.typeId, item.id || item.chapterLeafId].join(':'),
  citel: (item) => [item.type, item.id].join(':')
};

function invalidateFullscreenCourseCacheCompletion(platform) {
  fullscreenCourseCacheComplete.delete(platform);
  if (platform === 've') window.veCacheCourseSource = null;
}

function markFullscreenCourseCacheComplete(platform) {
  if (window.platformLoginState?.[platform] !== 'online' || !isPlatformEnabled(platform)) return;
  fullscreenCourseCacheComplete.add(platform);
  scheduleFullscreenCourseCacheSave(200);
}

function mergeCachedItems(previous = [], current = [], keyOf, update = (_old, item) => item) {
  const merged = new Map(previous.map((item) => [String(keyOf(item) ?? '') || Symbol(), item]));
  for (const item of current) {
    const key = String(keyOf(item) ?? '');
    if (key && merged.has(key)) merged.set(key, update(merged.get(key), item));
    else if (key) merged.set(key, item);
    else merged.set(Symbol(), item);
  }
  return [...merged.values()];
}

function mergeCachedTask(platform, old, task) {
  const merged = { ...old, ...task };
  const keep = (...fields) => { for (const field of fields) if (old[field] !== undefined) merged[field] = old[field]; };
  if (platform === 'ykt') {
    if (old.exam_detail_state === 'done' && task.exam_detail_state !== 'done') {
      keep('exam_detail_state', 'exam_detail_error', 'detail_problems', 'classroom_report_question_count');
    }
    if (task.video_progress_ratio == null) keep('video_progress_ratio', 'video_total_done', 'video_progress_loading');
  } else if (platform === 'jlgj' && (task.loadingMeta || task.detailUnavailable)) {
    keep('content', 'start', 'end', 'loadingMeta');
  } else if (platform === 'mrjzy' && task.details == null) {
    keep('details', 'loadingMeta');
  } else if (platform === 'mooc' && task.detail == null) {
    keep('detail');
  } else if (platform === 'xuetangx' && (task.exerciseDetailError || !task.exerciseProblems)) {
    if (old.exerciseProblems) keep('exerciseProblems', 'exerciseDetailError', 'exerciseDetailLoading', 'done');
  } else if (platform === 'citel' && task.actionable && !task.statusKnown && old.statusKnown) {
    keep('done', 'statusKnown', 'description', 'descriptionHtml', 'loadError');
  }
  return merged;
}

function mergeFullscreenCourseCache(previous, current, complete, veSource) {
  const result = { ...previous, ...current };
  const preserve = (fields) => { for (const field of fields) result[field] = previous[field] ?? current[field]; };
  const hasPreviousVe = !!previous.currentAccountLoginName || !!previous.currentVeCourseList?.length;
  const sameVeScope = !hasPreviousVe || (
    previous.currentAccountLoginName === current.currentAccountLoginName
    && (!previous.xqSelectValue || previous.xqSelectValue === current.xqSelectValue));
  const applyVe = veSource && (complete.has('ve') || sameVeScope);
  if (!applyVe) preserve(veCacheFields);
  else {
    const ids = new Set(current.currentVeCourseList.map((course) => String(cacheCourseKeys.ve(course))));
    const freshHomework = Object.fromEntries(Object.entries(current.courseHomeworkData)
      .filter(([id]) => ids.has(id) && veSource.homeworkCourseIds.has(id)));
    result.courseHomeworkData = freshHomework;
    if (!complete.has('ve')) {
      result.currentVeCourseList = mergeCachedItems(previous.currentVeCourseList, current.currentVeCourseList, cacheCourseKeys.ve);
      result.courseHomeworkData = { ...previous.courseHomeworkData };
      for (const [id, course] of Object.entries(freshHomework)) {
        result.courseHomeworkData[id] = { ...course, list: mergeCachedItems(previous.courseHomeworkData?.[id]?.list, course.list,
          cacheTaskKeys.ve, (old, task) => ({ ...old, ...task })) };
      }
    }
    if (sameVeScope) for (const field of veCacheFields.slice(2, -4)) {
      const updates = current[field];
      result[field] = { ...previous[field], ...updates };
      if (field === 'homeworkNoteAttachmentCacheByKey') {
        for (const [key, entry] of Object.entries(updates)) {
          if (previous[field]?.[key]?.loaded && (!entry.loaded || entry.failed)) result[field][key] = previous[field][key];
        }
      }
    }
  }
  for (const [platform, [courseField, ...derived]] of Object.entries(cacheCourseFields)) {
    if (platform === 'mrjzy' && Number(previous.mrjzySnapshotUpdatedAt) > current.mrjzySnapshotUpdatedAt) {
      preserve([courseField, ...derived, 'mrjzySnapshotUpdatedAt']);
      continue;
    }
    if (complete.has(platform)) continue;
    const taskField = derived.length ? 'homeworks' : 'tasks';
    if (!current[courseField].length) {
      preserve([courseField, ...derived]);
      continue;
    }
    result[courseField] = mergeCachedItems(previous[courseField], current[courseField], cacheCourseKeys[platform], (old, course) => ({
      ...old, ...course, detailLoaded: course.detailLoaded || old.detailLoaded,
      [taskField]: mergeCachedItems(old[taskField], course[taskField], cacheTaskKeys[platform], (prior, task) => mergeCachedTask(platform, prior, task))
    }));
  }
  for (const platform of ['ve', ...Object.keys(cacheCourseFields)]) {
    if (complete.has(platform)) continue;
    const data = result[platform === 've' ? 'currentVeCourseList' : cacheCourseFields[platform][0]];
    if (data?.length || previous.platformLoadedOnce?.[platform]) result.platformLoadedOnce[platform] = true;
  }
  if (!applyVe || !complete.has('ve') || Object.keys(cacheCourseFields).some((platform) => !complete.has(platform))) {
    const labels = window.BjtuHomeworkReminders.labels;
    const key = (item) => JSON.stringify([item.kind, item.platform, item.courseName, item.title, item.url]);
    result.searchIndex = mergeCachedItems((previous.searchIndex || []).filter((item) => {
      const platform = Object.keys(labels).find((id) => labels[id] === item.platform) || item.platform;
      return !complete.has(platform);
    }), (current.searchIndex || []).filter(item => applyVe || !['ve', labels.ve].includes(item.platform)), key);
  }
  return result;
}

function saveFullscreenCourseCache({ force = false } = {}) {
  if (popupMode || (!force && !shouldSaveFullscreenCourseCache()) || !courseListDiv) return Promise.resolve();
  fullscreenCourseCacheSaveRequested = true;
  fullscreenCourseCacheForceRequested ||= force;
  if (!fullscreenCourseCacheSavePromise) {
    fullscreenCourseCacheSavePromise = (async () => {
      // Save only the newest state after an outstanding write. Never enqueue copies
      // of every platform's full homework data behind a slow storage/reminder lock.
      try {
        while (fullscreenCourseCacheSaveRequested) {
          const nextForce = fullscreenCourseCacheForceRequested;
          fullscreenCourseCacheSaveRequested = false;
          fullscreenCourseCacheForceRequested = false;
          await writeFullscreenCourseCache({ force: nextForce });
        }
      } finally {
        fullscreenCourseCacheSavePromise = null;
      }
    })();
  }
  return fullscreenCourseCacheSavePromise;
}

function collectFullscreenCourseCache() {
  return {
    version: 1,
    structuredCourseCache: true,
    savedAt: Date.now(),
    searchIndex: collectOmniboxSearchIndex(),
    platformEnabled: safeStorageClone(window.platformEnabled, {}),
    platformLoginState: safeStorageClone(window.platformLoginState, {}),
    platformLoginChecked: safeStorageClone(window.platformLoginChecked, {}),
    platformLoadedOnce: safeStorageClone(window.platformLoadedOnce, {}),
    platformNeedLogin: safeStorageClone(window.platformNeedLogin, {}),
    currentVeCourseList: safeStorageClone(window.currentVeCourseList, []),
    courseHomeworkData: getCollapsedCourseHomeworkDataForPopup(),
    yktMatchedHomeworkByCourseId: safeStorageClone(window.yktMatchedHomeworkByCourseId, {}),
    yktMatchedCourseLinkByCourseId: safeStorageClone(window.yktMatchedCourseLinkByCourseId, {}),
    yktStandaloneCourses: safeStorageClone(window.yktStandaloneCourses, []),
    yktCourseGroupsSnapshot: safeStorageClone(window.yktCourseGroupsSnapshot, []),
    mrjzyMatchedHomeworkByCourseId: safeStorageClone(window.mrjzyMatchedHomeworkByCourseId, {}),
    mrjzyStandaloneCourses: safeStorageClone(window.mrjzyStandaloneCourses, []),
    mrjzyCourseGroupsSnapshot: safeStorageClone(window.mrjzyCourseGroupsSnapshot, []),
    mrjzySnapshotUpdatedAt: Number(window.mrjzySnapshotUpdatedAt || 0),
    jlgjMatchedHomeworkByCourseId: safeStorageClone(window.jlgjMatchedHomeworkByCourseId, {}),
    jlgjStandaloneCourses: safeStorageClone(window.jlgjStandaloneCourses, []),
    jlgjCourseGroupsSnapshot: safeStorageClone(window.jlgjCourseGroupsSnapshot, []),
    moocCourses: safeStorageClone(window.BjtuMoocPlatform?.getCourses?.(), []),
    xuetangxCourses: safeStorageClone(window.BjtuXuetangxPlatform?.getCourses?.(), []),
    citelCourses: safeStorageClone(window.BjtuCitelPlatform?.getCourses?.(), []),
    courseCardStateById: safeStorageClone(window.courseCardStateById, {}),
    videoReplayCacheByCourseId: safeStorageClone(window.videoReplayCacheByCourseId, {}),
    coursewareCacheByCourseId: safeStorageClone(window.coursewareCacheByCourseId, {}),
    homeworkScoreCacheByKey: safeStorageClone(window.homeworkScoreCacheByKey, {}),
    homeworkNoteAttachmentCacheByKey: safeStorageClone(window.homeworkNoteAttachmentCacheByKey, {}),
    veTeacherMetaByCourseId: safeStorageClone(window.veTeacherMetaByCourseId, {}),
    veCourseTeachersMetaByCourseId: safeStorageClone(window.veCourseTeachersMetaByCourseId, {}),
    resourceSpaceItems: [],
    currentAccountLoginName: String(window.currentAccountLoginName || ''),
    isTeacherAccount: !!window.isTeacherAccount,
    courseListHtml: '',
    resourceSpaceHtml: '',
    resourceSpaceStatusText: String(resourceSpaceStatus?.textContent || ''),
    resourceSpaceCountText: String(resourceSpaceCount?.textContent || ''),
    xqSelectHtml: String(xqSelect?.innerHTML || ''),
    xqSelectValue: String(xqSelect?.value || '')
  };
}

async function writeFullscreenCourseCache({ force = false } = {}) {
  if (popupMode || (!force && !shouldSaveFullscreenCourseCache()) || !courseListDiv) return;
  try {
    await window.BjtuHomeworkReminders.update(async () => {
      const key = POPUP_FULLSCREEN_CACHE_KEY;
      const previous = (await chrome.storage.local.get(key))[key] || {};
      const veSource = window.veCacheCourseSource;
      const account = String(window.currentAccountLoginName || '');
      const hasAccount = !account || !window.BjtuAccountStore || !!await window.BjtuAccountStore.get(account);
      const currentVeSource = hasAccount && veSource === window.veCacheCourseSource
        && account === String(window.currentAccountLoginName || '') && veSource?.account === account && veSource;
      const complete = new Set(fullscreenCourseCacheComplete);
      if (!currentVeSource) complete.delete('ve');
      const cache = collectFullscreenCourseCache();
      if (!hasAccount) {
        cache.currentAccountLoginName = '';
        cache.currentVeCourseList = [];
        for (const field of veCacheFields.slice(1, -4)) cache[field] = {};
        cache.platformLoadedOnce.ve = false;
      }
      const merged = mergeFullscreenCourseCache(previous, cache, complete, currentVeSource);
      await chrome.storage.local.set({ [key]: merged });
    });
  } catch (e) {
    try { console.warn('[bjtu] save popup cache failed:', e); } catch {}
  }
}

function detectReminderPlatform(item, courseCard) {
  if (item.classList.contains('xuetangx-task') || String(courseCard?.id || '').startsWith('course-xuetangx-')) return '学堂在线';
  if (item.classList.contains('citel-task') || String(courseCard?.id || '').startsWith('course-citel-')) return 'CITEL';
  if (item.classList.contains('mooc-task') || String(courseCard?.id || '').startsWith('course-mooc-')) return '中国大学MOOC';
  const hrefs = Array.from(item.querySelectorAll('a[href]')).map((link) => String(link.href || '')).join(' ');
  if (/yuketang\.cn|examination\.xuetangx\.com/i.test(hrefs)) return '雨课堂';
  if (/xuetangx\.com/i.test(hrefs)) return '学堂在线';
  if (/lulufind\.com|mrzuoye\.com/i.test(hrefs)) return '每日交作业';
  if (/jielong\.com/i.test(hrefs)) return '接龙管家';
  return '智慧课程平台';
}

function collectPendingHomeworkItems({ futureDeadlineOnly = false } = {}) {
  if (!courseListDiv) return [];
  const now = Date.now();
  const seen = new Set();
  const items = [];
  courseListDiv.querySelectorAll('.hw-card-item').forEach((homework) => {
    if (homework.matches('.citel-task[data-citel-status="unknown"], .citel-task[data-citel-status="resource"]')) return;
    const countdown = homework.querySelector('.deadline-countdown[data-deadline]');
    const deadline = countdown
      ? (typeof parseDeadlineToTs === 'function'
        ? parseDeadlineToTs(countdown.dataset.deadline)
        : Number(countdown.dataset.deadline || 0))
      : 0;
    if (futureDeadlineOnly && (!deadline || deadline <= now)) return;
    const courseCard = homework.closest('.file-item');
    if (!(homework instanceof HTMLElement) || !(courseCard instanceof HTMLElement)) return;
    if (homework.dataset.homeworkDone === '1') return;
    const courseName = String(courseCard.querySelector('.course-card-title')?.textContent || '未知课程').replace(/\s+/g, ' ').trim();
    const titleElement = homework.querySelector('.homework-card-title, .mooc-task-title, .xuetangx-task-title')
      || Array.from(homework.querySelectorAll('div')).find((node) => node instanceof HTMLElement && node.style.fontWeight === 'bold');
    const title = String(titleElement?.dataset.homeworkTitle || titleElement?.textContent || '未交作业').replace(/\s+/g, ' ').trim();
    const platform = detectReminderPlatform(homework, courseCard);
    const actionUrl = String(homework.querySelector('a.btn[href]')?.href || courseCard.querySelector('.course-card-title a[href]')?.href || '');
    const key = `${courseName}|${title}|${deadline}`;
    const identity = `${platform}|${key}`;
    if (seen.has(identity)) return;
    seen.add(identity);
    const detail = Array.from(homework.querySelectorAll('.expandable-body')).map((body) => window.BjtuHomeworkReminders.plainText(body.innerHTML)).filter(Boolean).join('\n');
    items.push({ key, platform, courseName, title, deadline, actionUrl, detail });
  });
  return items;
}

function collectHomeworkReminderSnapshot() {
  return collectPendingHomeworkItems({ futureDeadlineOnly: true });
}

let homeworkReminderSnapshotTimer = null;

async function saveHomeworkReminderSnapshotNow() {
  const reminders = window.BjtuHomeworkReminders;
  return reminders.update(async ({ snapshot }) => {
    // Read the latest DOM only after acquiring the lock, not before waiting for it.
    const now = Date.now();
    const account = String(window.currentAccountLoginName || '').trim();
    const currentItems = collectHomeworkReminderSnapshot();
    for (const [platform, label] of Object.entries(reminders.labels)) {
      const loaded = window.platformLoadedOnce?.[platform] === true;
      if (window.platformLoginState?.[platform] !== 'online' || !loaded) continue;
      if (platform === 've' && (!account || !await window.BjtuAccountStore.get(account))) continue;
      reminders.replaceSnapshot(snapshot, platform, account, currentItems.filter((item) => item.platform === label), now);
    }
    return snapshot;
  });
}

async function notifyForegroundNewHomework() {
  const now = Date.now();
  const account = String(window.currentAccountLoginName || '').trim();
  const items = collectPendingHomeworkItems().filter((item) => (!item.deadline || item.deadline > now)
    && !(item.platform === '雨课堂' && /\/student-lesson-report\//.test(item.actionUrl)));
  for (const course of window.yktCourseGroupsSnapshot || []) {
    for (const homework of course.homeworks || []) {
      if (Number(homework.__actype) !== 14 || homework.exam_detail_state !== 'done' || !Number.isInteger(homework.classroom_report_question_count)) continue;
      items.push({ monitorOnly: true, classroomReportKey: `${course.classroom_id}|${homework.courseware_id}`,
        classroomReportQuestionCount: homework.classroom_report_question_count, platform: '雨课堂',
        courseName: course.course_name || course.name || '', title: homework.title || '课堂', actionUrl: homework.link });
    }
  }
  for (const [platform, label] of Object.entries(window.BjtuHomeworkReminders.labels)) {
    if (!isPlatformEnabled(platform) || !getEnabledPlatformLoginResult(platform).ready) continue;
    if (platform === 've' && !account) continue;
    await chrome.runtime.sendMessage({ type: 'HOMEWORK_FOREGROUND_DISCOVERED',
      payload: { platform, account: platform === 've' ? account : '', assignments: items.filter((item) => item.platform === label) } });
  }
}

let foregroundHomeworkRefreshTimer = null;
let foregroundHomeworkRefreshGeneration = 0;
async function scheduleForegroundHomeworkRefresh() {
  const generation = ++foregroundHomeworkRefreshGeneration;
  clearTimeout(foregroundHomeworkRefreshTimer);
  const settings = await chrome.storage.local.get([
    'homeworkForegroundNewAssignmentNotificationEnabled', 'homeworkBackgroundRefreshIntervalMinutes'
  ]);
  if (generation !== foregroundHomeworkRefreshGeneration
      || settings.homeworkForegroundNewAssignmentNotificationEnabled !== true) return;
  const minutes = Math.max(1, Number(settings.homeworkBackgroundRefreshIntervalMinutes) || 30);
  foregroundHomeworkRefreshTimer = setTimeout(async () => {
    try {
      await navigator.locks.request('bjtu-homework-foreground-refresh', { ifAvailable: true }, async (lock) => {
        if (!lock) return;
        const current = await chrome.storage.local.get([
          'homeworkForegroundNewAssignmentNotificationEnabled', 'homeworkBackgroundRefreshPlatforms'
        ]);
        if (current.homeworkForegroundNewAssignmentNotificationEnabled !== true) return;
        for (const platform of current.homeworkBackgroundRefreshPlatforms || []) {
          if (!isPlatformEnabled(platform) || !getEnabledPlatformLoginResult(platform).ready) continue;
          try {
            if (platform === 've') await loadCourses();
            else await triggerExternalPlatformLoad(platform, true);
          } catch (error) {
            console.warn(`[bjtu] foreground ${platform} homework refresh failed:`, error);
          }
        }
        scheduleHomeworkReminderSnapshotSave();
      });
    } catch (error) {
      console.warn('[bjtu] foreground homework refresh failed:', error);
    } finally {
      if (generation === foregroundHomeworkRefreshGeneration) void scheduleForegroundHomeworkRefresh();
    }
  }, minutes * 60000);
}
chrome.storage.onChanged.addListener((changes, area) => {
  const cached = changes[POPUP_FULLSCREEN_CACHE_KEY]?.newValue;
  if (area === 'local' && cached?.mrjzySnapshotUpdatedAt
      && (!popupMode || window.__popupUsingFullscreenCache)) {
    void Promise.resolve(window.__bjtuPlatformModulesReady).then(() => {
      window.applyMrjzyCachedSnapshot?.(cached);
    }).catch((error) => console.warn('[bjtu] synchronize MRJZY homework failed:', error));
  }
  if (area === 'local' && (changes.homeworkForegroundNewAssignmentNotificationEnabled
      || changes.homeworkBackgroundRefreshIntervalMinutes || changes.homeworkBackgroundRefreshPlatforms)) {
    void scheduleForegroundHomeworkRefresh();
  }
});
void scheduleForegroundHomeworkRefresh();

function scheduleHomeworkReminderSnapshotSave(delayMs = 500) {
  if (homeworkReminderSnapshotTimer) clearTimeout(homeworkReminderSnapshotTimer);
  homeworkReminderSnapshotTimer = setTimeout(async () => {
    homeworkReminderSnapshotTimer = null;
    try {
      if (!popupMode) await saveHomeworkReminderSnapshotNow();
      await notifyForegroundNewHomework();
    } catch (error) {
      try { console.warn('[bjtu] save homework reminder snapshot failed:', error); } catch {}
    }
  }, Math.max(100, Number(delayMs) || 500));
}

let popupCourseCacheSaveTimer = null;
function scheduleFullscreenCourseCacheSave(delayMs = 900) {
  scheduleHomeworkReminderSnapshotSave(Math.min(500, Number(delayMs) || 500));
  if (popupMode || !shouldSaveFullscreenCourseCache()) return;
  if (popupCourseCacheSaveTimer) clearTimeout(popupCourseCacheSaveTimer);
  popupCourseCacheSaveTimer = setTimeout(() => {
    popupCourseCacheSaveTimer = null;
    saveFullscreenCourseCache().catch(() => {});
  }, Math.max(120, Number(delayMs) || 900));
}

function setupFullscreenCourseCacheObserver() {
  if (popupMode || !courseListDiv) return;
  try {
    const visualOnly = '.deadline-countdown, .deadline-countdown-prefix, .homework-toggle-label, .homework-group--done, .homework-group--overdue';
    const ignored = (node) => (node instanceof Element ? node : node?.parentElement)?.closest(visualOnly);
    const mo = new MutationObserver((mutations) => {
      const relevant = mutations.some((mutation) => {
        if (ignored(mutation.target)) return false;
        if (mutation.type !== 'childList') return true;
        return [...mutation.addedNodes, ...mutation.removedNodes].some((node) => !ignored(node));
      });
      if (relevant) scheduleFullscreenCourseCacheSave();
    });
    // The cache is structured and restores groups collapsed. Animation classes,
    // scrolling and opening/closing these groups do not change cached data.
    const options = { childList:true, subtree:true, characterData:true,
      attributeFilter:['href','data-homework-done','data-homework-deadline','data-homework-overdue','data-homework-title'] };
    mo.observe(courseListDiv,options);
    if (resourceSpaceList) mo.observe(resourceSpaceList,options);
  } catch {
    // ignore
  }
}

function restorePopupPlatformStates(cache) {
  window.platformLoginState = { ...window.platformLoginState, ...(cache?.platformLoginState || {}) };
  window.platformLoginChecked = { ...window.platformLoginChecked, ...(cache?.platformLoginChecked || {}) };
  window.platformLoadedOnce = { ...window.platformLoadedOnce, ...(cache?.platformLoadedOnce || {}) };
  window.platformNeedLogin = { ...window.platformNeedLogin, ...(cache?.platformNeedLogin || {}) };
  PLATFORM_IDS.forEach((id) => {
    if (window.platformLoadedOnce?.[id] === true && window.platformLoginState?.[id] === 'checking') {
      window.platformLoginState[id] = 'online';
    }
  });
}

async function restorePopupFullscreenCacheIfNeeded() {
  if (!popupMode || !useFullscreenCacheForCurrentCompactView()) return false;
  window.__popupUsingFullscreenCache = true;
  showPopupCacheLoadingFrame();
  await waitForPopupCachePaint();
  let cache = null;
  try {
    const data = await chrome.storage.local.get([POPUP_FULLSCREEN_CACHE_KEY]);
    cache = data[POPUP_FULLSCREEN_CACHE_KEY] || null;
  } catch {
    cache = null;
  }
  const veModuleAvailable = globalThis.BjtuModuleRegistry?.has('ve') === true;
  const hasStructuredVeData = (cache?.backgroundStructuredVe === true || cache?.structuredCourseCache === true)
    && Array.isArray(cache?.currentVeCourseList);
  const hasStructuredExternalData = [
    cache?.yktCourseGroupsSnapshot,
    cache?.yktStandaloneCourses,
    cache?.mrjzyCourseGroupsSnapshot,
    cache?.mrjzyStandaloneCourses,
    cache?.jlgjCourseGroupsSnapshot,
    cache?.jlgjStandaloneCourses,
    cache?.moocCourses,
    cache?.xuetangxCourses,
    cache?.citelCourses
  ].some((list) => Array.isArray(list) && list.length > 0);
  const canRenderStructuredVeCache = veModuleAvailable
    && hasStructuredVeData
    && typeof renderCourseList === 'function';
  if (!cache || (!canRenderStructuredVeCache
      && !hasStructuredExternalData
      && !String(cache.courseListHtml || '').trim())) {
    // Selection comes from current local settings, never from a content cache.
    restorePopupPlatformStates(cache);
    refreshPlatformLoginTip();
    showPopupCacheNotice(cache);
    if (courseListDiv) {
      courseListDiv.innerHTML = '<div style="color:#666;padding:6px 0;">暂无全屏缓存内容，请全屏打开后加载一次。</div>';
    }
    if (resourceSpaceStatus) setResourceSpaceStatus(`${compactCacheViewLabel()}使用缓存；暂无资源空间缓存`, 'warning');
    return true;
  }

  // Keep the current selection even when this content snapshot is older.
  restorePopupPlatformStates(cache);
  window.currentVeCourseList = veModuleAvailable && Array.isArray(cache.currentVeCourseList)
    ? cache.currentVeCourseList
    : [];
  window.courseHomeworkData = cache.courseHomeworkData || {};
  Object.values(window.courseHomeworkData).forEach((data) => {
    if (!data) return;
    data.showOverdue = false;
    data.showDone = false;
    data.justExpanded = false;
    data.justCollapsed = false;
  });
  window.courseShowOverdueById = {};
  window.courseShowDoneById = {};
  window.homeworkDetailExpandedByCourse = {};
  window.yktMatchedHomeworkByCourseId = cache.yktMatchedHomeworkByCourseId || {};
  window.yktMatchedCourseLinkByCourseId = cache.yktMatchedCourseLinkByCourseId || {};
  window.yktStandaloneCourses = Array.isArray(cache.yktStandaloneCourses) ? cache.yktStandaloneCourses : [];
  window.yktCourseGroupsSnapshot = Array.isArray(cache.yktCourseGroupsSnapshot) ? cache.yktCourseGroupsSnapshot : [];
  window.mrjzyMatchedHomeworkByCourseId = cache.mrjzyMatchedHomeworkByCourseId || {};
  window.mrjzyStandaloneCourses = Array.isArray(cache.mrjzyStandaloneCourses) ? cache.mrjzyStandaloneCourses : [];
  window.mrjzyCourseGroupsSnapshot = Array.isArray(cache.mrjzyCourseGroupsSnapshot) ? cache.mrjzyCourseGroupsSnapshot : [];
  window.mrjzySnapshotUpdatedAt = Number(cache.mrjzySnapshotUpdatedAt || 0);
  window.jlgjMatchedHomeworkByCourseId = cache.jlgjMatchedHomeworkByCourseId || {};
  window.jlgjStandaloneCourses = Array.isArray(cache.jlgjStandaloneCourses) ? cache.jlgjStandaloneCourses : [];
  window.jlgjCourseGroupsSnapshot = Array.isArray(cache.jlgjCourseGroupsSnapshot) ? cache.jlgjCourseGroupsSnapshot : [];
  window.BjtuMoocPlatform?.restore(cache.moocCourses || []);
  window.BjtuXuetangxPlatform?.restore(cache.xuetangxCourses || []);
  window.BjtuCitelPlatform?.restore(cache.citelCourses || []);
  window.courseCardStateById = cache.courseCardStateById || {};
  window.videoReplayCacheByCourseId = cache.videoReplayCacheByCourseId || {};
  window.coursewareCacheByCourseId = cache.coursewareCacheByCourseId || {};
  window.homeworkScoreCacheByKey = cache.homeworkScoreCacheByKey || {};
  window.homeworkNoteAttachmentCacheByKey = cache.homeworkNoteAttachmentCacheByKey || {};
  window.veTeacherMetaByCourseId = cache.veTeacherMetaByCourseId || {};
  window.veCourseTeachersMetaByCourseId = cache.veCourseTeachersMetaByCourseId || {};
  window.resourceSpaceItems = Array.isArray(cache.resourceSpaceItems) ? cache.resourceSpaceItems : [];
  window.currentAccountLoginName = String(cache.currentAccountLoginName || '');
  window.isTeacherAccount = !!cache.isTeacherAccount;
  normalizeRestoredCachesForPopup();
  if ((canRenderStructuredVeCache || hasStructuredExternalData)
      && typeof rematchExternalByVeCourses === 'function') {
    rematchExternalByVeCourses();
  }

  if (courseListDiv) {
    await renderPopupCachedCoursesProgressively({
      canRenderStructuredVeCache,
      hasStructuredExternalData,
      cache
    });
    unwrapPlatformCourseColumnsForPopup(courseListDiv);
    collapseRestoredCoursePanelsForPopup(courseListDiv);
  }
  if (resourceSpaceList) resourceSpaceList.innerHTML = String(cache.resourceSpaceHtml || '');
  if (resourceSpaceStatus) setResourceSpaceStatus(cache.resourceSpaceStatusText || `${compactCacheViewLabel()}使用缓存`, 'warning');
  if (resourceSpaceCount && cache.resourceSpaceCountText) resourceSpaceCount.textContent = String(cache.resourceSpaceCountText);
  if (xqSelect && cache.xqSelectHtml) {
    xqSelect.innerHTML = String(cache.xqSelectHtml || '');
    xqSelect.value = String(cache.xqSelectValue || '');
  }
  refreshPlatformLoginTip();
  applyPlatformVisibility();
  showPopupCacheNotice(cache);
  return true;
}
