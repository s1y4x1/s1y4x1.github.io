// Shared QR utilities for login, resource, and download links.

const QR_MIN_DISPLAY_SIZE = 90;
const QR_MIN_MODULE_SIZE = 2;
const QR_QUIET_ZONE_MODULES = 4;

function convertVisitNameToUrl(visitName) {
  const raw = String(visitName || '').trim();
  if (!raw) return '';
  let path = raw.replace(/^W:\\Root\\?/i, '');
  path = path.replace(/\\/g, '/');
  if (!path.startsWith('/')) path = '/' + path;
  if (path.startsWith('/rp/')) return `${FILE_BASE || 'http://123.121.147.7:8081'}${path}`.replace(/([^:]\/\/+)\/\/+?/g, '$1/');
  return `${BASE}${path}`.replace(/([^:]\/\/+)\/\/+?/g, '$1/');
}

function buildQrImageData(content, size = QR_MIN_DISPLAY_SIZE) {
  const text = String(content || '').trim();
  if (!text) return '';
  const safeSize = Math.max(QR_MIN_DISPLAY_SIZE, Number(size) || QR_MIN_DISPLAY_SIZE);
  if (typeof qrcode !== 'function') {
    throw new Error('本地二维码库未加载');
  }

  const qr = qrcode(0, 'M');
  qr.addData(text);
  qr.make();

  const moduleCount = Number(qr.getModuleCount() || 0);
  if (!moduleCount) {
    throw new Error('二维码数据无效');
  }

  const contentSize = Math.max(safeSize, moduleCount * QR_MIN_MODULE_SIZE);
  const pixelPerModule = contentSize / moduleCount;
  const quietZoneSize = QR_QUIET_ZONE_MODULES * QR_MIN_MODULE_SIZE;
  const displaySize = contentSize + quietZoneSize * 2;
  const pathParts = [];
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount; col += 1) {
      if (!qr.isDark(row, col)) continue;
      pathParts.push(`M${col} ${row}h1v1h-1z`);
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${displaySize} ${displaySize}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/><path d="${pathParts.join('')}" transform="translate(${quietZoneSize} ${quietZoneSize}) scale(${pixelPerModule})" fill="black"/></svg>`;

  return {
    url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`,
    moduleCount,
    pixelPerModule,
    contentSize,
    quietZoneSize,
    displaySize
  };
}

function buildQrImageUrl(content, size = QR_MIN_DISPLAY_SIZE) {
  return buildQrImageData(content, size).url;
}

function applyQrImageToElement(image, content, size = QR_MIN_DISPLAY_SIZE, resizeRelativeParent = false) {
  if (!(image instanceof HTMLImageElement)) throw new Error('二维码图片元素无效');
  const qrImage = buildQrImageData(content, size);
  image.src = qrImage.url;
  image.style.width = `${qrImage.displaySize}px`;
  image.style.height = `${qrImage.displaySize}px`;
  if (resizeRelativeParent) {
    const parent = image.parentElement;
    if (parent instanceof HTMLElement && getComputedStyle(parent).position === 'relative') {
      parent.style.width = `${qrImage.displaySize}px`;
      parent.style.height = `${qrImage.displaySize}px`;
    }
  }
  return qrImage;
}

function createQrDismissButton(settingKey) {
  const button = document.createElement('button');
  button.type = 'button'; button.className = 'qr-dismiss-btn'; button.textContent = '不再显示';
  button.style.cssText = 'background:#dc2626;color:#fff;border:0;border-radius:4px;padding:3px 8px;min-height:0;width:auto;font-size:var(--bjtu-font-size-body,13px);line-height:1.4;cursor:pointer;';
  button.addEventListener('click', () => chrome.storage.local.set({[settingKey]:false}));
  return button;
}

(async function initDownloadQRTooltips() {
  window.__linkQrEnabled = true;
  try {
    const { linkQrEnabled } = await chrome.storage.local.get(['linkQrEnabled']);
    window.__linkQrEnabled = linkQrEnabled !== false;
  } catch {
    // Use the default when storage cannot be read.
  }
  if (typeof qrcode !== 'function') return;

  const TOOLTIP_ID = '__bjtu_qr_tooltip__';
  let tooltip = document.getElementById(TOOLTIP_ID);
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = TOOLTIP_ID;
    tooltip.style.cssText = 'position:fixed;z-index:99999;padding:8px;background:#fff;color:#172033;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,0.15);display:none;flex-direction:column;align-items:center;gap:8px;max-width:calc(100vw - 24px);max-height:calc(100vh - 24px);overflow:auto;';
    document.body.appendChild(tooltip);
  }
  const codes = document.createElement('div');
  codes.style.cssText = 'display:flex;flex-wrap:wrap;justify-content:center;gap:8px;';
  const dismiss = createQrDismissButton('linkQrEnabled');
  tooltip.replaceChildren(codes,dismiss);
  let hideTimer = null;
  let activeLink = null;

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.linkQrEnabled) return;
      window.__linkQrEnabled = changes.linkQrEnabled.newValue === undefined
        ? true
        : !!changes.linkQrEnabled.newValue;
      if (!window.__linkQrEnabled) tooltip.style.display = 'none';
    });
  } catch {
    // ignore
  }

  const getQrUrl = (link) => {
    const explicit = link?.dataset?.qrUrl;
    if (explicit) return String(explicit || '').trim();
    return String(link?.href || '').trim();
  };

  const maybeShow = (link) => {
    if (!window.__linkQrEnabled) return;
    const url = getQrUrl(link);
    if (!url || url === '#' || /^javascript:/i.test(url)) return;
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    if (activeLink === link && tooltip.style.display !== 'none') return;
    activeLink = link;
    const rect = link.getBoundingClientRect();

    try {
      codes.replaceChildren();
      const row = link.closest('.file-item');
      const name = link.dataset.filename || row?.querySelector('.resource-name,.saved-upload-name,strong')?.textContent || '';
      const preview = globalThis.BjtuVeFilePreview?.previewUrl(url,name);
      for (const [label,href] of [['原链接',url],...(preview ? [['在线预览',preview]] : [])]) {
        const column = document.createElement('div'), title = document.createElement('a'), image = document.createElement('img');
        column.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:4px;';
        title.textContent = label; title.href = href; title.target = '_blank'; title.rel = 'noopener noreferrer';
        image.alt = `${label}二维码`; image.style.imageRendering = 'pixelated';
        applyQrImageToElement(image, href, 130); column.append(title,image); codes.append(column);
      }
    } catch (e) {
      tooltip.style.display = 'none';
      return;
    }
    tooltip.style.display = 'flex';
    let top = rect.bottom + 8;
    let left = rect.left;
    const tRect = tooltip.getBoundingClientRect();
    if (left + tRect.width > window.innerWidth - 4) left = window.innerWidth - tRect.width - 4;
    if (top + tRect.height > window.innerHeight - 4) top = rect.top - tRect.height - 4;
    if (left < 4) left = 4;
    if (top < 4) top = 4;
    tooltip.style.top = top + 'px';
    tooltip.style.left = left + 'px';
  };
  tooltip.addEventListener('mouseenter', () => { clearTimeout(hideTimer); });
  tooltip.addEventListener('mouseleave', (event) => {
    if (activeLink?.contains(event.relatedTarget)) return;
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { tooltip.style.display = 'none'; activeLink = null; }, 160);
  });

  const maybeHide = (fromLink, toNode) => {
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    if (toNode && (fromLink.contains(toNode) || (tooltip.style.display !== 'none' && tooltip.contains(toNode)))) return;
    hideTimer = setTimeout(() => { tooltip.style.display = 'none'; activeLink = null; }, 160);
  };

  document.addEventListener('mouseover', (e) => {
    if (!window.__linkQrEnabled) return;
    if (!(e.target instanceof Element)) return;
    const link = e.target.closest('a.resource-url, a.url-link, .video-links a, a[href*="batchDownload"], [data-qr-url]');
    if (!link) return;
    if (link.closest('#' + TOOLTIP_ID + ', [data-no-qr]')) return;
    maybeShow(link);
  }, true);

  document.addEventListener('mouseout', (e) => {
    if (!(e.target instanceof Element)) return;
    const link = e.target.closest('a.resource-url, a.url-link, .video-links a, a[href*="batchDownload"], [data-qr-url]');
    if (!link) return;
    maybeHide(link, e.relatedTarget);
  }, true);

  window.addEventListener('scroll', () => { tooltip.style.display = 'none'; }, { passive: true });
  window.addEventListener('resize', () => { tooltip.style.display = 'none'; }, { passive: true });
})();
