(function initBjtuOptionTips(global) {
  'use strict';

  const POPOVER_ID = 'option-tip-popover';
  let popover = null;
  let activeTrigger = null;
  let hideTimer = 0;

  function positionPopover() {
    if (!(activeTrigger instanceof HTMLElement) || !popover || popover.hidden) return;
    const margin = 8;
    const gap = 7;
    const triggerRect = activeTrigger.getBoundingClientRect();
    const popoverRect = popover.getBoundingClientRect();
    const maxLeft = Math.max(margin, window.innerWidth - popoverRect.width - margin);
    const left = Math.min(Math.max(margin, triggerRect.left), maxLeft);
    const below = triggerRect.bottom + gap;
    const above = triggerRect.top - popoverRect.height - gap;
    const top = below + popoverRect.height <= window.innerHeight - margin
      ? below
      : Math.max(margin, above);
    popover.style.left = `${Math.round(left)}px`;
    popover.style.top = `${Math.round(top)}px`;
  }

  function showPopover(trigger) {
    clearTimeout(hideTimer);
    activeTrigger = trigger;
    if (!popover) return;
    if (trigger?._tipHtml) {
      popover.innerHTML = trigger._tipHtml;
      popover.classList.add('is-markdown');
      popover.setAttribute('aria-label', `提示：${trigger.dataset.tip || ''}`);
    } else {
      popover.textContent = String(trigger?.dataset?.tip || '');
      popover.classList.remove('is-markdown');
    }
    popover.hidden = false;
    positionPopover();
  }

  function hidePopover(trigger) {
    if (activeTrigger !== trigger) return;
    activeTrigger = null;
    if (!popover) return;
    popover.hidden = true;
    popover.classList.remove('is-markdown');
  }

  function scheduleHide(trigger) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => hidePopover(trigger), 180);
  }

  function ensurePopover() {
    if (popover) return;
    popover = document.createElement('div');
    popover.id = POPOVER_ID;
    popover.className = 'option-tip-popover';
    popover.setAttribute('role', 'tooltip');
    popover.hidden = true;
    document.body.appendChild(popover);
    popover.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    popover.addEventListener('mouseleave', () => scheduleHide(activeTrigger));
    window.addEventListener('resize', positionPopover);
    window.addEventListener('scroll', positionPopover, true);
  }

  // 将 .tip 文本转换为 ℹ️ 触发器与悬浮气泡；可重复调用，仅处理尚未转换的 .tip。
  function setup() {
    ensurePopover();
    document.querySelectorAll('label[title]').forEach((label) => {
      const text = String(label.getAttribute('title') || '').trim();
      label.removeAttribute('title');
      if (!text || label.nextElementSibling?.matches('.tip')) return;
      const tip = document.createElement('span');
      tip.className = 'tip';
      tip.textContent = text;
      label.after(tip);
    });
    document.querySelectorAll('.tip').forEach((tip) => {
      const text = String(tip.textContent || '').replace(/\s+/g, ' ').trim();
      if (!text) {
        tip.remove();
        return;
      }
      const trigger = document.createElement('span');
      trigger.className = 'option-tip-trigger';
      trigger.textContent = 'ℹ️';
      trigger.dataset.tip = text;
      trigger.tabIndex = 0;
      trigger.setAttribute('role', 'img');
      trigger.setAttribute('aria-label', `提示：${text}`);
      trigger.setAttribute('aria-describedby', POPOVER_ID);
      trigger.addEventListener('mouseenter', () => showPopover(trigger));
      trigger.addEventListener('mouseleave', () => scheduleHide(trigger));
      trigger.addEventListener('focus', () => showPopover(trigger));
      trigger.addEventListener('blur', () => hidePopover(trigger));
      trigger.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
      const explicitTarget = String(tip.dataset.tipTarget || '').trim();
      let target = explicitTarget
        ? document.querySelector(explicitTarget)
        : tip.previousElementSibling;
      if (!explicitTarget && target instanceof HTMLElement && !target.matches('label')) {
        target = target.querySelector(':scope > label:last-of-type') || target;
      }
      if (target instanceof HTMLElement && (
        explicitTarget
        || target.matches('label, .popup-size-editor')
        || target.querySelector(':scope > label, :scope > button')
      )) {
        target.appendChild(trigger);
        target.addEventListener('mouseenter', () => showPopover(trigger));
        target.addEventListener('mouseleave', () => scheduleHide(trigger));
        tip.remove();
      } else {
        tip.replaceWith(trigger);
      }
    });
  }

  function setText(trigger, text) {
    if (!(trigger instanceof HTMLElement)) return;
    trigger._tipHtml = '';
    trigger.dataset.tip = String(text || '');
    trigger.setAttribute('aria-label', `提示：${trigger.dataset.tip}`);
    if (activeTrigger === trigger) showPopover(trigger);
  }

  function setHtml(trigger, html, plainText = '') {
    if (!(trigger instanceof HTMLElement)) return;
    trigger.dataset.tip = String(plainText || '');
    trigger._tipHtml = String(html || '');
    trigger.setAttribute('aria-label', `提示：${trigger.dataset.tip}`);
    if (activeTrigger === trigger) showPopover(trigger);
  }
  function mountTo(container) {
    if (!(container instanceof HTMLElement)) return;
    ensurePopover();
    if (popover.parentElement !== container) container.appendChild(popover);
  }
  global.BjtuOptionTips = {
    setup, setText, setHtml,
    show(trigger) { if (trigger instanceof HTMLElement) showPopover(trigger); },
    hide(trigger) { if (!trigger || activeTrigger === trigger) hidePopover(trigger); },
    mountTo
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setup(), { once: true });
  } else {
    setup();
  }
})(globalThis);
