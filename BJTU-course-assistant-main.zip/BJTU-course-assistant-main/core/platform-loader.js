(function loadBjtuPlatformModules(global) {
  'use strict';
  const scripts = {
    ykt: ['modules/ykt/network.js', 'modules/ykt/platform.js'],
    mrjzy: ['core/md5.js', 'modules/mrjzy/network.js', 'modules/mrjzy/platform.js'],
    jlgj: ['modules/jlgj/network.js', 'modules/jlgj/platform.js'],
    mooc: ['modules/mooc/platform.js'],
    xuetangx: ['modules/xuetangx/platform.js']
  };
  global.__bjtuPlatformModulesReady = (async () => {
    const autoUpdateParam = new URLSearchParams(global.location?.search || '').get('autoUpdate');
    if (autoUpdateParam === '1' || autoUpdateParam === '2') return {};
    const available = await global.BjtuModuleRegistry.ready;
    for (const [id, paths] of Object.entries(scripts)) {
      if (!available[id]) continue;
      const styles = global.BjtuModuleRegistry.definitions[id]?.styles || [];
      for (const path of styles) {
        await global.BjtuModuleRegistry.loadStyle(`modules/${id}/${path}`);
      }
      for (const path of paths) await global.BjtuModuleRegistry.loadScript(path);
    }
    return available;
  })();
})(globalThis);
