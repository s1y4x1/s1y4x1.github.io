(function loadBjtuVeOptionsModule(global) {
  'use strict';

  global.__bjtuVeOptionsReady = (async () => {
    const available = await global.BjtuModuleRegistry.ready;
    if (!available.ve) return false;
    await global.BjtuModuleRegistry.loadScript('modules/ve/address.js');
    await global.BjtuVeAddress.ready;
    const addressOption = document.getElementById('veDecimalAddressEnabled');
    addressOption.checked = global.BjtuVeAddress.enabled;
    addressOption.addEventListener('change', () => chrome.storage.local.set({ veDecimalAddressEnabled: addressOption.checked }));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.veDecimalAddressEnabled) addressOption.checked = changes.veDecimalAddressEnabled.newValue === true;
    });
    await global.BjtuModuleRegistry.loadScript('core/inert-html.js');
    await global.BjtuModuleRegistry.loadScript('modules/ve/account-store.js');
    await global.BjtuModuleRegistry.loadScript('modules/ve/account-login.js');
    return true;
  })().catch((error) => {
    console.warn('[bjtu] VE options module unavailable:', String(error?.message || error));
    if (global.__bjtuAvailableModules) global.__bjtuAvailableModules.ve = false;
    return false;
  });
})(globalThis);
