(function loadBjtuUpdater(global) {
  'use strict';
  global.__bjtuUpdaterReady = (async () => {
    const available = await global.BjtuModuleRegistry.ready;
    if (!available.updater) return false;
    // Permission checks must start independently of the complete update UI.
    await global.BjtuModuleRegistry.loadScript('modules/updater/filesystem.js');
    await global.BjtuModuleRegistry.loadScript('modules/updater/directory-permission.js');
    await global.BjtuModuleRegistry.loadStyle('UI/file-size-emphasis.css');
    await global.BjtuModuleRegistry.loadStyle('UI/markdown.css');
    await global.BjtuModuleRegistry.loadScript('UI/file-size-emphasis.js');
    await global.BjtuModuleRegistry.loadStyle('modules/updater/app.css');
    const markupResponse = await fetch(chrome.runtime.getURL('modules/updater/app.html'), {
      cache: 'no-store'
    });
    if (!markupResponse.ok) throw new Error(`无法加载更新模块界面：HTTP ${markupResponse.status}`);
    const holder = document.createElement('template');
    holder.innerHTML = await markupResponse.text();
    document.body.appendChild(holder.content.cloneNode(true));
    await global.BjtuUpdateFileSystem.ensureFileConcurrencyDefaults();
    await global.BjtuModuleRegistry.loadScript('UI/marked.umd.js');
    await global.BjtuModuleRegistry.loadScript('UI/markdown.js');
    // Optional formula/highlighting components must not delay directory checks.
    void global.BjtuMarkdown.ready?.catch(error => console.warn('[bjtu] optional Markdown components unavailable:',error));
    await global.BjtuModuleRegistry.loadScript('modules/updater/checker.js');
    return true;
  })().catch((error) => {
    console.error('[bjtu] updater module failed to load:', error);
    const permissionButton = document.getElementById('checkUpdateDirectoryPermission');
    if (permissionButton && !permissionButton.dataset.permissionBound) {
      permissionButton.textContent = '目录权限组件加载失败';
      permissionButton.title = String(error?.message || error);
    }
    const versionBtn = typeof document !== 'undefined' ? document.getElementById('version-btn') : null;
    if (versionBtn instanceof HTMLButtonElement) {
      versionBtn.style.display = '';
      versionBtn.className = 'version-btn failure';
      versionBtn.disabled = false;
      versionBtn.textContent = '更新组件加载失败';
    }
    return false;
  });
})(globalThis);
